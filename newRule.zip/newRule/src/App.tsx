import React from "react";
import { Provider } from "react-redux";
import store from "./redux/store";
import RulePage from "./pages/RulePage";
import "bootstrap/dist/css/bootstrap.min.css";

const App: React.FC = () => {
  return (
    <Provider store={store}>
      <RulePage />
    </Provider>
  );
};

export default App;
