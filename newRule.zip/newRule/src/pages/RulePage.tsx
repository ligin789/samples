import React from "react";
import MainLayout from "../components/layout/MainLayout";

const RulePage: React.FC = () => {
  return <MainLayout />;
};

export default RulePage;
