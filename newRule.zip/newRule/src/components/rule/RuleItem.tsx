import React from "react";
import { ListGroup } from "react-bootstrap";
import type { Rule } from "../../redux/types/ruleTypes";

interface RuleItemProps {
  rule: Rule;
  isSelected: boolean;
  onSelect: (rule: Rule) => void;
  onEdit: (rule: Rule) => void;
  onDelete: (rule: Rule) => void;
}

const RuleItem: React.FC<RuleItemProps> = ({
  rule,
  isSelected,
  onSelect,
  onEdit,
  onDelete,
}) => {
  return (
    <ListGroup.Item
      active={isSelected}
      action
      onClick={() => onSelect(rule)}
      className="d-flex justify-content-between align-items-start"
    >
      <div className="me-auto" style={{ minWidth: 0 }}>
        <div className="fw-bold text-truncate">{rule.ruleName}</div>
        <small className="text-truncate d-block" style={{ opacity: 0.75 }}>
          {rule.alertName}
        </small>
      </div>
      <div className="d-flex gap-1 ms-2 flex-shrink-0">
        <button
          className="btn btn-sm btn-outline-primary border-0"
          title="Edit"
          onClick={(e) => {
            e.stopPropagation();
            onEdit(rule);
          }}
        >
          &#9998;
        </button>
        <button
          className="btn btn-sm btn-outline-danger border-0"
          title="Delete"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(rule);
          }}
        >
          &#128465;
        </button>
      </div>
    </ListGroup.Item>
  );
};

export default RuleItem;
