import React from "react";
import { ListGroup } from "react-bootstrap";
import { useSelector } from "react-redux";
import type { RootState } from "../../redux/store";
import type { Rule } from "../../redux/types/ruleTypes";
import RuleItem from "./RuleItem";

interface RuleListProps {
  onSelect: (rule: Rule) => void;
  onEdit: (rule: Rule) => void;
  onDelete: (rule: Rule) => void;
}

const RuleList: React.FC<RuleListProps> = ({ onSelect, onEdit, onDelete }) => {
  const { rules, selectedRule } = useSelector((state: RootState) => state.rule);

  if (rules.length === 0) {
    return <p className="text-muted p-3 small">No rules created yet.</p>;
  }

  return (
    <ListGroup variant="flush" className="overflow-auto flex-grow-1">
      {rules.map((rule) => (
        <RuleItem
          key={rule.id}
          rule={rule}
          isSelected={selectedRule?.id === rule.id}
          onSelect={onSelect}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ))}
    </ListGroup>
  );
};

export default RuleList;
