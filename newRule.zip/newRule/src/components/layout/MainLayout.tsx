import React from "react";
import Sidebar from "./Sidebar";
import EditorPanel from "./EditorPanel";

const MainLayout: React.FC = () => {
  return (
    <div className="d-flex vh-100">
      <div style={{ width: "15%", minWidth: 200 }}>
        <Sidebar />
      </div>
      <div style={{ width: "85%" }}>
        <EditorPanel />
      </div>
    </div>
  );
};

export default MainLayout;
