import React, { useState } from "react";
import { Button } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import type { RootState } from "../../redux/store";
import type { Rule } from "../../redux/types/ruleTypes";
import {
  createRule,
  updateRule,
  deleteRule,
  selectRule,
} from "../../redux/actions/ruleActions";
import RuleList from "../rule/RuleList";
import CreateRuleModal from "../rule/CreateRuleModal";
import EditRuleModal from "../rule/EditRuleModal";
import DeleteConfirmModal from "../rule/DeleteConfirmModal";

const Sidebar: React.FC = () => {
  const dispatch = useDispatch();
  const rules = useSelector((state: RootState) => state.rule.rules);

  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [targetRule, setTargetRule] = useState<Rule | null>(null);

  const handleSelect = (rule: Rule) => {
    (dispatch as any)(selectRule(rule));
  };

  const handleCreate = (ruleId: string, ruleName: string, alertName: string) => {
    const newId = rules.length > 0 ? Math.max(...rules.map((r) => r.id)) + 1 : 1;
    const newRule: Rule = {
      id: newId,
      ruleId,
      ruleName,
      alertName,
      ruleJson: {
        nodes: [
          {
            id: "1",
            type: "inputNode",
            position: { x: 100, y: 200 },
            name: "Request",
          },
          {
            id: "2",
            type: "outputNode",
            position: { x: 600, y: 200 },
            name: "Response",
          },
        ],
        edges: [
          {
            id: "e1-2",
            sourceId: "1",
            targetId: "2",
            type: "edge",
          },
        ],
      },
    };
    (dispatch as any)(createRule(newRule));
    setShowCreate(false);
  };

  const handleEdit = (rule: Rule) => {
    setTargetRule(rule);
    setShowEdit(true);
  };

  const handleUpdate = (rule: Rule) => {
    (dispatch as any)(updateRule(rule));
    setShowEdit(false);
    setTargetRule(null);
  };

  const handleDeleteClick = (rule: Rule) => {
    setTargetRule(rule);
    setShowDelete(true);
  };

  const handleDeleteConfirm = () => {
    if (targetRule) {
      (dispatch as any)(deleteRule(targetRule.id));
    }
    setShowDelete(false);
    setTargetRule(null);
  };

  return (
    <div className="d-flex flex-column h-100 border-end bg-white">
      <div className="p-2 border-bottom">
        <Button
          variant="primary"
          size="sm"
          className="w-100"
          onClick={() => setShowCreate(true)}
        >
          + Create Rule
        </Button>
      </div>
      <RuleList
        onSelect={handleSelect}
        onEdit={handleEdit}
        onDelete={handleDeleteClick}
      />
      <CreateRuleModal
        show={showCreate}
        onClose={() => setShowCreate(false)}
        onCreate={handleCreate}
      />
      <EditRuleModal
        show={showEdit}
        rule={targetRule}
        onClose={() => {
          setShowEdit(false);
          setTargetRule(null);
        }}
        onUpdate={handleUpdate}
      />
      <DeleteConfirmModal
        show={showDelete}
        onClose={() => {
          setShowDelete(false);
          setTargetRule(null);
        }}
        onDelete={handleDeleteConfirm}
      />
    </div>
  );
};

export default Sidebar;
