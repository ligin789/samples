import React, { useRef, useState, useCallback, useEffect } from "react";
import { Button } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import { DecisionGraph, JdmConfigProvider } from "@gorules/jdm-editor";
import "@gorules/jdm-editor/dist/style.css";
import type { RootState } from "../../redux/store";
import { saveRuleJson } from "../../redux/actions/ruleActions";
import type { DecisionGraphRef } from "@gorules/jdm-editor";
import RunRuleModal from "../rule/RunRuleModal";

const EditorPanel: React.FC = () => {
  const dispatch = useDispatch();
  const selectedRule = useSelector((state: RootState) => state.rule.selectedRule);
  const graphRef = useRef<DecisionGraphRef>(null);
  const [graphValue, setGraphValue] = useState<{ nodes: any[]; edges: any[] }>({
    nodes: [],
    edges: [],
  });
  const [showRunModal, setShowRunModal] = useState(false);

  useEffect(() => {
    if (selectedRule) {
      const json = selectedRule.ruleJson as { nodes?: any[]; edges?: any[] };
      setGraphValue({
        nodes: json.nodes || [],
        edges: json.edges || [],
      });
    } else {
      setGraphValue({ nodes: [], edges: [] });
    }
  }, [selectedRule]);

  const handleChange = useCallback((val: { nodes: any[]; edges: any[] }) => {
    setGraphValue(val);
  }, []);

  const handleSave = () => {
    if (!selectedRule) return;
    (dispatch as any)(saveRuleJson(selectedRule.id, graphValue));
  };

  if (!selectedRule) {
    return (
      <div className="d-flex align-items-center justify-content-center h-100 text-muted">
        <h5>Select a rule from the sidebar to open the editor</h5>
      </div>
    );
  }

  return (
    <div className="d-flex flex-column h-100">
      <div className="d-flex align-items-center gap-2 p-2 border-bottom bg-light">
        <strong className="me-auto">{selectedRule.ruleName}</strong>
        <Button variant="success" size="sm" onClick={handleSave}>
          Save
        </Button>
        <Button variant="primary" size="sm" onClick={() => setShowRunModal(true)}>
          Run
        </Button>
      </div>
      <div className="flex-grow-1" style={{ position: "relative" }}>
        <JdmConfigProvider>
          <DecisionGraph
            ref={graphRef}
            value={graphValue}
            onChange={handleChange}
          />
        </JdmConfigProvider>
      </div>
      <RunRuleModal show={showRunModal} onClose={() => setShowRunModal(false)} />
    </div>
  );
};

export default EditorPanel;
