import { configureStore } from "@reduxjs/toolkit";
import ruleReducer from "../reducers/ruleReducer";

const store = configureStore({
  reducer: {
    rule: ruleReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
