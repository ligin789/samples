import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { RuleState, Rule } from "../types/ruleTypes";
import mockRules from "../../data/mockRules.json";

const STORAGE_KEY = "rule_management_state";

function loadFromStorage(): RuleState | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch {
    // ignore parse errors
  }
  return null;
}

function saveToStorage(state: RuleState) {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ ...state, selectedRule: null })
    );
  } catch {
    // ignore quota errors
  }
}

const defaultState: RuleState = {
  rules: mockRules as Rule[],
  selectedRule: null,
  loading: false,
  error: null,
};

const initialState: RuleState = loadFromStorage() ?? defaultState;

const ruleSlice = createSlice({
  name: "rule",
  initialState,
  reducers: {
    createRule(state, action: PayloadAction<Rule>) {
      state.rules.push(action.payload);
      saveToStorage(state);
    },
    updateRule(state, action: PayloadAction<Rule>) {
      const idx = state.rules.findIndex((r) => r.id === action.payload.id);
      if (idx !== -1) state.rules[idx] = action.payload;
      if (state.selectedRule?.id === action.payload.id) {
        state.selectedRule = action.payload;
      }
      saveToStorage(state);
    },
    deleteRule(state, action: PayloadAction<number>) {
      state.rules = state.rules.filter((r) => r.id !== action.payload);
      if (state.selectedRule?.id === action.payload) {
        state.selectedRule = null;
      }
      saveToStorage(state);
    },
    selectRule(state, action: PayloadAction<Rule | null>) {
      state.selectedRule = action.payload;
    },
    saveRuleJson(
      state,
      action: PayloadAction<{ id: number; ruleJson: Record<string, unknown> }>
    ) {
      const idx = state.rules.findIndex((r) => r.id === action.payload.id);
      if (idx !== -1) {
        state.rules[idx].ruleJson = action.payload.ruleJson;
      }
      if (state.selectedRule?.id === action.payload.id) {
        state.selectedRule.ruleJson = action.payload.ruleJson;
      }
      saveToStorage(state);
    },
  },
});

export const ruleActions = ruleSlice.actions;
export default ruleSlice.reducer;
