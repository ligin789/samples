import type { AppDispatch } from "../store";
import type { Rule } from "../types/ruleTypes";
import { ruleActions } from "../reducers/ruleReducer";

// Thunk actions — ready for future API integration

export const createRule = (rule: Rule) => {
  return (dispatch: AppDispatch) => {
    // Future: API call here
    dispatch(ruleActions.createRule(rule));
  };
};

export const updateRule = (rule: Rule) => {
  return (dispatch: AppDispatch) => {
    // Future: API call here
    dispatch(ruleActions.updateRule(rule));
  };
};

export const deleteRule = (id: number) => {
  return (dispatch: AppDispatch) => {
    // Future: API call here
    dispatch(ruleActions.deleteRule(id));
  };
};

export const selectRule = (rule: Rule | null) => {
  return (dispatch: AppDispatch) => {
    dispatch(ruleActions.selectRule(rule));
  };
};

export const saveRuleJson = (id: number, ruleJson: Record<string, unknown>) => {
  return (dispatch: AppDispatch) => {
    // Future: API call here
    dispatch(ruleActions.saveRuleJson({ id, ruleJson }));
  };
};
