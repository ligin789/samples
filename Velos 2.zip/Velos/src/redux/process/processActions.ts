import type { Dispatch } from 'redux';
import {
  FETCH_PROCESS_REQUEST,
  FETCH_PROCESS_SUCCESS,
  FETCH_PROCESS_FAILURE,
  ADD_PROCESS,
  UPDATE_PROCESS,
  DELETE_PROCESS,
  SET_SELECTED_PROCESS,
  type Process
} from './processTypes';

const mockProcessData: Process = {
  process_id: "proc-001",
  process_key: "SAMPLE_PROCESS",
  name: "Sample Process",
  version: "1.0.0",
  status: "active",
  description: "Sample process description",
  metadata: {
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
    created_by: "admin",
    updated_by: "admin"
  },
  domain: {
    industry: "AAM",
    function: "operations",
    subfunction: "flight",
    applicability: {
      operatingcluster: ["BLR"]
    }
  },
  operator: {
    operatorCode: "VELOSKY",
    operatorName: "VeloSky Aviation India Limited",
    operatorType: "AAM_OPERATOR",
    policyNamespace: "opa://policies/aam/operators/VELOSKY",
    region: "BLR"
  },
  governance: {
    owner: "operations-team",
    approver: "manager",
    reviewCycle: "quarterly"
  },
  tags: ["sample", "test"],
  processFlow: {
    nodes: [
      { node_id: "entry-1", type: "ENTRY", name: "Start", next: ["task-1"] },
      { node_id: "task-1", type: "TASK", name: "Validate Request", next: ["gateway-1"] },
      { node_id: "gateway-1", type: "GATEWAY", name: "Parallel Fork", gateway_type: "FORK", next: ["task-2", "task-3"] },
      { node_id: "task-2", type: "TASK", name: "Process A", next: ["gateway-2"] },
      { node_id: "task-3", type: "TASK", name: "Process B", next: ["gateway-2"] },
      { node_id: "gateway-2", type: "GATEWAY", name: "Join", gateway_type: "JOIN", next: ["task-4"] },
      { node_id: "task-4", type: "TASK", name: "Final Task", next: ["exit-1"] },
      { node_id: "exit-1", type: "EXIT", name: "End" }
    ]
  },
  tasks: [
    { task_id: "task-1", name: "Validate Request", type: "validation", sequence: 1 },
    { task_id: "task-2", name: "Process A", type: "processing", sequence: 2 },
    { task_id: "task-3", name: "Process B", type: "processing", sequence: 3 },
    { task_id: "task-4", name: "Final Task", type: "completion", sequence: 4 }
  ],
  entry_points: [
    { entry_id: "entry-1", name: "Start", type: "manual" }
  ],
  exit_points: [
    { exit_id: "exit-1", name: "End", type: "success" }
  ]
};

export const fetchProcesses = () => {
  return (dispatch: Dispatch) => {
    dispatch({ type: FETCH_PROCESS_REQUEST });

    setTimeout(() => {
      try {
        const processes = [mockProcessData];
        dispatch({ type: FETCH_PROCESS_SUCCESS, payload: processes });
      } catch (error) {
        dispatch({ 
          type: FETCH_PROCESS_FAILURE, 
          payload: error instanceof Error ? error.message : 'Failed to fetch processes'
        });
      }
    }, 1000);
  };
};

export const addProcess = (data: Process) => ({
  type: ADD_PROCESS,
  payload: data
});

export const updateProcess = (id: string, data: Partial<Process>) => ({
  type: UPDATE_PROCESS,
  payload: { id, data }
});

export const deleteProcess = (id: string) => ({
  type: DELETE_PROCESS,
  payload: id
});

export const setSelectedProcess = (process: any) => ({
  type: SET_SELECTED_PROCESS,
  payload: process
});
