import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface Domain {
  id: string;
  industry: string;
  function: string;
  subfunction: string;
  applicability: {
    operatingcluster: string[];
  };
}

interface DomainState {
  domainList: Domain[];
}

const initialState: DomainState = {
  domainList: [],
};

const domainSlice = createSlice({
  name: 'domain',
  initialState,
  reducers: {
    addDomain: (state, action: PayloadAction<Omit<Domain, 'id'>>) => {
      const newDomain: Domain = {
        ...action.payload,
        id: `domain-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      };
      state.domainList.push(newDomain);
    },
    updateDomain: (state, action: PayloadAction<Domain>) => {
      const index = state.domainList.findIndex((d) => d.id === action.payload.id);
      if (index !== -1) {
        state.domainList[index] = action.payload;
      }
    },
    deleteDomain: (state, action: PayloadAction<string>) => {
      state.domainList = state.domainList.filter((d) => d.id !== action.payload);
    },
    setDomains: (state, action: PayloadAction<Domain[]>) => {
      state.domainList = action.payload;
    },
  },
});

export const { addDomain, updateDomain, deleteDomain, setDomains } = domainSlice.actions;
export default domainSlice.reducer;
