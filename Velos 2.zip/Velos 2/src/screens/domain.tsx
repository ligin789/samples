import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { addDomain, updateDomain, deleteDomain, Domain } from '../redux/domain/domainSlice';

const DomainPage = () => {
  const dispatch = useAppDispatch();
  const domainList = useAppSelector((state) => state.domain.domainList);

  const [formData, setFormData] = useState({
    id: '',
    industry: '',
    function: '',
    subfunction: '',
    operatingcluster: '',
  });

  const [isEditing, setIsEditing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const domainData = {
      industry: formData.industry,
      function: formData.function,
      subfunction: formData.subfunction,
      applicability: {
        operatingcluster: formData.operatingcluster
          .split(',')
          .map((s) => s.trim())
          .filter((s) => s),
      },
    };

    if (isEditing) {
      dispatch(updateDomain({ ...domainData, id: formData.id }));
      setIsEditing(false);
    } else {
      dispatch(addDomain(domainData));
    }

    setFormData({
      id: '',
      industry: '',
      function: '',
      subfunction: '',
      operatingcluster: '',
    });
  };

  const handleEdit = (domain: Domain) => {
    setFormData({
      id: domain.id,
      industry: domain.industry,
      function: domain.function,
      subfunction: domain.subfunction,
      operatingcluster: domain.applicability.operatingcluster.join(', '),
    });
    setIsEditing(true);
  };

  const handleDelete = (id: string) => {
    dispatch(deleteDomain(id));
  };

  const handleCancel = () => {
    setFormData({
      id: '',
      industry: '',
      function: '',
      subfunction: '',
      operatingcluster: '',
    });
    setIsEditing(false);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Domain Management</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: '30px', border: '1px solid #ddd', padding: '20px', borderRadius: '4px' }}>
        <h3>{isEditing ? 'Edit Domain' : 'Add Domain'}</h3>
        
        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Industry:</label>
          <input
            type="text"
            value={formData.industry}
            onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Function:</label>
          <input
            type="text"
            value={formData.function}
            onChange={(e) => setFormData({ ...formData, function: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Subfunction:</label>
          <input
            type="text"
            value={formData.subfunction}
            onChange={(e) => setFormData({ ...formData, subfunction: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Operating Cluster (comma separated):</label>
          <input
            type="text"
            value={formData.operatingcluster}
            onChange={(e) => setFormData({ ...formData, operatingcluster: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
            placeholder="e.g., BLR, DEL, MUM"
          />
        </div>

        <div>
          <button type="submit" style={{ padding: '10px 20px', marginRight: '10px', cursor: 'pointer', background: '#4caf50', color: 'white', border: 'none', borderRadius: '4px' }}>
            {isEditing ? 'Update' : 'Add'}
          </button>
          {isEditing && (
            <button type="button" onClick={handleCancel} style={{ padding: '10px 20px', cursor: 'pointer', background: '#f44336', color: 'white', border: 'none', borderRadius: '4px' }}>
              Cancel
            </button>
          )}
        </div>
      </form>

      <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #ddd' }}>
        <thead>
          <tr style={{ background: '#f5f5f5' }}>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Industry</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Function</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Subfunction</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Operating Cluster</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {domainList.length === 0 ? (
            <tr>
              <td colSpan={5} style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'center' }}>
                No domains found
              </td>
            </tr>
          ) : (
            domainList.map((domain) => (
              <tr key={domain.id}>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{domain.industry}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{domain.function}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{domain.subfunction}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>
                  {domain.applicability.operatingcluster.join(', ')}
                </td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>
                  <button
                    onClick={() => handleEdit(domain)}
                    style={{ padding: '6px 12px', marginRight: '5px', cursor: 'pointer', background: '#2196f3', color: 'white', border: 'none', borderRadius: '4px' }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(domain.id)}
                    style={{ padding: '6px 12px', cursor: 'pointer', background: '#f44336', color: 'white', border: 'none', borderRadius: '4px' }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DomainPage;
