import { useState, useEffect, useMemo } from "react";
import { Tree } from "react-arborist";
import "./LeftSideBar.css";

/* =========================
   TYPES
========================= */

interface NodeType {
  node_id: string;
  process_key: string;
}

interface ProcessGroup {
  process_group_id: string;
  name: string;
  nodes: NodeType[];
}

interface Process {
  process_id: string;
  process_key: string;
  name: string;
  status: string;
  version: string;
}

interface TreeNode {
  id: string;
  name: string;
  children?: TreeNode[];
  isRoot?: boolean;
  processData?: Process;
}


/* =========================
   COMPONENT
========================= */

const LeftSideBar = ({
  processGroups,
  processes,
  onProcessSelect,
  onDeleteProcess,
}: any) => {
  const [selectedProcessGroup, setSelectedProcessGroup] =
    useState<string>("");
  const [selectedStatusFilter, setSelectedStatusFilter] =
    useState<string>("All");

  /* =========================
     DEFAULT SELECT GROUP
  ========================= */

  useEffect(() => {
    if (processGroups.length > 0 && !selectedProcessGroup) {
      setSelectedProcessGroup(
        processGroups[0].process_group_id
      );
    }
  }, [processGroups, selectedProcessGroup]);

  /* =========================
     PROCESS LOOKUP MAP (O1)
  ========================= */

  const processMap = useMemo(() => {
    const map: Record<string, Process> = {};
    processes.forEach((p:any) => {
      map[p.process_key] = p;
    });
    return map;
  }, [processes]);

  /* =========================
     RESOLVE PROCESSES FROM NODES
  ========================= */
function truncateString(str:any, maxLength:any) {
  if (str.length > maxLength) {
    return str.slice(0, maxLength) + "...";
  } else {
    return str;
  }
}
  const resolvedProcesses = useMemo(() => {
    if (!selectedProcessGroup) return [];

    const selectedGroup = processGroups.find(
      (pg:any) => pg.process_group_id === selectedProcessGroup
    );

    if (!selectedGroup) return [];

    return selectedGroup.nodes
      .map((node:any) => processMap[node.process_key])
      .filter((process:any): process is Process => {
        if (!process) return false;

        if (selectedStatusFilter === "All") return true;

        return (
          process.status.toLowerCase() ===
          selectedStatusFilter.toLowerCase()
        );
      });
  }, [
    selectedProcessGroup,
    processGroups,
    processMap,
    selectedStatusFilter,
  ]);

  /* =========================
     TREE DATA
  ========================= */

  const treeData = useMemo<TreeNode[]>(() => {
    if (!selectedProcessGroup) return [];

    const selectedGroup = processGroups.find(
      (pg:any) => pg.process_group_id === selectedProcessGroup
    );

    if (!selectedGroup) return [];

    const rootNode: TreeNode = {
      id: selectedProcessGroup,
      name: selectedGroup.name,
      isRoot: true,
      children: resolvedProcesses.map((p:any) => ({
        id: p.process_id,
        name: p.name,
        processData: p,
      })),
    };

    return [rootNode];
  }, [selectedProcessGroup, processGroups, resolvedProcesses]);

  /* =========================
     TREE NODE RENDER
  ========================= */

  const Node = ({
    node,
    style,
    dragHandle,
  }: {
    node: any;
    style: React.CSSProperties;
    dragHandle: (el: HTMLDivElement | null) => void;
  }) => {
    const isArchived =
      node.data.processData?.status === "archived";

    return (
      <div
        ref={dragHandle}
        style={style}
        className={`treeNode ${
          isArchived ? "archived" : ""
        }`}
        onClick={() => {
          if (node.data.processData) {
            onProcessSelect(node.data.processData);
          }
        }}
      >
        <div className="nodeContent">
          <span className="nodeIcon">
            {node.data.isRoot ? "📁" : "📄"}
          </span>
          <span
            className={`nodeName ${
              node.data.isRoot ? "rootNode" : ""
            }`}
          >
            {truncateString(node.data.name,20)}
          </span>
        </div>

        {node.data.processData && (
          <span
            className="deleteIcon"
            onClick={(e) => {
              e.stopPropagation();
              onDeleteProcess(
                node.data.processData.process_id
              );
            }}
          >
            🗑️
          </span>
        )}
      </div>
    );
  };

  /* =========================
     RENDER
  ========================= */

  return (
    <div className="leftSideBar">
      {/* Process Group Dropdown */}
      <div className="dropdownSection">
        <div className="dropdownLabel">
          Process Group
        </div>
        <select
          className="dropdown"
          value={selectedProcessGroup}
          onChange={(e) =>
            setSelectedProcessGroup(e.target.value)
          }
        >
          {processGroups.map((pg:any) => (
            <option
              key={pg.process_group_id}
              value={pg.process_group_id}
            >
              {pg.name}
            </option>
          ))}
        </select>
      </div>

      {/* Status Filter */}
      <div className="dropdownSection">
        <div className="dropdownLabel">
          Status Filter
        </div>
        <select
          className="dropdown"
          value={selectedStatusFilter}
          onChange={(e) =>
            setSelectedStatusFilter(e.target.value)
          }
        >
          <option value="All">All</option>
          <option value="active">Active</option>
          <option value="archived">Archived</option>
        </select>
      </div>

      {/* Tree */}
      <div className="treeContainer">
        {resolvedProcesses.length === 0 ? (
          <div className="emptyMessage">
            No processes available
          </div>
        ) : (
          <Tree
            data={treeData}
            openByDefault
            width="100%"
            height={400}
            indent={24}
            rowHeight={36}
          >
            {Node}
          </Tree>
        )}
      </div>
    </div>
  );
};

export default LeftSideBar;