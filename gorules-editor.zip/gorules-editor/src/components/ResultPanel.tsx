import { useState } from 'react';
import type { RunResult } from '../types/ruleTypes';

interface ResultPanelProps {
  result: RunResult | null;
  context: Record<string, unknown>;
  onContextChange: (ctx: Record<string, unknown>) => void;
  onRun: () => void;
}

export function ResultPanel({ result, context, onContextChange, onRun }: ResultPanelProps) {
  const [contextText, setContextText] = useState(JSON.stringify(context, null, 2));
  const [parseError, setParseError] = useState<string | null>(null);

  const handleContextChange = (value: string) => {
    setContextText(value);
    try {
      const parsed = JSON.parse(value);
      onContextChange(parsed);
      setParseError(null);
    } catch {
      setParseError('Invalid JSON');
    }
  };

  return (
    <div style={styles.panel}>
      <div style={styles.section}>
        <div style={styles.sectionHeader}>Input Context</div>
        <textarea
          style={{
            ...styles.textarea,
            ...(parseError ? { borderColor: '#ef4444' } : {}),
          }}
          value={contextText}
          onChange={(e) => handleContextChange(e.target.value)}
          spellCheck={false}
        />
        {parseError && <div style={styles.error}>{parseError}</div>}
        <button style={styles.runBtn} onClick={onRun} disabled={!!parseError}>
          Run Evaluation
        </button>
      </div>

      {result && (
        <div style={styles.section}>
          <div style={styles.sectionHeader}>
            Result
            <span
              style={{
                ...styles.badge,
                backgroundColor: result.success ? '#dcfce7' : '#fee2e2',
                color: result.success ? '#166534' : '#991b1b',
              }}
            >
              {result.success ? 'Success' : 'Error'}
            </span>
          </div>

          {result.error && <div style={styles.errorBox}>{result.error}</div>}

          {result.performance && (
            <div style={styles.meta}>Performance: {result.performance}</div>
          )}

          {result.result !== undefined && (
            <pre style={styles.resultPre}>
              {JSON.stringify(result.result, null, 2)}
            </pre>
          )}

          {result.trace && (
            <details style={styles.details}>
              <summary style={styles.summary}>Trace</summary>
              <pre style={styles.resultPre}>
                {JSON.stringify(result.trace, null, 2)}
              </pre>
            </details>
          )}
        </div>
      )}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  panel: {
    width: '320px',
    minWidth: '320px',
    borderLeft: '1px solid #e5e7eb',
    backgroundColor: '#f9fafb',
    overflowY: 'auto',
    display: 'flex',
    flexDirection: 'column',
  },
  section: {
    padding: '16px',
    borderBottom: '1px solid #e5e7eb',
  },
  sectionHeader: {
    fontSize: '13px',
    fontWeight: 600,
    color: '#374151',
    marginBottom: '8px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  textarea: {
    width: '100%',
    minHeight: '140px',
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #d1d5db',
    fontFamily: 'monospace',
    fontSize: '12px',
    resize: 'vertical',
    backgroundColor: '#fff',
    boxSizing: 'border-box' as const,
  },
  error: {
    color: '#ef4444',
    fontSize: '12px',
    marginTop: '4px',
  },
  runBtn: {
    marginTop: '8px',
    width: '100%',
    padding: '8px',
    borderRadius: '6px',
    border: 'none',
    backgroundColor: '#4f46e5',
    color: '#fff',
    fontSize: '13px',
    fontWeight: 500,
    cursor: 'pointer',
  },
  badge: {
    fontSize: '11px',
    padding: '2px 8px',
    borderRadius: '9999px',
    fontWeight: 600,
  },
  errorBox: {
    padding: '10px',
    borderRadius: '6px',
    backgroundColor: '#fee2e2',
    color: '#991b1b',
    fontSize: '12px',
    marginBottom: '8px',
  },
  meta: {
    fontSize: '12px',
    color: '#6b7280',
    marginBottom: '8px',
  },
  resultPre: {
    padding: '10px',
    borderRadius: '6px',
    backgroundColor: '#fff',
    border: '1px solid #e5e7eb',
    fontSize: '11px',
    fontFamily: 'monospace',
    overflow: 'auto',
    maxHeight: '300px',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
  },
  details: {
    marginTop: '8px',
  },
  summary: {
    cursor: 'pointer',
    fontSize: '12px',
    color: '#6b7280',
    fontWeight: 500,
  },
};
