import { forwardRef } from 'react';
import { DecisionGraph, type DecisionGraphRef } from '@gorules/jdm-editor';
import type { DecisionGraphType, Simulation } from '../types/ruleTypes';

interface RuleEditorProps {
  value: DecisionGraphType;
  onChange: (val: DecisionGraphType) => void;
  simulate?: Simulation;
}

export const RuleEditor = forwardRef<DecisionGraphRef, RuleEditorProps>(
  ({ value, onChange, simulate }, ref) => {
    return (
      <div style={styles.container}>
        <DecisionGraph
          ref={ref}
          value={value}
          onChange={onChange}
          simulate={simulate}
        />
      </div>
    );
  },
);

RuleEditor.displayName = 'RuleEditor';

const styles: Record<string, React.CSSProperties> = {
  container: {
    flex: 1,
    height: '100%',
    overflow: 'hidden',
  },
};
