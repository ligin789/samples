import { useState, useCallback, useRef } from 'react';
import { JdmConfigProvider, type DecisionGraphRef } from '@gorules/jdm-editor';
import '@gorules/jdm-editor/dist/style.css';

import { RuleEditor } from './components/RuleEditor';
import { Toolbar } from './components/Toolbar';
import { ResultPanel } from './components/ResultPanel';
import { exportToJson, importFromJson } from './utils/fileHandler';
import { evaluateRules } from './utils/ruleRunner';
import type { DecisionGraphType, RunResult, Simulation } from './types/ruleTypes';

const DEFAULT_GRAPH: DecisionGraphType = {
  nodes: [
    {
      id: '1',
      type: 'inputNode',
      name: 'Request',
      position: { x: 100, y: 200 },
    },
    {
      id: '2',
      type: 'outputNode',
      name: 'Response',
      position: { x: 700, y: 200 },
    },
    {
      id: '3',
      type: 'decisionTableNode',
      name: 'Discount Rules',
      position: { x: 380, y: 200 },
      content: {
        hitPolicy: 'first',
        inputs: [
          { id: 'input_1', name: 'Customer Type', field: 'customerType' },
          { id: 'input_2', name: 'Order Amount', field: 'orderAmount' },
        ],
        outputs: [
          { id: 'output_1', name: 'Discount %', field: 'discount' },
          { id: 'output_2', name: 'Message', field: 'message' },
        ],
        rules: [
          {
            _id: 'rule_1',
            input_1: '"premium"',
            input_2: '',
            output_1: '20',
            output_2: '"Premium discount applied"',
          },
          {
            _id: 'rule_2',
            input_1: '"regular"',
            input_2: '> 100',
            output_1: '10',
            output_2: '"Bulk order discount"',
          },
          {
            _id: 'rule_3',
            input_1: '',
            input_2: '',
            output_1: '0',
            output_2: '"No discount"',
          },
        ],
      },
    },
  ],
  edges: [
    { id: 'e1', sourceId: '1', targetId: '3', sourceHandle: null, targetHandle: null },
    { id: 'e2', sourceId: '3', targetId: '2', sourceHandle: null, targetHandle: null },
  ],
};

const DEFAULT_CONTEXT: Record<string, unknown> = {
  customerType: 'premium',
  orderAmount: 250,
};

export default function App() {
  const graphRef = useRef<DecisionGraphRef>(null);
  const [graph, setGraph] = useState<DecisionGraphType>(DEFAULT_GRAPH);
  const [context, setContext] = useState<Record<string, unknown>>(DEFAULT_CONTEXT);
  const [runResult, setRunResult] = useState<RunResult | null>(null);
  const [simulate, setSimulate] = useState<Simulation | undefined>(undefined);
  const [isRunning, setIsRunning] = useState(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  const showNotification = useCallback(
    (type: 'success' | 'error', message: string) => {
      setNotification({ type, message });
      setTimeout(() => setNotification(null), 3000);
    },
    [],
  );

  const handleImport = useCallback(
    async (file: File) => {
      try {
        const imported = await importFromJson(file);
        setGraph(imported);
        setSimulate(undefined);
        setRunResult(null);
        showNotification('success', `Imported "${file.name}" successfully`);
      } catch (err) {
        showNotification(
          'error',
          err instanceof Error ? err.message : 'Import failed',
        );
      }
    },
    [showNotification],
  );

  const handleExport = useCallback(() => {
    exportToJson(graph);
    showNotification('success', 'Exported rules.json');
  }, [graph, showNotification]);

  const handleRun = useCallback(() => {
    setIsRunning(true);
    try {
      const sim = evaluateRules(graph, context);
      setSimulate(sim);

      if (sim.error) {
        setRunResult({
          success: false,
          error: `${sim.error.title}: ${sim.error.message}`,
        });
        console.error('Rule evaluation error:', sim.error);
      } else if (sim.result) {
        setRunResult({
          success: true,
          result: sim.result.result,
          trace: sim.result.trace as unknown as Record<string, unknown>,
          performance: sim.result.performance,
        });
        console.log('Rule evaluation result:', sim.result.result);
        console.log('Trace:', sim.result.trace);
      }
    } catch (err) {
      setRunResult({
        success: false,
        error: err instanceof Error ? err.message : 'Unknown error',
      });
    } finally {
      setIsRunning(false);
    }
  }, [graph, context]);

  const handleGraphChange = useCallback((val: DecisionGraphType) => {
    setGraph(val);
  }, []);

  return (
    <JdmConfigProvider>
      <div style={styles.app}>
        {/* Header */}
        <div style={styles.header}>
          <div style={styles.headerContent}>
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#4f46e5"
              strokeWidth="2"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <path d="M9 9h6M9 12h6M9 15h4" />
            </svg>
            <h1 style={styles.title}>GoRules Rule Editor</h1>
          </div>
        </div>

        {/* Notification */}
        {notification && (
          <div
            style={{
              ...styles.notification,
              backgroundColor:
                notification.type === 'success' ? '#dcfce7' : '#fee2e2',
              color:
                notification.type === 'success' ? '#166534' : '#991b1b',
            }}
          >
            {notification.message}
          </div>
        )}

        {/* Toolbar */}
        <Toolbar
          onImport={handleImport}
          onExport={handleExport}
          onRun={handleRun}
          isRunning={isRunning}
        />

        {/* Main content */}
        <div style={styles.main}>
          <RuleEditor
            ref={graphRef}
            value={graph}
            onChange={handleGraphChange}
            simulate={simulate}
          />
          <ResultPanel
            result={runResult}
            context={context}
            onContextChange={setContext}
            onRun={handleRun}
          />
        </div>
      </div>
    </JdmConfigProvider>
  );
}

const styles: Record<string, React.CSSProperties> = {
  app: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    fontFamily:
      '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
    backgroundColor: '#f3f4f6',
  },
  header: {
    backgroundColor: '#fff',
    borderBottom: '1px solid #e5e7eb',
    padding: '10px 16px',
  },
  headerContent: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  },
  title: {
    fontSize: '18px',
    fontWeight: 700,
    color: '#111827',
    margin: 0,
  },
  notification: {
    padding: '8px 16px',
    fontSize: '13px',
    fontWeight: 500,
    textAlign: 'center' as const,
  },
  main: {
    flex: 1,
    display: 'flex',
    overflow: 'hidden',
  },
};
