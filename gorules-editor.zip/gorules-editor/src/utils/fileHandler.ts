import type { DecisionGraphType } from '../types/ruleTypes';

export function exportToJson(graph: DecisionGraphType, filename = 'rules.json'): void {
  const json = JSON.stringify(graph, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function importFromJson(file: File): Promise<DecisionGraphType> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);

        if (!parsed.nodes || !Array.isArray(parsed.nodes)) {
          reject(new Error('Invalid rule file: missing "nodes" array'));
          return;
        }
        if (!parsed.edges || !Array.isArray(parsed.edges)) {
          reject(new Error('Invalid rule file: missing "edges" array'));
          return;
        }

        resolve(parsed as DecisionGraphType);
      } catch {
        reject(new Error('Invalid JSON file'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
