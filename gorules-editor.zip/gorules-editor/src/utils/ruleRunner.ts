import type { DecisionGraphType, Simulation } from '../types/ruleTypes';

/**
 * Simulates rule evaluation using the jdm-editor's built-in simulation.
 * Since @gorules/zen-engine is a native Node.js module and cannot run in the browser,
 * we use the editor's simulate prop to show trace results visually,
 * and perform a basic client-side traversal for the Run panel output.
 */
export function evaluateRules(
  graph: DecisionGraphType,
  context: Record<string, unknown>,
): Simulation {
  try {
    // Find input and output nodes
    const inputNode = graph.nodes.find((n) => n.type === 'inputNode');
    const outputNode = graph.nodes.find((n) => n.type === 'outputNode');

    if (!inputNode || !outputNode) {
      return {
        error: {
          title: 'Missing Nodes',
          message: 'Graph must have both an Input and Output node.',
          data: {},
        },
      };
    }

    // Build adjacency from edges
    const adjacency = new Map<string, string[]>();
    for (const edge of graph.edges) {
      const list = adjacency.get(edge.sourceId) || [];
      list.push(edge.targetId);
      adjacency.set(edge.sourceId, list);
    }

    // Traverse graph and collect trace
    const trace: Record<string, Simulation extends { result?: infer R } ? R extends { trace: infer T } ? T extends Record<string, infer V> ? V : never : never : never> = {};
    const visited = new Set<string>();
    const queue = [inputNode.id];
    let currentData = { ...context };

    while (queue.length > 0) {
      const nodeId = queue.shift()!;
      if (visited.has(nodeId)) continue;
      visited.add(nodeId);

      const node = graph.nodes.find((n) => n.id === nodeId);
      if (!node) continue;

      trace[nodeId] = {
        id: nodeId,
        name: node.name,
        input: currentData,
        output: currentData,
        performance: '0ms',
        traceData: null,
      };

      // Process decision table nodes
      if (node.type === 'decisionTableNode' && node.content) {
        const table = node.content as {
          rules?: Array<Record<string, string>>;
          inputs?: Array<{ id: string; field: string }>;
          outputs?: Array<{ id: string; field: string }>;
          hitPolicy?: string;
        };
        if (table.rules && table.inputs && table.outputs) {
          const matchedOutputs: Record<string, unknown> = {};
          for (const rule of table.rules) {
            let ruleMatches = true;
            for (const input of table.inputs) {
              const ruleValue = rule[input.id];
              if (ruleValue && ruleValue.trim() !== '') {
                const contextValue = String(context[input.field] ?? '');
                if (ruleValue !== contextValue) {
                  ruleMatches = false;
                  break;
                }
              }
            }
            if (ruleMatches) {
              for (const output of table.outputs) {
                const val = rule[output.id];
                if (val !== undefined) {
                  matchedOutputs[output.field] = isNaN(Number(val)) ? val : Number(val);
                }
              }
              if (table.hitPolicy === 'first') break;
            }
          }
          currentData = { ...currentData, ...matchedOutputs };
          trace[nodeId] = {
            ...trace[nodeId],
            output: currentData,
            performance: '1ms',
          };
        }
      }

      const nextNodes = adjacency.get(nodeId) || [];
      queue.push(...nextNodes);
    }

    return {
      result: {
        performance: '1ms',
        result: currentData,
        snapshot: graph,
        trace: trace as never,
      },
    };
  } catch (err) {
    return {
      error: {
        title: 'Evaluation Error',
        message: err instanceof Error ? err.message : 'Unknown error during evaluation',
        data: {},
      },
    };
  }
}
