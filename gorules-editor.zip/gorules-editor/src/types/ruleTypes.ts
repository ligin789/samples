import type { DecisionGraphType, Simulation } from '@gorules/jdm-editor';

export type { DecisionGraphType, Simulation };

export interface RuleFile {
  name: string;
  graph: DecisionGraphType;
}

export interface RunContext {
  [key: string]: unknown;
}

export interface RunResult {
  success: boolean;
  result?: unknown;
  trace?: Record<string, unknown>;
  performance?: string;
  error?: string;
}
