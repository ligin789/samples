# FormBuilder Studio

A drag-and-drop form builder (in the spirit of [formengine.io](https://formbuilder.formengine.io/))
built with **React 19 + Vite + TypeScript**. Forms are saved as a
platform-agnostic **template JSON** that renders on the web *and* on React
Native (iPad) via the bundled renderer in [`native/`](native/README.md).

```bash
npm install
npm run dev
```

## What it does

- **Drag-and-drop designer** — component palette (text, textarea, number,
  select, radio, checkbox, switch, date picker, heading, paragraph, divider,
  button, container) onto a canvas; reorder, nest in containers, duplicate,
  delete, undo/redo (⌘Z / ⇧⌘Z).
- **API JSON ingestion** — paste or fetch an API response. The builder
  analyzes the structure (types, nesting, arrays, dates, enums) and can
  **auto-generate the whole form** with data bindings, or you drag individual
  data fields from the Data tab onto the canvas.
- **HTML/CSS card import** (`</> Import HTML`) — paste a card you hand-coded in
  plain HTML with inline styles (no packages). The builder parses it with the
  browser's `DOMParser`, maps the tags onto form components and the
  inline/`<style>` CSS onto the shared style subset, then renders the same UI —
  ready to export as a template. Only the subset shared by web + native
  (spacing, sizing, flex layout, colors, border, font) is carried over; effects
  like shadows, gradients and grid are dropped. See
  [`src/utils/htmlImport.ts`](src/utils/htmlImport.ts).
- **Data binding** — every input can bind to a JSON path
  (`user.address.city`). Bound values pre-fill the preview; on submit the flat
  form state is reassembled into the nested payload shape.
- **Validation** — required / min / max / length / regex per field, enforced
  in preview and by both renderers.
- **Preview** — live render with desktop / iPad / phone widths and a
  submission payload inspector.
- **JSON tab** — the output template; copy, download, or paste one back in to
  round-trip.

## Template format

```jsonc
{
  "version": "1.0",
  "name": "Customer Form",
  "sampleData": { "user": { "firstName": "Ava" } },   // imported API JSON
  "components": [
    {
      "id": "textfield_a1b2c3",
      "type": "textfield",
      "props": { "label": "First Name", "placeholder": "", "inputType": "text" },
      "binding": "user.firstName",                     // data path
      "validation": { "required": true, "minLength": 2 }
    },
    {
      "id": "container_x9y8z7",
      "type": "container",
      "props": { "label": "Address", "direction": "vertical" },
      "children": [ /* nested components */ ]
    }
  ]
}
```

Types live in [`src/types/schema.ts`](src/types/schema.ts).

## Rendering on iPad (React Native)

Copy [`native/FormRenderer.native.tsx`](native/FormRenderer.native.tsx) into
your RN/Expo project (zero extra dependencies) and feed it a template exported
from the builder — see [`native/README.md`](native/README.md) for a full
example screen with data loading, validation and submission.

## Project layout

```
src/
  types/schema.ts          # template JSON contract (shared concept w/ native)
  definitions/registry.ts  # component catalog: defaults + property editors
  state/store.ts           # zustand store with undo/redo history
  utils/json.ts            # API JSON analysis, path get/set, field generation
  utils/tree.ts            # component-tree helpers (find/move/insert/clone)
  utils/validate.ts        # validation rules shared by canvas/preview
  renderer/FormRenderer.tsx# web renderer (canvas preview + Preview tab)
  components/              # Toolbar, Palette, Canvas, PropertiesPanel,
                           # ApiImportModal, PreviewPane, JsonPanel
native/
  FormRenderer.native.tsx  # drop-in React Native renderer for the iPad app
  README.md                # integration guide
```
