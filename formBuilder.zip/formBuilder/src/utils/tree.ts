import type { FormComponent } from '../types/schema'

export function findById(list: FormComponent[], id: string): FormComponent | null {
  for (const c of list) {
    if (c.id === id) return c
    if (c.children) {
      const found = findById(c.children, id)
      if (found) return found
    }
  }
  return null
}

/** Returns the array that directly contains `id`, plus the index within it. */
export function findContainerOf(
  list: FormComponent[],
  id: string,
): { siblings: FormComponent[]; index: number } | null {
  const index = list.findIndex((c) => c.id === id)
  if (index !== -1) return { siblings: list, index }
  for (const c of list) {
    if (c.children) {
      const found = findContainerOf(c.children, id)
      if (found) return found
    }
  }
  return null
}

export function removeById(list: FormComponent[], id: string): FormComponent | null {
  const loc = findContainerOf(list, id)
  if (!loc) return null
  return loc.siblings.splice(loc.index, 1)[0]
}

/** Insert into the children of `parentId` (or the root list when null) at `index`. */
export function insertAt(
  root: FormComponent[],
  parentId: string | null,
  index: number,
  component: FormComponent,
): boolean {
  const target = parentId === null ? root : findById(root, parentId)?.children
  if (!target) return false
  target.splice(Math.max(0, Math.min(index, target.length)), 0, component)
  return true
}

export function isDescendant(ancestor: FormComponent, id: string): boolean {
  if (!ancestor.children) return false
  return findById(ancestor.children, id) !== null
}

export function visitAll(list: FormComponent[], fn: (c: FormComponent) => void): void {
  for (const c of list) {
    fn(c)
    if (c.children) visitAll(c.children, fn)
  }
}

export function cloneWithNewIds(
  component: FormComponent,
  makeId: (type: string) => string,
): FormComponent {
  return {
    ...structuredClone(component),
    id: makeId(component.type),
    children: component.children?.map((c) => cloneWithNewIds(c, makeId)),
  }
}
