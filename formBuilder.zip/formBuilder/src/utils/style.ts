import type { CSSProperties } from 'react'
import type { ComponentStyle } from '../types/schema'

/** Style keys that govern how a container lays out its children. */
const LAYOUT_KEYS = ['flexDirection', 'justifyContent', 'alignItems', 'flexWrap', 'gap'] as const

/** The whole style object as a web inline-style object. */
export function toCss(style?: ComponentStyle): CSSProperties | undefined {
  return style as CSSProperties | undefined
}

/** Just the flex-layout keys — applied to the element that wraps the children. */
export function containerLayoutStyle(style?: ComponentStyle): CSSProperties | undefined {
  if (!style) return undefined
  const out: Record<string, unknown> = {}
  for (const k of LAYOUT_KEYS) if (style[k] !== undefined) out[k] = style[k]
  return Object.keys(out).length ? (out as CSSProperties) : undefined
}

/** Everything except the flex-layout keys — applied to the container box itself. */
export function containerBoxStyle(style?: ComponentStyle): CSSProperties | undefined {
  if (!style) return undefined
  const out: Record<string, unknown> = { ...style }
  for (const k of LAYOUT_KEYS) delete out[k]
  return Object.keys(out).length ? (out as CSSProperties) : undefined
}

/** Effective layout direction, honouring an explicit style override then the `direction` prop. */
export function effectiveDirection(
  style: ComponentStyle | undefined,
  directionProp: unknown,
): 'horizontal' | 'vertical' {
  if (style?.flexDirection) return style.flexDirection === 'row' ? 'horizontal' : 'vertical'
  return directionProp === 'horizontal' ? 'horizontal' : 'vertical'
}
