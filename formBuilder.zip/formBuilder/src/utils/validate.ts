import type { FormComponent } from '../types/schema'
import { visitAll } from './tree'

export function valueKeyOf(component: FormComponent): string {
  return component.binding || component.id
}

const INPUT_TYPES = new Set([
  'textfield',
  'textarea',
  'number',
  'select',
  'radio',
  'checkbox',
  'switch',
  'datepicker',
])

export function isInputComponent(component: FormComponent): boolean {
  return INPUT_TYPES.has(component.type)
}

export function validateComponent(component: FormComponent, value: unknown): string | null {
  const rules = component.validation
  if (!rules) return null

  const empty =
    value === undefined || value === null || value === '' || (typeof value === 'boolean' && !value)

  if (rules.required && empty) return 'This field is required'
  if (empty) return null

  if (typeof value === 'string') {
    if (rules.minLength !== undefined && value.length < rules.minLength)
      return `Must be at least ${rules.minLength} characters`
    if (rules.maxLength !== undefined && value.length > rules.maxLength)
      return `Must be at most ${rules.maxLength} characters`
    if (rules.pattern) {
      try {
        if (!new RegExp(rules.pattern).test(value)) return 'Invalid format'
      } catch {
        // invalid regex in the template — skip rather than crash the form
      }
    }
  }

  const num = typeof value === 'number' ? value : Number.NaN
  if (!Number.isNaN(num)) {
    if (rules.min !== undefined && num < rules.min) return `Must be at least ${rules.min}`
    if (rules.max !== undefined && num > rules.max) return `Must be at most ${rules.max}`
  }
  return null
}

export function validateAll(
  components: FormComponent[],
  values: Record<string, unknown>,
): Record<string, string> {
  const errors: Record<string, string> = {}
  visitAll(components, (c) => {
    if (!isInputComponent(c)) return
    const error = validateComponent(c, values[valueKeyOf(c)])
    if (error) errors[valueKeyOf(c)] = error
  })
  return errors
}
