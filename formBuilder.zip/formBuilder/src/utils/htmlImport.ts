import type { ComponentStyle, ComponentType, FormComponent, SelectOption } from '../types/schema'
import { uid } from './id'

/**
 * Import a hand-written HTML/CSS card into the form template.
 *
 * The pasted markup is parsed with the browser's built-in DOMParser (no
 * dependencies) and mapped onto the SAME `FormComponent` tree that the rest of
 * the builder uses, so it renders identically on the web canvas, in Preview,
 * and on the React Native renderer — and exports straight to the template JSON.
 *
 * Because the template's `ComponentStyle` is a deliberate flexbox-based subset
 * shared by web and native, only the CSS properties in that subset are carried
 * over (margins, padding, sizing, flex layout, colors, border, font, align).
 * Properties outside it (shadows, gradients, grid, transforms, …) are dropped.
 */

/* ============================== CSS value parsing ========================== */

/** A `prop: value` map for one element, after splitting a style string. */
type Declarations = Record<string, string>

/** Split "a: b; c: d" into { a: 'b', c: 'd' }, ignoring ';' inside (). */
function splitDeclarations(css: string): Declarations {
  const out: Declarations = {}
  let depth = 0
  let start = 0
  const push = (chunk: string) => {
    const i = chunk.indexOf(':')
    if (i < 0) return
    const prop = chunk.slice(0, i).trim().toLowerCase()
    const value = chunk.slice(i + 1).trim()
    if (prop && value) out[prop] = value
  }
  for (let i = 0; i < css.length; i++) {
    const ch = css[i]
    if (ch === '(') depth++
    else if (ch === ')') depth = Math.max(0, depth - 1)
    else if (ch === ';' && depth === 0) {
      push(css.slice(start, i))
      start = i + 1
    }
  }
  push(css.slice(start))
  return out
}

/** "12px" / "1.5rem" / "2em" -> px number; non-length (%, auto, calc…) -> undefined. */
function lengthPx(value: string): number | undefined {
  const m = value.trim().match(/^(-?\d*\.?\d+)(px|rem|em)?$/i)
  if (!m) return undefined
  const n = Number(m[1])
  const unit = (m[2] || 'px').toLowerCase()
  return unit === 'px' ? n : Math.round(n * 16)
}

/** width/height accept px (number) and pass %, vw/vh, auto through as strings. */
function dimension(value: string): number | string | undefined {
  const px = lengthPx(value)
  if (px !== undefined) return px
  const t = value.trim()
  if (/^(auto|\d*\.?\d+(%|vh|vw))$/i.test(t)) return t
  return undefined
}

const NAMED_COLORS = new Set([
  'transparent', 'black', 'white', 'red', 'green', 'blue', 'yellow', 'orange',
  'purple', 'pink', 'gray', 'grey', 'brown', 'cyan', 'magenta', 'lime', 'navy',
  'teal', 'olive', 'maroon', 'silver', 'gold', 'indigo', 'violet', 'coral',
  'salmon', 'khaki', 'crimson', 'tomato', 'orchid', 'tan', 'beige', 'ivory',
  'lavender', 'turquoise', 'aqua', 'fuchsia', 'slategray', 'slategrey',
  'darkgray', 'darkgrey', 'lightgray', 'lightgrey', 'whitesmoke', 'gainsboro',
])

const COLOR_FUNC = /\b(?:rgb|rgba|hsl|hsla)\([^)]*\)/i
const HEX_COLOR = /#[0-9a-fA-F]{3,8}\b/

/** Pull the first color out of a value (handles `1px solid #ccc`, `#fff url(...)`). */
function firstColor(value: string): string | undefined {
  const fn = value.match(COLOR_FUNC)
  if (fn) return fn[0].replace(/\s+/g, '')
  const hex = value.match(HEX_COLOR)
  if (hex) return hex[0]
  const tokens = value.trim().split(/\s+/)
  for (const t of tokens) {
    const lc = t.toLowerCase()
    if (NAMED_COLORS.has(lc)) return lc
  }
  // A lone unknown word is most likely a named color we didn't list.
  if (tokens.length === 1 && /^[a-z]+$/i.test(tokens[0])) return tokens[0].toLowerCase()
  return undefined
}

/** Map any CSS font-weight to the template's allowed set. */
function fontWeight(value: string): ComponentStyle['fontWeight'] | undefined {
  const t = value.trim().toLowerCase()
  if (t === 'normal') return '400'
  if (t === 'bold' || t === 'bolder') return '700'
  if (t === 'lighter') return '400'
  const n = Number(t)
  if (Number.isNaN(n)) return undefined
  if (n <= 400) return '400'
  if (n <= 500) return '500'
  if (n <= 600) return '600'
  return '700'
}

const JUSTIFY_ALIASES: Record<string, ComponentStyle['justifyContent']> = {
  start: 'flex-start', left: 'flex-start', 'flex-start': 'flex-start',
  end: 'flex-end', right: 'flex-end', 'flex-end': 'flex-end',
  center: 'center', 'space-between': 'space-between',
  'space-around': 'space-around', 'space-evenly': 'space-evenly',
}

const ALIGN_ALIASES: Record<string, ComponentStyle['alignItems']> = {
  start: 'flex-start', 'flex-start': 'flex-start',
  end: 'flex-end', 'flex-end': 'flex-end',
  center: 'center', stretch: 'stretch',
}

/** 1–4 length values ("8px" / "8px 12px" / …) -> [top, right, bottom, left]. */
function expandBox(value: string): [number?, number?, number?, number?] {
  const parts = value.trim().split(/\s+/).map(lengthPx)
  const [a, b, c, d] = parts
  switch (parts.length) {
    case 1: return [a, a, a, a]
    case 2: return [a, b, a, b]
    case 3: return [a, b, c, b]
    default: return [a, b, c, d]
  }
}

function set<K extends keyof ComponentStyle>(
  style: ComponentStyle,
  key: K,
  value: ComponentStyle[K] | undefined,
) {
  if (value !== undefined) style[key] = value
}

/** Convert one element's CSS declarations into the template's ComponentStyle subset. */
function declarationsToStyle(d: Declarations): ComponentStyle {
  const s: ComponentStyle = {}

  if (d.margin) {
    const [t, r, b, l] = expandBox(d.margin)
    set(s, 'marginTop', t); set(s, 'marginRight', r); set(s, 'marginBottom', b); set(s, 'marginLeft', l)
  }
  set(s, 'marginTop', d['margin-top'] !== undefined ? lengthPx(d['margin-top']) : s.marginTop)
  set(s, 'marginRight', d['margin-right'] !== undefined ? lengthPx(d['margin-right']) : s.marginRight)
  set(s, 'marginBottom', d['margin-bottom'] !== undefined ? lengthPx(d['margin-bottom']) : s.marginBottom)
  set(s, 'marginLeft', d['margin-left'] !== undefined ? lengthPx(d['margin-left']) : s.marginLeft)

  if (d.padding) {
    const [t, r, b, l] = expandBox(d.padding)
    set(s, 'paddingTop', t); set(s, 'paddingRight', r); set(s, 'paddingBottom', b); set(s, 'paddingLeft', l)
  }
  set(s, 'paddingTop', d['padding-top'] !== undefined ? lengthPx(d['padding-top']) : s.paddingTop)
  set(s, 'paddingRight', d['padding-right'] !== undefined ? lengthPx(d['padding-right']) : s.paddingRight)
  set(s, 'paddingBottom', d['padding-bottom'] !== undefined ? lengthPx(d['padding-bottom']) : s.paddingBottom)
  set(s, 'paddingLeft', d['padding-left'] !== undefined ? lengthPx(d['padding-left']) : s.paddingLeft)

  if (d.width) set(s, 'width', dimension(d.width))
  if (d.height) set(s, 'height', dimension(d.height))
  // No max-width in the subset; approximate a card's max-width as its width.
  if (d['max-width'] && s.width === undefined) set(s, 'width', dimension(d['max-width']))

  // Flex layout. display:flex/grid implies a row unless flex-direction says otherwise.
  const display = d.display?.toLowerCase()
  if (d['flex-direction']) {
    set(s, 'flexDirection', d['flex-direction'].startsWith('column') ? 'column' : 'row')
  } else if (display === 'flex' || display === 'inline-flex' || display === 'grid') {
    set(s, 'flexDirection', 'row')
  }
  if (display === 'grid') set(s, 'flexWrap', 'wrap')
  if (d['justify-content']) set(s, 'justifyContent', JUSTIFY_ALIASES[d['justify-content'].toLowerCase()])
  if (d['align-items']) set(s, 'alignItems', ALIGN_ALIASES[d['align-items'].toLowerCase()])
  if (d['flex-wrap']) set(s, 'flexWrap', d['flex-wrap'].toLowerCase() === 'wrap' ? 'wrap' : 'nowrap')
  const gap = d.gap ?? d['row-gap'] ?? d['column-gap']
  if (gap) set(s, 'gap', lengthPx(gap.split(/\s+/)[0]))
  if (d.flex) {
    const n = Number(d.flex.trim().split(/\s+/)[0])
    if (!Number.isNaN(n)) set(s, 'flex', n)
  }
  if (d['align-self']) {
    const a = d['align-self'].toLowerCase()
    set(s, 'alignSelf', a === 'auto' ? 'auto' : (ALIGN_ALIASES[a] as ComponentStyle['alignSelf']))
  }

  // Colors
  const bg = d['background-color'] ?? d.background
  if (bg) set(s, 'backgroundColor', firstColor(bg))
  if (d.color) set(s, 'color', firstColor(d.color))

  // Border
  if (d.border !== undefined) {
    const b = d.border.trim().toLowerCase()
    if (b === 'none' || b === '0' || b === '0px') {
      set(s, 'borderWidth', 0)
    } else {
      const w = d.border.split(/\s+/).map(lengthPx).find((n) => n !== undefined)
      set(s, 'borderWidth', w)
      set(s, 'borderColor', firstColor(d.border))
    }
  }
  if (d['border-width']) set(s, 'borderWidth', lengthPx(d['border-width']))
  if (d['border-color']) set(s, 'borderColor', firstColor(d['border-color']))
  if (d['border-radius']) set(s, 'borderRadius', lengthPx(d['border-radius'].split(/\s+/)[0]))

  // Typography
  if (d['font-size']) set(s, 'fontSize', lengthPx(d['font-size']))
  if (d['font-weight']) set(s, 'fontWeight', fontWeight(d['font-weight']))
  if (d['text-align']) {
    const a = d['text-align'].toLowerCase()
    if (a === 'left' || a === 'center' || a === 'right') set(s, 'textAlign', a)
  }

  return s
}

/* ============================ <style> rule lookup ========================== */

/**
 * A very small CSS resolver for `<style>` blocks: it understands single
 * `.class`, `#id`, and `tag` selectors (and comma lists of them). Anything with
 * combinators, attributes, or pseudo-classes is skipped. Inline styles win.
 */
interface CssLookup {
  byTag: Record<string, Declarations>
  byClass: Record<string, Declarations>
  byId: Record<string, Declarations>
}

function buildCssLookup(doc: Document): CssLookup {
  const lookup: CssLookup = { byTag: {}, byClass: {}, byId: {} }
  const merge = (bucket: Record<string, Declarations>, key: string, decls: Declarations) => {
    bucket[key] = { ...bucket[key], ...decls }
  }
  for (const styleEl of Array.from(doc.querySelectorAll('style'))) {
    const css = (styleEl.textContent ?? '').replace(/\/\*[\s\S]*?\*\//g, '')
    for (const rule of css.split('}')) {
      const open = rule.indexOf('{')
      if (open < 0) continue
      const selectors = rule.slice(0, open)
      const decls = splitDeclarations(rule.slice(open + 1))
      if (Object.keys(decls).length === 0) continue
      for (const raw of selectors.split(',')) {
        const sel = raw.trim()
        if (/^\.[\w-]+$/.test(sel)) merge(lookup.byClass, sel.slice(1), decls)
        else if (/^#[\w-]+$/.test(sel)) merge(lookup.byId, sel.slice(1), decls)
        else if (/^[a-z][\w-]*$/i.test(sel)) merge(lookup.byTag, sel.toLowerCase(), decls)
        // anything more specific is intentionally ignored
      }
    }
  }
  return lookup
}

/** Resolved style for an element: tag < class < id < inline (inline wins). */
function resolveStyle(el: Element, lookup: CssLookup): ComponentStyle | undefined {
  const decls: Declarations = { ...lookup.byTag[el.tagName.toLowerCase()] }
  for (const cls of Array.from(el.classList)) Object.assign(decls, lookup.byClass[cls])
  if (el.id) Object.assign(decls, lookup.byId[el.id])
  const inline = el.getAttribute('style')
  if (inline) Object.assign(decls, splitDeclarations(inline))
  const style = declarationsToStyle(decls)
  return Object.keys(style).length ? style : undefined
}

/* =========================== element -> component ========================== */

const HEADING_TAGS = new Set(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
const CONTAINER_TAGS = new Set([
  'div', 'section', 'article', 'header', 'footer', 'main', 'aside', 'nav',
  'ul', 'ol', 'li', 'figure', 'form', 'fieldset', 'dl',
])
const TEXT_TAGS = new Set([
  'p', 'span', 'small', 'strong', 'em', 'b', 'i', 'label', 'figcaption',
  'blockquote', 'address', 'dt', 'dd', 'time', 'mark', 'code',
])

const make = (type: ComponentType, props: Record<string, unknown>, style?: ComponentStyle): FormComponent => {
  const c: FormComponent = { id: uid(type), type, props }
  if (style) c.style = style
  return c
}

/** True when an element holds at least one element child (so it's structural). */
function hasElementChildren(el: Element): boolean {
  return Array.from(el.childNodes).some((n) => n.nodeType === 1)
}

function looksLikeButton(el: Element): boolean {
  const cls = el.getAttribute('class') ?? ''
  return el.getAttribute('role') === 'button' || /\b(btn|button)\b/i.test(cls)
}

function inputComponent(el: HTMLInputElement, style?: ComponentStyle): FormComponent | null {
  const type = (el.getAttribute('type') || 'text').toLowerCase()
  const label =
    el.getAttribute('aria-label') ||
    (el.getAttribute('placeholder') ? '' : humanizeAttr(el.getAttribute('name'))) ||
    ''
  const placeholder = el.getAttribute('placeholder') || ''
  switch (type) {
    case 'checkbox':
    case 'radio':
      return make('checkbox', { label: label || humanizeAttr(el.getAttribute('name')) || 'Checkbox' }, style)
    case 'number':
    case 'range':
      return make('number', { label, placeholder }, style)
    case 'date':
    case 'datetime-local':
      return make('datepicker', { label: label || 'Date' }, style)
    case 'submit':
    case 'button':
    case 'reset':
      return make('button', { text: el.getAttribute('value') || 'Submit', variant: 'primary' }, style)
    case 'hidden':
      return null
    default: {
      const inputType = ['email', 'tel', 'url', 'password'].includes(type) ? type : 'text'
      return make('textfield', { label, placeholder, inputType }, style)
    }
  }
}

function humanizeAttr(value: string | null): string {
  if (!value) return ''
  return value
    .replace(/[_-]+/g, ' ')
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase())
}

/** Convert one element into a component (or null to drop it). */
function convertElement(el: Element, lookup: CssLookup): FormComponent | null {
  const tag = el.tagName.toLowerCase()
  const style = resolveStyle(el, lookup)
  const text = (el.textContent ?? '').trim()

  if (HEADING_TAGS.has(tag)) {
    const n = Number(tag[1])
    const level = n <= 1 ? '1' : n === 2 ? '2' : '3'
    return make('heading', { text, level }, style)
  }

  switch (tag) {
    case 'hr':
      return make('divider', {}, style)
    case 'br':
    case 'style':
    case 'script':
    case 'link':
    case 'meta':
      return null
    case 'img':
      // No image type in the shared contract; keep the alt text as a caption.
      return el.getAttribute('alt') ? make('paragraph', { text: el.getAttribute('alt') }, style) : null
    case 'button':
      return make('button', { text: text || 'Button', variant: buttonVariant(el) }, style)
    case 'input':
      return inputComponent(el as HTMLInputElement, style)
    case 'textarea':
      return make(
        'textarea',
        {
          label: el.getAttribute('aria-label') || '',
          placeholder: el.getAttribute('placeholder') || '',
          rows: Number(el.getAttribute('rows')) || 4,
        },
        style,
      )
    case 'select': {
      const options: SelectOption[] = Array.from(el.querySelectorAll('option')).map((o) => ({
        label: (o.textContent ?? '').trim(),
        value: o.getAttribute('value') ?? (o.textContent ?? '').trim(),
      }))
      return make('select', { label: el.getAttribute('aria-label') || '', placeholder: 'Select…', options }, style)
    }
    case 'a':
      if (looksLikeButton(el)) return make('button', { text: text || 'Button', variant: buttonVariant(el) }, style)
      break
  }

  // Structural element with element children -> container.
  if (CONTAINER_TAGS.has(tag) || hasElementChildren(el)) {
    const children = convertChildren(el, lookup)
    if (children.length === 0 && text) {
      return make('paragraph', { text }, style)
    }
    const direction = style?.flexDirection === 'row' ? 'horizontal' : 'vertical'
    return { ...make('container', { label: '', direction }, withContainerDefaults(style)), children }
  }

  // Leaf text element.
  if ((TEXT_TAGS.has(tag) || tag === 'a' || tag === 'div') && text) {
    return make('paragraph', { text }, style)
  }
  return null
}

/**
 * The web/native renderers give every container a default border, padding and
 * gap (the "fieldset" look). Raw HTML cards don't have that, so for an imported
 * container we pin those to 0 unless the source CSS set them — keeping the
 * rendered card flush with the original markup.
 */
function withContainerDefaults(style?: ComponentStyle): ComponentStyle {
  const s: ComponentStyle = { ...style }
  if (s.borderWidth === undefined) s.borderWidth = 0
  if (s.paddingTop === undefined) s.paddingTop = 0
  if (s.paddingRight === undefined) s.paddingRight = 0
  if (s.paddingBottom === undefined) s.paddingBottom = 0
  if (s.paddingLeft === undefined) s.paddingLeft = 0
  if (s.gap === undefined) s.gap = 0
  return s
}

function buttonVariant(el: Element): string {
  const cls = el.getAttribute('class') ?? ''
  return /\b(secondary|outline|ghost|link)\b/i.test(cls) ? 'secondary' : 'primary'
}

/** Convert an element's children (elements + significant text nodes) to components. */
function convertChildren(parent: Element, lookup: CssLookup): FormComponent[] {
  const out: FormComponent[] = []
  for (const node of Array.from(parent.childNodes)) {
    if (node.nodeType === 3) {
      const text = (node.textContent ?? '').trim()
      if (text) out.push(make('paragraph', { text }))
    } else if (node.nodeType === 1) {
      const comp = convertElement(node as Element, lookup)
      if (comp) out.push(comp)
    }
  }
  return out
}

/* ================================== entry ================================== */

/**
 * Parse a pasted HTML/CSS card into the form template's component tree.
 * Returns an empty array if nothing convertible was found.
 */
export function htmlToComponents(html: string): FormComponent[] {
  const doc = new DOMParser().parseFromString(html, 'text/html')
  const lookup = buildCssLookup(doc)
  return convertChildren(doc.body, lookup)
}
