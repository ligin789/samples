import { useMemo, useState } from 'react'
import type { SelectOption, ValidationRules } from '../types/schema'
import { registry } from '../definitions/registry'
import type { PropField } from '../definitions/registry'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { setFormName, setImportOpen, updateComponent } from '../state/actions'
import { StyleEditor } from './StyleEditor'
import { analyzeJson, getByPath } from '../utils/json'
import type { DataField } from '../utils/json'
import { findById } from '../utils/tree'

/* ------------------------------ value editors ----------------------------- */

function OptionsEditor({
  value,
  onChange,
}: {
  value: SelectOption[]
  onChange: (next: SelectOption[]) => void
}) {
  const update = (i: number, patch: Partial<SelectOption>) =>
    onChange(value.map((o, idx) => (idx === i ? { ...o, ...patch } : o)))
  return (
    <div className="options-editor">
      {value.map((o, i) => (
        <div key={i} className="options-row">
          <input
            placeholder="Label"
            value={o.label}
            onChange={(e) => update(i, { label: e.target.value })}
          />
          <input
            placeholder="Value"
            value={o.value}
            onChange={(e) => update(i, { value: e.target.value })}
          />
          <button title="Remove" onClick={() => onChange(value.filter((_, idx) => idx !== i))}>
            ✕
          </button>
        </div>
      ))}
      <button
        className="btn btn-sm"
        onClick={() => onChange([...value, { label: `Option ${value.length + 1}`, value: `option${value.length + 1}` }])}
      >
        + Add option
      </button>
    </div>
  )
}

function EditorField({
  field,
  value,
  onChange,
}: {
  field: PropField
  value: unknown
  onChange: (v: unknown) => void
}) {
  switch (field.editor) {
    case 'text':
      return (
        <input
          placeholder={field.placeholder}
          value={(value as string) ?? ''}
          onChange={(e) => onChange(e.target.value)}
        />
      )
    case 'textarea':
      return <textarea rows={4} value={(value as string) ?? ''} onChange={(e) => onChange(e.target.value)} />
    case 'number':
      return (
        <input
          type="number"
          value={value === undefined || value === null ? '' : String(value)}
          onChange={(e) => onChange(e.target.value === '' ? undefined : Number(e.target.value))}
        />
      )
    case 'checkbox':
      return (
        <input type="checkbox" checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} />
      )
    case 'select':
      return (
        <select value={(value as string) ?? ''} onChange={(e) => onChange(e.target.value)}>
          {field.options?.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      )
    case 'options':
      return <OptionsEditor value={(value as SelectOption[]) ?? []} onChange={onChange} />
  }
}

function FieldRow({
  field,
  value,
  onChange,
}: {
  field: PropField
  value: unknown
  onChange: (v: unknown) => void
}) {
  const isCheckbox = field.editor === 'checkbox'
  return (
    <div className={`prop-row${isCheckbox ? ' prop-row-inline' : ''}`}>
      <label>{field.label}</label>
      <EditorField field={field} value={value} onChange={onChange} />
    </div>
  )
}

/* ------------------------------- binding tab ------------------------------ */

function collectBindablePaths(fields: DataField[]): DataField[] {
  const out: DataField[] = []
  const walk = (list: DataField[]) => {
    for (const f of list) {
      if (f.type === 'object' || (f.type === 'array' && f.children)) {
        walk(f.children ?? [])
      } else {
        out.push(f)
      }
    }
  }
  walk(fields)
  return out
}

function BindingTab({ componentId }: { componentId: string }) {
  const component = useAppSelector((s) => findById(s.schema.components, componentId))
  const sampleData = useAppSelector((s) => s.schema.sampleData)
  const dispatch = useAppDispatch()
  const [filter, setFilter] = useState('')

  const paths = useMemo(
    () => (sampleData === undefined ? [] : collectBindablePaths(analyzeJson(sampleData))),
    [sampleData],
  )
  if (!component) return null

  const binding = component.binding ?? ''
  const sampleValue = binding ? getByPath(sampleData, binding) : undefined
  const filtered = paths.filter((p) => p.path.toLowerCase().includes(filter.toLowerCase()))

  return (
    <div className="panel-section">
      <div className="prop-row">
        <label>Data path</label>
        <input
          placeholder="e.g. user.address.city"
          value={binding}
          onChange={(e) => dispatch(updateComponent(componentId, { binding: e.target.value }))}
        />
      </div>
      {binding && (
        <div className="binding-sample">
          Sample value:{' '}
          <code>{sampleValue === undefined ? '— not found in data —' : JSON.stringify(sampleValue)}</code>
        </div>
      )}
      {binding && (
        <button className="btn btn-sm" onClick={() => dispatch(updateComponent(componentId, { binding: '' }))}>
          Clear binding
        </button>
      )}

      <div className="panel-subtitle">Available fields</div>
      {sampleData === undefined ? (
        <div className="panel-empty">
          <p className="muted">Import an API JSON to pick binding paths visually.</p>
          <button className="btn btn-sm" onClick={() => dispatch(setImportOpen(true))}>
            Import API JSON
          </button>
        </div>
      ) : (
        <>
          <input
            className="panel-search"
            placeholder="Filter paths…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
          <div className="binding-list">
            {filtered.map((p) => (
              <button
                key={p.path}
                className={`binding-path${p.path === binding ? ' active' : ''}`}
                onClick={() => dispatch(updateComponent(componentId, { binding: p.path }))}
              >
                <span className="data-key">{p.path}</span>
                <span className={`data-type data-type-${p.type}`}>{p.type}</span>
              </button>
            ))}
            {filtered.length === 0 && <p className="muted">No matching paths.</p>}
          </div>
        </>
      )}
    </div>
  )
}

/* --------------------------------- panel ---------------------------------- */

export function PropertiesPanel() {
  const selectedId = useAppSelector((s) => s.selectedId)
  const component = useAppSelector((s) =>
    s.selectedId ? findById(s.schema.components, s.selectedId) : null,
  )
  const formName = useAppSelector((s) => s.schema.name)
  const dispatch = useAppDispatch()
  const [tab, setTab] = useState<'props' | 'binding' | 'validation' | 'style'>('props')

  if (!selectedId || !component) {
    return (
      <aside className="right-panel">
        <div className="panel-tabs">
          <button className="active">Form</button>
        </div>
        <div className="panel-body">
          <div className="prop-row">
            <label>Form name</label>
            <input value={formName} onChange={(e) => dispatch(setFormName(e.target.value))} />
          </div>
          <p className="muted">Select a component on the canvas to edit its properties, data binding and validation.</p>
        </div>
      </aside>
    )
  }

  const def = registry[component.type]
  const showBinding = def.bindable
  const showValidation = def.validationFields.length > 0
  const activeTab = (tab === 'binding' && !showBinding) || (tab === 'validation' && !showValidation) ? 'props' : tab

  return (
    <aside className="right-panel">
      <div className="panel-tabs">
        <button className={activeTab === 'props' ? 'active' : ''} onClick={() => setTab('props')}>
          Properties
        </button>
        {showBinding && (
          <button className={activeTab === 'binding' ? 'active' : ''} onClick={() => setTab('binding')}>
            Binding
          </button>
        )}
        {showValidation && (
          <button className={activeTab === 'validation' ? 'active' : ''} onClick={() => setTab('validation')}>
            Validation
          </button>
        )}
        <button className={activeTab === 'style' ? 'active' : ''} onClick={() => setTab('style')}>
          Style
        </button>
      </div>
      <div className="panel-body">
        <div className="selected-chip">
          <span className="palette-icon">{def.icon}</span> {def.label}
          <code className="muted">{component.id}</code>
        </div>

        {activeTab === 'props' && (
          <div className="panel-section">
            {def.propFields.length === 0 && <p className="muted">This component has no properties.</p>}
            {def.propFields.map((f) => (
              <FieldRow
                key={f.key}
                field={f}
                value={component.props[f.key]}
                onChange={(v) => dispatch(updateComponent(component.id, { props: { [f.key]: v } }))}
              />
            ))}
          </div>
        )}

        {activeTab === 'binding' && <BindingTab componentId={component.id} />}

        {activeTab === 'style' && (
          <StyleEditor
            componentId={component.id}
            style={component.style}
            isContainer={component.type === 'container'}
          />
        )}

        {activeTab === 'validation' && (
          <div className="panel-section">
            {def.validationFields.map((f) => (
              <FieldRow
                key={f.key}
                field={f}
                value={component.validation?.[f.key as keyof ValidationRules]}
                onChange={(v) => dispatch(updateComponent(component.id, { validation: { [f.key]: v } }))}
              />
            ))}
          </div>
        )}
      </div>
    </aside>
  )
}
