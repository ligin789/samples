import { useMemo, useState } from 'react'
import { useDraggable } from '@dnd-kit/core'
import { componentDefinitions } from '../definitions/registry'
import { createComponent } from '../definitions/registry'
import type { ComponentDefinition } from '../definitions/registry'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { addComponent, setComponents, setImportOpen } from '../state/actions'
import { analyzeJson, componentFromDataField, generateComponentsFromFields } from '../utils/json'
import type { DataField } from '../utils/json'

/* ------------------------------ palette item ------------------------------ */

function PaletteItem({ def }: { def: ComponentDefinition }) {
  const rootCount = useAppSelector((s) => s.schema.components.length)
  const dispatch = useAppDispatch()
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `palette-${def.type}`,
    data: { kind: 'palette', type: def.type },
  })

  return (
    <button
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={`palette-item${isDragging ? ' dragging' : ''}`}
      title={`Click or drag to add ${def.label}`}
      onClick={() => dispatch(addComponent(createComponent(def.type), null, rootCount))}
    >
      <span className="palette-icon">{def.icon}</span>
      <span>{def.label}</span>
    </button>
  )
}

function ComponentsTab() {
  const [query, setQuery] = useState('')
  const groups = useMemo(() => {
    const q = query.trim().toLowerCase()
    const matches = componentDefinitions.filter((d) => d.label.toLowerCase().includes(q))
    return ['Fields', 'Static', 'Layout']
      .map((cat) => ({ cat, defs: matches.filter((d) => d.category === cat) }))
      .filter((g) => g.defs.length > 0)
  }, [query])

  return (
    <>
      <input
        className="panel-search"
        placeholder="Search components…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      {groups.map((g) => (
        <div key={g.cat} className="palette-group">
          <div className="palette-group-title">{g.cat}</div>
          <div className="palette-grid">
            {g.defs.map((def) => (
              <PaletteItem key={def.type} def={def} />
            ))}
          </div>
        </div>
      ))}
    </>
  )
}

/* -------------------------------- data tree ------------------------------- */

const TYPE_BADGE: Record<string, string> = {
  string: 'abc',
  number: '123',
  boolean: 'T/F',
  date: 'date',
  array: '[ ]',
  object: '{ }',
  null: 'null',
}

function DataLeaf({ field }: { field: DataField }) {
  const rootCount = useAppSelector((s) => s.schema.components.length)
  const dispatch = useAppDispatch()
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `data-${field.path}`,
    data: { kind: 'data', field },
  })

  return (
    <button
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={`data-leaf${isDragging ? ' dragging' : ''}`}
      title={`${field.path} — click or drag to add a bound field`}
      onClick={() => dispatch(addComponent(componentFromDataField(field), null, rootCount))}
    >
      <span className={`data-type data-type-${field.type}`}>{TYPE_BADGE[field.type]}</span>
      <span className="data-key">{field.key}</span>
    </button>
  )
}

function DataNode({ field, depth }: { field: DataField; depth: number }) {
  const [open, setOpen] = useState(depth < 2)
  const hasChildren = (field.children?.length ?? 0) > 0

  if (!hasChildren) {
    return (
      <div className="data-row" style={{ paddingLeft: depth * 14 }}>
        <DataLeaf field={field} />
      </div>
    )
  }
  return (
    <div>
      <div className="data-row" style={{ paddingLeft: depth * 14 }}>
        <button className="data-branch" onClick={() => setOpen(!open)}>
          <span className="data-caret">{open ? '▾' : '▸'}</span>
          <span className={`data-type data-type-${field.type}`}>{TYPE_BADGE[field.type]}</span>
          <span className="data-key">{field.key}</span>
        </button>
      </div>
      {open && field.children!.map((c) => <DataNode key={c.path} field={c} depth={depth + 1} />)}
    </div>
  )
}

function DataTab() {
  const sampleData = useAppSelector((s) => s.schema.sampleData)
  const hasComponents = useAppSelector((s) => s.schema.components.length > 0)
  const dispatch = useAppDispatch()

  const fields = useMemo(
    () => (sampleData === undefined ? [] : analyzeJson(sampleData)),
    [sampleData],
  )

  if (sampleData === undefined) {
    return (
      <div className="panel-empty">
        <p>No data source yet.</p>
        <p className="muted">
          Import an API JSON response — the builder analyzes its structure so you can bind fields
          and auto-generate the form.
        </p>
        <button className="btn btn-primary" onClick={() => dispatch(setImportOpen(true))}>
          Import API JSON
        </button>
      </div>
    )
  }

  const generate = () => {
    if (hasComponents && !confirm('Replace the current form with fields generated from the data?'))
      return
    dispatch(setComponents(generateComponentsFromFields(fields)))
  }

  return (
    <>
      <div className="data-actions">
        <button className="btn btn-primary btn-sm" onClick={generate}>
          ⚡ Generate form
        </button>
        <button className="btn btn-sm" onClick={() => dispatch(setImportOpen(true))}>
          Update data
        </button>
      </div>
      <p className="muted data-hint">Click or drag a field onto the canvas to create a bound input.</p>
      <div className="data-tree">
        {fields.map((f) => (
          <DataNode key={f.path} field={f} depth={0} />
        ))}
      </div>
    </>
  )
}

/* --------------------------------- palette -------------------------------- */

export function Palette() {
  const [tab, setTab] = useState<'components' | 'data'>('components')
  return (
    <aside className="left-panel">
      <div className="panel-tabs">
        <button className={tab === 'components' ? 'active' : ''} onClick={() => setTab('components')}>
          Components
        </button>
        <button className={tab === 'data' ? 'active' : ''} onClick={() => setTab('data')}>
          Data
        </button>
      </div>
      <div className="panel-body">{tab === 'components' ? <ComponentsTab /> : <DataTab />}</div>
    </aside>
  )
}
