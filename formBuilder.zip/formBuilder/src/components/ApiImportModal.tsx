import { useState } from 'react'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { setComponents, setImportOpen, setSampleData } from '../state/actions'
import { analyzeJson, generateComponentsFromFields } from '../utils/json'

const SAMPLE_JSON = {
  user: {
    firstName: 'Ava',
    lastName: 'Stone',
    email: 'ava.stone@example.com',
    phone: '+1 555 0100',
    birthDate: '1992-04-18',
    newsletter: true,
    address: {
      street: '12 Harbor Way',
      city: 'San Diego',
      zip: '92101',
      country: 'USA',
    },
  },
  membership: ['basic', 'premium', 'enterprise'],
  creditLimit: 2500,
  notes: 'Existing customer since 2019. Prefers email contact and quarterly billing.',
}

export function ApiImportModal() {
  const open = useAppSelector((s) => s.importOpen)
  const hasComponents = useAppSelector((s) => s.schema.components.length > 0)
  const dispatch = useAppDispatch()
  const setOpen = (value: boolean) => dispatch(setImportOpen(value))

  const [text, setText] = useState('')
  const [url, setUrl] = useState('')
  const [generate, setGenerate] = useState(true)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (!open) return null

  const fetchUrl = async () => {
    if (!url.trim()) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch(url.trim())
      if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`)
      const data = await res.json()
      setText(JSON.stringify(data, null, 2))
    } catch (e) {
      setError(
        `Could not fetch: ${e instanceof Error ? e.message : String(e)}. ` +
          'If this is a CORS error, copy the response body and paste it below instead.',
      )
    } finally {
      setLoading(false)
    }
  }

  const apply = () => {
    let data: unknown
    try {
      data = JSON.parse(text)
    } catch (e) {
      setError(`Invalid JSON: ${e instanceof Error ? e.message : String(e)}`)
      return
    }
    dispatch(setSampleData(data))
    if (generate) {
      if (hasComponents && !confirm('Replace the current form with generated fields?')) {
        setOpen(false)
        return
      }
      dispatch(setComponents(generateComponentsFromFields(analyzeJson(data))))
    }
    setError('')
    setOpen(false)
  }

  return (
    <div className="modal-backdrop" onClick={() => setOpen(false)}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Import API JSON</h3>
          <button className="icon-btn" onClick={() => setOpen(false)}>
            ✕
          </button>
        </div>
        <div className="modal-body">
          <p className="muted">
            Paste an API response (or fetch one). The builder studies its structure, exposes every
            field for data binding, and can generate the whole form for you.
          </p>

          <div className="url-row">
            <input
              placeholder="https://api.example.com/users/1"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && fetchUrl()}
            />
            <button className="btn" onClick={fetchUrl} disabled={loading}>
              {loading ? 'Fetching…' : 'Fetch'}
            </button>
          </div>

          <textarea
            className="json-input"
            rows={14}
            placeholder='{ "user": { "firstName": "Ava", ... } }'
            value={text}
            onChange={(e) => setText(e.target.value)}
            spellCheck={false}
          />

          {error && <div className="modal-error">{error}</div>}

          <div className="modal-footer">
            <button className="btn btn-sm" onClick={() => setText(JSON.stringify(SAMPLE_JSON, null, 2))}>
              Load sample
            </button>
            <label className="ff-check-row generate-check">
              <input type="checkbox" checked={generate} onChange={(e) => setGenerate(e.target.checked)} />
              <span>Auto-generate form fields from this data</span>
            </label>
            <div className="spacer" />
            <button className="btn" onClick={() => setOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={apply} disabled={!text.trim()}>
              Import
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
