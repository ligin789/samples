import { useEffect, useState } from 'react'
import type { FormSchema } from '../types/schema'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { replaceSchema } from '../state/actions'

/**
 * The "JSON" tab — the output template. This exact JSON is what the
 * React Native renderer consumes (see native/FormRenderer.native.tsx).
 * It is editable: paste a template and Apply to round-trip.
 */
export function JsonPanel() {
  const schema = useAppSelector((s) => s.schema)
  const dispatch = useAppDispatch()
  const [text, setText] = useState('')
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)

  const current = JSON.stringify(schema, null, 2)
  useEffect(() => {
    setText(current)
    setError('')
  }, [current])

  const dirty = text !== current

  const applyChanges = () => {
    try {
      const parsed = JSON.parse(text) as FormSchema
      if (!Array.isArray(parsed.components)) throw new Error('"components" must be an array')
      dispatch(replaceSchema(parsed))
      setError('')
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }

  const copy = async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <main className="json-panel">
      <div className="json-toolbar">
        <span className="muted">
          Form template — feed this JSON to the web or React Native renderer.
        </span>
        <div className="spacer" />
        <button className="btn btn-sm" onClick={copy}>
          {copied ? '✓ Copied' : 'Copy'}
        </button>
        {dirty && (
          <>
            <button className="btn btn-sm" onClick={() => setText(current)}>
              Reset
            </button>
            <button className="btn btn-primary btn-sm" onClick={applyChanges}>
              Apply changes
            </button>
          </>
        )}
      </div>
      {error && <div className="modal-error">{error}</div>}
      <textarea
        className="json-editor"
        value={text}
        onChange={(e) => setText(e.target.value)}
        spellCheck={false}
      />
    </main>
  )
}
