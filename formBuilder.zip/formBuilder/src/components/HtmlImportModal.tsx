import { useMemo, useState } from 'react'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { setComponents, setHtmlImportOpen } from '../state/actions'
import { htmlToComponents } from '../utils/htmlImport'

const SAMPLE_HTML = `<div style="max-width: 360px; padding: 24px; border: 1px solid #e2e8f0; border-radius: 16px; background: #ffffff;">
  <h2 style="font-size: 20px; font-weight: 700; color: #0f172a; margin-bottom: 6px;">Pro Plan</h2>
  <p style="color: #64748b; font-size: 14px; margin-bottom: 16px;">
    Everything you need to ship faster, billed monthly.
  </p>
  <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 20px;">
    <span style="font-size: 32px; font-weight: 700; color: #4f46e5;">$29</span>
    <span style="color: #94a3b8; font-size: 14px;">/ month</span>
  </div>
  <div style="display: flex; gap: 10px;">
    <button style="background: #4f46e5; color: #ffffff; padding: 10px 18px; border-radius: 8px; font-weight: 600;">
      Get started
    </button>
    <button class="secondary" style="background: #ffffff; color: #4f46e5; border: 1px solid #4f46e5; padding: 10px 18px; border-radius: 8px; font-weight: 600;">
      Learn more
    </button>
  </div>
</div>`

export function HtmlImportModal() {
  const open = useAppSelector((s) => s.htmlImportOpen)
  const hasComponents = useAppSelector((s) => s.schema.components.length > 0)
  const dispatch = useAppDispatch()
  const setOpen = (value: boolean) => dispatch(setHtmlImportOpen(value))

  const [text, setText] = useState('')
  const [append, setAppend] = useState(false)
  const [error, setError] = useState('')

  // Live count of what we'll create, so the user sees the parse worked before applying.
  const parsedCount = useMemo(() => {
    if (!text.trim()) return 0
    try {
      return htmlToComponents(text).length
    } catch {
      return 0
    }
  }, [text])

  if (!open) return null

  const apply = () => {
    let components
    try {
      components = htmlToComponents(text)
    } catch (e) {
      setError(`Could not parse HTML: ${e instanceof Error ? e.message : String(e)}`)
      return
    }
    if (components.length === 0) {
      setError('No convertible elements found. Paste a card with HTML tags (div, h2, p, button, …).')
      return
    }
    if (!append && hasComponents && !confirm('Replace the current form with the imported card?')) {
      return
    }
    dispatch(setComponents(components, append))
    setError('')
    setText('')
    setOpen(false)
  }

  return (
    <div className="modal-backdrop" onClick={() => setOpen(false)}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Import HTML / CSS card</h3>
          <button className="icon-btn" onClick={() => setOpen(false)}>
            ✕
          </button>
        </div>
        <div className="modal-body">
          <p className="muted">
            Paste a card you built in plain HTML with inline styles. It's mapped onto the form
            template so it renders the same here and on React Native, and exports as a template.
            Only the shared style subset (spacing, sizing, flex layout, colors, border, font) is
            carried over — shadows, gradients and grid are dropped.
          </p>

          <textarea
            className="json-input"
            rows={14}
            placeholder={'<div style="padding:24px;border-radius:16px;background:#fff;">…</div>'}
            value={text}
            onChange={(e) => setText(e.target.value)}
            spellCheck={false}
          />

          {error && <div className="modal-error">{error}</div>}

          <div className="modal-footer">
            <button className="btn btn-sm" onClick={() => setText(SAMPLE_HTML)}>
              Load sample card
            </button>
            <label className="ff-check-row generate-check">
              <input type="checkbox" checked={append} onChange={(e) => setAppend(e.target.checked)} />
              <span>Append to current form (instead of replacing)</span>
            </label>
            <div className="spacer" />
            {parsedCount > 0 && (
              <span className="muted" style={{ fontSize: 13 }}>
                {parsedCount} component{parsedCount === 1 ? '' : 's'}
              </span>
            )}
            <button className="btn" onClick={() => setOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={apply} disabled={!text.trim()}>
              Import
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
