import type { ComponentStyle } from '../types/schema'
import { useAppDispatch } from '../state/hooks'
import { updateComponent } from '../state/actions'

/* ------------------------------ option lists ------------------------------ */

const DIRECTION = [
  { label: 'Row (horizontal)', value: 'row' },
  { label: 'Column (vertical)', value: 'column' },
]
const JUSTIFY = [
  { label: 'Start', value: 'flex-start' },
  { label: 'Center', value: 'center' },
  { label: 'End', value: 'flex-end' },
  { label: 'Space between', value: 'space-between' },
  { label: 'Space around', value: 'space-around' },
  { label: 'Space evenly', value: 'space-evenly' },
]
const ALIGN = [
  { label: 'Stretch', value: 'stretch' },
  { label: 'Start', value: 'flex-start' },
  { label: 'Center', value: 'center' },
  { label: 'End', value: 'flex-end' },
]
const WRAP = [
  { label: 'No wrap', value: 'nowrap' },
  { label: 'Wrap', value: 'wrap' },
]
const ALIGN_SELF = [
  { label: 'Auto', value: 'auto' },
  { label: 'Stretch', value: 'stretch' },
  { label: 'Start', value: 'flex-start' },
  { label: 'Center', value: 'center' },
  { label: 'End', value: 'flex-end' },
]
const WEIGHT = [
  { label: 'Normal', value: '400' },
  { label: 'Medium', value: '500' },
  { label: 'Semibold', value: '600' },
  { label: 'Bold', value: '700' },
]
const TEXT_ALIGN = [
  { label: 'Left', value: 'left' },
  { label: 'Center', value: 'center' },
  { label: 'Right', value: 'right' },
]

/* -------------------------------- widgets --------------------------------- */

function NumberField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string
  value?: number
  onChange: (v: number | undefined) => void
  placeholder?: string
}) {
  return (
    <div className="prop-row">
      <label>{label}</label>
      <input
        type="number"
        value={value ?? ''}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value === '' ? undefined : Number(e.target.value))}
      />
    </div>
  )
}

function DimField({
  label,
  value,
  onChange,
}: {
  label: string
  value?: number | string
  onChange: (v: number | string | undefined) => void
}) {
  return (
    <div className="prop-row">
      <label>{label}</label>
      <input
        value={value ?? ''}
        placeholder="auto"
        title="A number (px) or any CSS size, e.g. 240 or 50%"
        onChange={(e) => {
          const t = e.target.value.trim()
          if (t === '') onChange(undefined)
          else if (/^\d+$/.test(t)) onChange(Number(t))
          else onChange(t)
        }}
      />
    </div>
  )
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string
  value?: string
  onChange: (v: string | undefined) => void
  options: { label: string; value: string }[]
}) {
  return (
    <div className="prop-row">
      <label>{label}</label>
      <select
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value === '' ? undefined : e.target.value)}
      >
        <option value="">Default</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  )
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string
  value?: string
  onChange: (v: string | undefined) => void
}) {
  const isHex = typeof value === 'string' && /^#[0-9a-fA-F]{3,8}$/.test(value)
  return (
    <div className="prop-row">
      <label>{label}</label>
      <div className="color-row">
        <input
          type="color"
          className="color-swatch"
          value={isHex ? value : '#000000'}
          onChange={(e) => onChange(e.target.value)}
        />
        <input
          className="color-text"
          value={value ?? ''}
          placeholder="#rrggbb"
          onChange={(e) => onChange(e.target.value === '' ? undefined : e.target.value)}
        />
        {value && (
          <button className="color-clear" title="Clear" onClick={() => onChange(undefined)}>
            ✕
          </button>
        )}
      </div>
    </div>
  )
}

function BoxField({
  label,
  sides,
  style,
  set,
}: {
  label: string
  sides: (keyof ComponentStyle)[]
  style: ComponentStyle
  set: (patch: ComponentStyle) => void
}) {
  const abbr = ['Top', 'Right', 'Bottom', 'Left']
  const update = (key: keyof ComponentStyle, raw: string) => {
    const patch: ComponentStyle = {}
    ;(patch as Record<string, unknown>)[key] = raw === '' ? undefined : Number(raw)
    set(patch)
  }
  return (
    <div className="prop-row">
      <label>{label}</label>
      <div className="style-box">
        {sides.map((k, i) => (
          <div key={k} className="style-box-cell">
            <input
              type="number"
              value={(style[k] as number | undefined) ?? ''}
              onChange={(e) => update(k, e.target.value)}
            />
            <span>{abbr[i]}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ------------------------------- the editor ------------------------------- */

export function StyleEditor({
  componentId,
  style,
  isContainer,
}: {
  componentId: string
  style?: ComponentStyle
  isContainer: boolean
}) {
  const dispatch = useAppDispatch()
  const s = style ?? {}
  const set = (patch: ComponentStyle) => dispatch(updateComponent(componentId, { style: patch }))
  const hasStyle = Object.keys(s).length > 0
  const reset = () => {
    const cleared: ComponentStyle = {}
    for (const k of Object.keys(s)) (cleared as Record<string, unknown>)[k] = undefined
    set(cleared)
  }

  return (
    <div className="panel-section">
      {isContainer && (
        <>
          <div className="panel-subtitle">Layout (children)</div>
          <SelectField
            label="Direction"
            value={s.flexDirection}
            options={DIRECTION}
            onChange={(v) => set({ flexDirection: v as ComponentStyle['flexDirection'] })}
          />
          <SelectField
            label="Justify (main axis)"
            value={s.justifyContent}
            options={JUSTIFY}
            onChange={(v) => set({ justifyContent: v as ComponentStyle['justifyContent'] })}
          />
          <SelectField
            label="Align (cross axis)"
            value={s.alignItems}
            options={ALIGN}
            onChange={(v) => set({ alignItems: v as ComponentStyle['alignItems'] })}
          />
          <SelectField
            label="Wrap"
            value={s.flexWrap}
            options={WRAP}
            onChange={(v) => set({ flexWrap: v as ComponentStyle['flexWrap'] })}
          />
          <NumberField label="Gap" value={s.gap} placeholder="0" onChange={(v) => set({ gap: v })} />
        </>
      )}

      <div className="panel-subtitle">Spacing</div>
      <BoxField
        label="Padding"
        sides={['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft']}
        style={s}
        set={set}
      />
      <BoxField
        label="Margin"
        sides={['marginTop', 'marginRight', 'marginBottom', 'marginLeft']}
        style={s}
        set={set}
      />

      <div className="panel-subtitle">Size</div>
      <div className="style-grid2">
        <DimField label="Width" value={s.width} onChange={(v) => set({ width: v })} />
        <DimField label="Height" value={s.height} onChange={(v) => set({ height: v })} />
      </div>
      <SelectField
        label="Align self"
        value={s.alignSelf}
        options={ALIGN_SELF}
        onChange={(v) => set({ alignSelf: v as ComponentStyle['alignSelf'] })}
      />
      <NumberField label="Flex grow" value={s.flex} placeholder="0" onChange={(v) => set({ flex: v })} />

      <div className="panel-subtitle">Appearance</div>
      <ColorField
        label="Background"
        value={s.backgroundColor}
        onChange={(v) => set({ backgroundColor: v })}
      />
      <div className="style-grid2">
        <NumberField label="Border width" value={s.borderWidth} onChange={(v) => set({ borderWidth: v })} />
        <NumberField
          label="Corner radius"
          value={s.borderRadius}
          onChange={(v) => set({ borderRadius: v })}
        />
      </div>
      <ColorField label="Border color" value={s.borderColor} onChange={(v) => set({ borderColor: v })} />

      <div className="panel-subtitle">Text</div>
      <div className="style-grid2">
        <NumberField label="Font size" value={s.fontSize} onChange={(v) => set({ fontSize: v })} />
        <SelectField
          label="Weight"
          value={s.fontWeight}
          options={WEIGHT}
          onChange={(v) => set({ fontWeight: v as ComponentStyle['fontWeight'] })}
        />
      </div>
      <ColorField label="Text color" value={s.color} onChange={(v) => set({ color: v })} />
      <SelectField
        label="Text align"
        value={s.textAlign}
        options={TEXT_ALIGN}
        onChange={(v) => set({ textAlign: v as ComponentStyle['textAlign'] })}
      />

      {hasStyle && (
        <button className="btn btn-sm style-reset" onClick={reset}>
          Reset styles
        </button>
      )}
    </div>
  )
}
