import type { FormSchema } from '../types/schema'
import { emptySchema } from '../types/schema'

const STORAGE_KEY = 'formbuilder.schema'

/** Read the persisted schema, falling back to an empty form on missing/corrupt data. */
export function loadInitialSchema(): FormSchema {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as FormSchema
      if (Array.isArray(parsed.components)) return parsed
    }
  } catch {
    // corrupted storage — start fresh
  }
  return emptySchema()
}

/** Best-effort persistence of the current schema to localStorage. */
export function persistSchema(schema: FormSchema): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(schema))
  } catch {
    // storage full or unavailable — persistence is best-effort
  }
}
