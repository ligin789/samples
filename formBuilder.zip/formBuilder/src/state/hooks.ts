import { useDispatch, useSelector } from 'react-redux'
import type { TypedUseSelectorHook } from 'react-redux'
import type { AppDispatch, RootState } from './store'

/** Typed `useDispatch` that accepts builder thunks as well as plain actions. */
export const useAppDispatch = () => useDispatch<AppDispatch>()

/** Typed `useSelector` bound to the builder state shape. */
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector
