import { applyMiddleware, createStore } from 'redux'
import { thunk } from 'redux-thunk'
import type { ThunkDispatch } from 'redux-thunk'
import type { BuilderAction } from './actions'
import { builderReducer } from './reducer'
import type { BuilderState } from './reducer'
import { persistSchema } from './persistence'

export const store = createStore(builderReducer, applyMiddleware(thunk))

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = ThunkDispatch<BuilderState, unknown, BuilderAction>

// Persist the schema to localStorage whenever it changes (best-effort).
let lastSchema = store.getState().schema
store.subscribe(() => {
  const { schema } = store.getState()
  if (schema !== lastSchema) {
    lastSchema = schema
    persistSchema(schema)
  }
})
