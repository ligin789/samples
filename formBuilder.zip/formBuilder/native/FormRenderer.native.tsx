/**
 * FormRenderer.native.tsx
 * -----------------------
 * Drop-in React Native renderer for templates produced by FormBuilder Studio
 * (the web builder in this repo). Copy this single file into your React
 * Native / Expo project — it only depends on react and react-native core.
 *
 * Usage:
 *   import { FormRenderer, buildInitialValues, buildSubmission, validateAll } from './FormRenderer.native'
 *
 *   const template = await (await fetch('https://your.api/templates/onboarding')).json()
 *   // or: import template from './onboarding.template.json'
 *
 *   const [values, setValues] = useState(() => buildInitialValues(template))
 *   const [errors, setErrors] = useState({})
 *
 *   <FormRenderer
 *     schema={template}
 *     values={values}
 *     errors={errors}
 *     onChange={(key, value) => setValues(v => ({ ...v, [key]: value }))}
 *     onSubmit={() => {
 *       const errs = validateAll(template.components, values)
 *       setErrors(errs)
 *       if (Object.keys(errs).length === 0) {
 *         const payload = buildSubmission(template, values) // nested JSON, bindings applied
 *         // POST payload to your API
 *       }
 *     }}
 *   />
 */
import React from 'react'
import {
  Pressable,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
  type TextStyle,
  type ViewStyle,
} from 'react-native'

/* --------------------------------- schema --------------------------------- */

export type ComponentType =
  | 'textfield'
  | 'textarea'
  | 'number'
  | 'select'
  | 'radio'
  | 'checkbox'
  | 'switch'
  | 'datepicker'
  | 'heading'
  | 'paragraph'
  | 'divider'
  | 'button'
  | 'container'

export interface SelectOption {
  label: string
  value: string
}

export interface ValidationRules {
  required?: boolean
  minLength?: number
  maxLength?: number
  min?: number
  max?: number
  pattern?: string
}

/**
 * Per-component style produced by FormBuilder Studio. A flexbox-based subset
 * that is valid as a React Native `style` (and identical to the web inline style),
 * so the same template renders consistently on web and native.
 */
export interface ComponentStyle {
  marginTop?: number
  marginRight?: number
  marginBottom?: number
  marginLeft?: number
  paddingTop?: number
  paddingRight?: number
  paddingBottom?: number
  paddingLeft?: number
  width?: number | string
  height?: number | string
  flexDirection?: 'row' | 'column'
  justifyContent?:
    | 'flex-start'
    | 'center'
    | 'flex-end'
    | 'space-between'
    | 'space-around'
    | 'space-evenly'
  alignItems?: 'flex-start' | 'center' | 'flex-end' | 'stretch'
  flexWrap?: 'nowrap' | 'wrap'
  gap?: number
  flex?: number
  alignSelf?: 'auto' | 'flex-start' | 'center' | 'flex-end' | 'stretch'
  backgroundColor?: string
  borderWidth?: number
  borderColor?: string
  borderRadius?: number
  fontSize?: number
  fontWeight?: '400' | '500' | '600' | '700'
  color?: string
  textAlign?: 'left' | 'center' | 'right'
}

export interface FormComponent {
  id: string
  type: ComponentType
  props: Record<string, any>
  binding?: string
  validation?: ValidationRules
  style?: ComponentStyle
  children?: FormComponent[]
}

const LAYOUT_KEYS: (keyof ComponentStyle)[] = [
  'flexDirection',
  'justifyContent',
  'alignItems',
  'flexWrap',
  'gap',
]

/** Flex-layout keys — applied to the View that wraps a container's children. */
function layoutStyle(style?: ComponentStyle): ComponentStyle | undefined {
  if (!style) return undefined
  const out: ComponentStyle = {}
  for (const k of LAYOUT_KEYS) if (style[k] !== undefined) (out as any)[k] = style[k]
  return out
}

/** Everything except the flex-layout keys — applied to the container box itself. */
function boxStyle(style?: ComponentStyle): ComponentStyle | undefined {
  if (!style) return undefined
  const out: ComponentStyle = { ...style }
  for (const k of LAYOUT_KEYS) delete out[k]
  return out
}

/**
 * ComponentStyle is the web+native style subset emitted by the builder. Its
 * width/height accept a raw string (valid on web) which RN's strict
 * DimensionValue typing rejects, so cast it to an RN style at the boundary.
 */
type RNStyle = ViewStyle & TextStyle
const rn = (style?: ComponentStyle): RNStyle | undefined =>
  style as unknown as RNStyle | undefined

export interface FormSchema {
  version: string
  name: string
  components: FormComponent[]
  sampleData?: unknown
}

/* ------------------------------ data binding ------------------------------ */

const pathTokens = (path: string) => path.split(/[.[\]]+/).filter(Boolean)

export function getByPath(obj: any, path: string): any {
  let cur = obj
  for (const token of pathTokens(path)) {
    if (cur === null || cur === undefined || typeof cur !== 'object') return undefined
    cur = cur[token]
  }
  return cur
}

export function setByPath(obj: any, path: string, value: any): void {
  const tokens = pathTokens(path)
  let cur = obj
  for (let i = 0; i < tokens.length - 1; i++) {
    const nextIsIndex = /^\d+$/.test(tokens[i + 1])
    if (cur[tokens[i]] === undefined || typeof cur[tokens[i]] !== 'object' || cur[tokens[i]] === null) {
      cur[tokens[i]] = nextIsIndex ? [] : {}
    }
    cur = cur[tokens[i]]
  }
  cur[tokens[tokens.length - 1]] = value
}

const INPUT_TYPES = new Set([
  'textfield',
  'textarea',
  'number',
  'select',
  'radio',
  'checkbox',
  'switch',
  'datepicker',
])

export const valueKeyOf = (c: FormComponent) => c.binding || c.id

export function visitAll(list: FormComponent[], fn: (c: FormComponent) => void): void {
  for (const c of list) {
    fn(c)
    if (c.children) visitAll(c.children, fn)
  }
}

/** Seed form values from defaultValue props and bound sample/API data. */
export function buildInitialValues(
  schema: FormSchema,
  data: unknown = schema.sampleData,
): Record<string, any> {
  const values: Record<string, any> = {}
  visitAll(schema.components, (c) => {
    if (!INPUT_TYPES.has(c.type)) return
    const key = valueKeyOf(c)
    if (c.props.defaultValue !== undefined && c.props.defaultValue !== '') {
      values[key] = c.props.defaultValue
    }
    if (c.binding && data !== undefined) {
      const bound = getByPath(data, c.binding)
      if (bound !== undefined && typeof bound !== 'object') values[key] = bound
    }
  })
  return values
}

/** Assemble the nested submission payload following each component's binding path. */
export function buildSubmission(
  schema: FormSchema,
  values: Record<string, any>,
): Record<string, any> {
  const out: Record<string, any> = {}
  visitAll(schema.components, (c) => {
    if (!INPUT_TYPES.has(c.type)) return
    setByPath(out, c.binding || c.id, values[valueKeyOf(c)] ?? null)
  })
  return out
}

/* -------------------------------- validation ------------------------------- */

export function validateComponent(component: FormComponent, value: any): string | null {
  const rules = component.validation
  if (!rules) return null
  const empty =
    value === undefined || value === null || value === '' || (typeof value === 'boolean' && !value)
  if (rules.required && empty) return 'This field is required'
  if (empty) return null
  if (typeof value === 'string') {
    if (rules.minLength !== undefined && value.length < rules.minLength)
      return `Must be at least ${rules.minLength} characters`
    if (rules.maxLength !== undefined && value.length > rules.maxLength)
      return `Must be at most ${rules.maxLength} characters`
    if (rules.pattern) {
      try {
        if (!new RegExp(rules.pattern).test(value)) return 'Invalid format'
      } catch {}
    }
  }
  const num = typeof value === 'number' ? value : NaN
  if (!Number.isNaN(num)) {
    if (rules.min !== undefined && num < rules.min) return `Must be at least ${rules.min}`
    if (rules.max !== undefined && num > rules.max) return `Must be at most ${rules.max}`
  }
  return null
}

export function validateAll(
  components: FormComponent[],
  values: Record<string, any>,
): Record<string, string> {
  const errors: Record<string, string> = {}
  visitAll(components, (c) => {
    if (!INPUT_TYPES.has(c.type)) return
    const error = validateComponent(c, values[valueKeyOf(c)])
    if (error) errors[valueKeyOf(c)] = error
  })
  return errors
}

/* --------------------------------- renderer -------------------------------- */

interface FieldProps {
  component: FormComponent
  value: any
  error?: string
  onChange: (value: any) => void
  onSubmit?: () => void
}

function Field({ component, value, error, onChange, onSubmit }: FieldProps) {
  const p = component.props
  const requiredMark = component.validation?.required ? <Text style={s.required}> *</Text> : null

  const label = p.label ? (
    <Text style={s.label}>
      {p.label}
      {requiredMark}
    </Text>
  ) : null
  const help = p.helpText ? <Text style={s.help}>{p.helpText}</Text> : null
  const errorText = error ? <Text style={s.error}>{error}</Text> : null

  switch (component.type) {
    case 'textfield':
      return (
        <View style={[s.field, rn(component.style)]}>
          {label}
          <TextInput
            style={[s.input, !!error && s.inputError]}
            placeholder={p.placeholder}
            placeholderTextColor="#94a3b8"
            value={value != null ? String(value) : ''}
            secureTextEntry={p.inputType === 'password'}
            keyboardType={
              p.inputType === 'email'
                ? 'email-address'
                : p.inputType === 'tel'
                  ? 'phone-pad'
                  : p.inputType === 'url'
                    ? 'url'
                    : 'default'
            }
            autoCapitalize={p.inputType === 'email' || p.inputType === 'url' ? 'none' : 'sentences'}
            onChangeText={onChange}
          />
          {help}
          {errorText}
        </View>
      )
    case 'textarea':
      return (
        <View style={[s.field, rn(component.style)]}>
          {label}
          <TextInput
            style={[s.input, s.textarea, !!error && s.inputError]}
            placeholder={p.placeholder}
            placeholderTextColor="#94a3b8"
            value={value != null ? String(value) : ''}
            multiline
            numberOfLines={p.rows || 4}
            onChangeText={onChange}
          />
          {help}
          {errorText}
        </View>
      )
    case 'number':
      return (
        <View style={[s.field, rn(component.style)]}>
          {label}
          <TextInput
            style={[s.input, !!error && s.inputError]}
            placeholder={p.placeholder}
            placeholderTextColor="#94a3b8"
            value={value != null ? String(value) : ''}
            keyboardType="numeric"
            onChangeText={(t) => {
              if (t === '') return onChange(undefined)
              const n = Number(t)
              onChange(Number.isNaN(n) ? t : n)
            }}
          />
          {help}
          {errorText}
        </View>
      )
    case 'select':
    case 'radio': {
      const options: SelectOption[] = p.options ?? []
      return (
        <View style={[s.field, rn(component.style)]}>
          {label}
          <View style={component.type === 'select' ? s.chipRow : undefined}>
            {options.map((o) => {
              const active = value === o.value
              return component.type === 'select' ? (
                <Pressable
                  key={o.value}
                  style={[s.chip, active && s.chipActive]}
                  onPress={() => onChange(o.value)}
                >
                  <Text style={[s.chipText, active && s.chipTextActive]}>{o.label}</Text>
                </Pressable>
              ) : (
                <Pressable key={o.value} style={s.radioRow} onPress={() => onChange(o.value)}>
                  <View style={[s.radioOuter, active && s.radioOuterActive]}>
                    {active && <View style={s.radioInner} />}
                  </View>
                  <Text style={s.optionText}>{o.label}</Text>
                </Pressable>
              )
            })}
          </View>
          {help}
          {errorText}
        </View>
      )
    }
    case 'checkbox':
      return (
        <View style={[s.field, rn(component.style)]}>
          <Pressable style={s.radioRow} onPress={() => onChange(!value)}>
            <View style={[s.checkbox, !!value && s.checkboxActive]}>
              {!!value && <Text style={s.checkmark}>✓</Text>}
            </View>
            <Text style={s.optionText}>
              {p.label}
              {requiredMark}
            </Text>
          </Pressable>
          {help}
          {errorText}
        </View>
      )
    case 'switch':
      return (
        <View style={[s.field, rn(component.style)]}>
          <View style={s.switchRow}>
            <Switch value={!!value} onValueChange={onChange} trackColor={{ true: '#4f46e5' }} />
            <Text style={s.optionText}>{p.label}</Text>
          </View>
          {help}
        </View>
      )
    case 'datepicker':
      // Plain ISO text input keeps this file dependency-free. Swap in
      // @react-native-community/datetimepicker here if you prefer a native picker.
      return (
        <View style={[s.field, rn(component.style)]}>
          {label}
          <TextInput
            style={[s.input, !!error && s.inputError]}
            placeholder="YYYY-MM-DD"
            placeholderTextColor="#94a3b8"
            value={value != null ? String(value).slice(0, 10) : ''}
            onChangeText={onChange}
          />
          {help}
          {errorText}
        </View>
      )
    case 'heading': {
      const sizes: Record<string, number> = { '1': 26, '2': 20, '3': 16 }
      return (
        <Text style={[s.heading, { fontSize: sizes[p.level] ?? 20 }, rn(component.style)]}>{p.text}</Text>
      )
    }
    case 'paragraph':
      return <Text style={[s.paragraph, rn(component.style)]}>{p.text}</Text>
    case 'divider':
      return <View style={[s.divider, rn(component.style)]} />
    case 'button':
      return (
        <Pressable
          style={[s.button, p.variant === 'secondary' && s.buttonSecondary, rn(component.style)]}
          onPress={onSubmit}
        >
          <Text style={[s.buttonText, p.variant === 'secondary' && s.buttonTextSecondary]}>
            {p.text}
          </Text>
        </Pressable>
      )
    default:
      return null
  }
}

interface RendererProps {
  schema: FormSchema
  values: Record<string, any>
  errors?: Record<string, string>
  onChange: (key: string, value: any) => void
  onSubmit?: () => void
}

function RenderList({ components, values, errors, onChange, onSubmit }: Omit<RendererProps, 'schema'> & { components: FormComponent[] }) {
  return (
    <>
      {components.map((c) => {
        if (c.type === 'container') {
          const horizontal = c.style?.flexDirection
            ? c.style.flexDirection === 'row'
            : c.props.direction === 'horizontal'
          return (
            <View key={c.id} style={[s.container, rn(boxStyle(c.style))]}>
              {!!c.props.label && <Text style={s.containerLabel}>{c.props.label}</Text>}
              <View style={[horizontal ? s.containerRow : s.containerCol, rn(layoutStyle(c.style))]}>
                <RenderList
                  components={c.children ?? []}
                  values={values}
                  errors={errors}
                  onChange={onChange}
                  onSubmit={onSubmit}
                />
              </View>
            </View>
          )
        }
        const key = valueKeyOf(c)
        return (
          <Field
            key={c.id}
            component={c}
            value={values[key]}
            error={errors?.[key]}
            onChange={(v) => onChange(key, v)}
            onSubmit={onSubmit}
          />
        )
      })}
    </>
  )
}

export function FormRenderer({ schema, values, errors, onChange, onSubmit }: RendererProps) {
  return (
    <View style={s.form}>
      <RenderList
        components={schema.components}
        values={values}
        errors={errors}
        onChange={onChange}
        onSubmit={onSubmit}
      />
    </View>
  )
}

/* ---------------------------------- styles --------------------------------- */

const s = StyleSheet.create({
  form: { gap: 16 },
  field: { gap: 6 },
  label: { fontWeight: '600', fontSize: 14, color: '#1e293b' },
  required: { color: '#dc2626' },
  help: { fontSize: 12, color: '#64748b' },
  error: { fontSize: 12, color: '#dc2626', fontWeight: '500' },
  input: {
    borderWidth: 1,
    borderColor: '#cbd5e1',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    color: '#1e293b',
    backgroundColor: '#fff',
  },
  inputError: { borderColor: '#dc2626' },
  textarea: { minHeight: 96, textAlignVertical: 'top' },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    borderWidth: 1,
    borderColor: '#cbd5e1',
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 7,
    backgroundColor: '#fff',
  },
  chipActive: { borderColor: '#4f46e5', backgroundColor: '#eef2ff' },
  chipText: { color: '#1e293b', fontSize: 14 },
  chipTextActive: { color: '#4f46e5', fontWeight: '600' },
  radioRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 3 },
  radioOuter: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#cbd5e1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioOuterActive: { borderColor: '#4f46e5' },
  radioInner: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#4f46e5' },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: '#cbd5e1',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  checkboxActive: { backgroundColor: '#4f46e5', borderColor: '#4f46e5' },
  checkmark: { color: '#fff', fontSize: 13, fontWeight: '700' },
  optionText: { fontSize: 15, color: '#1e293b' },
  switchRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  heading: { fontWeight: '700', color: '#0f172a' },
  paragraph: { color: '#64748b', lineHeight: 21 },
  divider: { height: 1, backgroundColor: '#e2e8f0' },
  button: {
    backgroundColor: '#4f46e5',
    borderRadius: 10,
    paddingVertical: 13,
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 28,
  },
  buttonSecondary: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#4f46e5',
  },
  buttonText: { color: '#fff', fontWeight: '600', fontSize: 15 },
  buttonTextSecondary: { color: '#4f46e5' },
  container: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 10,
    padding: 14,
    gap: 10,
  },
  containerLabel: { fontWeight: '700', fontSize: 15, color: '#0f172a' },
  containerCol: { gap: 14 },
  containerRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
})
