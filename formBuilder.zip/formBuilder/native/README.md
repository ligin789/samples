# React Native renderer (iPad)

`FormRenderer.native.tsx` renders templates produced by FormBuilder Studio on
React Native — no extra dependencies, just `react` and `react-native` core
components. Copy the single file into your RN/Expo project.

## How it fits together

```
┌──────────────────────┐   template JSON    ┌──────────────────────────┐
│  FormBuilder Studio  │ ─────────────────► │  iPad app (React Native) │
│  (web, this repo)    │   (export / API)   │  FormRenderer.native.tsx │
└──────────────────────┘                    └──────────────────────────┘
```

1. Design the form in the web builder (drag-drop, bind fields to API JSON paths).
2. Export the template (`Export` button, or copy from the JSON tab). Host it on
   your API or bundle it in the app.
3. Render it on the iPad with `FormRenderer`.

## Example screen

```tsx
import React, { useEffect, useState } from 'react'
import { ActivityIndicator, Alert, SafeAreaView, ScrollView, Text } from 'react-native'
import {
  FormRenderer,
  buildInitialValues,
  buildSubmission,
  validateAll,
  type FormSchema,
} from './FormRenderer.native'

export function FormScreen() {
  const [template, setTemplate] = useState<FormSchema | null>(null)
  const [values, setValues] = useState<Record<string, any>>({})
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    ;(async () => {
      // Template designed in the web builder, served by your API
      const schema: FormSchema = await (await fetch('https://your.api/templates/customer')).json()

      // Optional: bind live record data instead of the design-time sample
      const record = await (await fetch('https://your.api/customers/42')).json()

      setTemplate(schema)
      setValues(buildInitialValues(schema, record)) // second arg defaults to schema.sampleData
    })()
  }, [])

  if (!template) return <ActivityIndicator style={{ flex: 1 }} />

  const handleSubmit = async () => {
    const errs = validateAll(template.components, values)
    setErrors(errs)
    if (Object.keys(errs).length > 0) return

    // Nested payload assembled from each field's binding path,
    // e.g. { user: { address: { city: '…' } } }
    const payload = buildSubmission(template, values)
    await fetch('https://your.api/customers/42', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    Alert.alert('Saved')
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#f1f5f9' }}>
      <ScrollView contentContainerStyle={{ padding: 24, maxWidth: 700, alignSelf: 'center', width: '100%' }}>
        <Text style={{ fontSize: 22, fontWeight: '700', marginBottom: 16 }}>{template.name}</Text>
        <FormRenderer
          schema={template}
          values={values}
          errors={errors}
          onChange={(key, value) => setValues((v) => ({ ...v, [key]: value }))}
          onSubmit={handleSubmit}
        />
      </ScrollView>
    </SafeAreaView>
  )
}
```

## Notes

- **Value keys** — form state is keyed by `component.binding` when set,
  otherwise by `component.id`. `buildSubmission` turns the flat state back into
  nested JSON following the binding paths.
- **Date picker** — rendered as a `YYYY-MM-DD` text input to stay
  dependency-free. Swap in `@react-native-community/datetimepicker` inside the
  `datepicker` case of `Field` for a native picker.
- **Select** — rendered as tappable chips (works well on iPad). Replace with
  `@react-native-picker/picker` or an action sheet if you prefer.
- **Styling** — all styles live in the `StyleSheet.create` block at the bottom
  of the renderer; adjust freely to match your app's design system.
