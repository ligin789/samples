import { FlightSegment, Evtol } from './types';

const today = new Date();
const h = (hour: number, min = 0) => new Date(today.getFullYear(), today.getMonth(), today.getDate(), hour, min);

export const mockFlights: FlightSegment[] = [
  {
    id: 'f1', flightNumber: 'EV-1042', evtolId: 'N401EV', status: 'completed',
    schedule: { start: h(6, 0), end: h(6, 45) }, actual: { start: h(6, 2), end: h(6, 48) },
    origin: 'VTP-DOWNTOWN', destination: 'VTP-AIRPORT', delayMinutes: 3, issues: [], passengers: 4,
  },
  {
    id: 'f2', flightNumber: 'EV-1043', evtolId: 'N401EV', status: 'completed',
    schedule: { start: h(7, 30), end: h(8, 15) }, actual: { start: h(7, 32), end: h(8, 18) },
    origin: 'VTP-AIRPORT', destination: 'VTP-MARINA', delayMinutes: 3, issues: [], passengers: 3,
  },
  {
    id: 'f3', flightNumber: 'EV-1044', evtolId: 'N402EV', status: 'on-time',
    schedule: { start: h(9, 0), end: h(9, 50) },
    origin: 'VTP-DOWNTOWN', destination: 'VTP-SUBURBS', delayMinutes: 0, issues: [], passengers: 5,
  },
  {
    id: 'f4', flightNumber: 'EV-1045', evtolId: 'N402EV', status: 'delayed',
    schedule: { start: h(10, 30), end: h(11, 20) }, actual: { start: h(10, 48), end: h(11, 38) },
    origin: 'VTP-SUBURBS', destination: 'VTP-HOSPITAL', delayMinutes: 18,
    issues: [{ id: 'i1', timestamp: h(10, 25), type: 'weather', description: 'Wind shear advisory in sector 7. Holding pattern required.', resolved: false }],
    passengers: 2,
  },
  {
    id: 'f5', flightNumber: 'EV-1046', evtolId: 'N403EV', status: 'critical',
    schedule: { start: h(8, 15), end: h(9, 0) }, actual: { start: h(8, 15), end: h(9, 45) },
    origin: 'VTP-MARINA', destination: 'VTP-DOWNTOWN', delayMinutes: 45,
    issues: [
      { id: 'i2', timestamp: h(8, 40), type: 'battery', description: 'Battery cell #3 temp exceeding threshold. Emergency protocol initiated.', resolved: false },
      { id: 'i3', timestamp: h(8, 55), type: 'mechanical', description: 'Rotor vibration anomaly detected. Maintenance check required.', resolved: false },
    ],
    passengers: 4,
  },
  {
    id: 'f6', flightNumber: 'EV-1047', evtolId: 'N403EV', status: 'on-time',
    schedule: { start: h(11, 0), end: h(11, 45) },
    origin: 'VTP-DOWNTOWN', destination: 'VTP-AIRPORT', delayMinutes: 0, issues: [], passengers: 3,
  },
  {
    id: 'f7', flightNumber: 'EV-1048', evtolId: 'N404EV', status: 'on-time',
    schedule: { start: h(7, 0), end: h(7, 40) },
    origin: 'VTP-HOSPITAL', destination: 'VTP-DOWNTOWN', delayMinutes: 0, issues: [], passengers: 2,
  },
  {
    id: 'f8', flightNumber: 'EV-1049', evtolId: 'N404EV', status: 'completed',
    schedule: { start: h(8, 30), end: h(9, 10) }, actual: { start: h(8, 30), end: h(9, 10) },
    origin: 'VTP-DOWNTOWN', destination: 'VTP-MARINA', delayMinutes: 0, issues: [], passengers: 5,
  },
  {
    id: 'f9', flightNumber: 'EV-1050', evtolId: 'N405EV', status: 'delayed',
    schedule: { start: h(9, 30), end: h(10, 15) }, actual: { start: h(9, 42), end: h(10, 27) },
    origin: 'VTP-AIRPORT', destination: 'VTP-SUBURBS', delayMinutes: 12,
    issues: [{ id: 'i4', timestamp: h(9, 28), type: 'airspace', description: 'Temporary flight restriction in zone B-4. Rerouting required.', resolved: true }],
    passengers: 4,
  },
  {
    id: 'f10', flightNumber: 'EV-1051', evtolId: 'N405EV', status: 'on-time',
    schedule: { start: h(11, 30), end: h(12, 15) },
    origin: 'VTP-SUBURBS', destination: 'VTP-DOWNTOWN', delayMinutes: 0, issues: [], passengers: 3,
  },
  {
    id: 'f11', flightNumber: 'EV-1052', evtolId: 'N406EV', status: 'on-time',
    schedule: { start: h(6, 30), end: h(7, 15) },
    origin: 'VTP-AIRPORT', destination: 'VTP-HOSPITAL', delayMinutes: 0, issues: [], passengers: 2,
  },
  {
    id: 'f12', flightNumber: 'EV-1053', evtolId: 'N406EV', status: 'on-time',
    schedule: { start: h(8, 0), end: h(8, 50) },
    origin: 'VTP-HOSPITAL', destination: 'VTP-MARINA', delayMinutes: 0, issues: [], passengers: 4,
  },
];

export const mockEvtols: Evtol[] = [
  { id: 'N401EV', model: 'Joby S4', status: 'available', currentLocation: 'VTP-MARINA', batteryLevel: 72, totalFlightHours: 1240 },
  { id: 'N402EV', model: 'Joby S4', status: 'active', currentLocation: 'IN-FLIGHT', batteryLevel: 58, totalFlightHours: 890 },
  { id: 'N403EV', model: 'Lilium Jet', status: 'active', currentLocation: 'IN-FLIGHT', batteryLevel: 31, totalFlightHours: 2100 },
  { id: 'N404EV', model: 'Archer Midnight', status: 'available', currentLocation: 'VTP-DOWNTOWN', batteryLevel: 91, totalFlightHours: 560 },
  { id: 'N405EV', model: 'Archer Midnight', status: 'active', currentLocation: 'IN-FLIGHT', batteryLevel: 45, totalFlightHours: 780 },
  { id: 'N406EV', model: 'Joby S4', status: 'active', currentLocation: 'IN-FLIGHT', batteryLevel: 67, totalFlightHours: 1560 },
  { id: 'N407EV', model: 'Lilium Jet', status: 'available', currentLocation: 'VTP-AIRPORT', batteryLevel: 95, totalFlightHours: 320 },
  { id: 'N408EV', model: 'Joby S4', status: 'charging', currentLocation: 'VTP-DOWNTOWN', batteryLevel: 22, totalFlightHours: 1890 },
  { id: 'N409EV', model: 'Archer Midnight', status: 'maintenance', currentLocation: 'VTP-AIRPORT', batteryLevel: 0, totalFlightHours: 2400 },
];

export const EVTOL_IDS = [...new Set(mockFlights.map(f => f.evtolId))].sort();

export const TIMELINE_START_HOUR = 6;
export const TIMELINE_END_HOUR = 13;
export const PIXELS_PER_MINUTE = 4;
export const TRACK_HEIGHT = 52;
export const SIDEBAR_WIDTH = 180;
export const HEADER_HEIGHT = 48;
