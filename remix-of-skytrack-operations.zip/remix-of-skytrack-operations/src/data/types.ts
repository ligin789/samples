export type FlightStatus = 'on-time' | 'delayed' | 'critical' | 'completed';
export type EvtolStatus = 'active' | 'available' | 'maintenance' | 'charging';

export interface FlightIssue {
  id: string;
  timestamp: Date;
  type: 'mechanical' | 'weather' | 'battery' | 'airspace' | 'passenger';
  description: string;
  resolved: boolean;
}

export interface FlightSegment {
  id: string;
  flightNumber: string;
  evtolId: string;
  status: FlightStatus;
  schedule: { start: Date; end: Date };
  actual?: { start: Date; end: Date };
  origin: string;
  destination: string;
  delayMinutes: number;
  issues: FlightIssue[];
  passengers: number;
}

export interface Evtol {
  id: string;
  model: string;
  status: EvtolStatus;
  currentLocation: string;
  batteryLevel: number;
  totalFlightHours: number;
}

export const STATUS_CLASSES = {
  'on-time': { border: 'status-ontime', bg: 'status-bg-ontime', text: 'status-text-ontime', dot: 'status-dot-ontime' },
  'delayed': { border: 'status-delayed', bg: 'status-bg-delayed', text: 'status-text-delayed', dot: 'status-dot-delayed' },
  'critical': { border: 'status-critical', bg: 'status-bg-critical', text: 'status-text-critical', dot: 'status-dot-critical' },
  'completed': { border: 'status-completed', bg: 'status-bg-completed', text: 'status-text-completed', dot: 'status-dot-completed' },
} as const;
