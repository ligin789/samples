import { FlightStatus } from '@/data/types';
import { RefreshCw } from 'lucide-react';

interface ToolbarProps {
  statusFilter: FlightStatus | 'all';
  onFilterChange: (status: FlightStatus | 'all') => void;
  flightCount: number;
  issueCount: number;
}

const filters: { value: FlightStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'ALL' },
  { value: 'on-time', label: 'ON TIME' },
  { value: 'delayed', label: 'DELAYED' },
  { value: 'critical', label: 'CRITICAL' },
  { value: 'completed', label: 'COMPLETED' },
];

export default function Toolbar({ statusFilter, onFilterChange, flightCount, issueCount }: ToolbarProps) {
  return (
    <div
      className="d-flex align-items-center justify-content-between px-3"
      style={{ height: 48, background: 'var(--gantt-card)', borderBottom: '1px solid var(--gantt-border)' }}
    >
      <div className="d-flex align-items-center gap-3">
        <h1 className="font-mono text-data mb-0 text-uppercase" style={{ letterSpacing: '0.1em', color: 'var(--gantt-fg)' }}>
          FLIGHT OPS // COMMAND
        </h1>
        <div style={{ width: 1, height: 20, background: 'var(--gantt-border)' }} />
        <div className="d-flex align-items-center gap-1">
          {filters.map(f => (
            <button
              key={f.value}
              onClick={() => onFilterChange(f.value)}
              className="btn btn-sm font-mono text-uppercase border-0"
              style={{
                fontSize: 10,
                letterSpacing: '0.05em',
                padding: '4px 10px',
                borderRadius: 4,
                background: statusFilter === f.value ? 'var(--gantt-accent-light)' : 'transparent',
                color: statusFilter === f.value ? 'var(--gantt-accent)' : 'var(--gantt-muted-fg)',
              }}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>
      <div className="d-flex align-items-center gap-3">
        <div className="d-flex align-items-center gap-3 font-mono text-label" style={{ color: 'var(--gantt-muted-fg)' }}>
          <span>{flightCount} FLIGHTS</span>
          {issueCount > 0 && (
            <span style={{ color: 'var(--status-critical)' }}>{issueCount} ISSUES</span>
          )}
        </div>
        <div style={{ width: 1, height: 20, background: 'var(--gantt-border)' }} />
        <RefreshCw
          className="cursor-pointer"
          style={{ width: 14, height: 14, color: 'var(--gantt-muted-fg)', cursor: 'pointer' }}
        />
      </div>
    </div>
  );
}
