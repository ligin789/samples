import { STATUS_CLASSES, type FlightStatus } from '@/data/types';
import { TRACK_HEIGHT, SIDEBAR_WIDTH } from '@/data/mockData';
import { Battery } from 'lucide-react';
import { type Evtol } from '@/data/types';

interface FlightSidebarProps {
  evtolIds: string[];
  evtols: Evtol[];
  flightsByEvtol: Record<string, { status: FlightStatus; count: number }>;
}

export default function FlightSidebar({ evtolIds, evtols, flightsByEvtol }: FlightSidebarProps) {
  return (
    <div
      style={{
        width: SIDEBAR_WIDTH,
        position: 'sticky',
        left: 0,
        zIndex: 10,
        background: 'var(--gantt-surface)',
        borderRight: '1px solid var(--gantt-border)',
        flexShrink: 0,
      }}
    >
      {evtolIds.map((evtolId) => {
        const evtol = evtols.find(e => e.id === evtolId);
        const info = flightsByEvtol[evtolId];
        const statusCls = info ? STATUS_CLASSES[info.status] : STATUS_CLASSES['on-time'];

        return (
          <div
            key={evtolId}
            className="d-flex flex-column justify-content-center px-3"
            style={{ height: TRACK_HEIGHT, borderBottom: '1px solid var(--gantt-border)' }}
          >
            <div className="d-flex align-items-center gap-2">
              <div
                className={statusCls.dot}
                style={{ width: 6, height: 6, borderRadius: '50%' }}
              />
              <span className="font-mono text-data fw-semibold" style={{ color: 'var(--gantt-fg)' }}>{evtolId}</span>
            </div>
            {evtol && (
              <div className="d-flex align-items-center gap-2 mt-1">
                <span className="text-label" style={{ color: 'var(--gantt-muted-fg)' }}>{evtol.model}</span>
                <div className="d-flex align-items-center gap-1 text-label" style={{ color: 'var(--gantt-muted-fg)' }}>
                  <Battery style={{ width: 10, height: 10 }} />
                  <span>{evtol.batteryLevel}%</span>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
