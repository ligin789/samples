import { FlightSegment, Evtol, STATUS_CLASSES } from '@/data/types';
import { X, AlertTriangle, CheckCircle, ArrowRight, MapPin, Users, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

interface DetailPanelProps {
  segment: FlightSegment | null;
  evtols: Evtol[];
  onClose: () => void;
  onReassign: (segmentId: string, newEvtolId: string) => void;
  onResolveIssue: (segmentId: string, issueId: string) => void;
}

const fmt = (d: Date) => `${d.getHours().toString().padStart(2, '0')}.${d.getMinutes().toString().padStart(2, '0')}`;

export default function DetailPanel({ segment, evtols, onClose, onReassign, onResolveIssue }: DetailPanelProps) {
  const [showReassign, setShowReassign] = useState(false);

  if (!segment) return null;

  const statusCls = STATUS_CLASSES[segment.status];
  const availableEvtols = evtols.filter(e => e.status === 'available' && e.id !== segment.evtolId);
  const hasUnresolved = segment.issues.some(i => !i.resolved);

  return (
    <AnimatePresence>
      <motion.div
        key="detail-panel"
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'tween', duration: 0.4, ease: [0.2, 0, 0, 1] }}
        className="position-fixed d-flex flex-column overflow-auto"
        style={{
          right: 0,
          top: 0,
          bottom: 0,
          width: 380,
          background: 'var(--gantt-card)',
          borderLeft: '1px solid var(--gantt-border)',
          zIndex: 50,
          boxShadow: 'var(--shadow-panel)',
        }}
      >
        {/* Header */}
        <div className="d-flex align-items-center justify-content-between p-3" style={{ borderBottom: '1px solid var(--gantt-border)' }}>
          <div className="d-flex align-items-center gap-2">
            <div className={statusCls.dot} style={{ width: 8, height: 8, borderRadius: '50%' }} />
            <span className="font-mono text-header fw-bold" style={{ color: 'var(--gantt-fg)' }}>{segment.flightNumber}</span>
          </div>
          <button
            onClick={onClose}
            className="btn btn-sm p-1 border-0"
            style={{ background: 'transparent' }}
            onMouseOver={(e) => (e.currentTarget.style.background = 'var(--gantt-muted)')}
            onMouseOut={(e) => (e.currentTarget.style.background = 'transparent')}
          >
            <X style={{ width: 16, height: 16, color: 'var(--gantt-muted-fg)' }} />
          </button>
        </div>

        {/* Status Banner */}
        <div
          className={`mx-3 mt-3 p-3 rounded ${statusCls.bg}`}
          style={{ borderLeft: '4px solid' }}
        >
          <span className={`font-mono text-label text-uppercase ${statusCls.text} ${statusCls.border}`} style={{ letterSpacing: '0.05em' }}>
            {segment.status.replace('-', ' ')}
          </span>
          {segment.delayMinutes > 0 && (
            <span className={`ms-2 font-mono text-label ${statusCls.text}`}>
              +{segment.delayMinutes} MIN DELAY
            </span>
          )}
        </div>

        {/* Flight Details */}
        <div className="p-3 d-flex flex-column gap-3">
          {/* Route */}
          <div className="d-flex align-items-start gap-3">
            <div className="d-flex flex-column align-items-center">
              <MapPin style={{ width: 14, height: 14, color: 'var(--gantt-accent)' }} />
              <div style={{ width: 1, height: 24, background: 'var(--gantt-border)' }} />
              <MapPin style={{ width: 14, height: 14, color: 'var(--gantt-accent)' }} />
            </div>
            <div className="d-flex flex-column gap-3">
              <div>
                <div className="text-label text-uppercase" style={{ color: 'var(--gantt-muted-fg)' }}>ORIGIN</div>
                <div className="font-mono text-data" style={{ color: 'var(--gantt-fg)' }}>{segment.origin}</div>
              </div>
              <div>
                <div className="text-label text-uppercase" style={{ color: 'var(--gantt-muted-fg)' }}>DESTINATION</div>
                <div className="font-mono text-data" style={{ color: 'var(--gantt-fg)' }}>{segment.destination}</div>
              </div>
            </div>
          </div>

          {/* Times */}
          <div className="row g-2">
            <div className="col-6">
              <div className="p-3 rounded" style={{ background: 'var(--gantt-muted)' }}>
                <div className="text-label text-uppercase" style={{ color: 'var(--gantt-muted-fg)' }}>SCHEDULED</div>
                <div className="font-mono text-data" style={{ color: 'var(--gantt-fg)' }}>
                  {fmt(segment.schedule.start)} → {fmt(segment.schedule.end)}
                </div>
              </div>
            </div>
            {segment.actual && (
              <div className="col-6">
                <div className="p-3 rounded" style={{ background: 'var(--gantt-muted)' }}>
                  <div className="text-label text-uppercase" style={{ color: 'var(--gantt-muted-fg)' }}>ACTUAL</div>
                  <div className="font-mono text-data" style={{ color: 'var(--gantt-fg)' }}>
                    {fmt(segment.actual.start)} → {fmt(segment.actual.end)}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Aircraft */}
          <div className="p-3 rounded d-flex align-items-center justify-content-between" style={{ background: 'var(--gantt-muted)' }}>
            <div>
              <div className="text-label text-uppercase" style={{ color: 'var(--gantt-muted-fg)' }}>AIRCRAFT</div>
              <div className="font-mono text-data" style={{ color: 'var(--gantt-fg)' }}>{segment.evtolId}</div>
            </div>
            <div className="d-flex align-items-center gap-2">
              <Users style={{ width: 12, height: 12, color: 'var(--gantt-muted-fg)' }} />
              <span className="font-mono text-label" style={{ color: 'var(--gantt-muted-fg)' }}>{segment.passengers} PAX</span>
            </div>
          </div>

          {/* Issues */}
          {segment.issues.length > 0 && (
            <div className="d-flex flex-column gap-2">
              <div className="text-label text-uppercase" style={{ color: 'var(--gantt-muted-fg)', letterSpacing: '0.05em' }}>ISSUE LOG</div>
              {segment.issues.map(issue => (
                <div
                  key={issue.id}
                  className={`p-3 rounded ${issue.resolved ? '' : 'status-bg-critical'}`}
                  style={{
                    background: issue.resolved ? 'var(--gantt-muted)' : undefined,
                    borderLeft: `2px solid ${issue.resolved ? 'var(--status-completed)' : 'var(--status-critical)'}`,
                  }}
                >
                  <div className="d-flex align-items-center justify-content-between mb-1">
                    <div className="d-flex align-items-center gap-2">
                      {issue.resolved ? (
                        <CheckCircle style={{ width: 12, height: 12, color: 'var(--status-completed)' }} />
                      ) : (
                        <AlertTriangle style={{ width: 12, height: 12, color: 'var(--status-critical)' }} />
                      )}
                      <span className="font-mono text-uppercase" style={{ fontSize: 10, color: 'var(--gantt-muted-fg)' }}>
                        {issue.type} · {fmt(issue.timestamp)}
                      </span>
                    </div>
                    {!issue.resolved && (
                      <button
                        onClick={() => onResolveIssue(segment.id, issue.id)}
                        className="btn btn-sm p-0 border-0 font-mono text-uppercase"
                        style={{ fontSize: 10, color: 'var(--gantt-accent)', background: 'transparent' }}
                      >
                        RESOLVE
                      </button>
                    )}
                  </div>
                  <p className="mb-0" style={{ fontSize: 11, color: 'rgba(26,35,50,0.8)', lineHeight: 1.6 }}>{issue.description}</p>
                </div>
              ))}
            </div>
          )}

          {/* Reassign */}
          {hasUnresolved && (
            <div className="d-flex flex-column gap-2">
              <button
                onClick={() => setShowReassign(!showReassign)}
                className="btn w-100 d-flex align-items-center justify-content-center gap-2 font-mono text-label text-uppercase"
                style={{
                  padding: 12,
                  borderRadius: 6,
                  background: 'var(--gantt-accent-light)',
                  border: '1px solid rgba(0,102,255,0.2)',
                  color: 'var(--gantt-accent)',
                  letterSpacing: '0.05em',
                }}
              >
                <Zap style={{ width: 14, height: 14 }} />
                REASSIGN EVTOL
              </button>

              <AnimatePresence>
                {showReassign && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    style={{ overflow: 'hidden' }}
                    className="d-flex flex-column gap-1"
                  >
                    {availableEvtols.length === 0 ? (
                      <div className="p-3 rounded text-center text-label" style={{ background: 'var(--gantt-muted)', color: 'var(--gantt-muted-fg)' }}>
                        NO AVAILABLE AIRCRAFT
                      </div>
                    ) : (
                      availableEvtols.map(evtol => (
                        <button
                          key={evtol.id}
                          onClick={() => {
                            onReassign(segment.id, evtol.id);
                            setShowReassign(false);
                          }}
                          className="btn w-100 p-3 rounded d-flex align-items-center justify-content-between border-0"
                          style={{ background: 'var(--gantt-muted)' }}
                          onMouseOver={(e) => (e.currentTarget.style.background = 'var(--gantt-surface-raised)')}
                          onMouseOut={(e) => (e.currentTarget.style.background = 'var(--gantt-muted)')}
                        >
                          <div className="d-flex align-items-center gap-2">
                            <span className="font-mono text-data" style={{ color: 'var(--gantt-fg)' }}>{evtol.id}</span>
                            <span className="text-label" style={{ color: 'var(--gantt-muted-fg)' }}>{evtol.model}</span>
                          </div>
                          <div className="d-flex align-items-center gap-3">
                            <span className="text-label" style={{ color: 'var(--gantt-muted-fg)' }}>{evtol.currentLocation.replace('VTP-', '')}</span>
                            <span className="font-mono text-label" style={{ color: 'var(--status-ontime)' }}>{evtol.batteryLevel}%</span>
                            <ArrowRight style={{ width: 12, height: 12, color: 'var(--gantt-muted-fg)' }} />
                          </div>
                        </button>
                      ))
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
