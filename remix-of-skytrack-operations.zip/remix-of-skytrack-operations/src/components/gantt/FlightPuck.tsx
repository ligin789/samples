import { useCallback, useMemo } from 'react';
import { FlightSegment, STATUS_CLASSES } from '@/data/types';
import { PIXELS_PER_MINUTE, TRACK_HEIGHT } from '@/data/mockData';
import { AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

interface FlightPuckProps {
  segment: FlightSegment;
  timelineStartMs: number;
  isSelected: boolean;
  onClick: (segment: FlightSegment) => void;
}

const formatTime = (d: Date) => {
  const hh = d.getHours().toString().padStart(2, '0');
  const mm = d.getMinutes().toString().padStart(2, '0');
  return `${hh}.${mm}`;
};

export default function FlightPuck({ segment, timelineStartMs, isSelected, onClick }: FlightPuckProps) {
  const { left, width } = useMemo(() => {
    const start = segment.actual?.start || segment.schedule.start;
    const end = segment.actual?.end || segment.schedule.end;
    const l = ((start.getTime() - timelineStartMs) / 60000) * PIXELS_PER_MINUTE;
    const w = ((end.getTime() - start.getTime()) / 60000) * PIXELS_PER_MINUTE;
    return { left: Math.max(0, l), width: Math.max(40, w) };
  }, [segment, timelineStartMs]);

  const statusCls = STATUS_CLASSES[segment.status];
  const hasIssues = segment.issues.length > 0 && segment.issues.some(i => !i.resolved);

  const handleClick = useCallback(() => onClick(segment), [onClick, segment]);

  return (
    <motion.div
      layoutId={segment.id}
      className={`position-absolute d-flex align-items-center gap-2 px-3 rounded puck ${statusCls.border} ${statusCls.bg} ${isSelected ? 'puck-selected' : ''}`}
      style={{
        left,
        width,
        height: TRACK_HEIGHT - 12,
        top: 6,
        borderLeft: '4px solid',
        cursor: 'pointer',
        pointerEvents: 'auto',
      }}
      onClick={handleClick}
      transition={{ type: 'tween', duration: 0.2, ease: [0.2, 0, 0, 1] }}
      title={`${segment.flightNumber} · ${formatTime(segment.schedule.start)} → ${formatTime(segment.schedule.end)}`}
    >
      <div className="d-flex flex-column flex-grow-1" style={{ minWidth: 0 }}>
        <span className={`font-mono text-uppercase ${statusCls.text}`} style={{ fontSize: 10, lineHeight: 1 }}>
          {segment.flightNumber}
        </span>
        <span className="text-truncate" style={{ fontSize: 11, color: 'var(--gantt-fg)', lineHeight: 1.2 }}>
          {segment.origin.replace('VTP-', '')} → {segment.destination.replace('VTP-', '')}
        </span>
      </div>
      {hasIssues && (
        <AlertTriangle className="flex-shrink-0 animate-pulse-glow" style={{ width: 14, height: 14, color: 'var(--status-critical)' }} />
      )}
      {segment.delayMinutes > 5 && (
        <span className={`font-mono flex-shrink-0 ${statusCls.text}`} style={{ fontSize: 9 }}>
          +{segment.delayMinutes}m
        </span>
      )}
    </motion.div>
  );
}
