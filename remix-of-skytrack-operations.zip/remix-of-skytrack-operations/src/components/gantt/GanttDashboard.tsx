import { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { FlightSegment, FlightStatus } from '@/data/types';
import { mockFlights, mockEvtols, PIXELS_PER_MINUTE, TRACK_HEIGHT, SIDEBAR_WIDTH, HEADER_HEIGHT, TIMELINE_START_HOUR, TIMELINE_END_HOUR } from '@/data/mockData';
import TimelineHeader from '@/components/gantt/TimelineHeader';
import FlightSidebar from '@/components/gantt/FlightSidebar';
import FlightPuck from '@/components/gantt/FlightPuck';
import NowIndicator from '@/components/gantt/NowIndicator';
import DetailPanel from '@/components/gantt/DetailPanel';
import Toolbar from '@/components/gantt/Toolbar';
import { AnimatePresence } from 'framer-motion';

export default function GanttDashboard() {
  const [flights, setFlights] = useState<FlightSegment[]>(mockFlights);
  const [selectedFlight, setSelectedFlight] = useState<FlightSegment | null>(null);
  const [statusFilter, setStatusFilter] = useState<FlightStatus | 'all'>('all');
  const [scrollLeft, setScrollLeft] = useState(0);
  const canvasRef = useRef<HTMLDivElement>(null);

  const today = new Date();
  const timelineStartMs = new Date(today.getFullYear(), today.getMonth(), today.getDate(), TIMELINE_START_HOUR, 0).getTime();
  const totalMinutes = (TIMELINE_END_HOUR - TIMELINE_START_HOUR) * 60;
  const canvasWidth = totalMinutes * PIXELS_PER_MINUTE;

  const filteredFlights = useMemo(() => {
    if (statusFilter === 'all') return flights;
    return flights.filter(f => f.status === statusFilter);
  }, [flights, statusFilter]);

  const evtolIds = useMemo(() => {
    const ids = [...new Set(filteredFlights.map(f => f.evtolId))].sort();
    return ids;
  }, [filteredFlights]);

  const flightsByEvtol = useMemo(() => {
    const map: Record<string, { status: FlightStatus; count: number }> = {};
    for (const id of evtolIds) {
      const ef = filteredFlights.filter(f => f.evtolId === id);
      const critical = ef.find(f => f.status === 'critical');
      const delayed = ef.find(f => f.status === 'delayed');
      const active = ef.find(f => f.status === 'on-time');
      const status: FlightStatus = critical ? 'critical' : delayed ? 'delayed' : active ? 'on-time' : 'completed';
      map[id] = { status, count: ef.length };
    }
    return map;
  }, [evtolIds, filteredFlights]);

  const issueCount = useMemo(() => flights.filter(f => f.issues.some(i => !i.resolved)).length, [flights]);

  const handleSelect = useCallback((segment: FlightSegment) => {
    setSelectedFlight(prev => prev?.id === segment.id ? null : segment);
  }, []);

  const handleClose = useCallback(() => setSelectedFlight(null), []);

  const handleReassign = useCallback((segmentId: string, newEvtolId: string) => {
    setFlights(prev => prev.map(f => {
      if (f.id === segmentId) {
        const updated = { ...f, evtolId: newEvtolId };
        setSelectedFlight(updated);
        return updated;
      }
      return f;
    }));
  }, []);

  const handleResolveIssue = useCallback((segmentId: string, issueId: string) => {
    setFlights(prev => prev.map(f => {
      if (f.id === segmentId) {
        const updated = {
          ...f,
          issues: f.issues.map(i => i.id === issueId ? { ...i, resolved: true } : i),
        };
        const allResolved = updated.issues.every(i => i.resolved);
        if (allResolved && updated.status === 'critical') updated.status = 'delayed';
        if (allResolved && updated.status === 'delayed' && updated.delayMinutes <= 5) updated.status = 'on-time';
        setSelectedFlight(updated);
        return updated;
      }
      return f;
    }));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setFlights(prev => prev.map(f => {
        if (f.status === 'delayed' && Math.random() > 0.9) {
          return { ...f, delayMinutes: f.delayMinutes + 1 };
        }
        return f;
      }));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollLeft(e.currentTarget.scrollLeft);
  }, []);

  const gridLines = useMemo(() => {
    const lines: number[] = [];
    for (let h = TIMELINE_START_HOUR; h <= TIMELINE_END_HOUR; h++) {
      for (let m = 0; m < 60; m += 15) {
        if (h === TIMELINE_END_HOUR && m > 0) break;
        lines.push(((h - TIMELINE_START_HOUR) * 60 + m) * PIXELS_PER_MINUTE);
      }
    }
    return lines;
  }, []);

  return (
    <div className="vh-100 d-flex flex-column overflow-hidden" style={{ background: 'var(--gantt-bg)' }}>
      <Toolbar
        statusFilter={statusFilter}
        onFilterChange={setStatusFilter}
        flightCount={filteredFlights.length}
        issueCount={issueCount}
      />

      <div className="flex-grow-1 d-flex overflow-hidden">
        {/* Sidebar */}
        <div className="d-flex flex-column flex-shrink-0" style={{ width: SIDEBAR_WIDTH, borderRight: '1px solid var(--gantt-border)' }}>
          <div className="d-flex align-items-center px-3 font-mono text-uppercase" style={{ height: HEADER_HEIGHT, borderBottom: '1px solid var(--gantt-border)', fontSize: 10, letterSpacing: '0.1em', color: 'var(--gantt-muted-fg)' }}>
            AIRCRAFT
          </div>
          <div className="flex-grow-1 overflow-auto">
            <FlightSidebar evtolIds={evtolIds} evtols={mockEvtols} flightsByEvtol={flightsByEvtol} />
          </div>
        </div>

        {/* Canvas area */}
        <div className="flex-grow-1 overflow-auto" onScroll={handleScroll} ref={canvasRef}>
          <div style={{ width: canvasWidth, minHeight: '100%' }}>
            <TimelineHeader scrollLeft={scrollLeft} />

            <div className="position-relative" style={{ minHeight: evtolIds.length * TRACK_HEIGHT }}>
              {/* Grid lines */}
              {gridLines.map((left, i) => (
                <div
                  key={i}
                  className="position-absolute"
                  style={{
                    left,
                    top: 0,
                    bottom: 0,
                    borderRight: '1px solid rgba(223,227,232,0.3)',
                    height: evtolIds.length * TRACK_HEIGHT,
                    pointerEvents: 'none',
                  }}
                />
              ))}

              {/* Track backgrounds */}
              {evtolIds.map((_, i) => (
                <div
                  key={i}
                  className="position-absolute"
                  style={{
                    left: 0,
                    right: 0,
                    top: i * TRACK_HEIGHT,
                    height: TRACK_HEIGHT,
                    background: i % 2 === 1 ? 'rgba(232,236,240,0.1)' : 'transparent',
                    pointerEvents: 'none',
                  }}
                />
              ))}

              {/* Pucks */}
              {evtolIds.map((evtolId, trackIdx) => (
                filteredFlights
                  .filter(f => f.evtolId === evtolId)
                  .map(segment => (
                    <div key={segment.id} className="position-absolute" style={{ top: trackIdx * TRACK_HEIGHT, left: 0, right: 0, height: TRACK_HEIGHT, zIndex: 10, pointerEvents: 'none' }}>
                      <FlightPuck
                        segment={segment}
                        timelineStartMs={timelineStartMs}
                        isSelected={selectedFlight?.id === segment.id}
                        onClick={handleSelect}
                      />
                    </div>
                  ))
              ))}

              {/* Now line */}
              <NowIndicator />
            </div>
          </div>
        </div>
      </div>

      {/* Detail Panel */}
      <AnimatePresence>
        {selectedFlight && (
          <DetailPanel
            segment={selectedFlight}
            evtols={mockEvtols}
            onClose={handleClose}
            onReassign={handleReassign}
            onResolveIssue={handleResolveIssue}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
