import { useMemo } from 'react';
import { PIXELS_PER_MINUTE, TIMELINE_START_HOUR, TIMELINE_END_HOUR, HEADER_HEIGHT } from '@/data/mockData';

export default function TimelineHeader({ scrollLeft }: { scrollLeft: number }) {
  const ticks = useMemo(() => {
    const result: { label: string; left: number; isMajor: boolean }[] = [];
    for (let h = TIMELINE_START_HOUR; h <= TIMELINE_END_HOUR; h++) {
      for (let m = 0; m < 60; m += 15) {
        if (h === TIMELINE_END_HOUR && m > 0) break;
        const totalMin = (h - TIMELINE_START_HOUR) * 60 + m;
        const left = totalMin * PIXELS_PER_MINUTE;
        const isMajor = m === 0;
        const label = isMajor
          ? `${h.toString().padStart(2, '0')}.00`
          : `${h.toString().padStart(2, '0')}.${m.toString().padStart(2, '0')}`;
        result.push({ label, left, isMajor });
      }
    }
    return result;
  }, []);

  return (
    <div
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 20,
        background: 'var(--gantt-card)',
        borderBottom: '1px solid var(--gantt-border)',
        height: HEADER_HEIGHT,
      }}
    >
      <div className="position-relative h-100" style={{ width: ticks[ticks.length - 1].left + 100 }}>
        {ticks.map((tick) => (
          <div
            key={tick.label}
            className="position-absolute d-flex flex-column justify-content-end"
            style={{ left: tick.left, top: 0, height: '100%' }}
          >
            <div
              style={{
                borderLeft: `1px solid ${tick.isMajor ? 'rgba(107,118,133,0.3)' : 'var(--gantt-border)'}`,
                height: tick.isMajor ? '100%' : 12,
              }}
            />
            <span
              className="font-mono position-absolute"
              style={{
                bottom: 4,
                transform: 'translateX(-50%)',
                fontSize: tick.isMajor ? 11 : 9,
                color: tick.isMajor ? 'rgba(26,35,50,0.7)' : 'rgba(107,118,133,0.5)',
              }}
            >
              {tick.isMajor ? tick.label : tick.label.split('.')[1]}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
