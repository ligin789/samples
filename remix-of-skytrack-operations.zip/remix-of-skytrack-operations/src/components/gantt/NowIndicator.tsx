import { useMemo, useEffect, useState } from 'react';
import { PIXELS_PER_MINUTE, TIMELINE_START_HOUR } from '@/data/mockData';

export default function NowIndicator() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(interval);
  }, []);

  // Force demo time to 09:30 so indicator is always visible
  const demoNow = useMemo(() => {
    const d = new Date();
    d.setHours(9, 30, 0, 0);
    return d;
  }, []);

  const left = useMemo(() => {
    const today = new Date();
    const startOfTimeline = new Date(today.getFullYear(), today.getMonth(), today.getDate(), TIMELINE_START_HOUR, 0);
    const diffMin = (demoNow.getTime() - startOfTimeline.getTime()) / 60000;
    return diffMin * PIXELS_PER_MINUTE;
  }, [demoNow]);

  if (left < 0) return null;

  return (
    <div className="now-indicator" style={{ left, pointerEvents: 'none' }}>
      <div
        className="position-absolute rounded-circle"
        style={{
          top: -4,
          left: '50%',
          transform: 'translateX(-50%)',
          width: 8,
          height: 8,
          background: 'var(--status-critical)',
        }}
      />
      <span
        className="font-mono position-absolute text-nowrap"
        style={{
          top: -20,
          left: '50%',
          transform: 'translateX(-50%)',
          fontSize: 9,
          color: 'var(--status-critical)',
        }}
      >
        {now.getHours().toString().padStart(2, '0')}.{now.getMinutes().toString().padStart(2, '0')}
      </span>
    </div>
  );
}
