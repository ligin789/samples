import GanttDashboard from "@/components/gantt/GanttDashboard";

const Index = () => <GanttDashboard />;

export default Index;
