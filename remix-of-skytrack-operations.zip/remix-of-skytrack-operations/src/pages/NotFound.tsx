import { useLocation } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="d-flex min-vh-100 align-items-center justify-content-center" style={{ background: 'var(--gantt-muted)' }}>
      <div className="text-center">
        <h1 className="mb-3 fw-bold" style={{ fontSize: '2.5rem' }}>404</h1>
        <p className="mb-3 fs-5" style={{ color: 'var(--gantt-muted-fg)' }}>Oops! Page not found</p>
        <a href="/" className="text-decoration-underline" style={{ color: 'var(--gantt-accent)' }}>
          Return to Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;
