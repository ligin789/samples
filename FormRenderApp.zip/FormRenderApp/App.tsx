/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import { useState } from 'react';
import { Provider } from 'react-redux';
import { StatusBar, StyleSheet, useColorScheme, View } from 'react-native';
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';

import { store } from './src/store';
import type { FormSchema } from './src/renderer/FormRenderer';
import { TemplateInputScreen } from './src/features/template/TemplateInputScreen';
import { RenderedFormScreen } from './src/features/template/RenderedFormScreen';

function App() {
  const isDarkMode = useColorScheme() === 'dark';

  return (
    <Provider store={store}>
      <SafeAreaProvider>
        <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
        <AppContent />
      </SafeAreaProvider>
    </Provider>
  );
}

/**
 * Minimal two-screen flow: paste a template, then view it rendered.
 * The loaded schema doubles as the route — null means we're on the paste
 * screen. Swap this for @react-navigation if the app grows more screens.
 */
function AppContent() {
  const safeAreaInsets = useSafeAreaInsets();
  const [schema, setSchema] = useState<FormSchema | null>(null);

  return (
    <View style={[styles.container, { paddingTop: safeAreaInsets.top }]}>
      {schema ? (
        <RenderedFormScreen schema={schema} onBack={() => setSchema(null)} />
      ) : (
        <TemplateInputScreen onLoad={setSchema} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
