import { applyMiddleware, createStore, type Reducer } from 'redux';
import { thunk } from 'redux-thunk';

import { rootReducer } from './rootReducer';
import type { RootState } from './types';

/**
 * Classic Redux store wired with the standalone redux-thunk middleware.
 *
 * Note 1: `createStore` is flagged @deprecated in Redux 5 (the team now
 * recommends Redux Toolkit's configureStore), but it is fully functional.
 * We use it deliberately for the classic thunk setup.
 *
 * Note 2: Redux 5's `combineReducers` infers `PreloadedState` as `never`
 * for reducers typed with a narrow (discriminated-union) action type, which
 * trips up `createStore`'s overloads. Casting the combined reducer to a
 * plain `Reducer<RootState>` sidesteps that purely-typing issue without
 * changing any runtime behaviour or losing type-safety in the reducers.
 */
export const store = createStore(
  rootReducer as unknown as Reducer<RootState>,
  applyMiddleware(thunk),
);
