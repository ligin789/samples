import {
  useDispatch,
  useSelector,
  type TypedUseSelectorHook,
} from 'react-redux';

import type { AppDispatch, RootState } from './types';

/**
 * Pre-typed versions of the react-redux hooks. Use these throughout the app
 * instead of the plain `useDispatch` / `useSelector` so dispatch knows about
 * thunks and selectors know the state shape.
 */
export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
