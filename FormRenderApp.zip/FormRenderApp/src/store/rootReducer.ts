import { combineReducers } from 'redux';

import { formReducer } from '../features/form/reducer';

/**
 * Combine all feature reducers here. Add new slices as the app grows.
 */
export const rootReducer = combineReducers({
  form: formReducer,
});
