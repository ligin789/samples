import type { Action } from 'redux';
import type { ThunkAction, ThunkDispatch } from 'redux-thunk';

import type { rootReducer } from './rootReducer';

/** Shape of the entire Redux state tree, derived from the root reducer. */
export type RootState = ReturnType<typeof rootReducer>;

/**
 * Dispatch type that understands thunks (functions) in addition to plain
 * action objects. Use this anywhere you call `dispatch`.
 */
export type AppDispatch = ThunkDispatch<RootState, unknown, Action>;

/**
 * Helper type for writing thunks. Example:
 *
 *   export const loadThing = (): AppThunk => async (dispatch, getState) => { ... }
 *
 * Use `AppThunk<Promise<void>>` when the thunk is async and you want to await it.
 */
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action
>;
