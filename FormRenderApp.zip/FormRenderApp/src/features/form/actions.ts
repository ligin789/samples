import type { AppThunk } from '../../store/types';
import type { FormValues } from './types';

/* ------------------------------------------------------------------ */
/* Action type constants                                              */
/* ------------------------------------------------------------------ */

export const SET_FIELD = 'form/SET_FIELD';
export const SUBMIT_REQUEST = 'form/SUBMIT_REQUEST';
export const SUBMIT_SUCCESS = 'form/SUBMIT_SUCCESS';
export const SUBMIT_FAILURE = 'form/SUBMIT_FAILURE';
export const RESET = 'form/RESET';

/* ------------------------------------------------------------------ */
/* Action shapes (discriminated union for type-safe reducers)         */
/* ------------------------------------------------------------------ */

interface SetFieldAction {
  type: typeof SET_FIELD;
  payload: { field: keyof FormValues; value: string };
}

interface SubmitRequestAction {
  type: typeof SUBMIT_REQUEST;
}

interface SubmitSuccessAction {
  type: typeof SUBMIT_SUCCESS;
}

interface SubmitFailureAction {
  type: typeof SUBMIT_FAILURE;
  payload: string;
}

interface ResetAction {
  type: typeof RESET;
}

export type FormAction =
  | SetFieldAction
  | SubmitRequestAction
  | SubmitSuccessAction
  | SubmitFailureAction
  | ResetAction;

/* ------------------------------------------------------------------ */
/* Plain action creators                                              */
/* ------------------------------------------------------------------ */

export const setField = (
  field: keyof FormValues,
  value: string,
): SetFieldAction => ({
  type: SET_FIELD,
  payload: { field, value },
});

export const resetForm = (): ResetAction => ({ type: RESET });

/* ------------------------------------------------------------------ */
/* Thunk: async form submission                                       */
/* ------------------------------------------------------------------ */

/**
 * A redux-thunk action creator. Instead of returning a plain action it
 * returns a function that receives `dispatch` and `getState`, so it can run
 * async work (an API call here, simulated) and dispatch multiple actions.
 */
export const submitForm = (): AppThunk<Promise<void>> => {
  return async (dispatch, getState) => {
    dispatch({ type: SUBMIT_REQUEST });

    try {
      const { values } = getState().form;

      // Pretend to POST the form to a server.
      await fakeSubmitRequest(values);

      dispatch({ type: SUBMIT_SUCCESS });
    } catch (err) {
      dispatch({
        type: SUBMIT_FAILURE,
        payload: err instanceof Error ? err.message : 'Submission failed',
      });
    }
  };
};

/** Stand-in for a real network request. Replace with your API call. */
function fakeSubmitRequest(values: FormValues): Promise<void> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!values.name.trim()) {
        reject(new Error('Name is required'));
      } else if (!values.email.includes('@')) {
        reject(new Error('A valid email is required'));
      } else {
        resolve();
      }
    }, 800);
  });
}
