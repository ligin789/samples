import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { resetForm, setField, submitForm } from './actions';

/**
 * Demo screen wired to the Redux store. It reads form state via
 * `useAppSelector` and dispatches the async `submitForm` thunk via
 * `useAppDispatch` to prove the thunk middleware is working.
 */
export function FormScreen() {
  const dispatch = useAppDispatch();
  const { values, submitting, error, submitted } = useAppSelector(
    state => state.form,
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sign up</Text>

      <Text style={styles.label}>Name</Text>
      <TextInput
        style={styles.input}
        value={values.name}
        onChangeText={text => dispatch(setField('name', text))}
        placeholder="Jane Doe"
        autoCapitalize="words"
      />

      <Text style={styles.label}>Email</Text>
      <TextInput
        style={styles.input}
        value={values.email}
        onChangeText={text => dispatch(setField('email', text))}
        placeholder="jane@example.com"
        keyboardType="email-address"
        autoCapitalize="none"
      />

      {error ? <Text style={styles.error}>{error}</Text> : null}
      {submitted ? <Text style={styles.success}>Submitted! 🎉</Text> : null}

      <TouchableOpacity
        style={[styles.button, submitting && styles.buttonDisabled]}
        disabled={submitting}
        onPress={() => dispatch(submitForm())}
      >
        {submitting ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.buttonText}>Submit</Text>
        )}
      </TouchableOpacity>

      <TouchableOpacity onPress={() => dispatch(resetForm())}>
        <Text style={styles.reset}>Reset</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: 'center' },
  title: { fontSize: 28, fontWeight: '700', marginBottom: 24 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 6, marginTop: 12 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#2563eb',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 24,
  },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  reset: { textAlign: 'center', color: '#2563eb', marginTop: 16 },
  error: { color: '#dc2626', marginTop: 12 },
  success: { color: '#16a34a', marginTop: 12 },
});
