import type { Reducer } from 'redux';

import {
  RESET,
  SET_FIELD,
  SUBMIT_FAILURE,
  SUBMIT_REQUEST,
  SUBMIT_SUCCESS,
  type FormAction,
} from './actions';
import type { FormState } from './types';

const initialState: FormState = {
  values: { name: '', email: '' },
  submitting: false,
  error: null,
  submitted: false,
};

export const formReducer: Reducer<FormState, FormAction> = (
  state = initialState,
  action,
): FormState => {
  switch (action.type) {
    case SET_FIELD:
      return {
        ...state,
        values: {
          ...state.values,
          [action.payload.field]: action.payload.value,
        },
        // Editing clears any prior result.
        error: null,
        submitted: false,
      };

    case SUBMIT_REQUEST:
      return { ...state, submitting: true, error: null, submitted: false };

    case SUBMIT_SUCCESS:
      return { ...state, submitting: false, submitted: true };

    case SUBMIT_FAILURE:
      return { ...state, submitting: false, error: action.payload };

    case RESET:
      return initialState;

    default:
      return state;
  }
};
