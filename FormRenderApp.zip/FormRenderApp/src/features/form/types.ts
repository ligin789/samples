export interface FormValues {
  name: string;
  email: string;
}

export interface FormState {
  values: FormValues;
  submitting: boolean;
  error: string | null;
  submitted: boolean;
}
