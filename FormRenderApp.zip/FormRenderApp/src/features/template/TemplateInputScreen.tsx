import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import type { FormSchema } from '../../renderer/FormRenderer';
import { SAMPLE_TEMPLATE } from './sampleTemplate';

interface Props {
  /** Called with the parsed template once the pasted JSON is valid. */
  onLoad: (schema: FormSchema) => void;
}

/**
 * Entry screen. The user pastes the JSON exported from FormBuilder Studio
 * (the web builder's "Export" button). On "Render form" the text is parsed and
 * sanity-checked, then handed to the renderer screen — see RenderedFormScreen.
 */
export function TemplateInputScreen({ onLoad }: Props) {
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleRender = () => {
    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      setError('That is not valid JSON. Paste the contents of an exported .template.json file.');
      return;
    }

    const schema = parsed as Partial<FormSchema> | null;
    if (!schema || typeof schema !== 'object' || !Array.isArray(schema.components)) {
      setError('This JSON is not a FormBuilder template (it has no "components" array).');
      return;
    }

    setError(null);
    onLoad(schema as FormSchema);
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.title}>Paste form template</Text>
        <Text style={styles.subtitle}>
          Paste the template JSON exported from FormBuilder Studio, then render it
          with its data binding.
        </Text>

        <TextInput
          style={styles.input}
          value={text}
          onChangeText={t => {
            setText(t);
            if (error) setError(null);
          }}
          placeholder={'{\n  "version": "1.0",\n  "name": "...",\n  "components": [ ... ]\n}'}
          placeholderTextColor="#94a3b8"
          multiline
          autoCapitalize="none"
          autoCorrect={false}
          spellCheck={false}
          textAlignVertical="top"
        />

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <TouchableOpacity style={styles.button} onPress={handleRender}>
          <Text style={styles.buttonText}>Render form →</Text>
        </TouchableOpacity>

        <View style={styles.linkRow}>
          <TouchableOpacity onPress={() => setText(SAMPLE_TEMPLATE)}>
            <Text style={styles.link}>Load sample template</Text>
          </TouchableOpacity>
          {text ? (
            <TouchableOpacity
              onPress={() => {
                setText('');
                setError(null);
              }}
            >
              <Text style={styles.link}>Clear</Text>
            </TouchableOpacity>
          ) : null}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: { padding: 24, gap: 16 },
  title: { fontSize: 26, fontWeight: '700', color: '#0f172a' },
  subtitle: { fontSize: 14, color: '#64748b', lineHeight: 20 },
  input: {
    minHeight: 220,
    borderWidth: 1,
    borderColor: '#cbd5e1',
    borderRadius: 10,
    padding: 14,
    fontSize: 13,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    color: '#1e293b',
    backgroundColor: '#fff',
  },
  error: { color: '#dc2626', fontSize: 13, fontWeight: '500' },
  button: {
    backgroundColor: '#4f46e5',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
  },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  linkRow: { flexDirection: 'row', justifyContent: 'space-between' },
  link: { color: '#4f46e5', fontSize: 14, fontWeight: '500' },
});
