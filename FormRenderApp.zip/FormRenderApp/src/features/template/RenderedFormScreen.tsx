import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import {
  FormRenderer,
  buildInitialValues,
  buildSubmission,
  validateAll,
  type FormSchema,
} from '../../renderer/FormRenderer';

interface Props {
  schema: FormSchema;
  /** Return to the paste screen. */
  onBack: () => void;
}

/**
 * Renders a pasted template exactly as it was designed in FormBuilder Studio.
 *
 * Field values are seeded with buildInitialValues(schema), which resolves every
 * component's `binding` against `schema.sampleData` — so the form opens with the
 * bound data shown, matching the web builder's preview. Tapping the template's
 * button validates and assembles the nested submission payload.
 */
export function RenderedFormScreen({ schema, onBack }: Props) {
  const [values, setValues] = useState<Record<string, any>>(() =>
    buildInitialValues(schema),
  );
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = () => {
    const errs = validateAll(schema.components, values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    // Nested JSON rebuilt from each field's binding path.
    const payload = buildSubmission(schema, values);
    Alert.alert('Submission payload', JSON.stringify(payload, null, 2));
  };

  return (
    <View style={styles.flex}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} hitSlop={styles.hitSlop}>
          <Text style={styles.back}>‹ Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle} numberOfLines={1}>
          {schema.name || 'Form'}
        </Text>
        {/* Spacer keeps the title centered against the Back button. */}
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        <FormRenderer
          schema={schema}
          values={values}
          errors={errors}
          onChange={(key, value) => setValues(v => ({ ...v, [key]: value }))}
          onSubmit={handleSubmit}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
    backgroundColor: '#fff',
  },
  hitSlop: { top: 12, bottom: 12, left: 12, right: 12 },
  back: { color: '#4f46e5', fontSize: 16, fontWeight: '600', width: 64 },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    fontSize: 17,
    fontWeight: '700',
    color: '#0f172a',
  },
  headerSpacer: { width: 64 },
  content: { padding: 24, gap: 16 },
});
