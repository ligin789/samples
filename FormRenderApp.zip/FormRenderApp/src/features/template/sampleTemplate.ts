/**
 * A ready-to-paste example of the JSON produced by FormBuilder Studio's
 * "Export" button. Used by the "Load sample" shortcut on the paste screen so
 * the renderer can be tried without round-tripping through the web builder.
 *
 * Note the `sampleData` block: each field's `binding` resolves against it, so
 * the rendered form opens pre-filled — that is the data binding in action.
 */
export const SAMPLE_TEMPLATE = JSON.stringify(
  {
    version: '1.0',
    name: 'Customer Profile',
    components: [
      { id: 'h1', type: 'heading', props: { text: 'Customer Profile', level: '1' } },
      {
        id: 'p1',
        type: 'paragraph',
        props: { text: 'Review and update the customer details below.' },
      },
      {
        id: 'c1',
        type: 'container',
        props: { label: 'Contact', direction: 'vertical' },
        children: [
          {
            id: 'f1',
            type: 'textfield',
            props: { label: 'Full name', placeholder: 'Jane Doe' },
            binding: 'user.name',
            validation: { required: true },
          },
          {
            id: 'f2',
            type: 'textfield',
            props: { label: 'Email', placeholder: 'jane@acme.com', inputType: 'email' },
            binding: 'user.email',
            validation: { required: true },
          },
          {
            id: 'f3',
            type: 'textfield',
            props: { label: 'Phone', inputType: 'tel' },
            binding: 'user.phone',
          },
        ],
      },
      {
        id: 'c2',
        type: 'container',
        props: { label: 'Address', direction: 'vertical' },
        children: [
          {
            id: 'f4',
            type: 'textfield',
            props: { label: 'City' },
            binding: 'user.address.city',
          },
          {
            id: 'f5',
            type: 'select',
            props: {
              label: 'Country',
              placeholder: 'Select…',
              options: [
                { label: 'United States', value: 'US' },
                { label: 'India', value: 'IN' },
                { label: 'United Kingdom', value: 'UK' },
              ],
            },
            binding: 'user.address.country',
          },
        ],
      },
      {
        id: 'f6',
        type: 'switch',
        props: { label: 'Subscribed to newsletter' },
        binding: 'user.subscribed',
      },
      {
        id: 'f7',
        type: 'datepicker',
        props: { label: 'Member since' },
        binding: 'user.joinedAt',
      },
      { id: 'b1', type: 'button', props: { text: 'Save changes', variant: 'primary' } },
    ],
    sampleData: {
      user: {
        name: 'Ada Lovelace',
        email: 'ada@example.com',
        phone: '+1 555 0142',
        address: { city: 'London', country: 'UK' },
        subscribed: true,
        joinedAt: '2021-07-19',
      },
    },
  },
  null,
  2,
);
