import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { addProcess, updateProcess, deleteProcess } from '../redux/process/processActions';
import type { Process } from '../redux/process/processTypes';

const validateProcess = (data: unknown): data is Process => {
  if (typeof data !== 'object' || data === null) return false;
  
  const p = data as Record<string, unknown>;
  
  return (
    typeof p.process_id === 'string' &&
    typeof p.process_key === 'string' &&
    typeof p.name === 'string' &&
    typeof p.version === 'string' &&
    typeof p.status === 'string'
  );
};

const TempProcess = () => {
  const dispatch = useAppDispatch();
  const processes = useAppSelector(state => state.process.process);
  const [jsonInput, setJsonInput] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleEdit = (p: Process) => {
    setJsonInput(JSON.stringify(p, null, 2));
    setEditingId(p.process_id);
    setError('');
  };

  const handleDelete = (id: string) => {
    dispatch(deleteProcess(id));
  };

  const handleSubmit = () => {
    setError('');

    if (!jsonInput.trim()) {
      setError('Please paste a Process JSON');
      return;
    }

    try {
      const parsed = JSON.parse(jsonInput);
      
      if (!validateProcess(parsed)) {
        setError('Invalid Process: Missing required fields (process_id, process_key, name, version, status)');
        return;
      }

      if (editingId) {
        dispatch(updateProcess(editingId, parsed));
        setEditingId(null);
      } else {
        dispatch(addProcess(parsed));
      }
      
      setJsonInput('');
      setError('');
    } catch (err) {
      setError('Invalid JSON format');
    }
  };

  return (
    <div className="container-fluid py-4">
      <h2 className="mb-4">Processes</h2>

      {/* Add/Edit Section */}
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title">
            {editingId ? 'Edit Process' : 'Add New Process'}
          </h5>
          <textarea
            className="form-control mb-3"
            rows={10}
            placeholder="Paste Process JSON here"
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
          />
          {error && (
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
          )}
          <div className="d-flex gap-2">
            <button className="btn btn-primary" onClick={handleSubmit}>
              {editingId ? 'Update Process' : 'Add Process'}
            </button>
            {editingId && (
              <button 
                className="btn btn-secondary" 
                onClick={() => {
                  setEditingId(null);
                  setJsonInput('');
                  setError('');
                }}
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Display Section */}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title mb-3">Processes List</h5>
          <div className="table-responsive">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Version</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {processes.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="text-center text-muted">
                      No processes found. Add one using the form above.
                    </td>
                  </tr>
                ) : (
                  processes.map((p) => (
                    <tr key={p.process_id}>
                      <td>{p.name}</td>
                      <td>
                        <span className="badge bg-info">{p.version}</span>
                      </td>
                      <td>
                        <span className={`badge ${p.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
                          {p.status}
                        </span>
                      </td>
                      <td>
                        <button 
                          className="btn btn-sm btn-primary me-2"
                          onClick={() => handleEdit(p)}
                        >
                          Edit
                        </button>
                        <button 
                          className="btn btn-sm btn-danger"
                          onClick={() => handleDelete(p.process_id)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {processes.length > 0 && (
            <div className="mt-3">
              <p className="text-muted">
                Total Processes: <strong>{processes.length}</strong>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TempProcess;
