import { useState, useMemo } from 'react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { addProcessGroup, updateProcessGroup, deleteProcessGroup } from '../redux/processGroup/processGroupActions';
import type { ProcessGroup } from '../redux/processGroup/processGroupTypes';

const validateProcessGroup = (data: unknown): data is ProcessGroup => {
  if (typeof data !== 'object' || data === null) return false;
  
  const pg = data as Record<string, unknown>;
  
  return (
    typeof pg.process_group_id === 'string' &&
    typeof pg.name === 'string' &&
    typeof pg.execution_model === 'string' &&
    Array.isArray(pg.nodes) &&
    Array.isArray(pg.edges)
  );
};

const Temporary = () => {
  const dispatch = useAppDispatch();
  const processGroups = useAppSelector(state => state.processGroup.processGroup);
  const processes = useAppSelector(state => state.process.process);
  const [jsonInput, setJsonInput] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());

  const processMap = useMemo(() => {
    return Object.fromEntries(processes.map(p => [p.process_key, p]));
  }, [processes]);

  const toggleExpand = (id: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const handleEdit = (pg: ProcessGroup) => {
    setJsonInput(JSON.stringify(pg, null, 2));
    setEditingId(pg.process_group_id);
    setError('');
  };

  const handleDelete = (id: string) => {
    dispatch(deleteProcessGroup(id));
  };

  const handleSubmit = () => {
    setError('');

    if (!jsonInput.trim()) {
      setError('Please paste a ProcessGroup JSON');
      return;
    }

    try {
      const parsed = JSON.parse(jsonInput);
      
      if (!validateProcessGroup(parsed)) {
        setError('Invalid ProcessGroup: Missing required fields (process_group_id, name, execution_model, nodes, edges)');
        return;
      }

      if (editingId) {
        dispatch(updateProcessGroup(editingId, parsed));
        setEditingId(null);
      } else {
        dispatch(addProcessGroup(parsed));
      }
      
      setJsonInput('');
      setError('');
    } catch (err) {
      setError('Invalid JSON format');
    }
  };

  return (
    <div className="container-fluid py-4">
      <h2 className="mb-4">Process Groups</h2>

      {/* Add/Edit Section */}
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title">
            {editingId ? 'Edit Process Group' : 'Add New Process Group'}
          </h5>
          <textarea
            className="form-control mb-3"
            rows={10}
            placeholder="Paste ProcessGroup JSON here"
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
          />
          {error && (
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
          )}
          <div className="d-flex gap-2">
            <button className="btn btn-primary" onClick={handleSubmit}>
              {editingId ? 'Update Process Group' : 'Add Process Group'}
            </button>
            {editingId && (
              <button 
                className="btn btn-secondary" 
                onClick={() => {
                  setEditingId(null);
                  setJsonInput('');
                  setError('');
                }}
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Display Section */}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title mb-3">Process Groups List</h5>
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Nodes</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {processGroups.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="text-center text-muted">
                      No process groups found. Add one using the form above.
                    </td>
                  </tr>
                ) : (
                  processGroups.map((pg) => (
                    <>
                      <tr key={pg.process_group_id}>
                        <td>
                          <button
                            className="btn btn-sm btn-link p-0 me-2"
                            onClick={() => toggleExpand(pg.process_group_id)}
                          >
                            {expandedGroups.has(pg.process_group_id) ? '▼' : '▶'}
                          </button>
                          {pg.name}
                        </td>
                        <td>
                          <span className="badge bg-secondary">{pg.nodes.length}</span>
                        </td>
                        <td>
                          <button 
                            className="btn btn-sm btn-primary me-2"
                            onClick={() => handleEdit(pg)}
                          >
                            Edit
                          </button>
                          <button 
                            className="btn btn-sm btn-danger"
                            onClick={() => handleDelete(pg.process_group_id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                      {expandedGroups.has(pg.process_group_id) && (
                        <tr>
                          <td colSpan={3}>
                            <div className="ms-4">
                              <table className="table table-sm table-bordered mb-0">
                                <thead className="table-light">
                                  <tr>
                                    <th>Node ID</th>
                                    <th>Process Key</th>
                                    <th>Process Name</th>
                                    <th>Version</th>
                                    <th>Status</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {pg.nodes.length === 0 ? (
                                    <tr>
                                      <td colSpan={5} className="text-center text-muted">
                                        No nodes in this process group
                                      </td>
                                    </tr>
                                  ) : (
                                    pg.nodes.map((node) => {
                                      const process = processMap[node.process_key];
                                      return (
                                        <tr key={node.node_id}>
                                          <td><code>{node.node_id}</code></td>
                                          <td><code>{node.process_key}</code></td>
                                          <td>
                                            {process ? (
                                              process.name
                                            ) : (
                                              <span className="text-danger">Process Not Found</span>
                                            )}
                                          </td>
                                          <td>
                                            {process ? (
                                              <span className="badge bg-info">{process.version}</span>
                                            ) : (
                                              <span className="text-muted">-</span>
                                            )}
                                          </td>
                                          <td>
                                            {process ? (
                                              <span className={`badge ${process.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
                                                {process.status}
                                              </span>
                                            ) : (
                                              <span className="text-muted">-</span>
                                            )}
                                          </td>
                                        </tr>
                                      );
                                    })
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {processGroups.length > 0 && (
            <div className="mt-3">
              <p className="text-muted">
                Total Process Groups: <strong>{processGroups.length}</strong>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Temporary;
