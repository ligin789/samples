import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { addDomain, updateDomain, deleteDomain } from '../redux/domain/domainActions';
import type { Domain } from '../redux/domain/domainTypes';

const DomainPage = () => {
  const dispatch = useAppDispatch();
  const domainList = useAppSelector((state) => state.domain.domainList);

  const [jsonInput, setJsonInput] = useState('');
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const parsed = JSON.parse(jsonInput);

      if (!parsed.industry || !parsed.function || !parsed.subfunction) {
        setError('Missing required fields: industry, function, subfunction');
        return;
      }

      if (!parsed.applicability?.operatingcluster || !Array.isArray(parsed.applicability.operatingcluster)) {
        setError('applicability.operatingcluster must be an array');
        return;
      }

      const domainData = {
        industry: parsed.industry,
        function: parsed.function,
        subfunction: parsed.subfunction,
        applicability: {
          operatingcluster: parsed.applicability.operatingcluster
        }
      };

      if (editingId) {
        dispatch(updateDomain({ ...domainData, id: editingId }));
        setEditingId(null);
      } else {
        dispatch(addDomain(domainData));
      }

      setJsonInput('');
    } catch (err) {
      setError('Invalid JSON format');
    }
  };

  const handleEdit = (domain: Domain) => {
    const jsonStr = JSON.stringify({
      industry: domain.industry,
      function: domain.function,
      subfunction: domain.subfunction,
      applicability: domain.applicability
    }, null, 2);
    setJsonInput(jsonStr);
    setEditingId(domain.id);
    setError('');
  };

  const handleDelete = (id: string) => {
    dispatch(deleteDomain(id));
  };

  const handleCancel = () => {
    setJsonInput('');
    setEditingId(null);
    setError('');
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Domain Management</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: '30px', border: '1px solid #ddd', padding: '20px', borderRadius: '4px' }}>
        <h3>{editingId ? 'Edit Domain' : 'Add Domain'}</h3>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Domain JSON:</label>
          <textarea
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            required
            rows={12}
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc', fontFamily: 'monospace' }}
            placeholder={`{
  "industry": "AAM",
  "function": "operations",
  "subfunction": "flight",
  "applicability": {
    "operatingcluster": ["BLR", "DEL"]
  }
}`}
          />
        </div>

        {error && (
          <div style={{ marginBottom: '10px', padding: '10px', background: '#ffebee', color: '#c62828', borderRadius: '4px' }}>
            {error}
          </div>
        )}

        <div>
          <button type="submit" style={{ padding: '10px 20px', marginRight: '10px', cursor: 'pointer', background: '#4caf50', color: 'white', border: 'none', borderRadius: '4px' }}>
            {editingId ? 'Update' : 'Add'}
          </button>
          {editingId && (
            <button type="button" onClick={handleCancel} style={{ padding: '10px 20px', cursor: 'pointer', background: '#f44336', color: 'white', border: 'none', borderRadius: '4px' }}>
              Cancel
            </button>
          )}
        </div>
      </form>

      <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #ddd' }}>
        <thead>
          <tr style={{ background: '#f5f5f5' }}>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Industry</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Function</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Subfunction</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Operating Cluster</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {domainList.length === 0 ? (
            <tr>
              <td colSpan={5} style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'center' }}>
                No domains found
              </td>
            </tr>
          ) : (
            domainList.map((domain) => (
              <tr key={domain.id}>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{domain.industry}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{domain.function}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{domain.subfunction}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>
                  {domain.applicability.operatingcluster.join(', ')}
                </td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>
                  <button
                    onClick={() => handleEdit(domain)}
                    style={{ padding: '6px 12px', marginRight: '5px', cursor: 'pointer', background: '#2196f3', color: 'white', border: 'none', borderRadius: '4px' }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(domain.id)}
                    style={{ padding: '6px 12px', cursor: 'pointer', background: '#f44336', color: 'white', border: 'none', borderRadius: '4px' }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DomainPage;
