import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { addSchema, updateSchema, deleteSchema } from '../redux/schema/schemaActions';
import type { Schema } from '../redux/schema/schemaTypes';

const SchemaPage = () => {
  const dispatch = useAppDispatch();
  const domainList = useAppSelector((state) => state.domain.domainList);
  const schemaList = useAppSelector((state) => state.schema.schemaList);

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    comment: '',
    schemaRef: 'schema://velos-schema-registry/com.tcs.aam.OperatorContext:1.0.0',
    defaultValue: '{}',
    domainFunction: ''
  });

  const [isEditing, setIsEditing] = useState(false);

  const uniqueDomainFunctions = Array.from(
    new Set(domainList.map((d) => d.function))
  ).sort();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let parsedDefault = {};
    try {
      parsedDefault = JSON.parse(formData.defaultValue);
    } catch (err) {
      alert('Invalid JSON in default field');
      return;
    }

    const schemaData = {
      name: formData.name,
      domainId: formData.domainFunction,
      operatorContext: {
        _comment: formData.comment,
        $schemaRef: formData.schemaRef,
        default: parsedDefault,
        domain: formData.domainFunction
      }
    };

    if (isEditing) {
      dispatch(updateSchema({ ...schemaData, id: formData.id }));
      setIsEditing(false);
    } else {
      dispatch(addSchema(schemaData));
    }

    setFormData({
      id: '',
      name: '',
      comment: '',
      schemaRef: 'schema://velos-schema-registry/com.tcs.aam.OperatorContext:1.0.0',
      defaultValue: '{}',
      domainFunction: ''
    });
  };

  const handleEdit = (schema: Schema) => {
    setFormData({
      id: schema.id,
      name: schema.name,
      comment: schema.operatorContext._comment,
      schemaRef: schema.operatorContext.$schemaRef,
      defaultValue: JSON.stringify(schema.operatorContext.default),
      domainFunction: schema.operatorContext.domain
    });
    setIsEditing(true);
  };

  const handleDelete = (id: string) => {
    dispatch(deleteSchema(id));
  };

  const handleCancel = () => {
    setFormData({
      id: '',
      name: '',
      comment: '',
      schemaRef: 'schema://velos-schema-registry/com.tcs.aam.OperatorContext:1.0.0',
      defaultValue: '{}',
      domainFunction: ''
    });
    setIsEditing(false);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Schema Management</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: '30px', border: '1px solid #ddd', padding: '20px', borderRadius: '4px' }}>
        <h3>{isEditing ? 'Edit Schema' : 'Add Schema'}</h3>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Name:</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Comment:</label>
          <input
            type="text"
            value={formData.comment}
            onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>SchemaRef:</label>
          <input
            type="text"
            value={formData.schemaRef}
            onChange={(e) => setFormData({ ...formData, schemaRef: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Default (JSON):</label>
          <textarea
            value={formData.defaultValue}
            onChange={(e) => setFormData({ ...formData, defaultValue: e.target.value })}
            rows={3}
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc', fontFamily: 'monospace' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Domain:</label>
          <select
            value={formData.domainFunction}
            onChange={(e) => setFormData({ ...formData, domainFunction: e.target.value })}
            required
            style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
          >
            <option value="">Select Domain</option>
            {uniqueDomainFunctions.map((func) => (
              <option key={func} value={func}>
                {func}
              </option>
            ))}
          </select>
        </div>

        <div>
          <button type="submit" style={{ padding: '10px 20px', marginRight: '10px', cursor: 'pointer', background: '#4caf50', color: 'white', border: 'none', borderRadius: '4px' }}>
            {isEditing ? 'Update' : 'Add'}
          </button>
          {isEditing && (
            <button type="button" onClick={handleCancel} style={{ padding: '10px 20px', cursor: 'pointer', background: '#f44336', color: 'white', border: 'none', borderRadius: '4px' }}>
              Cancel
            </button>
          )}
        </div>
      </form>

      <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #ddd' }}>
        <thead>
          <tr style={{ background: '#f5f5f5' }}>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Name</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Comment</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>SchemaRef</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Domain</th>
            <th style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'left' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {schemaList.length === 0 ? (
            <tr>
              <td colSpan={5} style={{ padding: '12px', border: '1px solid #ddd', textAlign: 'center' }}>
                No schemas found
              </td>
            </tr>
          ) : (
            schemaList.map((schema) => (
              <tr key={schema.id}>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{schema.name}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{schema.operatorContext._comment}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{schema.operatorContext.$schemaRef}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>{schema.operatorContext.domain}</td>
                <td style={{ padding: '12px', border: '1px solid #ddd' }}>
                  <button
                    onClick={() => handleEdit(schema)}
                    style={{ padding: '6px 12px', marginRight: '5px', cursor: 'pointer', background: '#2196f3', color: 'white', border: 'none', borderRadius: '4px' }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(schema.id)}
                    style={{ padding: '6px 12px', cursor: 'pointer', background: '#f44336', color: 'white', border: 'none', borderRadius: '4px' }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default SchemaPage;
