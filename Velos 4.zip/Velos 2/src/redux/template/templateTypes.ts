export const ADD_TEMPLATE = 'ADD_TEMPLATE';
export const UPDATE_TEMPLATE = 'UPDATE_TEMPLATE';
export const DELETE_TEMPLATE = 'DELETE_TEMPLATE';
export const SET_SELECTED_TEMPLATE = 'SET_SELECTED_TEMPLATE';
export const SET_TEMPLATES = 'SET_TEMPLATES';
export const TEMPLATE_LOADING = 'TEMPLATE_LOADING';
export const TEMPLATE_ERROR = 'TEMPLATE_ERROR';

export interface Template {
  template_id: string;
  template_version: string;
  template: Record<string, any>;
}

export interface TemplateState {
  templates: Template[];
  selectedTemplate: Template | null;
  loading: boolean;
  error: string | null;
}