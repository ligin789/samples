import {
  ADD_TEMPLATE,
  UPDATE_TEMPLATE,
  DELETE_TEMPLATE,
  SET_SELECTED_TEMPLATE,
  SET_TEMPLATES,
  TEMPLATE_LOADING,
  TEMPLATE_ERROR,
  type Template
} from './templateTypes';

export const addTemplate = (template: Template) => ({
  type: ADD_TEMPLATE,
  payload: template
});

export const updateTemplate = (template: Template) => ({
  type: UPDATE_TEMPLATE,
  payload: template
});

export const deleteTemplate = (template_id: string) => ({
  type: DELETE_TEMPLATE,
  payload: template_id
});

export const setSelectedTemplate = (template: Template | null) => ({
  type: SET_SELECTED_TEMPLATE,
  payload: template
});

export const setTemplates = (templates: Template[]) => ({
  type: SET_TEMPLATES,
  payload: templates
});

export const setTemplateLoading = (loading: boolean) => ({
  type: TEMPLATE_LOADING,
  payload: loading
});

export const setTemplateError = (error: string | null) => ({
  type: TEMPLATE_ERROR,
  payload: error
});