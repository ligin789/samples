import type { Dispatch } from 'redux';
import {
  addTemplate as addTemplateAction,
  updateTemplate as updateTemplateAction,
  deleteTemplate as deleteTemplateAction,
  setSelectedTemplate,
  setTemplateLoading,
  setTemplateError
} from './templateActions';
import type { Template } from './templateTypes';

export const addTemplate = (template: Template) => {
  return (dispatch: Dispatch) => {
    dispatch(setTemplateLoading(true));
    try {
      dispatch(addTemplateAction(template));
      dispatch(setTemplateError(null));
    } catch (error) {
      dispatch(setTemplateError(error instanceof Error ? error.message : 'Failed to add template'));
    } finally {
      dispatch(setTemplateLoading(false));
    }
  };
};

export const updateTemplate = (template: Template) => {
  return (dispatch: Dispatch) => {
    dispatch(setTemplateLoading(true));
    try {
      dispatch(updateTemplateAction(template));
      dispatch(setTemplateError(null));
    } catch (error) {
      dispatch(setTemplateError(error instanceof Error ? error.message : 'Failed to update template'));
    } finally {
      dispatch(setTemplateLoading(false));
    }
  };
};

export const deleteTemplate = (template_id: string) => {
  return (dispatch: Dispatch) => {
    dispatch(setTemplateLoading(true));
    try {
      dispatch(deleteTemplateAction(template_id));
      dispatch(setTemplateError(null));
    } catch (error) {
      dispatch(setTemplateError(error instanceof Error ? error.message : 'Failed to delete template'));
    } finally {
      dispatch(setTemplateLoading(false));
    }
  };
};

export const selectTemplate = (template_id: string) => {
  return (dispatch: Dispatch, getState: () => any) => {
    const { template } = getState();
    const selectedTemplate = template.templates.find((t: Template) => t.template_id === template_id) || null;
    dispatch(setSelectedTemplate(selectedTemplate));
  };
};