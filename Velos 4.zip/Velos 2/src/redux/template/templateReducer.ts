import {
  ADD_TEMPLATE,
  UPDATE_TEMPLATE,
  DELETE_TEMPLATE,
  SET_SELECTED_TEMPLATE,
  SET_TEMPLATES,
  TEMPLATE_LOADING,
  TEMPLATE_ERROR,
  type TemplateState,
  type Template
} from './templateTypes';

interface TemplateAction {
  type: string;
  payload?: Template[] | Template | string | boolean | null;
}

const initialState: TemplateState = {
  templates: [],
  selectedTemplate: null,
  loading: false,
  error: null
};

const templateReducer = (state = initialState, action: TemplateAction): TemplateState => {
  switch (action.type) {
    case ADD_TEMPLATE:
      return {
        ...state,
        templates: [...state.templates, action.payload as Template]
      };

    case UPDATE_TEMPLATE: {
      const updatedTemplate = action.payload as Template;
      return {
        ...state,
        templates: state.templates.map(template =>
          template.template_id === updatedTemplate.template_id ? updatedTemplate : template
        ),
        selectedTemplate: state.selectedTemplate?.template_id === updatedTemplate.template_id
          ? updatedTemplate
          : state.selectedTemplate
      };
    }

    case DELETE_TEMPLATE: {
      const template_id = action.payload as string;
      return {
        ...state,
        templates: state.templates.filter(template => template.template_id !== template_id),
        selectedTemplate: state.selectedTemplate?.template_id === template_id
          ? null
          : state.selectedTemplate
      };
    }

    case SET_SELECTED_TEMPLATE:
      return {
        ...state,
        selectedTemplate: action.payload as Template | null
      };

    case SET_TEMPLATES:
      return {
        ...state,
        templates: action.payload as Template[]
      };

    case TEMPLATE_LOADING:
      return {
        ...state,
        loading: action.payload as boolean
      };

    case TEMPLATE_ERROR:
      return {
        ...state,
        error: action.payload as string | null
      };

    default:
      return state;
  }
};

export default templateReducer;