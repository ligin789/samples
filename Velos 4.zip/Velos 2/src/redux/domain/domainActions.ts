import type { Dispatch } from 'redux';
import {
  ADD_DOMAIN,
  UPDATE_DOMAIN,
  DELETE_DOMAIN,
  SET_DOMAINS,
  type Domain,
  type DomainActionTypes
} from './domainTypes';

export const addDomain = (domainData: Omit<Domain, 'id'>) => {
  return (dispatch: Dispatch<DomainActionTypes>) => {
    const newDomain: Domain = {
      ...domainData,
      id: `domain-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    };
    dispatch({
      type: ADD_DOMAIN,
      payload: newDomain
    });
  };
};

export const updateDomain = (domain: Domain) => ({
  type: UPDATE_DOMAIN,
  payload: domain
});

export const deleteDomain = (id: string) => ({
  type: DELETE_DOMAIN,
  payload: id
});

export const setDomains = (domains: Domain[]) => ({
  type: SET_DOMAINS,
  payload: domains
});
