import {
  ADD_DOMAIN,
  UPDATE_DOMAIN,
  DELETE_DOMAIN,
  SET_DOMAINS,
  type DomainState,
  type DomainActionTypes
} from './domainTypes';

const initialState: DomainState = {
  domainList: []
};

const domainReducer = (
  state = initialState,
  action: DomainActionTypes
): DomainState => {
  switch (action.type) {
    case ADD_DOMAIN:
      return {
        ...state,
        domainList: [...state.domainList, action.payload]
      };

    case UPDATE_DOMAIN:
      return {
        ...state,
        domainList: state.domainList.map((domain) =>
          domain.id === action.payload.id ? action.payload : domain
        )
      };

    case DELETE_DOMAIN:
      return {
        ...state,
        domainList: state.domainList.filter((domain) => domain.id !== action.payload)
      };

    case SET_DOMAINS:
      return {
        ...state,
        domainList: action.payload
      };

    default:
      return state;
  }
};

export default domainReducer;
