export const ADD_DOMAIN = 'ADD_DOMAIN';
export const UPDATE_DOMAIN = 'UPDATE_DOMAIN';
export const DELETE_DOMAIN = 'DELETE_DOMAIN';
export const SET_DOMAINS = 'SET_DOMAINS';

export interface Domain {
  id: string;
  industry: string;
  function: string;
  subfunction: string;
  applicability: {
    operatingcluster: string[];
  };
}

export interface DomainState {
  domainList: Domain[];
}

interface AddDomainAction {
  type: typeof ADD_DOMAIN;
  payload: Domain;
}

interface UpdateDomainAction {
  type: typeof UPDATE_DOMAIN;
  payload: Domain;
}

interface DeleteDomainAction {
  type: typeof DELETE_DOMAIN;
  payload: string;
}

interface SetDomainsAction {
  type: typeof SET_DOMAINS;
  payload: Domain[];
}

export type DomainActionTypes = 
  | AddDomainAction 
  | UpdateDomainAction 
  | DeleteDomainAction 
  | SetDomainsAction;
