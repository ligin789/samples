import {
  FETCH_PROCESS_REQUEST,
  FETCH_PROCESS_SUCCESS,
  FETCH_PROCESS_FAILURE,
  ADD_PROCESS,
  UPDATE_PROCESS,
  DELETE_PROCESS,
  SET_SELECTED_PROCESS,
  UPDATE_PROCESS_FLOW,
  type ProcessState,
  type Process
} from './processTypes';

interface ProcessAction {
  type: string;
  payload?: Process[] | Process | { id: string; data: Partial<Process> } | { processId: string; processFlow: { nodes: any[]; edges: any[] } } | string;
}

const initialState: any = {
  loading: false,
  error: null,
  process: [],
  selectedProcess: null
};

const processReducer = (state = initialState, action: ProcessAction): ProcessState => {
  switch (action.type) {
    case FETCH_PROCESS_REQUEST:
      return { ...state, loading: true, error: null };

    case FETCH_PROCESS_SUCCESS:
      return { 
        ...state, 
        loading: false, 
        process: action.payload as Process[] 
      };

    case FETCH_PROCESS_FAILURE:
      return { 
        ...state, 
        loading: false, 
        error: action.payload as string 
      };

    case ADD_PROCESS:
      return {
        ...state,
        process: [...state.process, action.payload as Process]
      };

    case UPDATE_PROCESS: {
      const { id, data } = action.payload as { id: string; data: Partial<Process> };
      return {
        ...state,
        process: state.process.map((p:any) =>
          p.process_id === id ? { ...p, ...data } : p
        )
      };
    }

    case DELETE_PROCESS:
      return {
        ...state,
        process: state.process.filter(
          (p:any) => p.process_id !== (action.payload as string)
        )
      };

    case SET_SELECTED_PROCESS:
      return {
        ...state,
        selectedProcess: action.payload as Process
      };

    case UPDATE_PROCESS_FLOW: {
      const { processId, processFlow } = action.payload as { processId: string; processFlow: { nodes: any[]; edges: any[] } };
      return {
        ...state,
        process: state.process.map((p: any) =>
          p.process_id === processId ? { ...p, processFlow } : p
        ),
        selectedProcess: state.selectedProcess?.process_id === processId
          ? { ...state.selectedProcess, processFlow }
          : state.selectedProcess
      };
    }

    default:
      return state;
  }
};

export default processReducer;
