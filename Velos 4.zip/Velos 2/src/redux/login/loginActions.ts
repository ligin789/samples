import { LOGIN_REQUEST, LOGIN_SUCCESS, LOGIN_FAILURE, LOGOUT, ADD_USER } from './loginTypes';
import type { User } from './types';
import type { Dispatch } from 'redux';
import type { RootState } from '../../store/rootReducer';

export const loginUser = (name: any) => {
  return (dispatch: Dispatch, getState: () => RootState) => {
    dispatch({ type: LOGIN_REQUEST });

    setTimeout(() => {
      const { users } = getState().login;
      const user = users.find(u => u.name.toLowerCase() === name.toLowerCase());

      if (user) {
        dispatch({ type: LOGIN_SUCCESS, payload: user });
      } else {
        dispatch({ type: LOGIN_FAILURE, payload: 'User not found' });
      }
    }, 1000);
  };
};

export const logoutUser = () => ({
  type: LOGOUT
});

export const addUser = (userData: User) => ({
  type: ADD_USER,
  payload: userData
});
