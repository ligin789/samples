export interface User {
  id: number;
  name: string;
  role: number;
  roleName: string;
}

export interface LoginState {
  users: User[];
  user: User | null;
  loading: boolean;
  error: string | null;
}
