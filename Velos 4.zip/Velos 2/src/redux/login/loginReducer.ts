import { LOGIN_REQUEST, LOGIN_SUCCESS, LOGIN_FAILURE, LOGOUT, ADD_USER } from './loginTypes';
import type { LoginState, User } from './types';

interface LoginAction {
  type: string;
  payload?: User | string;
}

const initialState: LoginState = {
  users: [
    { id: 1, name: "sam", role: 1, roleName: "Platform Admin" },
    { id: 2, name: "manu", role: 2, roleName: "EVTOL Operator" },
    { id: 3, name: "ravi", role: 3, roleName: "Ground Handler" },
    { id: 4, name: "anita", role: 4, roleName: "Booking Partner" },
    { id: 5, name: "john", role: 5, roleName: "Customer Service Portal" }
  ],
  user: null,
  loading: false,
  error: null
};

const loginReducer = (state = initialState, action: LoginAction): LoginState => {
  switch (action.type) {
    case LOGIN_REQUEST:
      return { ...state, loading: true, error: null };
    case LOGIN_SUCCESS:
      return { ...state, loading: false, user: action.payload as User };
    case LOGIN_FAILURE:
      return { ...state, loading: false, error: action.payload as string };
    case LOGOUT:
      return { ...state, user: null };
    case ADD_USER:
      return { ...state, users: [...state.users, action.payload as User] };
    default:
      return state;
  }
};

export default loginReducer;
