export const FETCH_PROCESS_GROUP_REQUEST = 'FETCH_PROCESS_GROUP_REQUEST';
export const FETCH_PROCESS_GROUP_SUCCESS = 'FETCH_PROCESS_GROUP_SUCCESS';
export const FETCH_PROCESS_GROUP_FAILURE = 'FETCH_PROCESS_GROUP_FAILURE';
export const ADD_PROCESS_GROUP = 'ADD_PROCESS_GROUP';
export const UPDATE_PROCESS_GROUP = 'UPDATE_PROCESS_GROUP';
export const DELETE_PROCESS_GROUP = 'DELETE_PROCESS_GROUP';

export interface Purpose {
  business_objective: string;
  primary_kpis: string[];
}

export interface Applicability {
  operatingcluster: string[];
}

export interface Domain {
  industry: string;
  function: string;
  subfunction: string;
  applicability: Applicability;
}

export interface Operator {
  operatorCode: string;
  operatorName: string;
  operatorType: string;
  policyNamespace: string;
  region: string;
}

export interface Planned {
  expectedDurationMinutes: number;
}

export interface Node {
  node_id: string;
  process_key: string;
  planned: Planned;
  actual: Record<string, unknown>;
  kpi_contributions: string[];
  imports?: string[];
  exports?: string[];
}

export interface Edge {
  from: string;
  to: string;
}

export interface ProcessGroup {
  process_group_id: string;
  name: string;
  execution_model: string;
  purpose: Purpose;
  domain: Domain;
  operator: Operator;
  nodes: Node[];
  edges: Edge[];
}

export interface ProcessGroupState {
  loading: boolean;
  error: string | null;
  processGroup: ProcessGroup[];
}
