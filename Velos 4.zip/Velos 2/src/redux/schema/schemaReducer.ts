import {
  ADD_SCHEMA,
  UPDATE_SCHEMA,
  DELETE_SCHEMA,
  SET_SCHEMAS,
  type SchemaState,
  type SchemaActionTypes
} from './schemaTypes';

const initialState: SchemaState = {
  schemaList: []
};

const schemaReducer = (
  state = initialState,
  action: SchemaActionTypes
): SchemaState => {
  switch (action.type) {
    case ADD_SCHEMA:
      return {
        ...state,
        schemaList: [...state.schemaList, action.payload]
      };

    case UPDATE_SCHEMA:
      return {
        ...state,
        schemaList: state.schemaList.map((schema) =>
          schema.id === action.payload.id ? action.payload : schema
        )
      };

    case DELETE_SCHEMA:
      return {
        ...state,
        schemaList: state.schemaList.filter((schema) => schema.id !== action.payload)
      };

    case SET_SCHEMAS:
      return {
        ...state,
        schemaList: action.payload
      };

    default:
      return state;
  }
};

export default schemaReducer;
