import type { Dispatch } from 'redux';
import {
  ADD_SCHEMA,
  UPDATE_SCHEMA,
  DELETE_SCHEMA,
  SET_SCHEMAS,
  type Schema,
  type SchemaActionTypes
} from './schemaTypes';

export const addSchema = (schemaData: Omit<Schema, 'id'>) => {
  return (dispatch: Dispatch<SchemaActionTypes>) => {
    const newSchema: Schema = {
      ...schemaData,
      id: `schema-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    };
    dispatch({
      type: ADD_SCHEMA,
      payload: newSchema
    });
  };
};

export const updateSchema = (schema: Schema) => ({
  type: UPDATE_SCHEMA,
  payload: schema
});

export const deleteSchema = (id: string) => ({
  type: DELETE_SCHEMA,
  payload: id
});

export const setSchemas = (schemas: Schema[]) => ({
  type: SET_SCHEMAS,
  payload: schemas
});
