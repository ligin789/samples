export const ADD_SCHEMA = 'ADD_SCHEMA';
export const UPDATE_SCHEMA = 'UPDATE_SCHEMA';
export const DELETE_SCHEMA = 'DELETE_SCHEMA';
export const SET_SCHEMAS = 'SET_SCHEMAS';

export interface Schema {
  id: string;
  name: string;
  domainId: string;
  operatorContext: {
    _comment: string;
    $schemaRef: string;
    default: object;
    domain: string;
  };
}

export interface SchemaState {
  schemaList: Schema[];
}

interface AddSchemaAction {
  type: typeof ADD_SCHEMA;
  payload: Schema;
}

interface UpdateSchemaAction {
  type: typeof UPDATE_SCHEMA;
  payload: Schema;
}

interface DeleteSchemaAction {
  type: typeof DELETE_SCHEMA;
  payload: string;
}

interface SetSchemasAction {
  type: typeof SET_SCHEMAS;
  payload: Schema[];
}

export type SchemaActionTypes =
  | AddSchemaAction
  | UpdateSchemaAction
  | DeleteSchemaAction
  | SetSchemasAction;
