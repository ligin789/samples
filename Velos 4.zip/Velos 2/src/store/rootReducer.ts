import { combineReducers } from "redux";
import loginReducer from "../redux/login/loginReducer";
import processGroupReducer from "../redux/processGroup/processGroupReducer";
import processReducer from "../redux/process/processReducer";
import domainReducer from "../redux/domain/domainReducer";
import schemaReducer from "../redux/schema/schemaReducer";
import templateReducer from "../redux/template/templateReducer";

const rootReducer = combineReducers({
  login: loginReducer,
  processGroup: processGroupReducer,
  process: processReducer,
  domain: domainReducer,
  schema: schemaReducer,
  template: templateReducer
});

type RootState = ReturnType<typeof rootReducer>;

export type { RootState };
export default rootReducer;
