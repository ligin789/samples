import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginUser } from '../redux/login/loginActions';
import { useAppDispatch, useAppSelector } from '../store/hooks';

const Login = () => {
  const [name, setName] = useState<string>('');
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { user, loading, error } = useAppSelector(state => state.login);

  const roleRoutes: Record<number, string> = {
    1: '/admin',
    2: '/evtol',
    3: '/ground',
    4: '/booking',
    5: '/support'
  };

  useEffect(() => {
    if (user) {
      navigate(roleRoutes[user.role]);
    }
  }, [user, navigate]);

  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (name.trim()) {
      dispatch(loginUser(name));
    }
  };

  return (
    <div className="container" style={{ minHeight: '100vh' , display: 'flex', alignItems: 'center', justifyContent: 'center', width:"100%"}}>
      <div className="row justify-content-center" style={{width:"100%"}}>
        <div className="col-md-6" style={{width:"100%"}}>
          <div className="card">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">Login</h2>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={loading}
                  />
                </div>
                {error && <div className="alert alert-danger">{error}</div>}
                <button type="submit" className="btn btn-danger w-100" disabled={loading}>
                  {loading ? 'Verifying OTP...' : 'Login'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
