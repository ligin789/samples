import Page from '../../components/Page';

const Notifications = () => <Page title="Notifications" />;

export default Notifications;
