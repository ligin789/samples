import Page from '../../components/Page';

const Home = () => <Page title="Home" />;

export default Home;
