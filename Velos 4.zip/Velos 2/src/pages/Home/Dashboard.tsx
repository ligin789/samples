import Page from '../../components/Page';

const Dashboard = () => <Page title="Dashboard" />;

export default Dashboard;
