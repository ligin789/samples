import Page from '../../components/Page';

const Runtime = () => <Page title="Runtime" />;

export default Runtime;
