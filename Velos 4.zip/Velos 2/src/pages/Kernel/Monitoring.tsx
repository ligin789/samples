import Page from '../../components/Page';

const Monitoring = () => <Page title="Monitoring" />;

export default Monitoring;
