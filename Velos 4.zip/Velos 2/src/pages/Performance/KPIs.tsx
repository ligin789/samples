import Page from '../../components/Page';

const KPIs = () => <Page title="KPIs" />;

export default KPIs;
