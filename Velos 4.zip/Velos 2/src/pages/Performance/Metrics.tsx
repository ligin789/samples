import Page from '../../components/Page';

const Metrics = () => <Page title="Metrics" />;

export default Metrics;
