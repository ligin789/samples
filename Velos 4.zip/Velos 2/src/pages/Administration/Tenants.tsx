import Page from '../../components/Page';

const Tenants = () => <Page title="Tenants" />;

export default Tenants;
