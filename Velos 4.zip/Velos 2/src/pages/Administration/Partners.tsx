import Page from '../../components/Page';

const Partners = () => <Page title="Partners" />;

export default Partners;
