import Page from '../../components/Page';

const Users = () => <Page title="Users" />;

export default Users;
