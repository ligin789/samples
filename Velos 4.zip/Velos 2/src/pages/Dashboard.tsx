import { useAppSelector } from '../store/hooks';

const Dashboard = () => {
  const user = useAppSelector(state => state.login.user);

  return (
    <div className="container mt-5">
      <div className="card">
        <div className="card-body">
          <h1 className="card-title">Welcome {user?.name}</h1>
          <p className="card-text"><strong>Role Name:</strong> {user?.roleName}</p>
          <p className="card-text"><strong>Role ID:</strong> {user?.role}</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
