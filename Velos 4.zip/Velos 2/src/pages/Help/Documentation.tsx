import Page from '../../components/Page';

const Documentation = () => <Page title="Documentation" />;

export default Documentation;
