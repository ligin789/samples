import Page from '../../components/Page';

const Support = () => <Page title="Support" />;

export default Support;
