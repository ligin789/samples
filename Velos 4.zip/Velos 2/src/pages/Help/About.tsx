import Page from '../../components/Page';

const About = () => <Page title="About" />;

export default About;
