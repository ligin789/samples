import { useEffect, useLayoutEffect, useRef, useState } from "react";
import "./Landing.css";
import Logo from "../assets/images/landingPage/logo.svg";
import LogoDark from "../assets/images/landingPage/logoDark.svg";
// import Mov from "../assets/images/landingPage/background.mov";
import Arrow from "../assets/images/landingPage/arrowUp.svg";

function LandingPage() {
  const [isLoaded, setIsLoaded] = useState(false);

  const [isFading, setIsFading] = useState(false);

    const overlayRef = useRef<HTMLDivElement | null>(null);
    const animLogoRef = useRef<HTMLImageElement | null>(null);
    const headerLogoRef = useRef<HTMLImageElement | null>(null);
  useEffect(() => {
    const header = document.querySelector(".site-header");
    if (!header) return;

    const SCROLLED_BG_THRESHOLD = 200; // when to add dark background
    const STICKY_THRESHOLD = 20; // when to make header sticky

    const onScroll = () => {
      const y = window.scrollY || window.pageYOffset || 0;

      // Background (already in your CSS via `.is-scrolled`)
      if (y > SCROLLED_BG_THRESHOLD) header.classList.add("is-scrolled");
      else header.classList.remove("is-scrolled");

      // Sticky behavior: becomes fixed after slight scroll, reverts at top
      if (y > STICKY_THRESHOLD) header.classList.add("is-fixed");
      else header.classList.remove("is-fixed");
    };

    // Attach listener
    window.addEventListener("scroll", onScroll, { passive: true });
    // Initialize state on mount
    onScroll();

    // Cleanup
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

    // Loader → animate logo from center to header brand location
    useLayoutEffect(() => {
    let minShowTimer: number | undefined;
    let afterMinShowCallback: (() => void) | null = null;

    const ensure3sVisible = new Promise<void>((resolve) => {
      // Ensure loader is visible for at least 3 seconds
      minShowTimer = window.setTimeout(() => resolve(), 1500);
    });

    const onWindowLoad = new Promise<void>((resolve) => {
      if (document.readyState === "complete") resolve();
      else window.addEventListener("load", () => resolve(), { once: true });
    });

    // Run animation only after both: window fully loaded + 3s min display
    Promise.all([onWindowLoad, ensure3sVisible]).then(() => {
      // slight delay to guarantee header layout is fully ready
      requestAnimationFrame(() => {
        runLogoIntoHeader();
      });
    });

    function runLogoIntoHeader() {
      const overlay = overlayRef.current;
      const animLogo = animLogoRef.current;
      const headerBrandImg = document.querySelector(
        ".site-header .navbar-brand img.brand-logo"
      ) as HTMLImageElement | null;

      if (!overlay || !animLogo || !headerBrandImg) {
        setIsLoaded(true);
        return;
      }

      // 1) Hide the header logo to avoid double-vision
      headerBrandImg.style.opacity = "0";

      // 2) Read initial & final positions
      const initialRect = animLogo.getBoundingClientRect();
      const finalRect = headerBrandImg.getBoundingClientRect();

      // 3) Compute movement & scale
      const deltaX =
        finalRect.left + finalRect.width / 2 - (initialRect.left + initialRect.width / 2);
      const deltaY =
        finalRect.top + finalRect.height / 2 - (initialRect.top + initialRect.height / 2);
      const scaleX = finalRect.width / initialRect.width;
      const scaleY = finalRect.height / initialRect.height;

      // 4) Make sure the browser has initial styles applied (no transition yet)
      animLogo.style.transition = "none";
      animLogo.style.transform = "translate(0, 0) scale(1, 1)";

      // 5) Force a reflow so the next transform transitions
      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
      animLogo.getBoundingClientRect();

      // 6) Animate to header logo position
      requestAnimationFrame(() => {
        animLogo.style.transition = "transform 700ms cubic-bezier(0.22, 1, 0.36, 1)";
        animLogo.style.transform = `translate(${deltaX}px, ${deltaY}px) scale(${scaleX}, ${scaleY})`;
      });

      // 7) On animation end → reveal header logo, fade overlay, then unmount
      const onEnd = () => {
        animLogo.removeEventListener("transitionend", onEnd);
        headerBrandImg.style.opacity = "1";

        // Fade the white overlay for a clean exit
        setIsFading(true);

        // Wait for CSS fade (~250ms), then remove the overlay
        setTimeout(() => {
          setIsLoaded(true);
        }, 260);
      };
      animLogo.addEventListener("transitionend", onEnd);
    }

    return () => {
      if (minShowTimer) clearTimeout(minShowTimer);
      afterMinShowCallback = null;
    };
  }, []);

  return (
    <div className="container-fluid p-0">
        
  {!isLoaded && (
        <div
          ref={overlayRef}
          className={`loader-overlay${isFading ? " fading" : ""}`}
        >
          <img ref={animLogoRef} src={LogoDark} alt="Brand" className="loader-logo" />
        </div>
      )}

      <header className="site-header position-absolute top-0 start-0 w-100">
        <nav className="navbar navbar-expand-lg navbar-dark transparent-nav py-3">
          <div className="container-fluid px-3 px-lg-4">
            <a
              className="navbar-brand d-flex align-items-center gap-2"
              href="/"
            >
              <img src={Logo} className="brand-logo" height={28} alt="Brand" />
            </a>

            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#mainNav"
              aria-controls="mainNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>

            {/* Right: Links */}
            <div className="collapse navbar-collapse" id="mainNav">
              <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                {/* Bootstrap 4 users: replace ms-auto with ml-auto */}
                <li className="nav-item">
                  <a className="nav-link" href="#features">
                    Features
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#about">
                    About
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/login">
                    Sign in
                  </a>
                </li>
                <li className="nav-item ms-lg-2">
                  <a className="nav-link" href="/get-started">
                    Get started
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>

      {/* ======= BELOW-HEADER SECTION WITH FULL-WIDTH VIDEO BACKGROUND ======= */}
      <div className="landing-hero">
        {/* Background video (covers the entire hero section) */}
        <div className="video-bg">
          {/* <video
            className="video-bg__media"
            src={Mov}
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            onLoadStart={(e: any) => {
              e.target.playbackRate = 0.8;
            }}
          /> */}

          {/* Contrast overlay (below header) */}
          <div className="video-bg__overlay" />
        </div>

        {/* Foreground content over the video */}
        <div className="landing-hero__content container-fluid ml-5">
          <div className="row " style={{ marginLeft: "40px" }}>
            <div className="col-12 col-lg-8 ml-5">
              <h1
                className="display-5  text-white mb-2"
                style={{ fontSize: "30px" }}
              >
                Why sit in traffic? When the
              </h1>
              <p
                className="lead text-white-50 fw-semibold mb-3"
                style={{ fontSize: "60px" }}
              >
                Sky is already waiting for you
              </p>
              <div className="d-flex gap-2">
                <a
                  href="/get-started"
                  className="btn btn-light btn-lg rounded-pill px-4"
                >
                  Explore{" "}
                  <img
                    src={Arrow}
                    className="brand-logo"
                    height={11}
                    alt="Brand"
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ======= MORE CONTENT BELOW (normal sections) ======= */}
      <div className="container py-5">
        <section id="features" className="py-5">
          <h2 className="mb-3">Features</h2>
          <p className="text-muted">Your feature list goes here…</p>
        </section>

        <section id="about" className="py-5">
          <h2 className="mb-3">About</h2>
          <p className="text-muted">About your product/company…</p>
        </section>
      </div>
    </div>
  );
}

export default LandingPage;
