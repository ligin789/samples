import Page from '../../components/Page';

const BusinessRules = () => <Page title="Business Rules" />;

export default BusinessRules;
