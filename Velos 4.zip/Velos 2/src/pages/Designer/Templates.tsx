import { useState } from 'react';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { addTemplate, updateTemplate, deleteTemplate } from '../../redux/template/templateThunks';
import type { Template } from '../../redux/template/templateTypes';

const Templates = () => {
  const dispatch = useAppDispatch();
  const { templates, loading, error } = useAppSelector((state) => state.template);
  const [jsonText, setJsonText] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [templateVersion, setTemplateVersion] = useState('');
  const [jsonError, setJsonError] = useState('');

  const handleAdd = () => {
    if (!templateId || !templateVersion || !jsonText) return;
    
    try {
      const parsed = JSON.parse(jsonText);
      const template: Template = {
        template_id: templateId,
        template_version: templateVersion,
        template: parsed
      };
      dispatch(addTemplate(template));
      setTemplateId('');
      setTemplateVersion('');
      setJsonText('');
      setJsonError('');
    } catch (err) {
      setJsonError('Invalid JSON format');
    }
  };

  const handleDelete = (id: string) => {
    dispatch(deleteTemplate(id));
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Templates</h2>
      
      <div style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '4px' }}>
        <h4>Add Template</h4>
        <div style={{ marginBottom: '10px' }}>
          <input
            placeholder="Template ID"
            value={templateId}
            onChange={(e) => setTemplateId(e.target.value)}
            style={{ marginRight: '10px', padding: '5px' }}
          />
          <input
            placeholder="Version"
            value={templateVersion}
            onChange={(e) => setTemplateVersion(e.target.value)}
            style={{ padding: '5px' }}
          />
        </div>
        <textarea
          placeholder="Template JSON"
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
          style={{ width: '100%', height: '200px', marginBottom: '10px', padding: '10px', fontFamily: 'monospace' }}
        />
        {jsonError && <div style={{ color: 'red', marginBottom: '10px' }}>{jsonError}</div>}
        <button onClick={handleAdd} style={{ padding: '8px 16px', background: '#007bff', color: 'white', border: 'none', borderRadius: '4px' }}>
          Add Template
        </button>
      </div>

      {loading && <div>Loading...</div>}
      {error && <div style={{ color: 'red' }}>{error}</div>}

      <div>
        <h4>Templates ({templates.length})</h4>
        {templates.map((template) => (
          <div key={template.template_id} style={{ padding: '10px', border: '1px solid #eee', marginBottom: '10px', borderRadius: '4px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <strong>{template.template_id}</strong> (v{template.template_version})
              </div>
              <button
                onClick={() => handleDelete(template.template_id)}
                style={{ padding: '4px 8px', background: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}
              >
                Delete
              </button>
            </div>
            <pre style={{ background: '#f8f9fa', padding: '10px', marginTop: '10px', fontSize: '12px', overflow: 'auto' }}>
              {JSON.stringify(template.template, null, 2)}
            </pre>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Templates;
