import Page from '../../components/Page';

const Workflow = () => <Page title="Workflow" />;

export default Workflow;
