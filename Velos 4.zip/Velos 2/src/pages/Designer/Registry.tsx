import Page from '../../components/Page';

const Registry = () => <Page title="Registry" />;

export default Registry;
