import { useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { addUser } from '../redux/login/loginActions';
import { useAppDispatch, useAppSelector } from '../store/hooks';

const Signup = () => {
  const [name, setName] = useState<string>('');
  const [role, setRole] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const users = useAppSelector(state => state.login.users);

  const roles = [
    { id: 1, name: "Platform Admin" },
    { id: 2, name: "EVTOL Operator" },
    { id: 3, name: "Ground Handler" },
    { id: 4, name: "Booking Partner" },
    { id: 5, name: "Customer Service Portal" }
  ];

  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (name.trim() && role) {
      setLoading(true);
      
      setTimeout(() => {
        const selectedRole = roles.find(r => r.id === parseInt(role));
        if (selectedRole) {
          const newUser = {
            id: users.length + 1,
            name: name.trim(),
            role: parseInt(role),
            roleName: selectedRole.name
          };
          
          dispatch(addUser(newUser));
          setLoading(false);
          navigate('/login');
        }
      }, 1000);
    }
  };

  return (
    <div className="container" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div className="row justify-content-center w-100">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">Signup</h2>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={loading}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Role</label>
                  <select
                    className="form-select"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    disabled={loading}
                  >
                    <option value="">Select Role</option>
                    {roles.map(r => (
                      <option key={r.id} value={r.id}>{r.name}</option>
                    ))}
                  </select>
                </div>
                <button type="submit" className="btn btn-primary w-100" disabled={loading}>
                  {loading ? 'Verifying OTP...' : 'Signup'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
