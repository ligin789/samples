import Page from '../../components/Page';

const AnotherApp = () => <Page title="Another App" />;

export default AnotherApp;
