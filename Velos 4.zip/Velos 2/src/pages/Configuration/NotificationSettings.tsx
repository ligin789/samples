import Page from '../../components/Page';

const NotificationSettings = () => <Page title="Notification Settings" />;

export default NotificationSettings;
