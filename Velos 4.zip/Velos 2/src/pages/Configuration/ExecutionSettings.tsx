import Page from '../../components/Page';

const ExecutionSettings = () => <Page title="Execution Settings" />;

export default ExecutionSettings;
