import Page from '../../components/Page';

const SecuritySettings = () => <Page title="Security Settings" />;

export default SecuritySettings;
