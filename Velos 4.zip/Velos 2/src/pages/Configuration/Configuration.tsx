import Page from '../../components/Page';

const Configuration = () => <Page title="Configuration" />;

export default Configuration;
