import Page from '../../components/Page';

const Event = () => <Page title="Event" />;

export default Event;
