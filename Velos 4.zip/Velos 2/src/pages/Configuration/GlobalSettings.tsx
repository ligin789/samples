import Page from '../../components/Page';

const GlobalSettings = () => <Page title="Global Settings" />;

export default GlobalSettings;
