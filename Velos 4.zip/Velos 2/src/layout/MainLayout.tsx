import { Outlet } from 'react-router-dom';
import Header from '../components/Header';

const MainLayout = () => {
  return (
    <div>
      <Header />
      <main style={{ padding: '40px', minHeight: 'calc(100vh - 80px)' }}>
        <Outlet />
      </main>
    </div>
  );
};

export default MainLayout;
