import { Link, useNavigate } from "react-router-dom";
import { logoutUser } from "../redux/login/loginActions";
import { useAppDispatch, useAppSelector } from '../store/hooks';

const Navbar = () => {
  const user = useAppSelector(state => state.login.user);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logoutUser());
    navigate("/login");
  };

  return (
    <nav className="container-fluid navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand" to="/">
          Velos
        </Link>
        <div className="navbar-nav ms-auto">
          {user ? (
            <>
              <span className="navbar-text me-3">Welcome, {user.name}</span>
              <button
                className="btn btn-outline-light btn-sm"
                onClick={handleLogout}
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link className="nav-link" to="/login">
                Login
              </Link>
              <Link className="nav-link" to="/signup">
                Signup
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
