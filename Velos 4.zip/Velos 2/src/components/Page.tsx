import type { ReactNode } from 'react';

interface PageProps {
  title: string;
  children?: ReactNode;
}

const Page = ({ title, children }: PageProps) => {
  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
      <h1 style={{ fontSize: '32px', marginBottom: '24px', color: '#1e3a5f' }}>{title}</h1>
      {children}
    </div>
  );
};

export default Page;
