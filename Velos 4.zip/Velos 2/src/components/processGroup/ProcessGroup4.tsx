import type { ReactNode } from 'react';

interface ProcessGroup4Props {
  children?: ReactNode;
}

const ProcessGroup4 = ({ children }: ProcessGroup4Props) => {
  return (
    <div className="p-3">
      <h6 className="mb-3">Right Top Section</h6>
      {children}
    </div>
  );
};

export default ProcessGroup4;
