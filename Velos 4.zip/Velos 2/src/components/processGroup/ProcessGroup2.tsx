import type { ReactNode } from 'react';

interface ProcessGroup2Props {
  children?: ReactNode;
}

const ProcessGroup2 = ({ children }: ProcessGroup2Props) => {
  return (
    <div className="d-flex align-items-center px-3 h-100">
      <div className="d-flex gap-2">
        <button className="btn btn-sm btn-outline-secondary">Button 1</button>
        <button className="btn btn-sm btn-outline-secondary">Button 2</button>
        <button className="btn btn-sm btn-outline-secondary">Button 3</button>
        <button className="btn btn-sm btn-outline-secondary">Button 4</button>
      </div>
      {children}
    </div>
  );
};

export default ProcessGroup2;
