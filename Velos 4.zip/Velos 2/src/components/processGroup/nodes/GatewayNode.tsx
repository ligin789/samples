import { Handle, Position } from '@xyflow/react';

const GatewayNode = ({ data }: any) => {
  return (
    <div style={{
      width: 80,
      height: 80,
      background: '#ff9800',
      transform: 'rotate(45deg)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '2px solid #e65100',
      position: 'relative'
    }}>
      <Handle type="target" position={Position.Top} style={{ transform: 'rotate(-45deg)' }} />
      <div style={{
        transform: 'rotate(-45deg)',
        color: 'white',
        fontSize: '10px',
        fontWeight: 'bold',
        textAlign: 'center',
        maxWidth: '60px',
        wordWrap: 'break-word'
      }}>
        {data.label}
      </div>
      <Handle type="source" position={Position.Bottom} style={{ transform: 'rotate(-45deg)' }} />
    </div>
  );
};

export default GatewayNode;
