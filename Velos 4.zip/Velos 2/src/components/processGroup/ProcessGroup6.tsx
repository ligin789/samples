import type { ReactNode } from 'react';

interface ProcessGroup6Props {
  children?: ReactNode;
}

const ProcessGroup6 = ({ children }: ProcessGroup6Props) => {
  return (
    <div className="d-flex align-items-center px-3 h-100">
      <div className="d-flex gap-2">
        <button className="btn btn-sm btn-outline-secondary">Action 1</button>
        <button className="btn btn-sm btn-outline-secondary">Action 2</button>
        <button className="btn btn-sm btn-outline-secondary">Action 3</button>
        <button className="btn btn-sm btn-outline-secondary">Action 4</button>
      </div>
      {children}
    </div>
  );
};

export default ProcessGroup6;
