import { useState, useEffect, useMemo } from "react";
import { Tree } from "react-arborist";
import { useAppSelector, useAppDispatch } from "../../store/hooks";
import { addProcess, setSelectedProcess } from "../../redux/process/processActions";
import type { Process } from "../../redux/process/processTypes";
import "./LeftSideBar.css";

/* =========================
   TYPES
========================= */

interface NodeType {
  node_id: string;
  process_key: string;
}

interface ProcessGroup {
  process_group_id: string;
  name: string;
  nodes: NodeType[];
}

interface TreeNode {
  id: string;
  name: string;
  children?: TreeNode[];
  isRoot?: boolean;
  processData?: Process;
}

interface CreateProcessModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (processData: any) => void;
}

const CreateProcessModal = ({ isOpen, onClose, onSubmit }: CreateProcessModalProps) => {
  const { processGroup } = useAppSelector((state) => state.processGroup);
  const { domainList } = useAppSelector((state) => state.domain);
  const { schemaList } = useAppSelector((state) => state.schema);
  const { templates } = useAppSelector((state) => state.template);

  const [formData, setFormData] = useState({
    name: '',
    processGroupId: '',
    domainId: '',
    schemas: [] as string[],
    templateId: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: Record<string, string> = {};
    if (!formData.name) newErrors.name = 'Process name is required';
    if (!formData.processGroupId) newErrors.processGroupId = 'Process group is required';
    if (!formData.domainId) newErrors.domainId = 'Domain is required';
    if (!formData.templateId && formData.schemas.length === 0) {
      newErrors.selection = 'Either template or at least one schema is required';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const selectedDomain = domainList.find(d => d.id === formData.domainId);
    const processId = `proc-${Date.now()}`;
    const processKey = formData.name.toUpperCase().replace(/\s+/g, '_');

    const processData: Process = {
      process_id: processId,
      process_key: processKey,
      name: formData.name,
      version: "1.0.0",
      status: "active",
      domain: selectedDomain ? {
        industry: selectedDomain.industry,
        function: selectedDomain.function,
        subfunction: selectedDomain.subfunction,
        applicability: selectedDomain.applicability
      } : undefined,
      processFlow: { nodes: [] },
      tasks: [],
      entry_points: [],
      exit_points: []
    };

    onSubmit(processData);
    setFormData({ name: '', processGroupId: '', domainId: '', schemas: [], templateId: '' });
    setErrors({});
  };

  if (!isOpen) return null;

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
      <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', width: '500px', maxHeight: '80vh', overflow: 'auto' }}>
        <h3>Create New Process</h3>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '15px' }}>
            <label>Process Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            />
            {errors.name && <div style={{ color: 'red', fontSize: '12px' }}>{errors.name}</div>}
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label>Process Group *</label>
            <select
              value={formData.processGroupId}
              onChange={(e) => setFormData({ ...formData, processGroupId: e.target.value })}
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            >
              <option value="">Select Process Group</option>
              {processGroup.map((pg) => (
                <option key={pg.process_group_id} value={pg.process_group_id}>
                  {pg.name}
                </option>
              ))}
            </select>
            {errors.processGroupId && <div style={{ color: 'red', fontSize: '12px' }}>{errors.processGroupId}</div>}
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label>Domain *</label>
            <select
              value={formData.domainId}
              onChange={(e) => setFormData({ ...formData, domainId: e.target.value })}
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            >
              <option value="">Select Domain</option>
              {domainList.map((domain) => (
                <option key={domain.id} value={domain.id}>
                  {domain.industry} - {domain.function} - {domain.subfunction}
                </option>
              ))}
            </select>
            {errors.domainId && <div style={{ color: 'red', fontSize: '12px' }}>{errors.domainId}</div>}
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label>Template</label>
            <select
              value={formData.templateId}
              onChange={(e) => setFormData({ ...formData, templateId: e.target.value, schemas: [] })}
              disabled={formData.schemas.length > 0}
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            >
              <option value="">Select Template (Optional)</option>
              {templates.map((template) => (
                <option key={template.template_id} value={template.template_id}>
                  {template.template_id} (v{template.template_version})
                </option>
              ))}
            </select>
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label>Schemas</label>
            <div style={{ maxHeight: '120px', overflow: 'auto', border: '1px solid #ccc', padding: '8px', marginTop: '5px' }}>
              {schemaList.map((schema) => (
                <div key={schema.id} style={{ marginBottom: '5px' }}>
                  <label style={{ display: 'flex', alignItems: 'center' }}>
                    <input
                      type="checkbox"
                      checked={formData.schemas.includes(schema.id)}
                      disabled={!!formData.templateId}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormData({ ...formData, schemas: [...formData.schemas, schema.id] });
                        } else {
                          setFormData({ ...formData, schemas: formData.schemas.filter(id => id !== schema.id) });
                        }
                      }}
                      style={{ marginRight: '8px' }}
                    />
                    {schema.name}
                  </label>
                </div>
              ))}
            </div>
            {errors.selection && <div style={{ color: 'red', fontSize: '12px' }}>{errors.selection}</div>}
          </div>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
            <button type="button" onClick={onClose} style={{ padding: '8px 16px' }}>Cancel</button>
            <button type="submit" style={{ padding: '8px 16px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px' }}>Create</button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* =========================
   COMPONENT
========================= */

const LeftSideBar = ({
  processGroups,
  processes,
  onProcessSelect,
  onDeleteProcess,
}: any) => {
  const dispatch = useAppDispatch();
  const [selectedProcessGroup, setSelectedProcessGroup] = useState<string>("");
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>("All");
  const [isModalOpen, setIsModalOpen] = useState(false);

  /* =========================
     DEFAULT SELECT GROUP
  ========================= */

  useEffect(() => {
    if (processGroups.length > 0 && !selectedProcessGroup) {
      setSelectedProcessGroup(processGroups[0].process_group_id);
    }
  }, [processGroups, selectedProcessGroup]);

  /* =========================
     PROCESS LOOKUP MAP (O1)
  ========================= */

  const processMap = useMemo(() => {
    const map: Record<string, Process> = {};
    processes.forEach((p: any) => {
      map[p.process_key] = p;
    });
    return map;
  }, [processes]);

  /* =========================
     RESOLVE PROCESSES FROM NODES
  ========================= */
  function truncateString(str: any, maxLength: any) {
    if (str.length > maxLength) {
      return str.slice(0, maxLength) + "...";
    } else {
      return str;
    }
  }

  const resolvedProcesses = useMemo(() => {
    if (!selectedProcessGroup) return [];

    const selectedGroup = processGroups.find(
      (pg: any) => pg.process_group_id === selectedProcessGroup
    );

    if (!selectedGroup) return [];

    return selectedGroup.nodes
      .map((node: any) => processMap[node.process_key])
      .filter((process: any): process is Process => {
        if (!process) return false;

        if (selectedStatusFilter === "All") return true;

        return (
          process.status.toLowerCase() === selectedStatusFilter.toLowerCase()
        );
      });
  }, [selectedProcessGroup, processGroups, processMap, selectedStatusFilter]);

  /* =========================
     TREE DATA
  ========================= */

  const treeData = useMemo<TreeNode[]>(() => {
    if (!selectedProcessGroup) return [];

    const selectedGroup = processGroups.find(
      (pg: any) => pg.process_group_id === selectedProcessGroup
    );

    if (!selectedGroup) return [];

    const rootNode: TreeNode = {
      id: selectedProcessGroup,
      name: selectedGroup.name,
      isRoot: true,
      children: resolvedProcesses.map((p: any) => ({
        id: p.process_id,
        name: p.name,
        processData: p,
      })),
    };

    return [rootNode];
  }, [selectedProcessGroup, processGroups, resolvedProcesses]);

  /* =========================
     HANDLERS
  ========================= */

  const handleCreateProcess = (processData: Process) => {
    dispatch(addProcess(processData));
    dispatch(setSelectedProcess(processData));
    onProcessSelect(processData);
    setIsModalOpen(false);
  };

  /* =========================
     TREE NODE RENDER
  ========================= */

  const Node = ({
    node,
    style,
    dragHandle,
  }: {
    node: any;
    style: React.CSSProperties;
    dragHandle: (el: HTMLDivElement | null) => void;
  }) => {
    const isArchived = node.data.processData?.status === "archived";

    return (
      <div
        ref={dragHandle}
        style={style}
        className={`treeNode ${isArchived ? "archived" : ""}`}
        onClick={() => {
          if (node.data.processData) {
            onProcessSelect(node.data.processData);
          }
        }}
      >
        <div className="nodeContent">
          <span className="nodeIcon">
            {node.data.isRoot ? "📁" : "📄"}
          </span>
          <span className={`nodeName ${node.data.isRoot ? "rootNode" : ""}`}>
            {truncateString(node.data.name, 20)}
          </span>
        </div>

        {node.data.processData && (
          <span
            className="deleteIcon"
            onClick={(e) => {
              e.stopPropagation();
              onDeleteProcess(node.data.processData.process_id);
            }}
          >
            🗑️
          </span>
        )}
      </div>
    );
  };

  /* =========================
     RENDER
  ========================= */

  return (
    <div className="leftSideBar">
      {/* Add Process Button */}
      <div style={{ padding: '10px', borderBottom: '1px solid #eee' }}>
        <button
          onClick={() => setIsModalOpen(true)}
          style={{
            width: '100%',
            padding: '8px',
            backgroundColor: '#28a745',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '5px'
          }}
        >
          <span style={{ fontSize: '16px' }}>+</span>
          New Process
        </button>
      </div>

      {/* Process Group Dropdown */}
      <div className="dropdownSection">
        <div className="dropdownLabel">Process Group</div>
        <select
          className="dropdown"
          value={selectedProcessGroup}
          onChange={(e) => setSelectedProcessGroup(e.target.value)}
        >
          {processGroups.map((pg: any) => (
            <option key={pg.process_group_id} value={pg.process_group_id}>
              {pg.name}
            </option>
          ))}
        </select>
      </div>

      {/* Status Filter */}
      <div className="dropdownSection">
        <div className="dropdownLabel">Status Filter</div>
        <select
          className="dropdown"
          value={selectedStatusFilter}
          onChange={(e) => setSelectedStatusFilter(e.target.value)}
        >
          <option value="All">All</option>
          <option value="active">Active</option>
          <option value="archived">Archived</option>
        </select>
      </div>

      {/* Tree */}
      <div className="treeContainer">
        {resolvedProcesses.length === 0 ? (
          <div className="emptyMessage">No processes available</div>
        ) : (
          <Tree
            data={treeData}
            openByDefault
            width="100%"
            height={400}
            indent={24}
            rowHeight={36}
          >
            {Node}
          </Tree>
        )}
      </div>

      <CreateProcessModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleCreateProcess}
      />
    </div>
  );
};

export default LeftSideBar;