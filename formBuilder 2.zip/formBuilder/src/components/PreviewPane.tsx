import { useMemo, useState } from 'react'
import { useAppSelector } from '../state/hooks'
import { FormRenderer } from '../renderer/FormRenderer'
import { getByPath, setByPath } from '../utils/json'
import { isInputComponent, validateAll, valueKeyOf } from '../utils/validate'
import { visitAll } from '../utils/tree'

const DEVICES = [
  { id: 'desktop', label: '🖥 Desktop', width: 720 },
  { id: 'tablet', label: '📱 iPad', width: 600 },
  { id: 'phone', label: '📱 Phone', width: 375 },
] as const

export function PreviewPane() {
  const schema = useAppSelector((s) => s.schema)
  const [device, setDevice] = useState<(typeof DEVICES)[number]>(DEVICES[0])

  // initial values: defaultValue prop, overridden by bound sample data
  const initialValues = useMemo(() => {
    const values: Record<string, unknown> = {}
    visitAll(schema.components, (c) => {
      const key = valueKeyOf(c)
      if (isInputComponent(c) && c.props.defaultValue !== undefined && c.props.defaultValue !== '') {
        values[key] = c.props.defaultValue
      }
      // Seed every bound component (inputs and display-bound heading/paragraph).
      if (c.binding && schema.sampleData !== undefined) {
        const bound = getByPath(schema.sampleData, c.binding)
        if (bound !== undefined && typeof bound !== 'object') values[key] = bound
      }
    })
    return values
  }, [schema])

  const [values, setValues] = useState<Record<string, unknown>>(initialValues)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [output, setOutput] = useState<string | null>(null)
  const [seededFrom, setSeededFrom] = useState(initialValues)

  // re-seed when the schema (and thus initial values) changes
  if (seededFrom !== initialValues) {
    setSeededFrom(initialValues)
    setValues(initialValues)
    setErrors({})
    setOutput(null)
  }

  const submit = () => {
    const validationErrors = validateAll(schema.components, values)
    setErrors(validationErrors)
    if (Object.keys(validationErrors).length > 0) {
      setOutput(null)
      return
    }
    // assemble submission payload following the binding paths
    const data: Record<string, unknown> = {}
    visitAll(schema.components, (c) => {
      if (!isInputComponent(c)) return
      const key = valueKeyOf(c)
      setByPath(data, c.binding || c.id, values[key] ?? null)
    })
    setOutput(JSON.stringify(data, null, 2))
  }

  return (
    <main className="preview-pane">
      <div className="preview-toolbar">
        {DEVICES.map((d) => (
          <button
            key={d.id}
            className={device.id === d.id ? 'active' : ''}
            onClick={() => setDevice(d)}
          >
            {d.label}
          </button>
        ))}
        <div className="spacer" />
        <button
          className="btn btn-sm"
          onClick={() => {
            setValues(initialValues)
            setErrors({})
            setOutput(null)
          }}
        >
          Reset values
        </button>
      </div>

      <div className="preview-stage">
        <div className="preview-frame" style={{ width: device.width, maxWidth: '100%' }}>
          <div className="form-card-title">{schema.name}</div>
          {schema.components.length === 0 ? (
            <p className="muted">Nothing to preview yet — add components in the Edit tab.</p>
          ) : (
            <FormRenderer
              components={schema.components}
              values={values}
              errors={errors}
              onChange={(key, value) => setValues((v) => ({ ...v, [key]: value }))}
              onSubmit={submit}
            />
          )}
        </div>

        {output && (
          <div className="preview-output">
            <div className="preview-output-title">✓ Submission payload (bindings applied)</div>
            <pre>{output}</pre>
          </div>
        )}
      </div>
    </main>
  )
}
