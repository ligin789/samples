import { Fragment } from 'react'
import type { CSSProperties } from 'react'
import { useDraggable, useDroppable } from '@dnd-kit/core'
import type { FormComponent } from '../types/schema'
import { registry } from '../definitions/registry'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { duplicateComponent, removeComponent, select, setImportOpen } from '../state/actions'
import { LeafField } from '../renderer/FormRenderer'
import { getByPath } from '../utils/json'
import { containerBoxStyle, containerLayoutStyle, effectiveDirection } from '../utils/style'

/* -------------------------------- drop zone ------------------------------- */

function DropZone({ parentId, index }: { parentId: string | null; index: number }) {
  const { setNodeRef, isOver } = useDroppable({
    id: `dz|${parentId ?? 'root'}|${index}`,
    data: { parentId, index },
  })
  return <div ref={setNodeRef} className={`drop-zone${isOver ? ' over' : ''}`} />
}

/* ------------------------------- canvas item ------------------------------ */

function CanvasItem({ component }: { component: FormComponent }) {
  const selectedId = useAppSelector((s) => s.selectedId)
  const sampleData = useAppSelector((s) => s.schema.sampleData)
  const dispatch = useAppDispatch()

  const { attributes, listeners, setNodeRef: setDragRef, isDragging } = useDraggable({
    id: `node-${component.id}`,
    data: { kind: 'canvas', id: component.id },
  })

  const def = registry[component.type]
  // Leaf, bindable components accept a Data-tab field dropped on them to map it.
  const canBind = def.bindable && component.type !== 'container'
  const { setNodeRef: setDropRef, isOver, active } = useDroppable({
    id: `bind-${component.id}`,
    data: { kind: 'bind-target', id: component.id },
    disabled: !canBind,
  })
  const setNodeRef = (el: HTMLElement | null) => {
    setDragRef(el)
    setDropRef(el)
  }
  const bindOver = isOver && active?.data.current?.kind === 'data'

  const selected = selectedId === component.id
  const bound = component.binding ? getByPath(sampleData, component.binding) : undefined
  // arrays/objects (e.g. a binding to the option-source array) aren't previewable values
  const boundValue = typeof bound === 'object' && bound !== null ? undefined : bound

  return (
    <div
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={`canvas-item${selected ? ' selected' : ''}${isDragging ? ' dragging' : ''}${bindOver ? ' bind-over' : ''}`}
      onClick={(e) => {
        e.stopPropagation()
        dispatch(select(component.id))
      }}
    >
      <div className="canvas-item-tools">
        <span className="canvas-item-tag">
          {def.label}
          {component.binding && <span className="canvas-item-binding">⇄ {component.binding}</span>}
        </span>
        <span className="canvas-item-actions">
          <button
            title="Duplicate"
            onClick={(e) => {
              e.stopPropagation()
              dispatch(duplicateComponent(component.id))
            }}
          >
            ⧉
          </button>
          <button
            title="Delete"
            onClick={(e) => {
              e.stopPropagation()
              dispatch(removeComponent(component.id))
            }}
          >
            ✕
          </button>
        </span>
      </div>

      {component.type === 'container' ? (
        <div
          className={`canvas-container ff-${effectiveDirection(component.style, component.props.direction)}`}
          style={containerBoxStyle(component.style)}
        >
          {Boolean(component.props.label) && (
            <div className="canvas-container-label">{component.props.label as string}</div>
          )}
          <ItemList
            parentId={component.id}
            components={component.children ?? []}
            layoutStyle={containerLayoutStyle(component.style)}
          />
        </div>
      ) : (
        <div className="canvas-leaf">
          <LeafField
            component={component}
            value={boundValue ?? (component.props.defaultValue as unknown)}
            disabled
          />
        </div>
      )}
    </div>
  )
}

function ItemList({
  parentId,
  components,
  layoutStyle,
}: {
  parentId: string | null
  components: FormComponent[]
  layoutStyle?: CSSProperties
}) {
  return (
    <div className={`item-list${components.length === 0 ? ' empty' : ''}`} style={layoutStyle}>
      <DropZone parentId={parentId} index={0} />
      {components.map((c, i) => (
        <Fragment key={c.id}>
          <CanvasItem component={c} />
          <DropZone parentId={parentId} index={i + 1} />
        </Fragment>
      ))}
      {components.length === 0 && parentId !== null && (
        <div className="container-empty-hint">Drop components here</div>
      )}
    </div>
  )
}

/* --------------------------------- canvas --------------------------------- */

export function Canvas() {
  const components = useAppSelector((s) => s.schema.components)
  const name = useAppSelector((s) => s.schema.name)
  const dispatch = useAppDispatch()

  return (
    <main className="canvas" onClick={() => dispatch(select(null))}>
      <div className="form-card">
        <div className="form-card-title">{name}</div>
        {components.length === 0 ? (
          <div className="canvas-empty">
            <DropZone parentId={null} index={0} />
            <div className="canvas-empty-art">⬡</div>
            <p>Drag components from the left panel, or</p>
            <button
              className="btn btn-primary"
              onClick={(e) => {
                e.stopPropagation()
                dispatch(setImportOpen(true))
              }}
            >
              Generate from API JSON
            </button>
          </div>
        ) : (
          <ItemList parentId={null} components={components} />
        )}
      </div>
    </main>
  )
}
