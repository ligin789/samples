import { useAppDispatch, useAppSelector } from '../state/hooks'
import { clearForm, redo, setFormName, setHtmlImportOpen, setImportOpen, setSchemaImportOpen, setTab, undo } from '../state/actions'

export function Toolbar() {
  const tab = useAppSelector((s) => s.tab)
  const name = useAppSelector((s) => s.schema.name)
  const schema = useAppSelector((s) => s.schema)
  const canUndo = useAppSelector((s) => s.past.length > 0)
  const canRedo = useAppSelector((s) => s.future.length > 0)
  const dispatch = useAppDispatch()

  const download = () => {
    const blob = new Blob([JSON.stringify(schema, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${name.replace(/\s+/g, '-').toLowerCase() || 'form'}.template.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <header className="toolbar">
      <div className="toolbar-left">
        <span className="logo">⬡ FormBuilder Studio</span>
        <input
          className="form-name-input"
          value={name}
          onChange={(e) => dispatch(setFormName(e.target.value))}
          title="Form name"
        />
      </div>

      <nav className="toolbar-tabs">
        {(['edit', 'preview', 'json'] as const).map((t) => (
          <button key={t} className={tab === t ? 'active' : ''} onClick={() => dispatch(setTab(t))}>
            {t === 'edit' ? '✏️ Edit' : t === 'preview' ? '▶ Preview' : '{ } JSON'}
          </button>
        ))}
      </nav>

      <div className="toolbar-right">
        <button className="icon-btn" title="Undo (⌘Z)" disabled={!canUndo} onClick={() => dispatch(undo())}>
          ↩
        </button>
        <button className="icon-btn" title="Redo (⇧⌘Z)" disabled={!canRedo} onClick={() => dispatch(redo())}>
          ↪
        </button>
        <span className="toolbar-sep" />
        <button className="btn" onClick={() => dispatch(setSchemaImportOpen(true))}>
          {'{ }'} Import JSON Schema
        </button>
        <button className="btn" onClick={() => dispatch(setImportOpen(true))}>
          ⇄ Import API JSON
        </button>
        <button className="btn" onClick={() => dispatch(setHtmlImportOpen(true))}>
          {'</>'} Import HTML
        </button>
        <button className="btn" onClick={download}>
          ⬇ Export
        </button>
        <button
          className="btn btn-danger"
          onClick={() => {
            if (confirm('Remove all components from the form?')) dispatch(clearForm())
          }}
        >
          Clear
        </button>
      </div>
    </header>
  )
}
