import { useMemo, useState } from 'react'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { setComponents, setJsonSchema, setSchemaImportOpen } from '../state/actions'
import { generateComponentsFromFields } from '../utils/json'
import { looksLikeJsonSchema, schemaToFields, schemaToSampleData } from '../utils/jsonSchema'

const SAMPLE_SCHEMA = {
  $schema: 'https://json-schema.org/draft-07/schema#',
  title: 'Customer',
  type: 'object',
  required: ['firstName', 'email'],
  properties: {
    firstName: { type: 'string', minLength: 2, maxLength: 40 },
    lastName: { type: 'string' },
    email: { type: 'string', format: 'email' },
    phone: { type: 'string', format: 'tel' },
    age: { type: 'integer', minimum: 18, maximum: 120 },
    birthDate: { type: 'string', format: 'date' },
    newsletter: { type: 'boolean', default: true },
    membership: { type: 'string', enum: ['basic', 'premium', 'enterprise'] },
    address: {
      type: 'object',
      required: ['city'],
      properties: {
        street: { type: 'string' },
        city: { type: 'string' },
        zip: { type: 'string', pattern: '^[0-9]{5}$' },
        country: { type: 'string', default: 'USA' },
      },
    },
    notes: { type: 'string', maxLength: 500 },
  },
}

export function SchemaImportModal() {
  const open = useAppSelector((s) => s.schemaImportOpen)
  const hasComponents = useAppSelector((s) => s.schema.components.length > 0)
  const dispatch = useAppDispatch()
  const setOpen = (value: boolean) => dispatch(setSchemaImportOpen(value))

  const [text, setText] = useState('')
  const [url, setUrl] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  // Live count of bindable fields so the user sees the schema parsed before applying.
  const fieldCount = useMemo(() => {
    if (!text.trim()) return 0
    try {
      return schemaToFields(JSON.parse(text)).length
    } catch {
      return 0
    }
  }, [text])

  if (!open) return null

  const fetchUrl = async () => {
    if (!url.trim()) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch(url.trim())
      if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`)
      const data = await res.json()
      setText(JSON.stringify(data, null, 2))
    } catch (e) {
      setError(
        `Could not fetch: ${e instanceof Error ? e.message : String(e)}. ` +
          'If this is a CORS error, copy the schema and paste it below instead.',
      )
    } finally {
      setLoading(false)
    }
  }

  /** Store the schema, optionally generating the whole form UI from it. */
  const apply = (generate: boolean) => {
    let parsed: unknown
    try {
      parsed = JSON.parse(text)
    } catch (e) {
      setError(`Invalid JSON: ${e instanceof Error ? e.message : String(e)}`)
      return
    }
    if (!looksLikeJsonSchema(parsed)) {
      setError(
        'This doesn’t look like a JSON Schema (expected "type" / "properties"). ' +
          'Paste a schema, or use “Import API JSON” for a raw response.',
      )
      return
    }
    if (generate && hasComponents && !confirm('Replace the current form with fields generated from the schema?')) {
      return
    }
    // The schema is the source of truth for binding + validation; sample data is
    // synthesized only so the Preview can pre-fill bound fields.
    dispatch(setJsonSchema(parsed, schemaToSampleData(parsed)))
    if (generate) {
      dispatch(setComponents(generateComponentsFromFields(schemaToFields(parsed))))
    }
    setError('')
    setText('')
    setOpen(false)
  }

  return (
    <div className="modal-backdrop" onClick={() => setOpen(false)}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Import JSON Schema</h3>
          <button className="icon-btn" onClick={() => setOpen(false)}>
            ✕
          </button>
        </div>
        <div className="modal-body">
          <p className="muted">
            Paste a JSON Schema (draft-07 style). The builder reads its fields, formats and validation
            rules so you can bind components to them — then either generate the whole form for you, or
            design your own layout (e.g. <strong>Import HTML</strong>) and link each field to the schema
            afterwards.
          </p>

          <div className="url-row">
            <input
              placeholder="https://api.example.com/schemas/customer.json"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && fetchUrl()}
            />
            <button className="btn" onClick={fetchUrl} disabled={loading}>
              {loading ? 'Fetching…' : 'Fetch'}
            </button>
          </div>

          <textarea
            className="json-input"
            rows={14}
            placeholder='{ "type": "object", "properties": { "firstName": { "type": "string" } } }'
            value={text}
            onChange={(e) => setText(e.target.value)}
            spellCheck={false}
          />

          {error && <div className="modal-error">{error}</div>}

          <div className="modal-footer">
            <button className="btn btn-sm" onClick={() => setText(JSON.stringify(SAMPLE_SCHEMA, null, 2))}>
              Load sample
            </button>
            <div className="spacer" />
            {fieldCount > 0 && (
              <span className="muted" style={{ fontSize: 13 }}>
                {fieldCount} field{fieldCount === 1 ? '' : 's'}
              </span>
            )}
            <button className="btn" onClick={() => setOpen(false)}>
              Cancel
            </button>
            <button className="btn" onClick={() => apply(false)} disabled={!text.trim()} title="Import the schema only; build the form yourself">
              I’ll design it myself
            </button>
            <button className="btn btn-primary" onClick={() => apply(true)} disabled={!text.trim()}>
              Generate the form
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
