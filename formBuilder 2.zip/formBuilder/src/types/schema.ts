/**
 * Platform-agnostic form template schema.
 * The same JSON is rendered by the web FormRenderer and the
 * React Native renderer (see native/FormRenderer.native.tsx).
 */

export type ComponentType =
  | 'textfield'
  | 'textarea'
  | 'number'
  | 'select'
  | 'radio'
  | 'checkbox'
  | 'switch'
  | 'datepicker'
  | 'heading'
  | 'paragraph'
  | 'divider'
  | 'button'
  | 'container'

export interface SelectOption {
  label: string
  value: string
}

export interface ValidationRules {
  required?: boolean
  minLength?: number
  maxLength?: number
  min?: number
  max?: number
  pattern?: string
}

/**
 * Per-component visual style. Intentionally a camelCase, flexbox-based subset
 * that is valid as BOTH a web React `style={}` and a React Native `style={}`,
 * so the same template JSON styles the web and native renderers identically.
 * Numbers are treated as px on web and as density-independent units on native.
 */
export interface ComponentStyle {
  marginTop?: number
  marginRight?: number
  marginBottom?: number
  marginLeft?: number
  paddingTop?: number
  paddingRight?: number
  paddingBottom?: number
  paddingLeft?: number
  width?: number | string
  height?: number | string
  /** Container layout (applies to a container's children) */
  flexDirection?: 'row' | 'column'
  justifyContent?:
    | 'flex-start'
    | 'center'
    | 'flex-end'
    | 'space-between'
    | 'space-around'
    | 'space-evenly'
  alignItems?: 'flex-start' | 'center' | 'flex-end' | 'stretch'
  flexWrap?: 'nowrap' | 'wrap'
  gap?: number
  /** Flex-item behaviour (useful when nested inside a horizontal container) */
  flex?: number
  alignSelf?: 'auto' | 'flex-start' | 'center' | 'flex-end' | 'stretch'
  backgroundColor?: string
  borderWidth?: number
  borderColor?: string
  borderRadius?: number
  fontSize?: number
  fontWeight?: '400' | '500' | '600' | '700'
  color?: string
  textAlign?: 'left' | 'center' | 'right'
}

export interface FormComponent {
  id: string
  type: ComponentType
  /** label, placeholder, options, text, direction, ... — per component type */
  props: Record<string, unknown>
  /** Data path into the bound API JSON, e.g. "user.address.city" or "items[0].name" */
  binding?: string
  validation?: ValidationRules
  /** Optional visual overrides — see ComponentStyle */
  style?: ComponentStyle
  children?: FormComponent[]
}

export interface FormSchema {
  version: string
  name: string
  components: FormComponent[]
  /** Sample API response used for binding suggestions and preview defaults */
  sampleData?: unknown
  /**
   * Imported JSON Schema (draft-07 style) describing the data contract.
   * When present it is the source of truth for bindable fields and validation;
   * `sampleData` is then only used to pre-fill the preview. Builder-only
   * metadata — the renderers consume `components`, not this.
   */
  jsonSchema?: unknown
}

export const emptySchema = (): FormSchema => ({
  version: '1.0',
  name: 'Untitled Form',
  components: [],
})
