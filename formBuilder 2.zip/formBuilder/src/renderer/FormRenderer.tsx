import type { FormComponent, SelectOption } from '../types/schema'
import { valueKeyOf } from '../utils/validate'
import { effectiveDirection, toCss } from '../utils/style'

/* ----------------------------- single field ------------------------------ */

/**
 * Text shown by a static heading/paragraph: the bound data value when the
 * component is bound and that value resolves to a non-empty primitive,
 * otherwise the authored `props.text`. Lets a hand-designed (HTML-imported)
 * card map its labels onto schema fields for display.
 */
function displayText(component: FormComponent, value: unknown): string {
  if (component.binding && value !== undefined && value !== null && value !== '') {
    return String(value)
  }
  return (component.props.text as string) ?? ''
}

interface LeafFieldProps {
  component: FormComponent
  value: unknown
  error?: string
  disabled?: boolean
  onChange?: (value: unknown) => void
}

/** Renders one non-container component. Used by the live renderer and (disabled) by the canvas. */
export function LeafField({ component, value, error, disabled, onChange }: LeafFieldProps) {
  const p = component.props
  const label = p.label as string | undefined
  const helpText = p.helpText as string | undefined
  const requiredMark = component.validation?.required ? <span className="ff-required">*</span> : null

  const wrap = (control: React.ReactNode, opts?: { inline?: boolean }) => (
    <div className={`ff-field${error ? ' ff-field-error' : ''}`} style={toCss(component.style)}>
      {!opts?.inline && label && (
        <label className="ff-label">
          {label} {requiredMark}
        </label>
      )}
      {control}
      {helpText && <div className="ff-help">{helpText}</div>}
      {error && <div className="ff-error">{error}</div>}
    </div>
  )

  switch (component.type) {
    case 'textfield':
      return wrap(
        <input
          className="ff-input"
          type={(p.inputType as string) || 'text'}
          placeholder={p.placeholder as string}
          value={(value as string) ?? ''}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.value)}
        />,
      )
    case 'textarea':
      return wrap(
        <textarea
          className="ff-input"
          rows={(p.rows as number) || 4}
          placeholder={p.placeholder as string}
          value={(value as string) ?? ''}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.value)}
        />,
      )
    case 'number':
      return wrap(
        <input
          className="ff-input"
          type="number"
          placeholder={p.placeholder as string}
          value={value === undefined || value === null ? '' : String(value)}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.value === '' ? undefined : Number(e.target.value))}
        />,
      )
    case 'select': {
      const options = (p.options as SelectOption[]) ?? []
      return wrap(
        <select
          className="ff-input"
          value={typeof value === 'string' || typeof value === 'number' ? String(value) : ''}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.value)}
        >
          <option value="" disabled>
            {(p.placeholder as string) || 'Select…'}
          </option>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>,
      )
    }
    case 'radio': {
      const options = (p.options as SelectOption[]) ?? []
      return wrap(
        <div className="ff-radio-group" role="radiogroup">
          {options.map((o) => (
            <label key={o.value} className="ff-check-row">
              <input
                type="radio"
                name={component.id}
                checked={value === o.value}
                disabled={disabled}
                onChange={() => onChange?.(o.value)}
              />
              <span>{o.label}</span>
            </label>
          ))}
        </div>,
      )
    }
    case 'checkbox':
      return wrap(
        <label className="ff-check-row">
          <input
            type="checkbox"
            checked={Boolean(value)}
            disabled={disabled}
            onChange={(e) => onChange?.(e.target.checked)}
          />
          <span>
            {label} {requiredMark}
          </span>
        </label>,
        { inline: true },
      )
    case 'switch':
      return wrap(
        <label className="ff-check-row">
          <span className={`ff-switch${value ? ' on' : ''}`}>
            <input
              type="checkbox"
              checked={Boolean(value)}
              disabled={disabled}
              onChange={(e) => onChange?.(e.target.checked)}
            />
            <span className="ff-switch-thumb" />
          </span>
          <span>{label}</span>
        </label>,
        { inline: true },
      )
    case 'datepicker': {
      // bound sample values may carry a time part — <input type=date> needs YYYY-MM-DD
      const dateValue = typeof value === 'string' ? value.slice(0, 10) : ''
      return wrap(
        <input
          className="ff-input"
          type="date"
          value={dateValue}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.value)}
        />,
      )
    }
    case 'heading': {
      const level = (p.level as string) || '2'
      const Tag = (`h${level}` as 'h1' | 'h2' | 'h3')
      return <Tag className={`ff-heading ff-h${level}`} style={toCss(component.style)}>{displayText(component, value)}</Tag>
    }
    case 'paragraph':
      return <p className="ff-paragraph" style={toCss(component.style)}>{displayText(component, value)}</p>
    case 'divider':
      return <hr className="ff-divider" style={toCss(component.style)} />
    case 'button':
      return (
        <button
          type={disabled ? 'button' : 'submit'}
          className={`ff-button ff-button-${(p.variant as string) || 'primary'}`}
          style={toCss(component.style)}
          disabled={disabled}
        >
          {displayText(component, value)}
        </button>
      )
    default:
      return null
  }
}

/* ------------------------------ full renderer ----------------------------- */

interface FormRendererProps {
  components: FormComponent[]
  values: Record<string, unknown>
  errors?: Record<string, string>
  onChange: (key: string, value: unknown) => void
  onSubmit?: () => void
}

function RenderList({
  components,
  values,
  errors,
  onChange,
}: Omit<FormRendererProps, 'onSubmit'>) {
  return (
    <>
      {components.map((c) => {
        if (c.type === 'container') {
          return (
            <fieldset
              key={c.id}
              className={`ff-container ff-${effectiveDirection(c.style, c.props.direction)}`}
              style={toCss(c.style)}
            >
              {Boolean(c.props.label) && <legend className="ff-container-label">{c.props.label as string}</legend>}
              <RenderList components={c.children ?? []} values={values} errors={errors} onChange={onChange} />
            </fieldset>
          )
        }
        const key = valueKeyOf(c)
        return (
          <LeafField
            key={c.id}
            component={c}
            value={values[key]}
            error={errors?.[key]}
            onChange={(v) => onChange(key, v)}
          />
        )
      })}
    </>
  )
}

export function FormRenderer({ components, values, errors, onChange, onSubmit }: FormRendererProps) {
  return (
    <form
      className="ff-form"
      onSubmit={(e) => {
        e.preventDefault()
        onSubmit?.()
      }}
    >
      <RenderList components={components} values={values} errors={errors} onChange={onChange} />
    </form>
  )
}
