import type { ComponentType, FormComponent } from '../types/schema'
import { uid } from '../utils/id'

export type PropEditor = 'text' | 'textarea' | 'number' | 'checkbox' | 'select' | 'options'

export interface PropField {
  key: string
  label: string
  editor: PropEditor
  options?: { label: string; value: string }[]
  placeholder?: string
}

export interface ComponentDefinition {
  type: ComponentType
  label: string
  icon: string
  category: 'Fields' | 'Static' | 'Layout'
  bindable: boolean
  defaultProps: Record<string, unknown>
  propFields: PropField[]
  /** Keys map into FormComponent.validation */
  validationFields: PropField[]
}

const required: PropField = { key: 'required', label: 'Required', editor: 'checkbox' }
const minLength: PropField = { key: 'minLength', label: 'Min length', editor: 'number' }
const maxLength: PropField = { key: 'maxLength', label: 'Max length', editor: 'number' }

export const componentDefinitions: ComponentDefinition[] = [
  {
    type: 'textfield',
    label: 'Text Field',
    icon: 'Aa',
    category: 'Fields',
    bindable: true,
    defaultProps: { label: 'Text Field', placeholder: '', helpText: '', inputType: 'text', defaultValue: '' },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'placeholder', label: 'Placeholder', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
      {
        key: 'inputType',
        label: 'Input type',
        editor: 'select',
        options: [
          { label: 'Text', value: 'text' },
          { label: 'Email', value: 'email' },
          { label: 'Phone', value: 'tel' },
          { label: 'URL', value: 'url' },
          { label: 'Password', value: 'password' },
        ],
      },
      { key: 'defaultValue', label: 'Default value', editor: 'text' },
    ],
    validationFields: [required, minLength, maxLength, { key: 'pattern', label: 'Regex pattern', editor: 'text', placeholder: '^[A-Z].*$' }],
  },
  {
    type: 'textarea',
    label: 'Text Area',
    icon: '¶',
    category: 'Fields',
    bindable: true,
    defaultProps: { label: 'Text Area', placeholder: '', helpText: '', rows: 4 },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'placeholder', label: 'Placeholder', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
      { key: 'rows', label: 'Rows', editor: 'number' },
    ],
    validationFields: [required, minLength, maxLength],
  },
  {
    type: 'number',
    label: 'Number',
    icon: '#',
    category: 'Fields',
    bindable: true,
    defaultProps: { label: 'Number', placeholder: '', helpText: '' },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'placeholder', label: 'Placeholder', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
    ],
    validationFields: [
      required,
      { key: 'min', label: 'Min value', editor: 'number' },
      { key: 'max', label: 'Max value', editor: 'number' },
    ],
  },
  {
    type: 'select',
    label: 'Select',
    icon: '▾',
    category: 'Fields',
    bindable: true,
    defaultProps: {
      label: 'Select',
      placeholder: 'Select an option…',
      helpText: '',
      options: [
        { label: 'Option 1', value: 'option1' },
        { label: 'Option 2', value: 'option2' },
      ],
    },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'placeholder', label: 'Placeholder', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
      { key: 'options', label: 'Options', editor: 'options' },
    ],
    validationFields: [required],
  },
  {
    type: 'radio',
    label: 'Radio Group',
    icon: '◉',
    category: 'Fields',
    bindable: true,
    defaultProps: {
      label: 'Radio Group',
      helpText: '',
      options: [
        { label: 'Option 1', value: 'option1' },
        { label: 'Option 2', value: 'option2' },
      ],
    },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
      { key: 'options', label: 'Options', editor: 'options' },
    ],
    validationFields: [required],
  },
  {
    type: 'checkbox',
    label: 'Checkbox',
    icon: '☑',
    category: 'Fields',
    bindable: true,
    defaultProps: { label: 'Checkbox', helpText: '' },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
    ],
    validationFields: [required],
  },
  {
    type: 'switch',
    label: 'Switch',
    icon: '⊙',
    category: 'Fields',
    bindable: true,
    defaultProps: { label: 'Switch', helpText: '' },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
    ],
    validationFields: [],
  },
  {
    type: 'datepicker',
    label: 'Date Picker',
    icon: '📅',
    category: 'Fields',
    bindable: true,
    defaultProps: { label: 'Date', helpText: '' },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      { key: 'helpText', label: 'Help text', editor: 'text' },
    ],
    validationFields: [required],
  },
  {
    type: 'heading',
    label: 'Heading',
    icon: 'H',
    category: 'Static',
    bindable: true,
    defaultProps: { text: 'Heading', level: '2' },
    propFields: [
      { key: 'text', label: 'Text', editor: 'text' },
      {
        key: 'level',
        label: 'Size',
        editor: 'select',
        options: [
          { label: 'Large (H1)', value: '1' },
          { label: 'Medium (H2)', value: '2' },
          { label: 'Small (H3)', value: '3' },
        ],
      },
    ],
    validationFields: [],
  },
  {
    type: 'paragraph',
    label: 'Paragraph',
    icon: '≡',
    category: 'Static',
    bindable: true,
    defaultProps: { text: 'Paragraph text goes here.' },
    propFields: [{ key: 'text', label: 'Text', editor: 'textarea' }],
    validationFields: [],
  },
  {
    type: 'divider',
    label: 'Divider',
    icon: '—',
    category: 'Static',
    bindable: true,
    defaultProps: {},
    propFields: [],
    validationFields: [],
  },
  {
    type: 'button',
    label: 'Button',
    icon: '▭',
    category: 'Static',
    bindable: true,
    defaultProps: { text: 'Submit', variant: 'primary' },
    propFields: [
      { key: 'text', label: 'Text', editor: 'text' },
      {
        key: 'variant',
        label: 'Variant',
        editor: 'select',
        options: [
          { label: 'Primary', value: 'primary' },
          { label: 'Secondary', value: 'secondary' },
        ],
      },
    ],
    validationFields: [],
  },
  {
    type: 'container',
    label: 'Container',
    icon: '▣',
    category: 'Layout',
    bindable: true,
    defaultProps: { label: 'Group', direction: 'vertical' },
    propFields: [
      { key: 'label', label: 'Label', editor: 'text' },
      {
        key: 'direction',
        label: 'Direction',
        editor: 'select',
        options: [
          { label: 'Vertical', value: 'vertical' },
          { label: 'Horizontal', value: 'horizontal' },
        ],
      },
    ],
    validationFields: [],
  },
]

export const registry: Record<ComponentType, ComponentDefinition> = Object.fromEntries(
  componentDefinitions.map((d) => [d.type, d]),
) as Record<ComponentType, ComponentDefinition>

export function createComponent(type: ComponentType): FormComponent {
  const def = registry[type]
  const component: FormComponent = {
    id: uid(type),
    type,
    props: structuredClone(def.defaultProps),
  }
  if (type === 'container') component.children = []
  if (def.validationFields.length > 0) component.validation = {}
  return component
}
