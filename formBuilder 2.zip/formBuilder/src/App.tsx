import { useEffect, useState } from 'react'
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  closestCenter,
  pointerWithin,
  useSensor,
  useSensors,
} from '@dnd-kit/core'
import type { CollisionDetection, DragEndEvent, DragStartEvent } from '@dnd-kit/core'
import type { ComponentType } from './types/schema'
import { createComponent, registry } from './definitions/registry'
import { store } from './state/store'
import { useAppDispatch, useAppSelector } from './state/hooks'
import { addComponent, moveComponent, redo, removeComponent, undo, updateComponent } from './state/actions'
import { componentFromDataField } from './utils/json'
import type { DataField } from './utils/json'
import { findById } from './utils/tree'
import { Toolbar } from './components/Toolbar'
import { Palette } from './components/Palette'
import { Canvas } from './components/Canvas'
import { PropertiesPanel } from './components/PropertiesPanel'
import { ApiImportModal } from './components/ApiImportModal'
import { SchemaImportModal } from './components/SchemaImportModal'
import { HtmlImportModal } from './components/HtmlImportModal'
import { JsonPanel } from './components/JsonPanel'
import { PreviewPane } from './components/PreviewPane'

type DragSource =
  | { kind: 'palette'; type: ComponentType }
  | { kind: 'canvas'; id: string }
  | { kind: 'data'; field: DataField }

/** Prefer the zone directly under the pointer; fall back to the nearest one. */
const collisionDetection: CollisionDetection = (args) => {
  const within = pointerWithin(args)
  const base = within.length > 0 ? within : closestCenter(args)
  // "bind-target" droppables (an existing component) only apply when dragging a
  // Data-tab field onto it; for palette/canvas drags, fall back to drop zones.
  if (args.active.data.current?.kind === 'data') return base
  return base.filter((c) => !String(c.id).startsWith('bind-'))
}

export default function App() {
  const tab = useAppSelector((s) => s.tab)
  const selectedId = useAppSelector((s) => s.selectedId)
  const dispatch = useAppDispatch()

  const [dragLabel, setDragLabel] = useState<string | null>(null)

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }))

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement
      const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z' && !typing) {
        e.preventDefault()
        if (e.shiftKey) dispatch(redo())
        else dispatch(undo())
        return
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && !typing && selectedId) {
        e.preventDefault()
        dispatch(removeComponent(selectedId))
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [selectedId, dispatch])

  const onDragStart = (e: DragStartEvent) => {
    const src = e.active.data.current as DragSource | undefined
    if (!src) return
    if (src.kind === 'palette') setDragLabel(registry[src.type].label)
    else if (src.kind === 'data') setDragLabel(`⇄ ${src.field.path}`)
    else {
      const c = findById(store.getState().schema.components, src.id)
      setDragLabel(c ? registry[c.type].label : 'Component')
    }
  }

  const onDragEnd = (e: DragEndEvent) => {
    setDragLabel(null)
    const src = e.active.data.current as DragSource | undefined
    const target = e.over?.data.current as
      | { parentId: string | null; index: number }
      | { kind: 'bind-target'; id: string }
      | undefined
    if (!src || !target) return

    // Drop a schema field onto an existing component to map (bind) it.
    if ('kind' in target) {
      if (target.kind === 'bind-target' && src.kind === 'data') {
        dispatch(updateComponent(target.id, { binding: src.field.path }))
      }
      return
    }

    if (src.kind === 'palette') {
      dispatch(addComponent(createComponent(src.type), target.parentId, target.index))
    } else if (src.kind === 'data') {
      dispatch(addComponent(componentFromDataField(src.field), target.parentId, target.index))
    } else {
      dispatch(moveComponent(src.id, target.parentId, target.index))
    }
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={collisionDetection}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onDragCancel={() => setDragLabel(null)}
    >
      <div className={`app${dragLabel ? ' is-dragging' : ''}`}>
        <Toolbar />
        <div className="workspace">
          {tab === 'edit' && (
            <>
              <Palette />
              <Canvas />
              <PropertiesPanel />
            </>
          )}
          {tab === 'preview' && <PreviewPane />}
          {tab === 'json' && <JsonPanel />}
        </div>
        <ApiImportModal />
        <SchemaImportModal />
        <HtmlImportModal />
      </div>
      <DragOverlay dropAnimation={null}>
        {dragLabel && <div className="drag-chip">{dragLabel}</div>}
      </DragOverlay>
    </DndContext>
  )
}
