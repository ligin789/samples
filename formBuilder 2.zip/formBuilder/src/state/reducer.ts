import type { FormSchema } from '../types/schema'
import { uid } from '../utils/id'
import {
  cloneWithNewIds,
  findById,
  findContainerOf,
  insertAt,
  isDescendant,
  removeById,
} from '../utils/tree'
import type { BuilderAction } from './actions'
import { loadInitialSchema } from './persistence'

const HISTORY_LIMIT = 50

export type EditorTab = 'edit' | 'preview' | 'json'

export interface BuilderState {
  schema: FormSchema
  selectedId: string | null
  tab: EditorTab
  importOpen: boolean
  schemaImportOpen: boolean
  htmlImportOpen: boolean
  past: FormSchema[]
  future: FormSchema[]
}

export const initialState: BuilderState = {
  schema: loadInitialSchema(),
  selectedId: null,
  tab: 'edit',
  importOpen: false,
  schemaImportOpen: false,
  htmlImportOpen: false,
  past: [],
  future: [],
}

/** Snapshot the current schema into history, then return state holding a mutated draft copy. */
function applyToSchema(state: BuilderState, mutate: (draft: FormSchema) => void): BuilderState {
  const draft = structuredClone(state.schema)
  mutate(draft)
  return {
    ...state,
    schema: draft,
    past: [...state.past.slice(-(HISTORY_LIMIT - 1)), state.schema],
    future: [],
  }
}

export function builderReducer(
  state: BuilderState = initialState,
  action: BuilderAction,
): BuilderState {
  switch (action.type) {
    case 'builder/setTab':
      return { ...state, tab: action.tab }

    case 'builder/setImportOpen':
      return { ...state, importOpen: action.open }

    case 'builder/setSchemaImportOpen':
      return { ...state, schemaImportOpen: action.open }

    case 'builder/setHtmlImportOpen':
      return { ...state, htmlImportOpen: action.open }

    case 'builder/select':
      return { ...state, selectedId: action.id }

    case 'builder/setFormName':
      return applyToSchema(state, (d) => void (d.name = action.name))

    case 'builder/addComponent':
      return applyToSchema(state, (d) =>
        insertAt(d.components, action.parentId, action.index, action.component),
      )

    case 'builder/moveComponent':
      return applyToSchema(state, (d) => {
        const moving = findById(d.components, action.id)
        if (!moving) return
        // never drop a container into itself or its own subtree
        if (action.parentId !== null && (action.parentId === action.id || isDescendant(moving, action.parentId)))
          return

        const loc = findContainerOf(d.components, action.id)
        if (!loc) return
        // adjust target index when removing an earlier sibling from the same list
        let index = action.index
        const targetList =
          action.parentId === null ? d.components : findById(d.components, action.parentId)?.children
        if (targetList === loc.siblings && loc.index < index) index -= 1

        removeById(d.components, action.id)
        insertAt(d.components, action.parentId, index, moving)
      })

    case 'builder/updateComponent':
      return applyToSchema(state, (d) => {
        const c = findById(d.components, action.id)
        if (!c) return
        const { patch } = action
        if (patch.props) c.props = { ...c.props, ...patch.props }
        if ('binding' in patch) c.binding = patch.binding || undefined
        if (patch.validation) c.validation = { ...c.validation, ...patch.validation }
        if (patch.style) {
          // merge, but drop keys cleared to undefined/'' so the template JSON stays tidy
          const merged: Record<string, unknown> = { ...c.style }
          for (const [k, v] of Object.entries(patch.style)) {
            if (v === undefined || v === '') delete merged[k]
            else merged[k] = v
          }
          c.style = Object.keys(merged).length ? (merged as typeof c.style) : undefined
        }
      })

    case 'builder/removeComponent':
      return applyToSchema(state, (d) => void removeById(d.components, action.id))

    case 'builder/duplicateComponent':
      return applyToSchema(state, (d) => {
        const loc = findContainerOf(d.components, action.id)
        if (!loc) return
        const copy = cloneWithNewIds(loc.siblings[loc.index], uid)
        loc.siblings.splice(loc.index + 1, 0, copy)
      })

    case 'builder/setSampleData':
      return applyToSchema(state, (d) => void (d.sampleData = action.data))

    case 'builder/setJsonSchema':
      return applyToSchema(state, (d) => {
        d.jsonSchema = action.jsonSchema
        d.sampleData = action.sampleData
      })

    case 'builder/setComponents':
      return applyToSchema(state, (d) => {
        d.components = action.append ? [...d.components, ...action.components] : action.components
      })

    case 'builder/replaceSchema':
      return applyToSchema(state, (d) => {
        const { schema } = action
        d.name = schema.name ?? d.name
        d.version = schema.version ?? d.version
        d.components = schema.components ?? []
        d.sampleData = schema.sampleData
        d.jsonSchema = schema.jsonSchema
      })

    case 'builder/clearForm':
      return applyToSchema(state, (d) => void (d.components = []))

    case 'builder/undo': {
      const prev = state.past[state.past.length - 1]
      if (!prev) return state
      return {
        ...state,
        schema: prev,
        past: state.past.slice(0, -1),
        future: [state.schema, ...state.future],
        selectedId: null,
      }
    }

    case 'builder/redo': {
      const next = state.future[0]
      if (!next) return state
      return {
        ...state,
        schema: next,
        past: [...state.past, state.schema],
        future: state.future.slice(1),
        selectedId: null,
      }
    }

    default:
      return state
  }
}
