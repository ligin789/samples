import type { ThunkAction } from 'redux-thunk'
import type { FormComponent, FormSchema } from '../types/schema'
import type { BuilderState, EditorTab } from './reducer'

/** The subset of a component that the properties panel can patch. */
export type ComponentPatch = Partial<Pick<FormComponent, 'props' | 'binding' | 'validation' | 'style'>>

/** Every plain action the reducer understands. */
export type BuilderAction =
  | { type: 'builder/setTab'; tab: EditorTab }
  | { type: 'builder/setImportOpen'; open: boolean }
  | { type: 'builder/setSchemaImportOpen'; open: boolean }
  | { type: 'builder/setHtmlImportOpen'; open: boolean }
  | { type: 'builder/select'; id: string | null }
  | { type: 'builder/setFormName'; name: string }
  | { type: 'builder/addComponent'; component: FormComponent; parentId: string | null; index: number }
  | { type: 'builder/moveComponent'; id: string; parentId: string | null; index: number }
  | { type: 'builder/updateComponent'; id: string; patch: ComponentPatch }
  | { type: 'builder/removeComponent'; id: string }
  | { type: 'builder/duplicateComponent'; id: string }
  | { type: 'builder/setSampleData'; data: unknown }
  | { type: 'builder/setJsonSchema'; jsonSchema: unknown; sampleData: unknown }
  | { type: 'builder/setComponents'; components: FormComponent[]; append: boolean }
  | { type: 'builder/replaceSchema'; schema: FormSchema }
  | { type: 'builder/clearForm' }
  | { type: 'builder/undo' }
  | { type: 'builder/redo' }

/** A thunk that operates over the builder state. */
export type AppThunk<R = void> = ThunkAction<R, BuilderState, unknown, BuilderAction>

/* --------------------------- plain action creators -------------------------- */

export const setTab = (tab: EditorTab): BuilderAction => ({ type: 'builder/setTab', tab })

export const setImportOpen = (open: boolean): BuilderAction => ({ type: 'builder/setImportOpen', open })

export const setSchemaImportOpen = (open: boolean): BuilderAction => ({
  type: 'builder/setSchemaImportOpen',
  open,
})

export const setHtmlImportOpen = (open: boolean): BuilderAction => ({
  type: 'builder/setHtmlImportOpen',
  open,
})

export const select = (id: string | null): BuilderAction => ({ type: 'builder/select', id })

export const setFormName = (name: string): BuilderAction => ({ type: 'builder/setFormName', name })

export const moveComponent = (id: string, parentId: string | null, index: number): BuilderAction => ({
  type: 'builder/moveComponent',
  id,
  parentId,
  index,
})

export const updateComponent = (id: string, patch: ComponentPatch): BuilderAction => ({
  type: 'builder/updateComponent',
  id,
  patch,
})

export const duplicateComponent = (id: string): BuilderAction => ({
  type: 'builder/duplicateComponent',
  id,
})

export const setSampleData = (data: unknown): BuilderAction => ({ type: 'builder/setSampleData', data })

/** Set the imported JSON Schema (the binding/validation source) plus the sample data the preview pre-fills from. */
export const setJsonSchema = (jsonSchema: unknown, sampleData: unknown): BuilderAction => ({
  type: 'builder/setJsonSchema',
  jsonSchema,
  sampleData,
})

export const setComponents = (components: FormComponent[], append = false): BuilderAction => ({
  type: 'builder/setComponents',
  components,
  append,
})

export const undo = (): BuilderAction => ({ type: 'builder/undo' })

export const redo = (): BuilderAction => ({ type: 'builder/redo' })

/* ------------------------ internal single-step actions ----------------------- */
// These mirror the reducer's mutations one-to-one; the thunks below compose them
// with a follow-up selection change, matching the original store's behaviour.

const componentAdded = (component: FormComponent, parentId: string | null, index: number): BuilderAction => ({
  type: 'builder/addComponent',
  component,
  parentId,
  index,
})

const componentRemoved = (id: string): BuilderAction => ({ type: 'builder/removeComponent', id })

const schemaReplaced = (schema: FormSchema): BuilderAction => ({ type: 'builder/replaceSchema', schema })

const formCleared = (): BuilderAction => ({ type: 'builder/clearForm' })

/* --------------------------------- thunks ---------------------------------- */

/** Insert a component, then select the freshly added node. */
export const addComponent =
  (component: FormComponent, parentId: string | null, index: number): AppThunk =>
  (dispatch) => {
    dispatch(componentAdded(component, parentId, index))
    dispatch(select(component.id))
  }

/** Remove a component, clearing the selection when it was the one selected. */
export const removeComponent =
  (id: string): AppThunk =>
  (dispatch, getState) => {
    dispatch(componentRemoved(id))
    if (getState().selectedId === id) dispatch(select(null))
  }

/** Replace the whole schema and drop the current selection. */
export const replaceSchema =
  (schema: FormSchema): AppThunk =>
  (dispatch) => {
    dispatch(schemaReplaced(schema))
    dispatch(select(null))
  }

/** Remove every component and drop the current selection. */
export const clearForm = (): AppThunk => (dispatch) => {
  dispatch(formCleared())
  dispatch(select(null))
}
