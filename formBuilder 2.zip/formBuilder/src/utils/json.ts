import type { FormComponent, ValidationRules } from '../types/schema'
import { uid } from './id'

/* ---------------------------------- paths --------------------------------- */

/** "user.tags[0].name" -> ["user", "tags", "0", "name"] */
export function pathTokens(path: string): string[] {
  return path.split(/[.[\]]+/).filter(Boolean)
}

export function getByPath(obj: unknown, path: string): unknown {
  let cur: unknown = obj
  for (const token of pathTokens(path)) {
    if (cur === null || cur === undefined || typeof cur !== 'object') return undefined
    cur = (cur as Record<string, unknown>)[token]
  }
  return cur
}

export function setByPath(obj: Record<string, unknown>, path: string, value: unknown): void {
  const tokens = pathTokens(path)
  let cur: Record<string, unknown> = obj
  for (let i = 0; i < tokens.length - 1; i++) {
    const token = tokens[i]
    const nextIsIndex = /^\d+$/.test(tokens[i + 1])
    if (cur[token] === undefined || typeof cur[token] !== 'object' || cur[token] === null) {
      cur[token] = nextIsIndex ? [] : {}
    }
    cur = cur[token] as Record<string, unknown>
  }
  cur[tokens[tokens.length - 1]] = value
}

/** "firstName" / "first_name" / "first-name" -> "First Name" */
export function humanize(key: string): string {
  return key
    .replace(/[_-]+/g, ' ')
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase())
}

/* ---------------------------- structure analysis --------------------------- */

export type DataFieldType =
  | 'string'
  | 'number'
  | 'boolean'
  | 'date'
  | 'object'
  | 'array'
  | 'null'

export interface DataField {
  /** Full dot path from the root, arrays use [0] for the representative item */
  path: string
  key: string
  type: DataFieldType
  sample: unknown
  /** Children for objects and arrays-of-objects */
  children?: DataField[]
  /** Distinct primitive values when the field is an array of primitives */
  enumValues?: string[]
  /** Validation rules carried over from a JSON Schema (required, min/max, …) */
  validation?: ValidationRules
  /** True when listed in the parent object's JSON Schema `required` array */
  required?: boolean
  /** JSON Schema `format` (email, date, uri, …) used to refine the input type */
  format?: string
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?$/

function inferType(value: unknown): DataFieldType {
  if (value === null || value === undefined) return 'null'
  if (Array.isArray(value)) return 'array'
  switch (typeof value) {
    case 'number':
      return 'number'
    case 'boolean':
      return 'boolean'
    case 'string':
      return ISO_DATE.test(value) ? 'date' : 'string'
    case 'object':
      return 'object'
    default:
      return 'string'
  }
}

function analyzeValue(key: string, value: unknown, path: string): DataField {
  const type = inferType(value)
  const field: DataField = { path, key, type, sample: value }

  if (type === 'object') {
    field.children = Object.entries(value as Record<string, unknown>).map(([k, v]) =>
      analyzeValue(k, v, path ? `${path}.${k}` : k),
    )
  } else if (type === 'array') {
    const arr = value as unknown[]
    const first = arr[0]
    if (first !== null && typeof first === 'object' && !Array.isArray(first)) {
      field.children = Object.entries(first as Record<string, unknown>).map(([k, v]) =>
        analyzeValue(k, v, `${path}[0].${k}`),
      )
    } else {
      const values = arr
        .filter((v) => v !== null && v !== undefined && typeof v !== 'object')
        .map((v) => String(v))
      field.enumValues = [...new Set(values)].slice(0, 50)
    }
  }
  return field
}

/** Walk an API JSON payload and describe its structure as a field tree. */
export function analyzeJson(data: unknown): DataField[] {
  if (data === null || typeof data !== 'object') {
    return [analyzeValue('value', data, 'value')]
  }
  if (Array.isArray(data)) {
    return [analyzeValue('items', data, 'items')]
  }
  return Object.entries(data as Record<string, unknown>).map(([k, v]) => analyzeValue(k, v, k))
}

/* ------------------------- field -> form component ------------------------- */

const EMAIL_KEY = /e?mail/i
const PHONE_KEY = /phone|mobile|tel/i

/** Create a single form component (with binding) for one data field. */
export function componentFromDataField(field: DataField): FormComponent {
  const label = humanize(field.key)
  const base = { binding: field.path, validation: field.validation ? { ...field.validation } : {} }

  // A constrained set of values -> dropdown, whether it came from an array of
  // primitives or a JSON Schema `enum` on a scalar field.
  if (field.enumValues && field.enumValues.length > 0) {
    return {
      id: uid('select'),
      type: 'select',
      props: {
        label,
        placeholder: `Select ${label.toLowerCase()}…`,
        options: field.enumValues.map((v) => ({ label: humanize(v), value: v })),
      },
      ...base,
    }
  }

  switch (field.type) {
    case 'number':
      return { id: uid('number'), type: 'number', props: { label, placeholder: '' }, ...base }
    case 'boolean':
      return { id: uid('switch'), type: 'switch', props: { label }, ...base }
    case 'date':
      return { id: uid('datepicker'), type: 'datepicker', props: { label }, ...base }
    case 'array':
    case 'object':
      // object / array of objects -> group built from the representative item
      return {
        id: uid('container'),
        type: 'container',
        props: { label, direction: 'vertical' },
        children: (field.children ?? []).map(componentFromDataField),
      }
    default: {
      const isLong = typeof field.sample === 'string' && field.sample.length > 120
      if (isLong) {
        return { id: uid('textarea'), type: 'textarea', props: { label, placeholder: '', rows: 4 }, ...base }
      }
      const inputType =
        field.format === 'email' || EMAIL_KEY.test(field.key)
          ? 'email'
          : field.format === 'tel' || field.format === 'phone' || PHONE_KEY.test(field.key)
            ? 'tel'
            : field.format === 'uri' || field.format === 'url'
              ? 'url'
              : 'text'
      return { id: uid('textfield'), type: 'textfield', props: { label, placeholder: '', inputType }, ...base }
    }
  }
}

/** Generate an entire form (fields + submit button) from an analyzed API payload. */
export function generateComponentsFromFields(fields: DataField[]): FormComponent[] {
  const components = fields.map(componentFromDataField)
  components.push({
    id: uid('button'),
    type: 'button',
    props: { text: 'Submit', variant: 'primary' },
  })
  return components
}
