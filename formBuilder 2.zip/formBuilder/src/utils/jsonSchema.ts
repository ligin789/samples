import type { FormSchema, ValidationRules } from '../types/schema'
import { analyzeJson, setByPath } from './json'
import type { DataField, DataFieldType } from './json'

/**
 * Turn an imported JSON Schema (draft-07 style) into the same `DataField` tree
 * the rest of the builder already understands — so binding, generation and the
 * Data tab keep working unchanged. Unlike `analyzeJson` (which infers structure
 * from a concrete API response) this reads the contract directly, which means we
 * can also carry over the schema's validation: `required`, `minLength`/
 * `maxLength`, `minimum`/`maximum`, `pattern`, `format` and `enum`.
 *
 * The supported subset is deliberately small (object/array/string/number/
 * integer/boolean, `enum`, `format`, the validation keywords, and shallow
 * `allOf`/`anyOf`/`oneOf` merging). `$ref` is not resolved.
 */

interface SchemaNode {
  type?: string | string[]
  format?: string
  properties?: Record<string, SchemaNode>
  required?: string[]
  items?: SchemaNode | SchemaNode[]
  enum?: unknown[]
  minLength?: number
  maxLength?: number
  minimum?: number
  maximum?: number
  pattern?: string
  default?: unknown
  const?: unknown
  example?: unknown
  examples?: unknown[]
  allOf?: SchemaNode[]
  anyOf?: SchemaNode[]
  oneOf?: SchemaNode[]
}

const isNode = (v: unknown): v is SchemaNode => typeof v === 'object' && v !== null && !Array.isArray(v)

const uniqueStrings = (values: unknown[]): string[] =>
  [...new Set(values.filter((v) => v !== null && typeof v !== 'object').map((v) => String(v)))].slice(0, 50)

/** Map a schema node's `type`/`format` onto our DataFieldType. */
function schemaType(node: SchemaNode): DataFieldType {
  const t = Array.isArray(node.type) ? (node.type.find((x) => x !== 'null') ?? node.type[0]) : node.type
  if (t === 'object' || (!t && node.properties)) return 'object'
  if (t === 'array' || (!t && node.items)) return 'array'
  if (t === 'integer' || t === 'number') return 'number'
  if (t === 'boolean') return 'boolean'
  if (t === 'null') return 'null'
  if (t === 'string') return node.format === 'date' || node.format === 'date-time' ? 'date' : 'string'
  return 'string'
}

/** Merge `properties`/`required` from a node and its shallow allOf/anyOf/oneOf branches. */
function objectShape(node: SchemaNode): { properties: Record<string, SchemaNode>; required: string[] } {
  let properties: Record<string, SchemaNode> = {}
  let required: string[] = []
  const branches = [...(node.allOf ?? []), ...(node.anyOf ?? []).slice(0, 1), ...(node.oneOf ?? []).slice(0, 1)]
  for (const sub of branches) {
    if (!isNode(sub)) continue
    const shape = objectShape(sub)
    properties = { ...properties, ...shape.properties }
    required = [...required, ...shape.required]
  }
  // The node's own declarations win over inherited ones.
  properties = { ...properties, ...(node.properties ?? {}) }
  required = [...required, ...(node.required ?? [])]
  return { properties, required }
}

function exampleOf(node: SchemaNode): unknown {
  if (node.default !== undefined) return node.default
  if (node.const !== undefined) return node.const
  if (Array.isArray(node.examples) && node.examples.length > 0) return node.examples[0]
  if (node.example !== undefined) return node.example
  return undefined
}

function validationOf(node: SchemaNode, type: DataFieldType, required: boolean): ValidationRules {
  const v: ValidationRules = {}
  if (required) v.required = true
  if (type === 'string' || type === 'date') {
    if (typeof node.minLength === 'number') v.minLength = node.minLength
    if (typeof node.maxLength === 'number') v.maxLength = node.maxLength
    if (typeof node.pattern === 'string') v.pattern = node.pattern
  }
  if (type === 'number') {
    if (typeof node.minimum === 'number') v.min = node.minimum
    if (typeof node.maximum === 'number') v.max = node.maximum
  }
  return v
}

function schemaField(key: string, node: SchemaNode, path: string, required: boolean): DataField {
  const type = schemaType(node)
  const field: DataField = { path, key, type, sample: exampleOf(node) }
  if (typeof node.format === 'string') field.format = node.format
  if (required) field.required = true
  const validation = validationOf(node, type, required)
  if (Object.keys(validation).length > 0) field.validation = validation

  // A scalar with an enum becomes a dropdown (componentFromDataField handles it).
  if (Array.isArray(node.enum) && node.enum.length > 0) {
    field.enumValues = uniqueStrings(node.enum)
    return field
  }

  if (type === 'object') {
    const { properties, required: req } = objectShape(node)
    const reqSet = new Set(req)
    field.children = Object.entries(properties).map(([k, v]) =>
      schemaField(k, v, path ? `${path}.${k}` : k, reqSet.has(k)),
    )
  } else if (type === 'array') {
    const items = (Array.isArray(node.items) ? node.items[0] : node.items) ?? {}
    if (Array.isArray(items.enum) && items.enum.length > 0) {
      field.enumValues = uniqueStrings(items.enum)
    } else if (schemaType(items) === 'object') {
      const { properties, required: req } = objectShape(items)
      const reqSet = new Set(req)
      field.children = Object.entries(properties).map(([k, v]) =>
        schemaField(k, v, `${path}[0].${k}`, reqSet.has(k)),
      )
    }
  }
  return field
}

/** Walk a JSON Schema and describe its data contract as a field tree. */
export function schemaToFields(schema: unknown): DataField[] {
  if (!isNode(schema)) return []
  const type = schemaType(schema)
  if (type === 'object') {
    const { properties, required } = objectShape(schema)
    const reqSet = new Set(required)
    return Object.entries(properties).map(([k, v]) => schemaField(k, v, k, reqSet.has(k)))
  }
  if (type === 'array') return [schemaField('items', schema, 'items', false)]
  return [schemaField('value', schema, 'value', false)]
}

/**
 * Build a best-effort sample payload from a JSON Schema's `default`/`const`/
 * `examples` values, so the Preview can still pre-fill bound fields even though
 * a schema (unlike an API response) carries no concrete data of its own.
 */
export function schemaToSampleData(schema: unknown): Record<string, unknown> | undefined {
  const data: Record<string, unknown> = {}
  const walk = (fields: DataField[]) => {
    for (const f of fields) {
      if (f.children) walk(f.children)
      else if (f.sample !== undefined && typeof f.sample !== 'object') setByPath(data, f.path, f.sample)
    }
  }
  walk(schemaToFields(schema))
  return Object.keys(data).length > 0 ? data : undefined
}

const SCHEMA_TYPES = new Set(['object', 'array', 'string', 'number', 'integer', 'boolean', 'null'])

/** Heuristic: does this parsed JSON look like a JSON Schema rather than raw data? */
export function looksLikeJsonSchema(data: unknown): boolean {
  if (!isNode(data)) return false
  if ('$schema' in data || 'properties' in data || '$defs' in data || 'definitions' in data) return true
  // A bare {"type":"object"} is schema-ish, but only trust a `type` string when
  // it pairs with another schema keyword (raw data can have a "type" field too).
  const typed = typeof data.type === 'string' && SCHEMA_TYPES.has(data.type)
  return typed && ('items' in data || 'enum' in data || 'required' in data || 'format' in data)
}

/**
 * The single source of bindable fields: the imported JSON Schema when present
 * (it also carries validation), otherwise the analyzed API sample data.
 */
export function dataFields(schema: Pick<FormSchema, 'jsonSchema' | 'sampleData'>): DataField[] {
  if (schema.jsonSchema !== undefined) return schemaToFields(schema.jsonSchema)
  if (schema.sampleData !== undefined) return analyzeJson(schema.sampleData)
  return []
}
