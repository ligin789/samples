import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { addUser } from "../../redux/login/loginActions";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import LogoDark from "../../assets/images/landingPage/logoDark.svg";
import './style.css'

import Logo1 from '../../assets/images/landingPage/R1.svg'
import Logo2 from '../../assets/images/landingPage/R2.svg'
import Logo3 from '../../assets/images/landingPage/R3.svg'
import Logo4 from '../../assets/images/landingPage/R4.svg'
type Step = "chooseRole" | "details";

const Signup = () => {
  const [step, setStep] = useState<Step>("chooseRole");
  const [selectedRoleId, setSelectedRoleId] = useState<number | null>(null);

  const [name, setName] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [mobile, setMobile] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const users = useAppSelector((state) => state.login.users);

  const roles = useMemo(
    () => [
      {
        id: 2,
        name: "eVTOL Operator",
        desc: "Manage fleet & operations",
        icon: Logo1,
      },
      {
        id: 3,
        name: "Ground Handlers",
        desc: "Manage Ground Activities",
        icon: Logo2,
      },
      {
        id: 4,
        name: "Booking Partners",
        desc: "Book tickets for customers",
        icon: Logo3,
      },
      {
        id: 5,
        name: "Customer Service Portal",
        desc: "Raise Incidents",
        icon: Logo4,
      },
     
    ],
    []
  );

  const selectedRole = useMemo(
    () => roles.find((r) => r.id === selectedRoleId) || null,
    [roles, selectedRoleId]
  );

  const handleRoleClick = (roleId: number) => {
    setSelectedRoleId(roleId);
    setStep("details");
  };

  const resetForm = () => {
    setName("");
    setEmail("");
    setMobile("");
    setLoading(false);
  };

  const handleBack = () => {
    // Go back to role selection and keep previously selected role if you prefer
    setStep("chooseRole");
    // If you want to clear selection on back, uncomment next line:
    // setSelectedRoleId(null);
  };

  // Basic field validations (disable button until valid)
  const isValidEmail = (val: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());

  const isValidMobile = (val: string) =>
    // A simple mobile rule: 7-15 digits (adjust to your locale needs)
    /^\+?\d{7,15}$/.test(val.trim());

  const canRequestOtp =
    !!name.trim() &&
    isValidEmail(email) &&
    isValidMobile(mobile) &&
    !!selectedRoleId &&
    !loading;

  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (!canRequestOtp || !selectedRole) return;

    setLoading(true);

    // Simulate OTP request/verification
    setTimeout(() => {
      const newUser = {
        id: users.length + 1,
        name: name.trim(),
        role: selectedRole.id,
        roleName: selectedRole.name,
        email: email.trim(),
        mobile: mobile.trim(),
      };

      dispatch(addUser(newUser));
      setLoading(false);
      resetForm();
      navigate("/login"); // after OTP request (adjust to your real flow if you need verification step)
    }, 1000);
  };

  return (
    <div className="container-fluid m-0 p-0">
      {/* Top nav */}
      <nav className="navbar p-3 pl-5">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            <img
              src={LogoDark}
              className="brand-logo pl-5"
              height={28}
              alt="Brand"
            />
          </a>
        </div>
      </nav>

      {/* Left side headline (hidden on small screens) */}
      <div className="d-sm-none d-lg-block">
        <div className="container-fluid mx-3 my-5 pt-4">
          <h2 className="mainLogin-text">
            Urban air mobility orchestration platform
          </h2>
          <h4 className="subLogin-text">
            Connect with the ecosystem. Manage operations.
            <br />
            Transform mobility
          </h4>
        </div>
      </div>

      {/* Main box */}
      <div className="login-box col-lg-4 col-sm-10">
        <div className="pb-3">
          <h3 className="login-box-text pb-3">Register</h3>
        </div>

        {/* ---------- STEP 1: Role selection ---------- */}
        <div
          className={step === "chooseRole" ? "d-block" : "d-none"}
          aria-hidden={step !== "chooseRole"}
        >
          <h6 className="login-box-text2 mb-1">Select your role</h6>
          <p className="text-muted mb-4">
            Choose how you&apos;ll participate in the UAM ecosystem
          </p>

          <div className="row g-3">
            {roles.map((role) => (
              <div key={role.id} className="col-12 col-sm-6">
                <button
                  type="button"
                  className="w-100 h-100 btn bg-white border-0  p-3  hover-shadow"
                  onClick={() => handleRoleClick(role.id)}
                >
                  {/* Optional icon (needs Bootstrap Icons) */}
                  <div className="d-flex text-start flex-column">
                    <div className="pb-4">
                      <img src={role?.icon} width={20}/>
                    </div>
                    <div>
                      <div className="fw-semibold">{role.name}</div>
                      <small className="text-muted">{role.desc}</small>
                    </div>
                  </div>
                </button>
              </div>
            ))}
          </div>

          {/* Divider and Sign in link */}
          <div className="d-flex justify-content-center mt-4 align-items-center">
            <div className="loginBox-horizontalLine" />
            <h5 className="login-box-or-text mx-2">Or</h5>
            <div className="loginBox-horizontalLine" />
          </div>

          <div className="d-flex justify-content-center mt-3">
            <h6 className="loginbox-register-text1">
              Already a Velos user?&nbsp;
            </h6>
            <h6
              className="loginbox-register-text2 text-primary"
              role="button"
              onClick={() => navigate("/login")}
            >
              Sign in
            </h6>
          </div>
        </div>

        {/* ---------- STEP 2: Details form (username, email, mobile) ---------- */}
        <div
          className={step === "details" ? "d-block" : "d-none"}
          aria-hidden={step !== "details"}
        >
          {/* Header with back */}
          <div className="d-flex align-items-center mb-3">
            <button
              type="button"
              className="btn btn-link px-0 me-2 text-decoration-none"
              onClick={handleBack}
              disabled={loading}
              aria-label="Back to role selection"
            >
              ← Back
            </button>
            <h6 className="m-0 text-muted">Selected role</h6>
          </div>

          {/* Selected role pill */}
          {selectedRole && (
            <div className="mb-4">
              <span className="badge rounded-pill text-bg-light border px-3 py-2">
                <i
                  className={`${selectedRole.icon} me-2`}
                  aria-hidden="true"
                ></i>
                {selectedRole.name}
              </span>
            </div>
          )}

          {/* Form */}
          <form className="d-flex flex-column" onSubmit={handleSubmit}>
            <label htmlFor="su_name" className="login-box-text2">
              Username
            </label>
            <input
              id="su_name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={loading}
              className="login-box-input mb-3"
              autoComplete="username"
              placeholder="Enter your name"
              required
            />

            <label htmlFor="su_email" className="login-box-text2">
              Email
            </label>
            <input
              id="su_email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
              className="login-box-input mb-3"
              autoComplete="email"
              placeholder="you@example.com"
              required
            />

            <label htmlFor="su_mobile" className="login-box-text2">
              Mobile
            </label>
            <input
              id="su_mobile"
              type="tel"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              disabled={loading}
              className="login-box-input mb-4"
              autoComplete="tel"
              placeholder="+11234567890"
              required
            />

            {/* Request OTP */}
            <button
              className="login-box-button border-0"
              type="submit"
              disabled={!canRequestOtp}
              aria-busy={loading}
            >
              <h3 className="loginbox-button-text">
                {loading ? "Requesting OTP..." : "Get OTP"}
              </h3>
            </button>

            {/* Divider and Sign in link */}
            <div className="d-flex justify-content-center mt-4 align-items-center">
              <div className="loginBox-horizontalLine" />
              <h5 className="login-box-or-text mx-2">Or</h5>
              <div className="loginBox-horizontalLine" />
            </div>

            <div className="d-flex justify-content-center mt-3">
              <h6 className="loginbox-register-text1">
                Already a Velos user?&nbsp;
              </h6>
              <h6
                className="loginbox-register-text2 text-primary"
                role="button"
                onClick={() => navigate("/login")}
              >
                Sign in
              </h6>
            </div>
          </form>
        </div>
      </div>

      <div className="container-fluid login-bottom-wrapper" />
    </div>
  );
};

export default Signup;
