import { useState } from 'react';
import LeftSideBar from '../../components/processGroup/LeftSideBar';
import ProcessGroup2 from '../../components/processGroup/ProcessGroup2';
import MainCanvas from '../../components/processGroup/MainCanvas';
import ProcessGroup4 from '../../components/processGroup/ProcessGroup4';
import ProcessGroup5 from '../../components/processGroup/ProcessGroup5';
import ProcessGroup6 from '../../components/processGroup/ProcessGroup6';
import styles from './ProcessGroup.module.css';

import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { setSelectedProcess } from '../../redux/process/processActions';
import type { Process } from '../../redux/process/processTypes';


interface ProcessGroup {
  id: string;
  name: string;
}

const ProcessGroup = () => {
  const dispatch = useAppDispatch();

  const handleProcessSelect = (process: Process) => {
    dispatch(setSelectedProcess(process));
  };

  const handleDeleteProcess = (id: string) => {
    console.log('Delete process:', id);
  };

  const processGroups = useAppSelector(state => state.processGroup.processGroup);
  const processes = useAppSelector(state => state.process.process);

  return (
    <div className={`container-fluid ${styles.processGroupContainer}`}>
      <div className="row g-0 h-100">
        {/* Left Sidebar */}
        <div className={`${styles.leftSidebar} ${styles.scrollable}`}>
          <LeftSideBar
            processGroups={processGroups}
            processes={processes}
            onProcessSelect={handleProcessSelect}
            onDeleteProcess={handleDeleteProcess}
          />
        </div>

        {/* Center Area */}
        <div className="col d-flex flex-column">
          {/* Top Toolbar */}
          

          {/* Main Canvas */}
          <div className={styles.mainCanvas}>
            <MainCanvas />
          </div>

          {/* Bottom Toolbar */}
          <div className={styles.bottomToolbar}>
            <ProcessGroup6 />
          </div>
        </div>

        {/* Right Sidebar */}
        <div className={`${styles.rightSidebar} d-flex flex-column`}>
          <div className={styles.rightTop}>
            <ProcessGroup4 />
          </div>
          <div className={styles.rightBottom}>
            <ProcessGroup5 />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProcessGroup;
