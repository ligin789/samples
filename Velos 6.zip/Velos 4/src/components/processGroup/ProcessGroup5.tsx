import { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { updateProcessFlow } from '../../redux/process/processActions';

const ProcessGroup5 = () => {
  const dispatch = useAppDispatch();
  const selectedProcess = useAppSelector((state) => state.process.selectedProcess);
  const [jsonText, setJsonText] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (selectedProcess?.processFlow) {
      setJsonText(JSON.stringify(selectedProcess, null, 2));
      setError('');
    }
  }, [selectedProcess]);

  const handleSave = () => {
    if (!selectedProcess) return;

    try {
      const parsed = JSON.parse(jsonText);
      dispatch(updateProcessFlow(selectedProcess.process_id, parsed));
      setError('');
    } catch (err) {
      setError('Invalid JSON format');
    }
  };

  if (!selectedProcess) {
    return (
      <div className="p-3">
        <h6 className="mb-3">Process Flow JSON</h6>
        <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
          No process selected
        </div>
      </div>
    );
  }

  return (
    <div className="p-3">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h6 style={{ margin: 0 }}>Process Flow JSON</h6>
        <button
          onClick={handleSave}
          style={{
            padding: '6px 16px',
            background: '#4caf50',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          Save
        </button>
      </div>
      {error && (
        <div style={{ padding: '8px', background: '#ffebee', color: '#c62828', borderRadius: '4px', marginBottom: '10px', fontSize: '12px' }}>
          {error}
        </div>
      )}
      <textarea
        value={jsonText}
        onChange={(e) => setJsonText(e.target.value)}
        style={{
          width: '100%',
          height: '500px',
          border: '1px solid #ddd',
          borderRadius: '4px',
          padding: '10px',
          fontFamily: 'monospace',
          fontSize: '12px',
          backgroundColor: '#f9f9f9',
          resize: 'vertical'
        }}
      />
    </div>
  );
};

export default ProcessGroup5;
