import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Login from './pages/login/Login';
import Signup from './pages/signup/Signup';
import Dashboard from './pages/Dashboard';
import ProtectedRoute from './routes/ProtectedRoute';
import MainLayout from './layout/MainLayout';
import Temporary from './screens/Temporary';
import TempProcess from './screens/TempProcess';

import Home from './pages/Home/Home';
import HomeDashboard from './pages/Home/Dashboard';
import Notifications from './pages/Home/Notifications';

import ProcessGroup from './pages/Designer/ProcessGroup';
import Templates from './pages/Designer/Templates';
import Workflow from './pages/Designer/Workflow';
import BusinessRules from './pages/Designer/BusinessRules';
import Registry from './pages/Designer/Registry';

import AnotherApp from './pages/ProjectGroup/AnotherApp';

import Runtime from './pages/Kernel/Runtime';
import Monitoring from './pages/Kernel/Monitoring';

import Metrics from './pages/Performance/Metrics';
import KPIs from './pages/Performance/KPIs';

import GlobalSettings from './pages/Configuration/GlobalSettings';
import ExecutionSettings from './pages/Configuration/ExecutionSettings';
import Event from './pages/Configuration/Event';
import Configuration from './pages/Configuration/Configuration';
import SecuritySettings from './pages/Configuration/SecuritySettings';
import NotificationSettings from './pages/Configuration/NotificationSettings';

import Users from './pages/Administration/Users';
import Tenants from './pages/Administration/Tenants';
import Partners from './pages/Administration/Partners';

import Documentation from './pages/Help/Documentation';
import Support from './pages/Help/Support';
import About from './pages/Help/About';
import LandingPage from './pages/LandingPage';
import DomainPage from './screens/domain';
import SchemaPage from './screens/schema';

import './App.css'

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage/>} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/temp1" element={<Temporary />} />
        <Route path="/temp2" element={<TempProcess />} />
        <Route path="/temp3" element={<DomainPage />} />
        <Route path="/temp4" element={<SchemaPage />} />
        
        <Route path="/admin" element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="/admin/home" replace />} />
          <Route path="home" element={<Home />} />
          <Route path="dashboard" element={<HomeDashboard />} />
          <Route path="notifications" element={<Notifications />} />
          
          <Route path="designer/process-group" element={<ProcessGroup />} />
          <Route path="designer/templates" element={<Templates />} />
          <Route path="designer/workflow" element={<Workflow />} />
          <Route path="designer/business-rules" element={<BusinessRules />} />
          <Route path="designer/registry" element={<Registry />} />
          
          <Route path="project-group/another-app" element={<AnotherApp />} />
          
          <Route path="kernel/runtime" element={<Runtime />} />
          <Route path="kernel/monitoring" element={<Monitoring />} />
          
          <Route path="performance/metrics" element={<Metrics />} />
          <Route path="performance/kpis" element={<KPIs />} />
          
          <Route path="configuration/global-settings" element={<GlobalSettings />} />
          <Route path="configuration/execution-settings" element={<ExecutionSettings />} />
          <Route path="configuration/event" element={<Event />} />
          <Route path="configuration/configuration" element={<Configuration />} />
          <Route path="configuration/security-settings" element={<SecuritySettings />} />
          <Route path="configuration/notification-settings" element={<NotificationSettings />} />
          
          <Route path="administration/users" element={<Users />} />
          <Route path="administration/tenants" element={<Tenants />} />
          <Route path="administration/partners" element={<Partners />} />
          
          <Route path="help/documentation" element={<Documentation />} />
          <Route path="help/support" element={<Support />} />
          <Route path="help/about" element={<About />} />
        </Route>
        
        <Route path="/evtol" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/ground" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/booking" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/support" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
