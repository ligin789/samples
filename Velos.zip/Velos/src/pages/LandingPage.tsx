import { useEffect, useLayoutEffect, useRef, useState } from "react";
import "./Landing.css";
import Aos from "aos";
import "aos/dist/aos.css";
import Logo from "../assets/images/landingPage/logo.svg";
import LogoDark from "../assets/images/landingPage/logoDark.svg";
// import Mov from "../assets/images/landingPage/background.mov";
import Arrow from "../assets/images/landingPage/arrowUp.svg";

import SettingIcon from "../assets/images/landingPage/settings.svg";
import CloudIcon from "../assets/images/landingPage/cloud.svg";
import CallCenterIcon from "../assets/images/landingPage/callcenter.svg";
import PersonIcon from "../assets/images/landingPage/person.svg";
import VertiportIcon from "../assets/images/landingPage/vertiport.svg";

function LandingPage() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isScrollEvent, setIsScrollEvent] = useState(false);
  const [isFading, setIsFading] = useState(false);

  const overlayRef = useRef<HTMLDivElement | null>(null);
  const animLogoRef = useRef<HTMLImageElement | null>(null);
  const headerLogoRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    const header = document.querySelector(".site-header");
    if (!header) return;

    const SCROLLED_BG_THRESHOLD = 200; // when to add dark background
    const STICKY_THRESHOLD = 20; // when to make header sticky

    const onScroll = () => {
      const y = window.scrollY || window.pageYOffset || 0;

      const aTag = document.querySelectorAll(".nav-link");

      if (y > SCROLLED_BG_THRESHOLD) header.classList.add("is-scrolled");
      else header.classList.remove("is-scrolled");

      if (y > SCROLLED_BG_THRESHOLD)
        aTag.forEach((el) => el.classList.add("text-dark"));
      else aTag.forEach((el) => el.classList.remove("text-dark"));

      if (y > SCROLLED_BG_THRESHOLD) setIsScrollEvent(true);
      else setIsScrollEvent(false);

      if (y > STICKY_THRESHOLD) header.classList.add("is-fixed");
      else header.classList.remove("is-fixed");
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    Aos.init({
      duration: 800,
      easing: "ease-in-out",
      once: false,
      offset: 100,
    });
  }, []);

  /**
   * Loader → keep white overlay with logo for 2s, then zoom the logo out (scale up & fade),
   * then fade overlay and reveal header brand.
   */
  useLayoutEffect(() => {
    let minShowTimer: number | undefined;

    const ensure2sVisible = new Promise<void>((resolve) => {
      // Ensure loader is visible for at least 2 seconds
      minShowTimer = window.setTimeout(() => resolve(), 2000);
    });

    const onWindowLoad = new Promise<void>((resolve) => {
      if (document.readyState === "complete") resolve();
      else window.addEventListener("load", () => resolve(), { once: true });
    });

    Promise.all([onWindowLoad, ensure2sVisible]).then(() => {
      requestAnimationFrame(() => {
        runLogoZoomOut();
      });
    });

    function runLogoZoomOut() {
      const overlay = overlayRef.current;
      const animLogo = animLogoRef.current;
      const headerBrandImg = document.querySelector(
        ".site-header .navbar-brand img.brand-logo"
      ) as HTMLImageElement | null;

      if (!overlay || !animLogo) {
        setIsLoaded(true);
        return;
      }

      // Hide header brand during splash to avoid double-vision
      if (headerBrandImg) headerBrandImg.style.opacity = "0";

      // Trigger the CSS zoom animation
      animLogo.classList.add("loader-logo--zoom");

      const onAnimEnd = () => {
        animLogo.removeEventListener("animationend", onAnimEnd);

        // Reveal header brand now
        if (headerBrandImg) headerBrandImg.style.opacity = "1";

        // Fade the white overlay for a clean exit
        setIsFading(true);

        // Wait for CSS fade (~250ms), then remove the overlay
        setTimeout(() => {
          setIsLoaded(true);
        }, 260);
      };

      animLogo.addEventListener("animationend", onAnimEnd);
    }

    return () => {
      if (minShowTimer) clearTimeout(minShowTimer);
    };
  }, []);

  return (
    <div className="container-fluid p-0">
      {!isLoaded && (
        <div
          ref={overlayRef}
          className={`loader-overlay${isFading ? " fading" : ""}`}
        >
          <img
            ref={animLogoRef}
            src={LogoDark}
            alt="Brand"
            className="loader-logo"
          />
        </div>
      )}

      <header className="site-header position-absolute top-0 start-0 w-100">
        <nav className="navbar navbar-expand-lg navbar-dark transparent-nav py-3">
          <div className="container-fluid px-3 px-lg-4">
            <a className="navbar-brand d-flex align-items-center gap-2" href="/">
              {isScrollEvent ? (
                <img src={LogoDark} className="brand-logo" height={28} alt="Brand" />
              ) : (
                <img src={Logo} className="brand-logo" height={28} alt="Brand" />
              )}
            </a>

            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#mainNav"
              aria-controls="mainNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>

            {/* Right: Links */}
            <div className="collapse navbar-collapse" id="mainNav">
              <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-2 ">
                <li className="nav-item ">
                  <a className="nav-link" href="#features">
                    Features
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#about">
                    About
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/login">
                    Sign in
                  </a>
                </li>
                <li className="nav-item ms-lg-2">
                  <a className="nav-link" href="/get-started">
                    Get started
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>

      {/* ======= BELOW-HEADER SECTION WITH FULL-WIDTH VIDEO BACKGROUND ======= */}
      <div className="landing-hero">
        {/* Background video (covers the entire hero section) */}
        <div className="video-bg">
          {/* <video
            className="video-bg__media"
            src={Mov}
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            onLoadStart={(e: any) => {
              e.target.playbackRate = 0.8;
            }}
          /> */}

          {/* Contrast overlay (below header) */}
          <div className="video-bg__overlay" />
        </div>

        {/* Foreground content over the video */}
        <div className="landing-hero__content container-fluid ml-5">
          <div className="row " style={{ marginLeft: "40px" }}>
            <div className="col-12 col-lg-8 ml-5">
              <h1
                className="display-5  text-white mb-2"
                style={{ fontSize: "30px" }}
              >
                Why sit in traffic? When the
              </h1>
              <p
                className="lead text-white-50 fw-semibold mb-3"
                style={{ fontSize: "60px" }}
              >
                Sky is already waiting for you
              </p>
              <div className="d-flex gap-2">
                <a
                  href="/get-started"
                  className="btn btn-light btn-lg rounded-pill px-4"
                >
                  Explore &nbsp;
                  <img src={Arrow} className="brand-logo" height={11} alt="Brand" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ======= MORE CONTENT BELOW (normal sections) ======= */}
      <div className="container-fluid pt-5 mt-5">
        <div className="d-flex mt-5 pt-5 pb-5 justify-content-evenly">
          <div className="card border-0" data-aos="fade-right">
            <h3 className="darkVioloteText secondSectionMain">50+</h3>
            <h6 className="secondSectionSecondary">Vertiports</h6>
          </div>
          <div className="card border-0" data-aos="fade-right">
            <h3 className="darkVioloteText secondSectionMain">200</h3>
            <h6 className="secondSectionSecondary ">Aircrafts</h6>
          </div>
          <div className="card border-0" data-aos="fade-left">
            <h3 className="darkVioloteText secondSectionMain">10</h3>
            <h6 className="secondSectionSecondary">City Regions</h6>
          </div>
          <div className="card border-0" data-aos="fade-left">
            <h3 className="darkVioloteText secondSectionMain">99%</h3>
            <h6 className="secondSectionSecondary">Uptime</h6>
          </div>
        </div>
      </div>

      <div className="stakeholder-section container-fluid pt-5 pl-5">
        <h3 className="secondSectionMainHeading">Build for every Stakeholder</h3>
        <h3 className="secondSectionSecondHeading">
          Role based access with tailored dashboards for each participant in the
          ecosystem
        </h3>
        <div className="d-flex justify-content-start  pt-5 topMargin">
          <div className="secondSectionCard mx-2 p-4">
            <img src={CallCenterIcon} width={23} alt="" />
            <h4 className="secondSectionText pt-5">eVTOL Operators</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={CallCenterIcon} alt="" width={23} />
            <h4 className="secondSectionText pt-5">Vertiport Owners</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={SettingIcon} alt="" width={23} />
            <h4 className="secondSectionText  pt-5">Regulators</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={CloudIcon} alt="" width={23} />
            <h4 className="secondSectionText  pt-5">MET Agencies</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={PersonIcon} alt="" width={23} />
            <h4 className="secondSectionText  pt-5">Passengers</h4>
          </div>
        </div>
      </div>

      <div className="orchestration-section-main container-fluid">
        <h3 className="">
          A unified marketplace connecting eVTOL operators, vertiport owners,
          regulators
          <br />
          &amp; passengers for seamless urban air mobility operations
        </h3>
      </div>
      <div className="white-container">
        <span className="px-5 p-3">Watch Demo</span>
      </div>

      <div className="orchestration-section container-fluid pt-5">
        <h3 className="secondSectionMainHeading">
          Complete Orchestration Platform
        </h3>
        <h3 className="secondSectionSecondHeading">
          Everything you need to operate, manage &amp; scale urban air mobility
          services
        </h3>
        <div className="d-flex justify-content-start  pt-5 topMargin">
          <div className="secondSectionCard mx-2 p-4">
            <img src={CallCenterIcon} width={23} alt="" />
            <h4 className="secondSectionText pt-5">eVTOL Operators</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={CallCenterIcon} alt="" width={23} />
            <h4 className="secondSectionText pt-5">Vertiport Owners</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={SettingIcon} alt="" width={23} />
            <h4 className="secondSectionText  pt-5">Regulators</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={CloudIcon} alt="" width={23} />
            <h4 className="secondSectionText  pt-5">MET Agencies</h4>
          </div>
          <div className="secondSectionCard mx-2 p-4">
            <img src={PersonIcon} alt="" width={23} />
            <h4 className="secondSectionText  pt-5">Passengers</h4>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
