import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Page from '../../components/Page';
import CreateRuleModal from '../../components/businessRules/CreateRuleModal';
import RuleEditorCanvas from '../../components/businessRules/RuleEditorCanvas';
import { setSelectedRule, deleteRule } from '../../store/businessRules/businessRulesActions';
import type { RootState } from '../../store/rootReducer';

const BusinessRules = () => {
  const dispatch = useDispatch();
  const [showModal, setShowModal] = useState(false);
  const { rules, selectedRuleId } = useSelector((state: RootState) => state.businessRules);
  
  const selectedRule = rules.find(rule => rule.id === selectedRuleId);

  const handleRuleClick = (ruleId: string) => {
    dispatch(setSelectedRule(ruleId));
  };

  const handleDeleteRule = (ruleId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    dispatch(deleteRule(ruleId));
  };

  return (
    <Page title=''>
      <div className="row" style={{ height: 'calc(100vh - 100px)' }}>
        <div className="col-md-3">
          <div className="card h-100">
            <div className="card-header">
              <button 
                className="btn btn-primary w-100"
                onClick={() => setShowModal(true)}
              >
                Create Rule
              </button>
            </div>
            <div className="card-body p-0" style={{ overflowY: 'auto' }}>
              <div className="list-group list-group-flush">
                {rules.length === 0 ? (
                  <div className="list-group-item text-muted text-center">
                    No rules created
                  </div>
                ) : (
                  rules.map((rule) => (
                    <div
                      key={rule.id}
                      className={`list-group-item list-group-item-action d-flex justify-content-between align-items-start ${
                        selectedRuleId === rule.id ? 'active' : ''
                      }`}
                      onClick={() => handleRuleClick(rule.id)}
                      style={{ cursor: 'pointer' }}
                    >
                      <div className="flex-grow-1">
                        <h6 className="mb-1">{rule.name}</h6>
                        <small className={selectedRuleId === rule.id ? 'text-white-50' : 'text-muted'}>
                          {rule.category}
                        </small>
                      </div>
                      <button
                        className="btn btn-sm btn-link text-danger p-0 ms-2"
                        onClick={(e) => handleDeleteRule(rule.id, e)}
                        title="Delete rule"
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-9">
          {selectedRule ? (
            <RuleEditorCanvas rule={selectedRule} />
          ) : (
            <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #eee' }}>
              <div style={{ textAlign: 'center', color: '#888' }}>
                <h5>Select or create a rule</h5>
                <p>Choose a rule from the list or create a new one to get started</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <CreateRuleModal show={showModal} onClose={() => setShowModal(false)} />
    </Page>
  );
};

export default BusinessRules;
