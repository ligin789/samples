import Page from '../../components/Page';

const Templates = () => <Page title="Templates" />;

export default Templates;
