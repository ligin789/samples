import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../store/rootReducer';
import { addDemandZone, updateDemandZone, deleteDemandZone } from '../../redux/demandZones/demandZonesThunks';
import type { DemandZone } from '../../redux/demandZones/demandZonesTypes';
import LeafletMap from '../../components/Map/LeafletMap';
import DrawableMap from '../../components/Map/DrawableMap';

const DemandZones = () => {
  const dispatch = useDispatch();
  const { zones, loading } = useSelector((state: RootState) => state.demandZones);
  const { regions } = useSelector((state: RootState) => state.region);
  const [expanded, setExpanded] = useState(false);
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [densityFilter, setDensityFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');
  const [regionFilter, setRegionFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [editingZone, setEditingZone] = useState<DemandZone | null>(null);
  const [formData, setFormData] = useState<Omit<DemandZone, 'id'>>({
    zoneCode: '',
    zoneName: '',
    regionId: '',
    density: 'commercial',
    type: 'medium',
    status: 'active',
    geojson: null,
  });

  const handleOpenModal = (zone?: DemandZone) => {
    if (zone) {
      setEditingZone(zone);
      setFormData({
        zoneCode: zone.zoneCode,
        zoneName: zone.zoneName,
        regionId: zone.regionId,
        density: zone.density,
        type: zone.type,
        status: zone.status,
        geojson: zone.geojson,
      });
    } else {
      setEditingZone(null);
      setFormData({
        zoneCode: '',
        zoneName: '',
        regionId: '',
        density: 'commercial',
        type: 'medium',
        status: 'active',
        geojson: null,
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingZone(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handlePolygonCreated = (geojson: any) => {
    setFormData({ ...formData, geojson });
  };

  const handleSubmit = () => {
    if (!formData.zoneCode || !formData.zoneName || !formData.regionId) {
      alert('Please fill all required fields');
      return;
    }

    if (editingZone) {
      dispatch(updateDemandZone({
        ...editingZone,
        ...formData
      }) as any);
    } else {
      dispatch(addDemandZone(formData) as any);
    }

    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this demand zone?')) {
      dispatch(deleteDemandZone(id) as any);
    }
  };

  const filteredZones = zones.filter(zone => {
    const matchesSearch = zone.zoneName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDensity = densityFilter === 'All' || zone.density === densityFilter;
    const matchesType = typeFilter === 'All' || zone.type === typeFilter;
    const matchesRegion = regionFilter === 'All' || zone.regionId === regionFilter;
    const matchesStatus = statusFilter === 'All' || zone.status === statusFilter;
    return matchesSearch && matchesDensity && matchesType && matchesRegion && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      active: 'success',
      inactive: 'danger',
    };
    return <span className={`badge bg-${colors[status] || 'secondary'}`}>{status}</span>;
  };

  const getDensityBadge = (density: string) => {
    const colors: Record<string, string> = {
      airport: 'primary',
      station: 'info',
      hospital: 'danger',
      campus: 'warning',
      commercial: 'success',
      tourism: 'secondary',
    };
    return <span className={`badge bg-${colors[density] || 'secondary'}`}>{density}</span>;
  };

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      very_high: 'danger',
      high: 'warning',
      medium: 'info',
      low: 'secondary',
    };
    return <span className={`badge bg-${colors[type] || 'secondary'}`}>{type.replace('_', ' ')}</span>;
  };

  const mapZones = zones.map(z => ({
    id: z.id,
    cityCode: z.zoneCode,
    cityName: z.zoneName,
    geoJson: z.geojson
  }));

  const totalZones = zones.length;
  const veryHighZones = zones.filter(z => z.type === 'very_high').length;
  const highZones = zones.filter(z => z.type === 'high').length;
  const activeZones = zones.filter(z => z.status === 'active').length;

  return (
    <div className="container-fluid h-100 p-0">
      <div className="d-flex justify-content-between align-items-center p-3 bg-light border-bottom">
        <h4 className="mb-0">Demand Zones Management</h4>
        <button
          className="btn btn-outline-primary btn-sm"
          onClick={() => setExpanded(!expanded)}
        >
          ⇄ Toggle View
        </button>
      </div>
      
      <div className="row g-0 h-100">
        <div className={`${expanded ? 'col-md-8' : 'col-md-4'} cities-map-col`}>
          <div className="h-100 position-relative shadow-sm">
            <LeafletMap 
              zoom={expanded ? 13 : 11} 
              cities={mapZones}
              selectedCityId={selectedZoneId}
            />
          </div>
        </div>
        
        <div className={`${expanded ? 'col-md-4' : 'col-md-8'} cities-table-col`}>
          <div className="h-100 p-3 overflow-auto">
            <div className="row mb-3">
              <div className="col-md-3">
                <div className="card text-center">
                  <div className="card-body">
                    <h3 className="text-primary">{totalZones}</h3>
                    <p className="mb-0 small">Total Demand Zones</p>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card text-center">
                  <div className="card-body">
                    <h3 className="text-danger">{veryHighZones}</h3>
                    <p className="mb-0 small">Very High Demand</p>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card text-center">
                  <div className="card-body">
                    <h3 className="text-warning">{highZones}</h3>
                    <p className="mb-0 small">High Demand</p>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card text-center">
                  <div className="card-body">
                    <h3 className="text-success">{activeZones}</h3>
                    <p className="mb-0 small">Active Zones</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-header">
                <h5 className="mb-0">Demand Zones</h5>
              </div>
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                  <div className="d-flex gap-2 flex-wrap">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search by zone name..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      style={{ width: '180px' }}
                    />
                    <select
                      className="form-select"
                      value={densityFilter}
                      onChange={(e) => setDensityFilter(e.target.value)}
                      style={{ width: '130px' }}
                    >
                      <option value="All">All Density</option>
                      <option value="airport">Airport</option>
                      <option value="station">Station</option>
                      <option value="hospital">Hospital</option>
                      <option value="campus">Campus</option>
                      <option value="commercial">Commercial</option>
                      <option value="tourism">Tourism</option>
                    </select>
                    <select
                      className="form-select"
                      value={typeFilter}
                      onChange={(e) => setTypeFilter(e.target.value)}
                      style={{ width: '130px' }}
                    >
                      <option value="All">All Types</option>
                      <option value="very_high">Very High</option>
                      <option value="high">High</option>
                      <option value="medium">Medium</option>
                      <option value="low">Low</option>
                    </select>
                    <select
                      className="form-select"
                      value={regionFilter}
                      onChange={(e) => setRegionFilter(e.target.value)}
                      style={{ width: '130px' }}
                    >
                      <option value="All">All Regions</option>
                      {regions.map(region => (
                        <option key={region.id} value={region.id}>
                          {region.region_name}
                        </option>
                      ))}
                    </select>
                    <select
                      className="form-select"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      style={{ width: '110px' }}
                    >
                      <option value="All">All Status</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                    </select>
                  </div>
                  <button
                    className="btn btn-primary"
                    onClick={() => handleOpenModal()}
                  >
                    + Add Demand Zone
                  </button>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead>
                      <tr>
                        <th>Zone Code</th>
                        <th>Zone Name</th>
                        <th>Region</th>
                        <th>Density</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredZones.map((zone) => {
                        const region = regions.find(r => r.id === zone.regionId);
                        return (
                          <tr 
                            key={zone.id}
                            onClick={() => setSelectedZoneId(zone.id)}
                            style={{ cursor: 'pointer' }}
                            className={selectedZoneId === zone.id ? 'table-active' : ''}
                          >
                            <td>{zone.zoneCode}</td>
                            <td>{zone.zoneName}</td>
                            <td>{region?.region_name || 'N/A'}</td>
                            <td>{getDensityBadge(zone.density)}</td>
                            <td>{getTypeBadge(zone.type)}</td>
                            <td>{getStatusBadge(zone.status)}</td>
                            <td>
                              <button
                                className="btn btn-sm btn-outline-primary me-2"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenModal(zone);
                                }}
                              >
                                Edit
                              </button>
                              <button
                                className="btn btn-sm btn-outline-danger"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(zone.id);
                                }}
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
      <div className="modal fade show" id="demandZoneModal" tabIndex={-1} style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{editingZone ? 'Edit Demand Zone' : 'Add Demand Zone'}</h5>
              <button type="button" className="btn-close" onClick={handleCloseModal} aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Zone Code *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="zoneCode"
                    value={formData.zoneCode}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Zone Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="zoneName"
                    value={formData.zoneName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Region *</label>
                  <select
                    className="form-select"
                    name="regionId"
                    value={formData.regionId}
                    onChange={handleInputChange}
                  >
                    <option value="">Select Region</option>
                    {regions.map(region => (
                      <option key={region.id} value={region.id}>
                        {region.region_name} ({region.region_code})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Density *</label>
                  <select
                    className="form-select"
                    name="density"
                    value={formData.density}
                    onChange={handleInputChange}
                  >
                    <option value="airport">Airport</option>
                    <option value="station">Station</option>
                    <option value="hospital">Hospital</option>
                    <option value="campus">Campus</option>
                    <option value="commercial">Commercial</option>
                    <option value="tourism">Tourism</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Type *</label>
                  <select
                    className="form-select"
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                  >
                    <option value="very_high">Very High</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Status</label>
                  <select
                    className="form-select"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                <div className="col-12">
                  <label className="form-label">Draw Zone Boundary</label>
                  <div style={{ height: '400px' }}>
                    <DrawableMap
                      onPolygonCreated={handlePolygonCreated}
                      existingGeoJson={formData.geojson}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                Cancel
              </button>
              <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                {editingZone ? 'Update' : 'Add'}
              </button>
            </div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
};

export default DemandZones;
