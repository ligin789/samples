import { useState, useEffect } from 'react';
import LeafletMap from '../../components/Map/LeafletMap';
import DrawableMap from '../../components/Map/DrawableMap';
import { v4 as uuidv4 } from 'uuid';
import './Cities.css';

interface City {
  id: string;
  cityCode: string;
  cityName: string;
  country: string;
  code: string;
  timezone: string;
  createdDate: string;
  status: string;
  geoJson?: any;
}

const Cities = () => {
  const [expanded, setExpanded] = useState(false);
  const [selectedCityId, setSelectedCityId] = useState<string | null>(null);
  const blrId = 'blr-central-001';
  const [cities, setCities] = useState<City[]>([
    {
      id: blrId,
      cityCode: 'BLR',
      cityName: 'Bangalore Central',
      country: 'India',
      code: 'KA',
      timezone: 'Asia/Kolkata',
      createdDate: '2024-01-15',
      status: 'Active',
      geoJson: {
        type: 'Feature',
        properties: { id: blrId, name: 'Bangalore Central' },
        geometry: {
          type: 'Polygon',
          coordinates: [[
            [77.56, 12.96],
            [77.60, 12.96],
            [77.60, 12.99],
            [77.56, 12.99],
            [77.56, 12.96]
          ]]
        }
      }
    },
  ]);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [editingCity, setEditingCity] = useState<City | null>(null);
  const [formData, setFormData] = useState<Omit<City, 'id' | 'createdDate'>>({
    cityCode: '',
    cityName: '',
    country: '',
    code: '',
    timezone: '',
    status: 'Active',
    geoJson: null,
  });

  const handleOpenModal = (city?: City) => {
    if (city) {
      setEditingCity(city);
      setFormData({
        cityCode: city.cityCode,
        cityName: city.cityName,
        country: city.country,
        code: city.code,
        timezone: city.timezone,
        createdDate: city.createdDate,
        status: city.status,
        geoJson: city.geoJson,
      });
    } else {
      setEditingCity(null);
      setFormData({
        cityCode: '',
        cityName: '',
        country: '',
        code: '',
        timezone: '',
        status: 'Active',
        geoJson: null,
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingCity(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePolygonCreated = (geoJson: any) => {
    setFormData({ ...formData, geoJson });
  };

  const handleSubmit = () => {
    if (!formData.cityCode || !formData.cityName || !formData.country || !formData.code || !formData.timezone) {
      alert('Please fill all required fields');
      return;
    }

    const cityData = {
      cityCode: formData.cityCode,
      cityName: formData.cityName,
      country: formData.country,
      code: formData.code,
      timezone: formData.timezone,
      status: formData.status,
      createdDate: new Date().toISOString(),
      geoJsonBoundary: formData.geoJson,
    };

    console.log(cityData);

    if (editingCity) {
      setCities(cities.map(city => 
        city.id === editingCity.id 
          ? { ...city, ...formData, createdDate: city.createdDate }
          : city
      ));
    } else {
      setCities([...cities, { id: uuidv4(), ...formData, createdDate: new Date().toISOString() }]);
    }

    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this city?')) {
      setCities(cities.filter(city => city.id !== id));
    }
  };

  const filteredCities = cities.filter(city => {
    const matchesSearch = city.cityName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || city.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      Active: 'success',
      Pending: 'warning',
      Inactive: 'danger',
    };
    return <span className={`badge bg-${colors[status] || 'secondary'}`}>{status}</span>;
  };



  return (
    <div className="container-fluid h-100 p-0">
      <div className="d-flex justify-content-between align-items-center p-3 bg-light border-bottom">
        <h4 className="mb-0">Cities Management</h4>
        <button
          className="btn btn-outline-primary btn-sm"
          onClick={() => setExpanded(!expanded)}
        >
          ⇄ Toggle View
        </button>
      </div>
      
      <div className="row g-0 h-100">
        <div className={`${expanded ? 'col-md-8' : 'col-md-4'} cities-map-col`}>
          <div className="h-100 position-relative shadow-sm">
            <LeafletMap 
              zoom={expanded ? 13 : 11} 
              cities={cities}
              selectedCityId={selectedCityId}
            />
          </div>
        </div>
        
        <div className={`${expanded ? 'col-md-4' : 'col-md-8'} cities-table-col`}>
          <div className="h-100 p-3 overflow-auto">
            <div className="card">
              <div className="card-header">
                <h5 className="mb-0">Cities</h5>
              </div>
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <div className="d-flex gap-2">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search by city name..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      style={{ width: '250px' }}
                    />
                    <select
                      className="form-select"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      style={{ width: '150px' }}
                    >
                      <option value="All">All Status</option>
                      <option value="Active">Active</option>
                      <option value="Pending">Pending</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                  <button
                    className="btn btn-primary"
                    onClick={() => handleOpenModal()}
                  >
                    + Add City
                  </button>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead>
                      <tr>
                        <th>City Code</th>
                        <th>City Name</th>
                        <th>Country</th>
                        <th>Code</th>
                        <th>Timezone</th>
                        <th>Created Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredCities.map((city) => (
                        <tr 
                          key={city.id}
                          onClick={() => setSelectedCityId(city.id)}
                          style={{ cursor: 'pointer' }}
                          className={selectedCityId === city.id ? 'table-active' : ''}
                        >
                          <td>{city.cityCode}</td>
                          <td>{city.cityName}</td>
                          <td>{city.country}</td>
                          <td>{city.code}</td>
                          <td>{city.timezone}</td>
                          <td>{city.createdDate}</td>
                          <td>{getStatusBadge(city.status)}</td>
                          <td>
                            <button
                              className="btn btn-sm btn-outline-primary me-2"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenModal(city);
                              }}
                            >
                              Edit
                            </button>
                            <button
                              className="btn btn-sm btn-outline-danger"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(city.id);
                              }}
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
      <div className="modal fade show" id="cityModal" tabIndex={-1} style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{editingCity ? 'Edit City' : 'Add City'}</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">City Code *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="cityCode"
                    value={formData.cityCode}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">City Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="cityName"
                    value={formData.cityName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Country *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="country"
                    value={formData.country}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Code *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="code"
                    value={formData.code}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Timezone *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="timezone"
                    value={formData.timezone}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Status</label>
                  <select
                    className="form-select"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
                <div className="col-12">
                  <label className="form-label">Draw Boundary Polygon</label>
                  <div style={{ height: '400px' }}>
                    <DrawableMap
                      onPolygonCreated={handlePolygonCreated}
                      existingGeoJson={formData.geoJson}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                Cancel
              </button>
              <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                {editingCity ? 'Update' : 'Add'}
              </button>
            </div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
};

export default Cities;
