const Zones = () => {
  return (
    <div className="p-4">
      <h2>Authorized Zones</h2>
      <p>Manage authorized zones in the airspace system.</p>
    </div>
  );
};

export default Zones;
