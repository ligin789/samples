const Regions = () => {
  return (
    <div className="p-4">
      <h2>Regions</h2>
      <p>Manage regions in the airspace system.</p>
    </div>
  );
};

export default Regions;
