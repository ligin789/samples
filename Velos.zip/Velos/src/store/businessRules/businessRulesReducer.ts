import {
  CREATE_RULE,
  UPDATE_RULE,
  SET_SELECTED_RULE,
  DELETE_RULE,
  type BusinessRulesState,
  type BusinessRulesActionTypes
} from './businessRulesTypes';

const STORAGE_KEY = 'businessRules';

const loadFromStorage = (): BusinessRulesState => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return {
        rules: parsed.rules || [],
        selectedRuleId: parsed.selectedRuleId || null
      };
    }
  } catch (e) {
    console.error('Failed to load business rules from storage:', e);
  }
  return { rules: [], selectedRuleId: null };
};

const saveToStorage = (state: BusinessRulesState) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save business rules to storage:', e);
  }
};

const initialState: BusinessRulesState = loadFromStorage();

const businessRulesReducer = (
  state = initialState,
  action: BusinessRulesActionTypes
): BusinessRulesState => {
  let newState: BusinessRulesState;

  switch (action.type) {
    case CREATE_RULE:
      newState = {
        ...state,
        rules: [...state.rules, action.payload]
      };
      saveToStorage(newState);
      return newState;

    case UPDATE_RULE:
      newState = {
        ...state,
        rules: state.rules.map((rule) =>
          rule.id === action.payload.id ? action.payload : rule
        )
      };
      saveToStorage(newState);
      return newState;

    case SET_SELECTED_RULE:
      newState = {
        ...state,
        selectedRuleId: action.payload
      };
      saveToStorage(newState);
      return newState;

    case DELETE_RULE:
      const remainingRules = state.rules.filter((rule) => rule.id !== action.payload);
      let newSelectedId = state.selectedRuleId;
      
      if (state.selectedRuleId === action.payload) {
        newSelectedId = remainingRules.length > 0 ? remainingRules[0].id : null;
      }
      
      newState = {
        ...state,
        rules: remainingRules,
        selectedRuleId: newSelectedId
      };
      saveToStorage(newState);
      return newState;

    default:
      return state;
  }
};

export default businessRulesReducer;
