import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  CREATE_RULE,
  UPDATE_RULE,
  SET_SELECTED_RULE,
  DELETE_RULE,
  type Rule,
  type BusinessRulesActionTypes
} from './businessRulesTypes';

export const createRule = (ruleData: Omit<Rule, 'id' | 'createdAt'>) => {
  return (dispatch: Dispatch<BusinessRulesActionTypes>) => {
    const newRule: Rule = {
      ...ruleData,
      id: uuidv4(),
      createdAt: new Date().toISOString()
    };
    dispatch({
      type: CREATE_RULE,
      payload: newRule
    });
    dispatch(setSelectedRule(newRule.id));
  };
};

export const updateRule = (rule: Rule) => ({
  type: UPDATE_RULE,
  payload: rule
});

export const setSelectedRule = (ruleId: string | null) => ({
  type: SET_SELECTED_RULE,
  payload: ruleId
});

export const deleteRule = (id: string) => ({
  type: DELETE_RULE,
  payload: id
});
