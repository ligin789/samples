export const CREATE_RULE = 'CREATE_RULE';
export const UPDATE_RULE = 'UPDATE_RULE';
export const SET_SELECTED_RULE = 'SET_SELECTED_RULE';
export const DELETE_RULE = 'DELETE_RULE';

export interface Rule {
  id: string;
  name: string;
  category: string;
  value: any;
  createdAt: string;
}

export interface BusinessRulesState {
  rules: Rule[];
  selectedRuleId: string | null;
}

interface CreateRuleAction {
  type: typeof CREATE_RULE;
  payload: Rule;
}

interface UpdateRuleAction {
  type: typeof UPDATE_RULE;
  payload: Rule;
}

interface SetSelectedRuleAction {
  type: typeof SET_SELECTED_RULE;
  payload: string | null;
}

interface DeleteRuleAction {
  type: typeof DELETE_RULE;
  payload: string;
}

export type BusinessRulesActionTypes =
  | CreateRuleAction
  | UpdateRuleAction
  | SetSelectedRuleAction
  | DeleteRuleAction;
