import { combineReducers } from "redux";
import loginReducer from "../redux/login/loginReducer";
import processGroupReducer from "../redux/processGroup/processGroupReducer";
import processReducer from "../redux/process/processReducer";

const rootReducer = combineReducers({
  login: loginReducer,
  processGroup: processGroupReducer,
  process: processReducer
});

type RootState = ReturnType<typeof rootReducer>;

export type { RootState };
export default rootReducer;
