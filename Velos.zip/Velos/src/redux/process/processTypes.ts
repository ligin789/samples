export const FETCH_PROCESS_REQUEST = 'FETCH_PROCESS_REQUEST';
export const FETCH_PROCESS_SUCCESS = 'FETCH_PROCESS_SUCCESS';
export const FETCH_PROCESS_FAILURE = 'FETCH_PROCESS_FAILURE';
export const ADD_PROCESS = 'ADD_PROCESS';
export const UPDATE_PROCESS = 'UPDATE_PROCESS';
export const DELETE_PROCESS = 'DELETE_PROCESS';
export const SET_SELECTED_PROCESS = 'SET_SELECTED_PROCESS';
export const UPDATE_PROCESS_FLOW = 'UPDATE_PROCESS_FLOW';
export const SET_SELECTED_NODE = 'SET_SELECTED_NODE';
export const UPDATE_NODE = 'UPDATE_NODE';

export interface Metadata {
  created_at?: string;
  updated_at?: string;
  created_by?: string;
  updated_by?: string;
}

export interface Applicability {
  operatingcluster?: string[];
}

export interface Domain {
  industry: string;
  function: string;
  subfunction: string;
  applicability?: Applicability;
}

export interface Operator {
  operatorCode: string;
  operatorName: string;
  operatorType: string;
  policyNamespace?: string;
  region: string;
}

export interface Governance {
  owner?: string;
  approver?: string;
  reviewCycle?: string;
}

export interface EntryPoint {
  entry_id: string;
  name: string;
  type: string;
}

export interface ExitPoint {
  exit_id: string;
  name: string;
  type: string;
}

export interface Task {
  task_id: string;
  name: string;
  type: string;
  sequence?: number;
}

export interface ProcessFlowNode {
  node_id: string;
  type: 'ENTRY' | 'TASK' | 'GATEWAY' | 'EXIT';
  name: string;
  next?: string[];
  gateway_type?: 'FORK' | 'JOIN';
}

export interface ProcessFlow {
  nodes: ProcessFlowNode[];
}

export interface Process {
  process_id: string;
  process_key: string;
  name: string;
  version: string;
  status: string;
  description?: string;
  metadata?: Metadata;
  domain?: Domain;
  operator?: Operator;
  governance?: Governance;
  tags?: string[];
  processFlow?: ProcessFlow;
  tasks?: Task[];
  entry_points?: EntryPoint[];
  exit_points?: ExitPoint[];
  process_context?: Record<string, any>;
}

export interface ProcessState {
  loading: boolean;
  error: string | null;
  process: Process[];
  selectedProcess: Process | null;
  selectedNode: any | null;
}
