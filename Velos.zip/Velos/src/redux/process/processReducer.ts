import {
  FETCH_PROCESS_REQUEST,
  FETCH_PROCESS_SUCCESS,
  FETCH_PROCESS_FAILURE,
  ADD_PROCESS,
  UPDATE_PROCESS,
  DELETE_PROCESS,
  SET_SELECTED_PROCESS,
  type ProcessState,
  type Process
} from './processTypes';

interface ProcessAction {
  type: string;
  payload?: Process[] | Process | { id: string; data: Partial<Process> } | string;
}

const initialState: ProcessState = {
  loading: false,
  error: null,
  process: [],
  selectedProcess: null
};

const processReducer = (state = initialState, action: ProcessAction): ProcessState => {
  switch (action.type) {
    case FETCH_PROCESS_REQUEST:
      return { ...state, loading: true, error: null };

    case FETCH_PROCESS_SUCCESS:
      return { 
        ...state, 
        loading: false, 
        process: action.payload as Process[] 
      };

    case FETCH_PROCESS_FAILURE:
      return { 
        ...state, 
        loading: false, 
        error: action.payload as string 
      };

    case ADD_PROCESS:
      return {
        ...state,
        process: [...state.process, action.payload as Process]
      };

    case UPDATE_PROCESS: {
      const { id, data } = action.payload as { id: string; data: Partial<Process> };
      return {
        ...state,
        process: state.process.map(p =>
          p.process_id === id ? { ...p, ...data } : p
        )
      };
    }

    case DELETE_PROCESS:
      return {
        ...state,
        process: state.process.filter(
          p => p.process_id !== (action.payload as string)
        )
      };

    case SET_SELECTED_PROCESS:
      return {
        ...state,
        selectedProcess: action.payload as Process
      };

    default:
      return state;
  }
};

export default processReducer;
