import {
  FETCH_PROCESS_GROUP_REQUEST,
  FETCH_PROCESS_GROUP_SUCCESS,
  FETCH_PROCESS_GROUP_FAILURE,
  ADD_PROCESS_GROUP,
  UPDATE_PROCESS_GROUP,
  DELETE_PROCESS_GROUP,
  ADD_NODE_TO_PROCESS_GROUP,
  type ProcessGroupState,
  type ProcessGroup,
  type Node
} from './processGroupTypes';

interface ProcessGroupAction {
  type: string;
  payload?: ProcessGroup[] | ProcessGroup | { id: string; data: Partial<ProcessGroup> } | string | { processGroupId: string; node: Node };
}

const initialState: ProcessGroupState = {
  loading: false,
  error: null,
  processGroup: []
};

const processGroupReducer = (state = initialState, action: ProcessGroupAction): ProcessGroupState => {
  switch (action.type) {
    case FETCH_PROCESS_GROUP_REQUEST:
      return { ...state, loading: true, error: null };

    case FETCH_PROCESS_GROUP_SUCCESS:
      return { 
        ...state, 
        loading: false, 
        processGroup: action.payload as ProcessGroup[] 
      };

    case FETCH_PROCESS_GROUP_FAILURE:
      return { 
        ...state, 
        loading: false, 
        error: action.payload as string 
      };

    case ADD_PROCESS_GROUP:
      return {
        ...state,
        processGroup: [...state.processGroup, action.payload as ProcessGroup]
      };

    case UPDATE_PROCESS_GROUP: {
      const { id, data } = action.payload as { id: string; data: Partial<ProcessGroup> };
      return {
        ...state,
        processGroup: state.processGroup.map(pg =>
          pg.process_group_id === id ? { ...pg, ...data } : pg
        )
      };
    }

    case DELETE_PROCESS_GROUP:
      return {
        ...state,
        processGroup: state.processGroup.filter(
          pg => pg.process_group_id !== (action.payload as string)
        )
      };

    case ADD_NODE_TO_PROCESS_GROUP: {
      const { processGroupId, node } = action.payload as { processGroupId: string; node: Node };
      return {
        ...state,
        processGroup: state.processGroup.map(pg =>
          pg.process_group_id === processGroupId
            ? { ...pg, nodes: [...pg.nodes, node], edges: pg.edges || [] }
            : pg
        )
      };
    }

    default:
      return state;
  }
};

export default processGroupReducer;
