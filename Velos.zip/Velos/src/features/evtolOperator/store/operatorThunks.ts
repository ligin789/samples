import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  createOperatorRequest,
  createOperatorSuccess,
  createOperatorFailure,
  fetchOperatorsSuccess,
} from './operatorActions';
import type { EvtolOperator, OperatorActionTypes } from './operatorTypes';

export const createOperatorThunk = (operatorData: Omit<EvtolOperator, 'id'>) => {
  return async (dispatch: Dispatch<OperatorActionTypes>) => {
    dispatch(createOperatorRequest());
    
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      const newOperator: EvtolOperator = {
        id: uuidv4(),
        ...operatorData,
      };
      
      dispatch(createOperatorSuccess(newOperator));
      return newOperator;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create operator';
      dispatch(createOperatorFailure(errorMessage));
      throw error;
    }
  };
};

export const fetchOperatorsThunk = () => {
  return async (dispatch: Dispatch<OperatorActionTypes>) => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      dispatch(fetchOperatorsSuccess([]));
    } catch (error) {
      console.error('Failed to fetch operators', error);
    }
  };
};
