import type {
  OperatorState,
  OperatorActionTypes,
} from './operatorTypes';
import {
  CREATE_OPERATOR_REQUEST,
  CREATE_OPERATOR_SUCCESS,
  CREATE_OPERATOR_FAILURE,
  FETCH_OPERATORS_SUCCESS,
} from './operatorTypes';

const initialState: OperatorState = {
  operators: [],
  loading: false,
  error: null,
};

const operatorReducer = (
  state = initialState,
  action: OperatorActionTypes
): OperatorState => {
  switch (action.type) {
    case CREATE_OPERATOR_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case CREATE_OPERATOR_SUCCESS:
      return {
        ...state,
        loading: false,
        operators: [...state.operators, action.payload],
      };
    case CREATE_OPERATOR_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case FETCH_OPERATORS_SUCCESS:
      return {
        ...state,
        operators: action.payload,
      };
    default:
      return state;
  }
};

export default operatorReducer;
