export interface EvtolOperator {
  id: string;
  operatorCode: string;
  legalName: string;
  tradingName: string;
  registrationName: string;
  registrationDate: string;
  businessStructure: "01" | "02";
  businessStructureCode: string;
  websiteUrl: string;
  onboardingDateTime: string;
}

export interface OperatorState {
  operators: EvtolOperator[];
  loading: boolean;
  error: string | null;
}

export const CREATE_OPERATOR_REQUEST = 'CREATE_OPERATOR_REQUEST';
export const CREATE_OPERATOR_SUCCESS = 'CREATE_OPERATOR_SUCCESS';
export const CREATE_OPERATOR_FAILURE = 'CREATE_OPERATOR_FAILURE';
export const FETCH_OPERATORS_SUCCESS = 'FETCH_OPERATORS_SUCCESS';

export interface CreateOperatorRequestAction {
  type: typeof CREATE_OPERATOR_REQUEST;
}

export interface CreateOperatorSuccessAction {
  type: typeof CREATE_OPERATOR_SUCCESS;
  payload: EvtolOperator;
}

export interface CreateOperatorFailureAction {
  type: typeof CREATE_OPERATOR_FAILURE;
  payload: string;
}

export interface FetchOperatorsSuccessAction {
  type: typeof FETCH_OPERATORS_SUCCESS;
  payload: EvtolOperator[];
}

export type OperatorActionTypes =
  | CreateOperatorRequestAction
  | CreateOperatorSuccessAction
  | CreateOperatorFailureAction
  | FetchOperatorsSuccessAction;
