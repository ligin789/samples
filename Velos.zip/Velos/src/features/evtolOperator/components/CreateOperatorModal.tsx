import { useState } from 'react';
import { useAppDispatch } from '../../../store/hooks';
import { createOperatorThunk } from '../store/operatorThunks';
import type { EvtolOperator } from '../store/operatorTypes';

interface CreateOperatorModalProps {
  show: boolean;
  onClose: () => void;
}

const CreateOperatorModal = ({ show, onClose }: CreateOperatorModalProps) => {
  const dispatch = useAppDispatch();
  const [formData, setFormData] = useState<Omit<EvtolOperator, 'id'>>({
    operatorCode: '',
    legalName: '',
    tradingName: '',
    registrationName: '',
    registrationDate: '',
    businessStructure: '01',
    businessStructureCode: '',
    websiteUrl: '',
    onboardingDateTime: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.operatorCode) newErrors.operatorCode = 'Operator code is required';
    if (!formData.legalName) newErrors.legalName = 'Legal name is required';
    if (!formData.registrationName) newErrors.registrationName = 'Registration name is required';
    
    if (formData.websiteUrl && !/^https?:\/\/.+/.test(formData.websiteUrl)) {
      newErrors.websiteUrl = 'Invalid URL format';
    }
    
    if (formData.registrationDate && new Date(formData.registrationDate) > new Date()) {
      newErrors.registrationDate = 'Registration date cannot be in the future';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    try {
      await dispatch(createOperatorThunk(formData) as any);
      onClose();
      setFormData({
        operatorCode: '',
        legalName: '',
        tradingName: '',
        registrationName: '',
        registrationDate: '',
        businessStructure: '01',
        businessStructureCode: '',
        websiteUrl: '',
        onboardingDateTime: '',
      });
    } catch (error) {
      console.error('Failed to create operator', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: '' });
    }
  };

  if (!show) return null;

  return (
    <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog modal-lg">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Create eVTOL Operator</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Operator Code *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.operatorCode ? 'is-invalid' : ''}`}
                    name="operatorCode"
                    value={formData.operatorCode}
                    onChange={handleChange}
                  />
                  {errors.operatorCode && <div className="invalid-feedback">{errors.operatorCode}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Legal Name *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.legalName ? 'is-invalid' : ''}`}
                    name="legalName"
                    value={formData.legalName}
                    onChange={handleChange}
                  />
                  {errors.legalName && <div className="invalid-feedback">{errors.legalName}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Trading Name</label>
                  <input
                    type="text"
                    className="form-control"
                    name="tradingName"
                    value={formData.tradingName}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Registration Name *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.registrationName ? 'is-invalid' : ''}`}
                    name="registrationName"
                    value={formData.registrationName}
                    onChange={handleChange}
                  />
                  {errors.registrationName && <div className="invalid-feedback">{errors.registrationName}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Registration Date</label>
                  <input
                    type="date"
                    className={`form-control ${errors.registrationDate ? 'is-invalid' : ''}`}
                    name="registrationDate"
                    value={formData.registrationDate}
                    onChange={handleChange}
                  />
                  {errors.registrationDate && <div className="invalid-feedback">{errors.registrationDate}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Business Structure</label>
                  <select
                    className="form-select"
                    name="businessStructure"
                    value={formData.businessStructure}
                    onChange={handleChange}
                  >
                    <option value="01">01</option>
                    <option value="02">02</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Business Structure Code</label>
                  <input
                    type="text"
                    className="form-control"
                    name="businessStructureCode"
                    value={formData.businessStructureCode}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Website URL</label>
                  <input
                    type="text"
                    className={`form-control ${errors.websiteUrl ? 'is-invalid' : ''}`}
                    name="websiteUrl"
                    value={formData.websiteUrl}
                    onChange={handleChange}
                  />
                  {errors.websiteUrl && <div className="invalid-feedback">{errors.websiteUrl}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Onboarding Date & Time</label>
                  <input
                    type="datetime-local"
                    className="form-control"
                    name="onboardingDateTime"
                    value={formData.onboardingDateTime}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose} disabled={loading}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Creating...' : 'Create Operator'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateOperatorModal;
