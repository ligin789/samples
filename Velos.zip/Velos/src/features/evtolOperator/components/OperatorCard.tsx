import { useNavigate } from 'react-router-dom';
import type { EvtolOperator } from '../store/operatorTypes';

interface OperatorCardProps {
  operator: EvtolOperator;
}

const OperatorCard = ({ operator }: OperatorCardProps) => {
  const navigate = useNavigate();

  return (
    <div
      className="card h-100"
      style={{
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-5px)';
        e.currentTarget.style.boxShadow = '0 8px 16px rgba(0,0,0,0.15)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
      }}
      onClick={() => navigate(`/admin/administration/evtol-operator/${operator.id}`)}
    >
      <div className="card-body p-4">
        <h4 className="card-title mb-3" style={{ fontWeight: 'bold', color: '#1a1a1a' }}>
          {operator.legalName}
        </h4>
        <p className="card-text mb-2" style={{ color: '#666' }}>
          <strong>Reg No:</strong> {operator.registrationName}
        </p>
        <p className="card-text mb-0" style={{ color: '#666' }}>
          <strong>Operator Code:</strong> {operator.operatorCode}
        </p>
      </div>
    </div>
  );
};

export default OperatorCard;
