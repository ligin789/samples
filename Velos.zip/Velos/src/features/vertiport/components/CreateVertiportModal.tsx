import { useState } from 'react';
import { useAppDispatch } from '../../../store/hooks';
import { createVertiportThunk } from '../store/vertiportThunks';
import type { Vertiport } from '../store/vertiportTypes';

interface CreateVertiportModalProps {
  show: boolean;
  onClose: () => void;
}

const CreateVertiportModal = ({ show, onClose }: CreateVertiportModalProps) => {
  const dispatch = useAppDispatch();
  const [formData, setFormData] = useState<Omit<Vertiport, 'id'>>({
    vertiport_code: '',
    vertiport_icao_code: '',
    vertiport_type_code: '',
    vertiport_type_name: '',
    facility_name: '',
    facility_code: '',
    facility_status_code: '',
    facility_status: '',
    vertiport_operational_status_code: 'operational',
    vertiport_operational_status: '',
    certification_level: 'level1',
    facility_class_code: '',
    facility_class_description: '',
    total_area_sqm: 0,
    total_parking_stands: 0,
    total_FATO_pads: 0,
    hangar_capacity: 0,
    is_maintenance_facilities_available: false,
    onboarding_datetime: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.vertiport_code) newErrors.vertiport_code = 'Vertiport code is required';
    if (!formData.facility_name) newErrors.facility_name = 'Facility name is required';
    
    if (formData.vertiport_icao_code && formData.vertiport_icao_code.length !== 4) {
      newErrors.vertiport_icao_code = 'ICAO code must be 4 characters';
    }
    
    if (formData.total_area_sqm < 0) newErrors.total_area_sqm = 'Must be positive';
    if (formData.total_parking_stands < 0) newErrors.total_parking_stands = 'Must be positive';
    if (formData.total_FATO_pads < 0) newErrors.total_FATO_pads = 'Must be positive';
    if (formData.hangar_capacity < 0) newErrors.hangar_capacity = 'Must be positive';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    try {
      await dispatch(createVertiportThunk(formData) as any);
      onClose();
      setFormData({
        vertiport_code: '',
        vertiport_icao_code: '',
        vertiport_type_code: '',
        vertiport_type_name: '',
        facility_name: '',
        facility_code: '',
        facility_status_code: '',
        facility_status: '',
        vertiport_operational_status_code: 'operational',
        vertiport_operational_status: '',
        certification_level: 'level1',
        facility_class_code: '',
        facility_class_description: '',
        total_area_sqm: 0,
        total_parking_stands: 0,
        total_FATO_pads: 0,
        hangar_capacity: 0,
        is_maintenance_facilities_available: false,
        onboarding_datetime: '',
      });
    } catch (error) {
      console.error('Failed to create vertiport', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData({ 
      ...formData, 
      [name]: type === 'checkbox' ? checked : type === 'number' ? Number(value) : value 
    });
    
    if (errors[name]) {
      setErrors({ ...errors, [name]: '' });
    }
  };

  if (!show) return null;

  return (
    <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog modal-xl">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Create Vertiport</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-4">
                  <label className="form-label">Vertiport Code *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.vertiport_code ? 'is-invalid' : ''}`}
                    name="vertiport_code"
                    value={formData.vertiport_code}
                    onChange={handleChange}
                  />
                  {errors.vertiport_code && <div className="invalid-feedback">{errors.vertiport_code}</div>}
                </div>
                <div className="col-md-4">
                  <label className="form-label">ICAO Code</label>
                  <input
                    type="text"
                    className={`form-control ${errors.vertiport_icao_code ? 'is-invalid' : ''}`}
                    name="vertiport_icao_code"
                    maxLength={4}
                    value={formData.vertiport_icao_code}
                    onChange={handleChange}
                  />
                  {errors.vertiport_icao_code && <div className="invalid-feedback">{errors.vertiport_icao_code}</div>}
                </div>
                <div className="col-md-4">
                  <label className="form-label">Facility Name *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.facility_name ? 'is-invalid' : ''}`}
                    name="facility_name"
                    value={formData.facility_name}
                    onChange={handleChange}
                  />
                  {errors.facility_name && <div className="invalid-feedback">{errors.facility_name}</div>}
                </div>
                <div className="col-md-4">
                  <label className="form-label">Vertiport Type Code</label>
                  <input
                    type="text"
                    className="form-control"
                    name="vertiport_type_code"
                    value={formData.vertiport_type_code}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-4">
                  <label className="form-label">Vertiport Type Name</label>
                  <input
                    type="text"
                    className="form-control"
                    name="vertiport_type_name"
                    value={formData.vertiport_type_name}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-4">
                  <label className="form-label">Facility Code</label>
                  <input
                    type="text"
                    className="form-control"
                    name="facility_code"
                    value={formData.facility_code}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-4">
                  <label className="form-label">Facility Status Code</label>
                  <input
                    type="text"
                    className="form-control"
                    name="facility_status_code"
                    value={formData.facility_status_code}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-4">
                  <label className="form-label">Facility Status</label>
                  <input
                    type="text"
                    className="form-control"
                    name="facility_status"
                    value={formData.facility_status}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-4">
                  <label className="form-label">Operational Status</label>
                  <select
                    className="form-select"
                    name="vertiport_operational_status_code"
                    value={formData.vertiport_operational_status_code}
                    onChange={handleChange}
                  >
                    <option value="operational">Operational</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="closed">Closed</option>
                  </select>
                </div>
                <div className="col-md-4">
                  <label className="form-label">Certification Level</label>
                  <select
                    className="form-select"
                    name="certification_level"
                    value={formData.certification_level}
                    onChange={handleChange}
                  >
                    <option value="level1">Level 1</option>
                    <option value="level2">Level 2</option>
                    <option value="level3">Level 3</option>
                  </select>
                </div>
                <div className="col-md-4">
                  <label className="form-label">Facility Class Code</label>
                  <input
                    type="number"
                    className="form-control"
                    name="facility_class_code"
                    value={formData.facility_class_code}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-4">
                  <label className="form-label">Total Area (sqm)</label>
                  <input
                    type="number"
                    className={`form-control ${errors.total_area_sqm ? 'is-invalid' : ''}`}
                    name="total_area_sqm"
                    value={formData.total_area_sqm}
                    onChange={handleChange}
                  />
                  {errors.total_area_sqm && <div className="invalid-feedback">{errors.total_area_sqm}</div>}
                </div>
                <div className="col-md-4">
                  <label className="form-label">Total Parking Stands</label>
                  <input
                    type="number"
                    className={`form-control ${errors.total_parking_stands ? 'is-invalid' : ''}`}
                    name="total_parking_stands"
                    value={formData.total_parking_stands}
                    onChange={handleChange}
                  />
                  {errors.total_parking_stands && <div className="invalid-feedback">{errors.total_parking_stands}</div>}
                </div>
                <div className="col-md-4">
                  <label className="form-label">Total FATO Pads</label>
                  <input
                    type="number"
                    className={`form-control ${errors.total_FATO_pads ? 'is-invalid' : ''}`}
                    name="total_FATO_pads"
                    value={formData.total_FATO_pads}
                    onChange={handleChange}
                  />
                  {errors.total_FATO_pads && <div className="invalid-feedback">{errors.total_FATO_pads}</div>}
                </div>
                <div className="col-md-4">
                  <label className="form-label">Hangar Capacity</label>
                  <input
                    type="number"
                    className={`form-control ${errors.hangar_capacity ? 'is-invalid' : ''}`}
                    name="hangar_capacity"
                    value={formData.hangar_capacity}
                    onChange={handleChange}
                  />
                  {errors.hangar_capacity && <div className="invalid-feedback">{errors.hangar_capacity}</div>}
                </div>
                <div className="col-md-4">
                  <label className="form-label">Onboarding Date & Time</label>
                  <input
                    type="datetime-local"
                    className="form-control"
                    name="onboarding_datetime"
                    value={formData.onboarding_datetime}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-4">
                  <div className="form-check mt-4">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      name="is_maintenance_facilities_available"
                      checked={formData.is_maintenance_facilities_available}
                      onChange={handleChange}
                    />
                    <label className="form-check-label">
                      Maintenance Facilities Available
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose} disabled={loading}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Creating...' : 'Create Vertiport'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateVertiportModal;
