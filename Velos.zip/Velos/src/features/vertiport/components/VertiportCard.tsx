import { useNavigate } from 'react-router-dom';
import type { Vertiport } from '../store/vertiportTypes';

interface VertiportCardProps {
  vertiport: Vertiport;
}

const VertiportCard = ({ vertiport }: VertiportCardProps) => {
  const navigate = useNavigate();

  return (
    <div
      className="card h-100"
      style={{
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        border: '1px solid #e0e0e0',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-5px)';
        e.currentTarget.style.boxShadow = '0 8px 16px rgba(0,0,0,0.15)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
      }}
      onClick={() => navigate(`/admin/vertiport/${vertiport.id}`)}
    >
      <div className="card-body p-4">
        <h4 className="card-title mb-3" style={{ fontWeight: 'bold', color: '#1a1a1a' }}>
          {vertiport.facility_name}
        </h4>
        <p className="card-text mb-2" style={{ color: '#666' }}>
          <strong>Code:</strong> {vertiport.vertiport_code}
        </p>
        <p className="card-text mb-0" style={{ color: '#666' }}>
          <strong>Vertiport ID:</strong> {vertiport.id.substring(0, 13)}
        </p>
      </div>
    </div>
  );
};

export default VertiportCard;
