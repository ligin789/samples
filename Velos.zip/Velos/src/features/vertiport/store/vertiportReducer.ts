import type {
  VertiportState,
  VertiportActionTypes,
} from './vertiportTypes';
import {
  CREATE_VERTIPORT_REQUEST,
  CREATE_VERTIPORT_SUCCESS,
  CREATE_VERTIPORT_FAILURE,
  FETCH_VERTIPORTS_SUCCESS,
} from './vertiportTypes';

const initialState: VertiportState = {
  vertiports: [],
  loading: false,
  error: null,
};

const vertiportReducer = (
  state = initialState,
  action: VertiportActionTypes
): VertiportState => {
  switch (action.type) {
    case CREATE_VERTIPORT_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case CREATE_VERTIPORT_SUCCESS:
      return {
        ...state,
        loading: false,
        vertiports: [...state.vertiports, action.payload],
      };
    case CREATE_VERTIPORT_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case FETCH_VERTIPORTS_SUCCESS:
      return {
        ...state,
        vertiports: action.payload,
      };
    default:
      return state;
  }
};

export default vertiportReducer;
