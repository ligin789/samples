import { Link } from "react-router-dom";
import styles from "./Header.module.css";

import logo from "../assets/images/landingPage/logo.svg";

const menuStructure = [
  {
    label: "Designer",
    submenu: [
      { name: "Process Group", path: "/admin/designer/process-group" },
      { name: "Templates", path: "/admin/designer/templates" },
      { name: "Workflow", path: "/admin/designer/workflow" },
      { name: "Business Rules", path: "/admin/designer/business-rules" },
      { name: "Registry", path: "/admin/designer/registry" },
    ],
  },
  {
    label: "AirSpace",
    submenu: [
      { name: "Cities", path: "/admin/airspace/cities" },
      { name: "Regions", path: "/admin/airspace/regions" },
      { name: "Authorized Zones", path: "/admin/airspace/zones" },
      { name: "Demand Zones", path: "/admin/designer/process-group" },
    ],
  },
  {
    label: "Kernel",
    submenu: [
      { name: "Runtime", path: "/admin/kernel/runtime" },
      { name: "Monitoring", path: "/admin/kernel/monitoring" },
    ],
  },
  {
    label: "Performance",
    submenu: [
      { name: "Metrics", path: "/admin/performance/metrics" },
      { name: "KPIs", path: "/admin/performance/kpis" },
    ],
  },
  {
    label: "Configuration",
    submenu: [
      { name: "Global Settings", path: "/admin/configuration/global-settings" },
      {
        name: "Execution Settings",
        path: "/admin/configuration/execution-settings",
      },
      { name: "Event", path: "/admin/configuration/event" },
      { name: "Configuration", path: "/admin/configuration/configuration" },
      {
        name: "Security Settings",
        path: "/admin/configuration/security-settings",
      },
      {
        name: "Notification Settings",
        path: "/admin/configuration/notification-settings",
      },
    ],
  },
  {
    label: "Administration",
    submenu: [
      { name: "Users", path: "/admin/administration/users" },
      { name: "Tenants", path: "/admin/administration/tenants" },
      { name: "Partners", path: "/admin/administration/partners" },
      { name: "eVTOL Operator", path: "/admin/administration/evtol-operator" },
      { name: "Vertiport", path: "/admin/vertiport" },
    ],
  },
  {
    label: "Help",
    submenu: [
      { name: "Documentation", path: "/admin/help/documentation" },
      { name: "Support", path: "/admin/help/support" },
      { name: "About", path: "/admin/help/about" },
    ],
  },
];

const Header = () => {
  return (
    <header className={styles.header}>
      <div className={styles.topBar}>
        <Link to="/admin/home" className="d-flex text-decoration-none">
          <div className={styles.logo}>
            <img src={logo} width={70} alt="Platform Logo" />
          </div>
          <div className={styles.platformName}>Platform Portal</div>
        </Link>

        <nav className={styles.mainNav}>
          {menuStructure.map((menu) => (
            <div key={menu.label} className={styles.navItem}>
              <button className={styles.navButton}>{menu.label}</button>
              <div className={styles.dropdown}>
                {menu.submenu.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={styles.dropdownItem}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div className={styles.profile}>
          <div className={styles.profileInfo}>
            <p className={styles.profileName}>Gilbert Dawson</p>
            <p className={styles.profileRole}>Duty Manager</p>
          </div>
          <div className={styles.avatar}>GD</div>
        </div>
      </div>
    </header>
  );
};

export default Header;
