import { useState, useCallback } from 'react';

interface JsonTreeViewerProps {
  data: any;
  onChange: (newData: any) => void;
}

interface TreeNodeProps {
  keyName: string;
  value: any;
  path: string[];
  onChange: (path: string[], newValue: any) => void;
  isLast: boolean;
}

const TreeNode = ({ keyName, value, path, onChange, isLast }: TreeNodeProps) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState('');

  const isObject = value !== null && typeof value === 'object' && !Array.isArray(value);
  const isArray = Array.isArray(value);
  const isExpandable = isObject || isArray;

  const handleEdit = () => {
    setEditValue(JSON.stringify(value));
    setIsEditing(true);
  };

  const handleSaveEdit = () => {
    try {
      const parsed = JSON.parse(editValue);
      onChange(path, parsed);
      setIsEditing(false);
    } catch {
      setIsEditing(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      setIsEditing(false);
    }
  };

  const renderValue = () => {
    if (isEditing) {
      return (
        <input
          type="text"
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          onBlur={handleSaveEdit}
          onKeyDown={handleKeyDown}
          autoFocus
          style={{
            fontFamily: 'monospace',
            fontSize: '12px',
            padding: '2px 4px',
            border: '1px solid #4caf50',
            borderRadius: '2px',
            outline: 'none',
            minWidth: '100px'
          }}
        />
      );
    }

    if (isObject) {
      return (
        <span style={{ color: '#666' }}>
          {isExpanded ? '{' : `{ ... }`}
        </span>
      );
    }

    if (isArray) {
      return (
        <span style={{ color: '#666' }}>
          {isExpanded ? '[' : `[ ${value.length} items ]`}
        </span>
      );
    }

    const color = typeof value === 'string' ? '#c41a16' : typeof value === 'number' ? '#1c00cf' : typeof value === 'boolean' ? '#0000ff' : '#666';
    const displayValue = typeof value === 'string' ? `"${value}"` : String(value);

    return (
      <span
        style={{ color, cursor: 'pointer' }}
        onDoubleClick={handleEdit}
        title="Double-click to edit"
      >
        {displayValue}
      </span>
    );
  };

  return (
    <div style={{ marginLeft: keyName ? '20px' : '0' }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '2px 0' }}>
        {isExpandable && (
          <span
            onClick={() => setIsExpanded(!isExpanded)}
            style={{
              cursor: 'pointer',
              marginRight: '4px',
              userSelect: 'none',
              width: '12px',
              display: 'inline-block',
              fontSize: '10px'
            }}
          >
            {isExpanded ? '▼' : '▶'}
          </span>
        )}
        {!isExpandable && <span style={{ width: '16px', display: 'inline-block' }} />}
        
        {keyName && (
          <span style={{ color: '#881391', fontWeight: 500, marginRight: '8px' }}>
            "{keyName}":
          </span>
        )}
        
        {renderValue()}
        
        {!isExpanded && isObject && <span style={{ color: '#666' }}> }</span>}
        {!isExpanded && isArray && <span style={{ color: '#666' }}> ]</span>}
        {!isLast && !isExpanded && <span style={{ color: '#666' }}>,</span>}
      </div>

      {isExpanded && isExpandable && (
        <div>
          {isObject &&
            Object.entries(value).map(([key, val], idx, arr) => (
              <TreeNode
                key={key}
                keyName={key}
                value={val}
                path={[...path, key]}
                onChange={onChange}
                isLast={idx === arr.length - 1}
              />
            ))}
          {isArray &&
            value.map((val: any, idx: number) => (
              <TreeNode
                key={idx}
                keyName={String(idx)}
                value={val}
                path={[...path, String(idx)]}
                onChange={onChange}
                isLast={idx === value.length - 1}
              />
            ))}
          <div style={{ marginLeft: '16px', color: '#666' }}>
            {isObject ? '}' : ']'}
            {!isLast && ','}
          </div>
        </div>
      )}
    </div>
  );
};

const JsonTreeViewer = ({ data, onChange }: JsonTreeViewerProps) => {
  const handleChange = useCallback((path: string[], newValue: any) => {
    const updateNested = (obj: any, pathArray: string[], value: any): any => {
      if (pathArray.length === 0) return value;
      
      const [current, ...rest] = pathArray;
      const isArrayIndex = !isNaN(Number(current));
      
      if (Array.isArray(obj)) {
        const newArray = [...obj];
        newArray[Number(current)] = rest.length === 0 ? value : updateNested(obj[Number(current)], rest, value);
        return newArray;
      }
      
      return {
        ...obj,
        [current]: rest.length === 0 ? value : updateNested(obj[current], rest, value)
      };
    };

    const updated = updateNested(data, path, newValue);
    onChange(updated);
  }, [data, onChange]);

  return (
    <div
      style={{
        fontFamily: 'monospace',
        fontSize: '12px',
        padding: '12px',
        backgroundColor: '#f9f9f9',
        border: '1px solid #ddd',
        borderRadius: '4px',
        maxHeight: '500px',
        overflowY: 'auto',
        overflowX: 'auto'
      }}
    >
      <TreeNode
        keyName=""
        value={data}
        path={[]}
        onChange={handleChange}
        isLast={true}
      />
    </div>
  );
};

export default JsonTreeViewer;
