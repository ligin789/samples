import { useState, useCallback, useRef, useEffect } from 'react';
import { ReactFlow, MiniMap, Controls, Background, MarkerType, ReactFlowProvider, useReactFlow, addEdge } from '@xyflow/react';
import type { Node, Edge, Connection } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { useAppSelector } from '../../store/hooks';
import GatewayNode from './nodes/GatewayNode';
import type { ProcessFlowNode } from '../../redux/process/processTypes';

const nodeTypes = {
  gateway: GatewayNode,
};

const FlowCanvas = () => {
  const selectedProcess = useAppSelector(state => state.process.selectedProcess);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const { screenToFlowPosition } = useReactFlow();

  console.log("Selected Process FULL:", JSON.stringify(selectedProcess, null, 2));

  useEffect(() => {
    if (!selectedProcess?.processFlow?.nodes) {
      console.log("No processFlow.nodes found");
      setNodes([]);
      setEdges([]);
      return;
    }

    const flowNodes = selectedProcess.processFlow.nodes;
    const nodePositions = new Map<string, { x: number; y: number }>();
    const levelMap = new Map<string, number>();
    
    const calculateLevels = (nodeId: string, level: number, visited = new Set<string>()) => {
      if (visited.has(nodeId)) return;
      visited.add(nodeId);
      
      const currentLevel = levelMap.get(nodeId) ?? -1;
      if (level > currentLevel) {
        levelMap.set(nodeId, level);
      }
      
      const node = flowNodes.find(n => n.node_id === nodeId);
      if (node?.next) {
        node.next.forEach(nextId => calculateLevels(nextId, level + 1, visited));
      }
    };

    const entryNodes = flowNodes.filter(n => n.type === 'ENTRY');
    entryNodes.forEach(n => calculateLevels(n.node_id, 0));

    const levelGroups = new Map<number, string[]>();
    levelMap.forEach((level, nodeId) => {
      if (!levelGroups.has(level)) {
        levelGroups.set(level, []);
      }
      levelGroups.get(level)!.push(nodeId);
    });

    levelGroups.forEach((nodeIds, level) => {
      const count = nodeIds.length;
      const startX = 250 - ((count - 1) * 200) / 2;
      nodeIds.forEach((nodeId, index) => {
        nodePositions.set(nodeId, {
          x: startX + index * 200,
          y: level * 150
        });
      });
    });

    const reactFlowNodes: Node[] = flowNodes.map((node: ProcessFlowNode) => {
      const pos = nodePositions.get(node.node_id) || { x: 250, y: 0 };
      
      let nodeType = 'default';
      let style: any = { background: '#2196f3', color: 'white', border: '2px solid #1565c0', padding: 10 };
      
      if (node.type === 'ENTRY') {
        nodeType = 'input';
        style = { background: '#4caf50', color: 'white', border: '2px solid #2e7d32', padding: 10 };
      } else if (node.type === 'EXIT') {
        nodeType = 'output';
        style = { background: '#f44336', color: 'white', border: '2px solid #c62828', padding: 10 };
      } else if (node.type === 'GATEWAY') {
        nodeType = 'gateway';
        style = {};
      }

      return {
        id: node.node_id,
        type: nodeType,
        position: pos,
        data: { label: node.name },
        style
      };
    });

    const reactFlowEdges: Edge[] = [];
    flowNodes.forEach((node: ProcessFlowNode) => {
      if (node.next) {
        node.next.forEach((targetId: string) => {
          reactFlowEdges.push({
            id: `${node.node_id}-${targetId}`,
            source: node.node_id,
            target: targetId,
            type: 'smoothstep',
            animated: true,
            markerEnd: { type: MarkerType.ArrowClosed }
          });
        });
      }
    });

    console.log("Final Nodes:", reactFlowNodes);
    console.log("Final Edges:", reactFlowEdges);
    console.log("Node IDs:", reactFlowNodes.map(n => n.id));
    console.log("Edge Sources:", reactFlowEdges.map(e => e.source));
    console.log("Edge Targets:", reactFlowEdges.map(e => e.target));

    setNodes(reactFlowNodes);
    setEdges(reactFlowEdges);
  }, [selectedProcess]);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    []
  );

  const onDragStart = (event: React.DragEvent, nodeType: string) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      if (!type) return;

      const position = screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const newNodeId = `${type.toLowerCase()}-${Date.now()}`;
      let nodeType = 'default';
      let style: any = { background: '#2196f3', color: 'white', border: '2px solid #1565c0', padding: 10 };

      if (type === 'ENTRY') {
        nodeType = 'input';
        style = { background: '#4caf50', color: 'white', border: '2px solid #2e7d32', padding: 10 };
      } else if (type === 'EXIT') {
        nodeType = 'output';
        style = { background: '#f44336', color: 'white', border: '2px solid #c62828', padding: 10 };
      } else if (type === 'GATEWAY') {
        nodeType = 'gateway';
        style = {};
      }

      const newNode: Node = {
        id: newNodeId,
        type: nodeType,
        position,
        data: { label: `${type}` },
        style
      };

      console.log("Dropped Node:", newNode);
      setNodes((nds) => nds.concat(newNode));
    },
    [screenToFlowPosition]
  );

  if (!selectedProcess) {
    return (
      <div className="p-3 h-100">
        <div className="bg-white rounded p-3 h-100 d-flex align-items-center justify-content-center">
          <h5 className="text-muted">Select a process to view workflow</h5>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 h-100">
      <div className="bg-white rounded p-3 h-100" style={{ position: 'relative' }}>
        <h5>{selectedProcess.name}</h5>
        
        {/* Toolbox */}
        <div style={{
          position: 'absolute',
          left: '20px',
          top: '60px',
          zIndex: 10,
          background: 'white',
          border: '1px solid #ddd',
          borderRadius: '4px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <div style={{ marginBottom: '5px', fontWeight: 'bold', fontSize: '12px' }}>Toolbox</div>
          <div
            draggable
            onDragStart={(e) => onDragStart(e, 'ENTRY')}
            style={{
              padding: '8px 12px',
              margin: '5px 0',
              background: '#4caf50',
              color: 'white',
              borderRadius: '4px',
              cursor: 'grab',
              fontSize: '12px'
            }}
          >
            Entry
          </div>
          <div
            draggable
            onDragStart={(e) => onDragStart(e, 'TASK')}
            style={{
              padding: '8px 12px',
              margin: '5px 0',
              background: '#2196f3',
              color: 'white',
              borderRadius: '4px',
              cursor: 'grab',
              fontSize: '12px'
            }}
          >
            Task
          </div>
          <div
            draggable
            onDragStart={(e) => onDragStart(e, 'GATEWAY')}
            style={{
              padding: '8px 12px',
              margin: '5px 0',
              background: '#ff9800',
              color: 'white',
              borderRadius: '4px',
              cursor: 'grab',
              fontSize: '12px'
            }}
          >
            Gateway
          </div>
          <div
            draggable
            onDragStart={(e) => onDragStart(e, 'EXIT')}
            style={{
              padding: '8px 12px',
              margin: '5px 0',
              background: '#f44336',
              color: 'white',
              borderRadius: '4px',
              cursor: 'grab',
              fontSize: '12px'
            }}
          >
            Exit
          </div>
        </div>

        <div ref={reactFlowWrapper} style={{ height: 'calc(100% - 40px)', width: '100%' }}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            onConnect={onConnect}
            onDrop={onDrop}
            onDragOver={onDragOver}
            fitView
          >
            <MiniMap />
            <Controls />
            <Background />
          </ReactFlow>
        </div>
      </div>
    </div>
  );
};

const MainCanvas = () => {
  return (
    <ReactFlowProvider>
      <FlowCanvas />
    </ReactFlowProvider>
  );
};

export default MainCanvas;
