import { useState, useEffect } from "react";
import { useAppSelector } from "../../store/hooks";
import type { Process } from "../../redux/process/processTypes";

interface CreateProcessModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (processData: Process, processGroupId: string, templateId?: string) => void;
}

const CreateProcessModal = ({ isOpen, onClose, onSubmit }: CreateProcessModalProps) => {
  const { processGroup } = useAppSelector((state) => state.processGroup);
  const { domainList } = useAppSelector((state) => state.domain);
  const { schemaList } = useAppSelector((state) => state.schema);
  const { templates } = useAppSelector((state) => state.template);

  const [formData, setFormData] = useState({
    name: "",
    processGroupId: "",
    domainId: "",
    schemas: [] as string[],
    templateId: ""
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!isOpen) {
      setFormData({ name: "", processGroupId: "", domainId: "", schemas: [], templateId: "" });
      setErrors({});
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = "Process name is required";
    if (!formData.processGroupId) newErrors.processGroupId = "Process group is required";
    
    if (!formData.templateId) {
      if (!formData.domainId) newErrors.domainId = "Domain is required when no template selected";
      if (formData.schemas.length === 0) newErrors.schemas = "At least one schema is required when no template selected";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const selectedDomain = domainList.find(d => d.id === formData.domainId);
    const processId = `proc-${Date.now()}`;
    const processKey = formData.name.toUpperCase().replace(/\s+/g, "_");

    const process_context: Record<string, any> = {};
    if (formData.schemas.length > 0) {
      formData.schemas.forEach(schemaId => {
        const schema = schemaList.find(s => s.id === schemaId);
        if (schema) {
          process_context[schema.name] = schema;
        }
      });
    }

    const processData: Process = {
      process_id: processId,
      process_key: processKey,
      name: formData.name,
      version: "1.0.0",
      status: "active",
      domain: selectedDomain ? {
        industry: selectedDomain.industry,
        function: selectedDomain.function,
        subfunction: selectedDomain.subfunction,
        applicability: selectedDomain.applicability
      } : undefined,
      processFlow: { nodes: [] },
      tasks: [],
      entry_points: [],
      exit_points: [],
      ...(Object.keys(process_context).length > 0 && { process_context })
    };

    onSubmit(processData, formData.processGroupId, formData.templateId || undefined);
  };

  const isTemplateSelected = !!formData.templateId;

  if (!isOpen) return null;

  return (
    <>
      <div className="modal fade show d-block" tabIndex={-1} style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
        <div className="modal-dialog modal-dialog-centered modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Create New Process</h5>
              <button type="button" className="btn-close" onClick={onClose}></button>
            </div>
            <div className="modal-body">
              <form onSubmit={handleSubmit} id="createProcessForm">
                <div className="mb-3">
                  <label className="form-label">Process Name <span className="text-danger">*</span></label>
                  <input
                    type="text"
                    className={`form-control ${errors.name ? "is-invalid" : ""}`}
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter process name"
                  />
                  {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                </div>

                <div className="mb-3">
                  <label className="form-label">Process Group <span className="text-danger">*</span></label>
                  <select
                    className={`form-select ${errors.processGroupId ? "is-invalid" : ""}`}
                    value={formData.processGroupId}
                    onChange={(e) => setFormData({ ...formData, processGroupId: e.target.value })}
                  >
                    <option value="">Select Process Group</option>
                    {processGroup.map((pg) => (
                      <option key={pg.process_group_id} value={pg.process_group_id}>
                        {pg.name}
                      </option>
                    ))}
                  </select>
                  {errors.processGroupId && <div className="invalid-feedback">{errors.processGroupId}</div>}
                </div>

                <div className="mb-3">
                  <label className="form-label">Template</label>
                  {templates.length > 0 ? (
                    <div className="template-scroll-container" style={{ 
                      overflowX: "auto", 
                      whiteSpace: "nowrap", 
                      padding: "10px 0",
                      marginTop: "8px"
                    }}>
                      <div className="d-inline-flex gap-3">
                        {templates.map((template) => (
                          <div
                            key={template.template_id}
                            className={`card ${formData.templateId === template.template_id ? "border-primary shadow" : "border"}`}
                            style={{ 
                              minWidth: "200px", 
                              cursor: "pointer",
                              transition: "all 0.2s"
                            }}
                            onClick={() => setFormData({ 
                              ...formData, 
                              templateId: formData.templateId === template.template_id ? "" : template.template_id,
                              schemas: []
                            })}
                          >
                            <div className="card-body">
                              <h6 className="card-title text-truncate">{template.template_id}</h6>
                              <p className="card-text text-muted small mb-1">Version: {template.template_version}</p>
                              <p className="card-text small text-truncate">
                                {template.template?.description || "Template for process creation"}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-muted small">No templates available</p>
                  )}
                </div>

                <div className="mb-3">
                  <label className="form-label">
                    Domain {!isTemplateSelected && <span className="text-danger">*</span>}
                  </label>
                  <select
                    className={`form-select ${errors.domainId ? "is-invalid" : ""}`}
                    value={formData.domainId}
                    onChange={(e) => setFormData({ ...formData, domainId: e.target.value })}
                    disabled={isTemplateSelected}
                  >
                    <option value="">Select Domain</option>
                    {domainList.map((domain) => (
                      <option key={domain.id} value={domain.id}>
                        {domain.industry} - {domain.function} - {domain.subfunction}
                      </option>
                    ))}
                  </select>
                  {errors.domainId && <div className="invalid-feedback">{errors.domainId}</div>}
                </div>

                <div className="mb-3">
                  <label className="form-label">
                    Schemas {!isTemplateSelected && <span className="text-danger">*</span>}
                  </label>
                  <div 
                    className={`border rounded p-2 ${errors.schemas ? "border-danger" : ""}`}
                    style={{ 
                      maxHeight: "150px", 
                      overflowY: "auto",
                      backgroundColor: isTemplateSelected ? "#f8f9fa" : "white"
                    }}
                  >
                    {schemaList.length > 0 ? (
                      schemaList.map((schema) => (
                        <div key={schema.id} className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id={`schema-${schema.id}`}
                            checked={formData.schemas.includes(schema.id)}
                            disabled={isTemplateSelected}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFormData({ ...formData, schemas: [...formData.schemas, schema.id] });
                              } else {
                                setFormData({ ...formData, schemas: formData.schemas.filter(id => id !== schema.id) });
                              }
                            }}
                          />
                          <label className="form-check-label" htmlFor={`schema-${schema.id}`}>
                            {schema.name}
                          </label>
                        </div>
                      ))
                    ) : (
                      <p className="text-muted small mb-0">No schemas available</p>
                    )}
                  </div>
                  {errors.schemas && <div className="text-danger small mt-1">{errors.schemas}</div>}
                </div>
              </form>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>
                Cancel
              </button>
              <button type="submit" form="createProcessForm" className="btn btn-primary">
                Create Process
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CreateProcessModal;
