import type { ReactNode } from 'react';

interface ProcessGroup5Props {
  children?: ReactNode;
}

const ProcessGroup5 = ({ children }: ProcessGroup5Props) => {
  return (
    <div className="p-3">
      <h6 className="mb-3">Right Bottom Section</h6>
      {children}
    </div>
  );
};

export default ProcessGroup5;
