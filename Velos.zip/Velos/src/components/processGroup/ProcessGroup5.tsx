import { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { updateProcess } from '../../redux/process/processActions';
import JsonTreeViewer from './JsonTreeViewer';

const ProcessGroup5 = () => {
  const dispatch = useAppDispatch();
  const selectedProcess = useAppSelector((state) => state.process.selectedProcess);
  const [localData, setLocalData] = useState<any>(null);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState<'tree' | 'raw'>('tree');
  const [rawText, setRawText] = useState('');

  useEffect(() => {
    if (selectedProcess) {
      setLocalData(selectedProcess);
      setRawText(JSON.stringify(selectedProcess, null, 2));
      setError('');
    }
  }, [selectedProcess]);

  const handleTreeChange = (newData: any) => {
    setLocalData(newData);
    setRawText(JSON.stringify(newData, null, 2));
  };

  const handleRawChange = (text: string) => {
    setRawText(text);
    try {
      const parsed = JSON.parse(text);
      setLocalData(parsed);
      setError('');
    } catch {
      setError('Invalid JSON format');
    }
  };

  const handleSave = () => {
    if (!selectedProcess || !localData) return;

    try {
      const dataToSave = viewMode === 'raw' ? JSON.parse(rawText) : localData;
      dispatch(updateProcess(selectedProcess.process_id, dataToSave));
      setError('');
    } catch (err) {
      setError('Invalid JSON format - cannot save');
    }
  };

  if (!selectedProcess) {
    return (
      <div className="p-3">
        <h6 className="mb-3">Process Flow JSON</h6>
        <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
          No process selected
        </div>
      </div>
    );
  }

  return (
    <div className="p-3">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h6 style={{ margin: 0 }}>Process Flow JSON</h6>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <div style={{ display: 'flex', border: '1px solid #ddd', borderRadius: '4px', overflow: 'hidden' }}>
            <button
              onClick={() => setViewMode('tree')}
              style={{
                padding: '4px 12px',
                background: viewMode === 'tree' ? '#e3f2fd' : 'white',
                color: viewMode === 'tree' ? '#1976d2' : '#666',
                border: 'none',
                cursor: 'pointer',
                fontSize: '12px',
                fontWeight: viewMode === 'tree' ? 600 : 400
              }}
            >
              Tree
            </button>
            <button
              onClick={() => setViewMode('raw')}
              style={{
                padding: '4px 12px',
                background: viewMode === 'raw' ? '#e3f2fd' : 'white',
                color: viewMode === 'raw' ? '#1976d2' : '#666',
                border: 'none',
                borderLeft: '1px solid #ddd',
                cursor: 'pointer',
                fontSize: '12px',
                fontWeight: viewMode === 'raw' ? 600 : 400
              }}
            >
              Raw
            </button>
          </div>
          <button
            onClick={handleSave}
            style={{
              padding: '6px 16px',
              background: '#4caf50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            Save
          </button>
        </div>
      </div>
      
      {error && (
        <div style={{ 
          padding: '8px', 
          background: '#ffebee', 
          color: '#c62828', 
          borderRadius: '4px', 
          marginBottom: '10px', 
          fontSize: '12px' 
        }}>
          {error}
        </div>
      )}

      {viewMode === 'tree' && localData && (
        <JsonTreeViewer data={localData} onChange={handleTreeChange} />
      )}

      {viewMode === 'raw' && (
        <textarea
          value={rawText}
          onChange={(e) => handleRawChange(e.target.value)}
          style={{
            width: '100%',
            height: '500px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            padding: '10px',
            fontFamily: 'monospace',
            fontSize: '12px',
            backgroundColor: '#f9f9f9',
            resize: 'vertical'
          }}
        />
      )}
    </div>
  );
};

export default ProcessGroup5;
