import { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { updateNode } from '../../redux/process/processActions';

const ProcessGroup6 = () => {
  const dispatch = useAppDispatch();
  const selectedNode = useAppSelector((state) => state.process.selectedNode);
  const [activeTab, setActiveTab] = useState('properties');
  const [localNode, setLocalNode] = useState<any>(null);

  useEffect(() => {
    if (selectedNode) {
      setLocalNode({ ...selectedNode });
      setActiveTab('properties');
    }
  }, [selectedNode?.id, selectedNode?.node_id]);

  const handleFieldChange = (field: string, value: any) => {
    const updated = { ...localNode, [field]: value };
    setLocalNode(updated);
    dispatch(updateNode(localNode.node_id || localNode.id, { [field]: value }));
  };

  const handleNestedChange = (path: string[], value: any) => {
    const updated = { ...localNode };
    let current = updated;
    for (let i = 0; i < path.length - 1; i++) {
      if (!current[path[i]]) current[path[i]] = {};
      current = current[path[i]];
    }
    current[path[path.length - 1]] = value;
    setLocalNode(updated);
    dispatch(updateNode(localNode.node_id || localNode.id, updated));
  };

  const handleArrayChange = (field: string, index: number, value: string) => {
    const arr = [...(localNode[field] || [])];
    arr[index] = value;
    handleFieldChange(field, arr);
  };

  const handleArrayAdd = (field: string) => {
    const arr = [...(localNode[field] || []), ''];
    handleFieldChange(field, arr);
  };

  const handleArrayRemove = (field: string, index: number) => {
    const arr = [...(localNode[field] || [])];
    arr.splice(index, 1);
    handleFieldChange(field, arr);
  };

  if (!selectedNode || !localNode) {
    return (
      <div className="p-3 h-100 d-flex align-items-center justify-content-center">
        <div className="text-muted text-center">
          <i className="bi bi-info-circle" style={{ fontSize: '48px' }}></i>
          <p className="mt-3">Select a node to view properties</p>
        </div>
      </div>
    );
  }

  const nodeType = (localNode.type || '').toLowerCase();
  const isTask = nodeType.includes('task') || nodeType === 'service_task' || nodeType === 'manual_task';
  const isGateway = nodeType === 'gateway';
  const isEntry = nodeType === 'entry' || nodeType === 'start';
  const isExit = nodeType === 'exit';

  let propertiesLabel = 'Properties';
  if (isTask) propertiesLabel = 'Task Properties';
  else if (isGateway) propertiesLabel = 'Gateway Properties';
  else if (isEntry) propertiesLabel = 'Start Properties';
  else if (isExit) propertiesLabel = 'Exit Properties';

  return (
    <div className="p-1 flex-1" style={{ overflow: 'scroll',height:"100%" }}>
      <div className="card  p-0">
        <div className="card-body">
          <ul className="nav nav-tabs mb-3">
            <li className="nav-item">
              <button
                className={`nav-link ${activeTab === 'properties' ? 'active' : ''}`}
                type="button"
                onClick={() => setActiveTab('properties')}
              >
                {propertiesLabel}
              </button>
            </li>
            {isTask && (
              <li className="nav-item">
                <button
                  className={`nav-link ${activeTab === 'steps' ? 'active' : ''}`}
                  type="button"
                  onClick={() => setActiveTab('steps')}
                >
                  Task Steps
                </button>
              </li>
            )}
          </ul>

          {activeTab === 'properties' && (
            <div>
              <div className="mb-3">
                <label className="form-label">ID</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  value={localNode.node_id || localNode.id || ''}
                  readOnly
                  disabled
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Name</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  value={localNode.name || ''}
                  onChange={(e) => handleFieldChange('name', e.target.value)}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Type</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  value={localNode.type || ''}
                  readOnly
                  disabled
                />
              </div>

              {isTask && (
                <>
                  <div className="mb-3">
                    <label className="form-label">Task Key</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      value={localNode.task_key || ''}
                      onChange={(e) => handleFieldChange('task_key', e.target.value)}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Department</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      value={localNode.department || ''}
                      onChange={(e) => handleFieldChange('department', e.target.value)}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Role</label>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      value={localNode.role || ''}
                      onChange={(e) => handleFieldChange('role', e.target.value)}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Description</label>
                    <textarea
                      className="form-control form-control-sm"
                      rows={3}
                      value={localNode.description || ''}
                      onChange={(e) => handleFieldChange('description', e.target.value)}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Inputs</label>
                    {(localNode.inputs || []).map((input: string, idx: number) => (
                      <div key={idx} className="input-group input-group-sm mb-2">
                        <input
                          type="text"
                          className="form-control"
                          value={input}
                          onChange={(e) => handleArrayChange('inputs', idx, e.target.value)}
                        />
                        <button
                          className="btn btn-outline-danger"
                          onClick={() => handleArrayRemove('inputs', idx)}
                        >
                          ×
                        </button>
                      </div>
                    ))}
                    <button
                      className="btn btn-sm btn-outline-primary"
                      onClick={() => handleArrayAdd('inputs')}
                    >
                      + Add Input
                    </button>
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Outputs</label>
                    {(localNode.outputs || []).map((output: string, idx: number) => (
                      <div key={idx} className="input-group input-group-sm mb-2">
                        <input
                          type="text"
                          className="form-control"
                          value={output}
                          onChange={(e) => handleArrayChange('outputs', idx, e.target.value)}
                        />
                        <button
                          className="btn btn-outline-danger"
                          onClick={() => handleArrayRemove('outputs', idx)}
                        >
                          ×
                        </button>
                      </div>
                    ))}
                    <button
                      className="btn btn-sm btn-outline-primary"
                      onClick={() => handleArrayAdd('outputs')}
                    >
                      + Add Output
                    </button>
                  </div>
                </>
              )}

              {isGateway && (
                <div className="mb-3">
                  <label className="form-label">Gateway Type</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={localNode.gateway_type || ''}
                    onChange={(e) => handleFieldChange('gateway_type', e.target.value)}
                  />
                </div>
              )}
            </div>
          )}

          {activeTab === 'steps' && isTask && (
            <div>
              {localNode.task_steps ? (
                <>
                  <div className="mb-3">
                    <label className="form-label">Execution Mode</label>
                    <select
                      className="form-select form-select-sm"
                      value={localNode.task_steps.executionMode || 'sequential'}
                      onChange={(e) => handleNestedChange(['task_steps', 'executionMode'], e.target.value)}
                    >
                      <option value="sequential">Sequential</option>
                      <option value="parallel">Parallel</option>
                    </select>
                  </div>

                  <div className="mb-3 form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="failOnFirstError"
                      checked={localNode.task_steps.failOnFirstError || false}
                      onChange={(e) => handleNestedChange(['task_steps', 'failOnFirstError'], e.target.checked)}
                    />
                    <label className="form-check-label" htmlFor="failOnFirstError">
                      Fail on First Error
                    </label>
                  </div>

                  {localNode.task_steps.execution_steps && (
                    <div className="accordion" id="executionStepsAccordion">
                      {localNode.task_steps.execution_steps.map((step: any, idx: number) => (
                        <div className="accordion-item" key={idx}>
                          <h2 className="accordion-header">
                            <button
                              className="accordion-button collapsed"
                              type="button"
                              onClick={(e) => {
                                const target = e.currentTarget.nextElementSibling;
                                if (target) {
                                  target.classList.toggle('show');
                                  e.currentTarget.classList.toggle('collapsed');
                                }
                              }}
                            >
                              {step.name || `Step ${idx + 1}`}
                            </button>
                          </h2>
                          <div className="accordion-collapse collapse">
                            <div className="accordion-body">
                              <div className="mb-2">
                                <label className="form-label small">Name</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={step.name || ''}
                                  onChange={(e) => {
                                    const steps = [...localNode.task_steps.execution_steps];
                                    steps[idx] = { ...steps[idx], name: e.target.value };
                                    handleNestedChange(['task_steps', 'execution_steps'], steps);
                                  }}
                                />
                              </div>
                              <div className="mb-2">
                                <label className="form-label small">Type</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={step.type || ''}
                                  readOnly
                                />
                              </div>
                              {step.toolkitName && (
                                <div className="mb-2">
                                  <label className="form-label small">Toolkit Name</label>
                                  <input
                                    type="text"
                                    className="form-control form-control-sm"
                                    value={step.toolkitName}
                                    readOnly
                                  />
                                </div>
                              )}
                              {step.rulesetName && (
                                <div className="mb-2">
                                  <label className="form-label small">Ruleset Name</label>
                                  <input
                                    type="text"
                                    className="form-control form-control-sm"
                                    value={step.rulesetName}
                                    readOnly
                                  />
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-muted">No task steps defined</div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProcessGroup6;
