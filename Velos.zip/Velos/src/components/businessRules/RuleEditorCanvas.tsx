import { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import '@gorules/jdm-editor/dist/style.css';
import { JdmConfigProvider, DecisionGraph } from '@gorules/jdm-editor';
import { updateRule } from '../../store/businessRules/businessRulesActions';
import type { Rule } from '../../store/businessRules/businessRulesTypes';

interface RuleEditorCanvasProps {
  rule: Rule;
}

const RuleEditorCanvas = ({ rule }: RuleEditorCanvasProps) => {
  const dispatch = useDispatch();
  const [graph, setGraph] = useState(rule.value);
  const [key, setKey] = useState(rule.id);

  useEffect(() => {
    setGraph(rule.value);
    setKey(rule.id);
  }, [rule.id]);

  const saveGraph = () => {
    dispatch(updateRule({
      ...rule,
      value: graph
    }));
    alert('Saved!');
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header style={{ padding: 8, borderBottom: '1px solid #eee' }}>
        <button onClick={saveGraph}>Save</button>
      </header>

      <div style={{ flex: 1 }}>
        <JdmConfigProvider>
          <DecisionGraph
            key={key}
            value={graph}
            onChange={(val) => setGraph(val as any)}
            onSimulatorOpen={(opened: any) => console.log('Simulator:', opened)}
            onSimulationRun={async ({ context, decisionGraph }: any) => {
              const res = await fetch('/api/simulate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ context, decisionGraph }),
              });
              return await res.json();
            }}
          />
        </JdmConfigProvider>
      </div>
    </div>
  );
};

export default RuleEditorCanvas;
