import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createRule } from '../../store/businessRules/businessRulesActions';

interface CreateRuleModalProps {
  show: boolean;
  onClose: () => void;
}

const CreateRuleModal = ({ show, onClose }: CreateRuleModalProps) => {
  const dispatch = useDispatch();
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !category.trim()) return;

    dispatch(createRule({
      name: name.trim(),
      category: category.trim(),
      value: { contentType: 'application/vnd.gorules.decision', nodes: [], edges: [] }
    }) as any);

    setName('');
    setCategory('');
    onClose();
  };

  const handleClose = () => {
    setName('');
    setCategory('');
    onClose();
  };

  if (!show) return null;

  return (
    <>
      <div className="modal show d-block" tabIndex={-1}>
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Create Rule</h5>
              <button type="button" className="btn-close" onClick={handleClose}></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="modal-body">
                <div className="mb-3">
                  <label htmlFor="ruleName" className="form-label">Rule Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    id="ruleName"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="ruleCategory" className="form-label">Category *</label>
                  <input
                    type="text"
                    className="form-control"
                    id="ruleCategory"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={handleClose}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="modal-backdrop show"></div>
    </>
  );
};

export default CreateRuleModal;
