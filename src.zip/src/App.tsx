// src/App.tsx
import React from "react";
import RuleEditor from "./RuleEditor";

export default function App() {
  return <RuleEditor />;
}
``