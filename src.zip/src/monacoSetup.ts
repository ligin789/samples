// src/monacoSetup.ts
import type { Monaco } from "@monaco-editor/react";
import { loader } from "@monaco-editor/react";
import * as monaco from "monaco-editor";

import editorWorker from "monaco-editor/esm/vs/editor/editor.worker?worker";
import cssWorker from "monaco-editor/esm/vs/language/css/css.worker?worker";
import htmlWorker from "monaco-editor/esm/vs/language/html/html.worker?worker";
import jsonWorker from "monaco-editor/esm/vs/language/json/json.worker?worker";
import tsWorker from "monaco-editor/esm/vs/language/typescript/ts.worker?worker";

declare global {
  interface Window {
    monaco?: Monaco;
  }
}

(self as any).monaco = monaco;
(self as any).MonacoEnvironment = {
  getWorker(_: string, label: string) {
    if (label === "json") return new (jsonWorker as any)();
    if (label === "css" || label === "scss" || label === "less") return new (cssWorker as any)();
    if (label === "html" || label === "handlebars" || label === "razor") return new (htmlWorker as any)();
    if (label === "typescript" || label === "javascript") return new (tsWorker as any)();
    return new (editorWorker as any)();
  },
};

loader.config({ monaco });
``