
// src/main.tsx or src/index.tsx (depending on your setup)
import React from "react";
import ReactDOM from "react-dom/client";

import "./monacoSetup";

import App from "./App";

// --- ZEN Engine WASM init ---
import * as ZenEngineWasm from "@gorules/zen-engine-wasm";
import wasmUrl from "@gorules/zen-engine-wasm/dist/zen_engine_wasm_bg.wasm?url";

async function bootstrap() {
  // Initialize WASM once
  await ZenEngineWasm.default(wasmUrl);

  const root = ReactDOM.createRoot(document.getElementById("root")!);
  root.render(<App />);
}

bootstrap();
``
