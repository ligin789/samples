// src/RuleEditor.tsx
import React, { useState } from "react";
import "@gorules/jdm-editor/dist/style.css";
import { JdmConfigProvider, DecisionGraph } from "@gorules/jdm-editor";

export default function RuleEditor() {
  const [graph, setGraph] = useState<{ nodes: any[]; edges: any[] }>({
    nodes: [],
    edges: [],
  });

  const saveGraph = async () => {
    await fetch("/api/decision-graphs/123", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(graph),
    });
    alert("Saved!");
  };

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column" }}>
      <header style={{ padding: 8, borderBottom: "1px solid #eee" }}>
        <button onClick={saveGraph}>Save</button>
      </header>

      <div style={{ flex: 1 }}>
        <JdmConfigProvider>
          <DecisionGraph
            value={graph}
            onChange={(val) => setGraph(val as any)}
            // disabled // uncomment for read-only
            onSimulatorOpen={(opened:any) => console.log("Simulator:", opened)}
            onSimulationRun={async ({ context, decisionGraph }:any) => {
              const res = await fetch("/api/simulate", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ context, decisionGraph }),
              });
              return await res.json();
            }}
          />
        </JdmConfigProvider>
      </div>
    </div>
  );
}
``