import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { Provider } from 'react-redux';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppNavigator } from './src/navigation/AppNavigator';
import { fetchDashboardData } from './src/redux/dashboard/actions';
import { store, useAppDispatch } from './src/redux/store';

const Bootstrap: React.FC = () => {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(fetchDashboardData());
  }, [dispatch]);
  return <AppNavigator />;
};

const App: React.FC = () => (
  <Provider store={store}>
    <SafeAreaProvider>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <Bootstrap />
    </SafeAreaProvider>
  </Provider>
);

export default App;
