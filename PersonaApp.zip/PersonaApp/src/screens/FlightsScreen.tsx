import React, { useEffect, useRef, useState } from 'react';
import {
  Animated,
  Easing,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Svg, {
  Circle,
  Defs,
  G,
  Line,
  Pattern,
  Path,
  RadialGradient,
  Rect,
  Stop,
  Text as SvgText,
} from 'react-native-svg';
import { FilterChip } from '../components';
import { FLIGHTS, Flight, VERTIPORTS } from '../data/mockData';
import { colors, fontFamilies, radius, spacing } from '../theme';
import { useViewport } from '../utils/responsive';

const STATUS_STYLES: Record<Flight['status'], { bg: string; color: string; dot: string }> = {
  'In Flight': { bg: '#EFF6FF', color: '#2563EB', dot: '#3B82F6' },
  Boarding: { bg: '#FDF4FF', color: '#9333EA', dot: '#A855F7' },
  Scheduled: { bg: '#F8FAFC', color: '#64748B', dot: '#94A3B8' },
  Landed: { bg: '#ECFDF5', color: '#059669', dot: '#10B981' },
  Cancelled: { bg: '#FEF2F2', color: '#DC2626', dot: '#EF4444' },
};

const FILTERS: Array<'All' | Flight['status']> = [
  'All', 'In Flight', 'Boarding', 'Scheduled', 'Landed', 'Cancelled',
];

const ROUTES: Array<[string, string]> = [
  ['VPA', 'VPB'], ['VPA', 'VPC'], ['VPA', 'VPE'],
  ['VPB', 'VPD'], ['VPB', 'VPE'], ['VPD', 'VPE'], ['VPC', 'VPD'],
];

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

type ProgressMap = Record<string, number>;

const useAnimatedProgress = (flights: Flight[]): ProgressMap => {
  const [progMap, setProgMap] = useState<ProgressMap>(() =>
    Object.fromEntries(flights.map(f => [f.id, f.progress])),
  );
  useEffect(() => {
    const id = setInterval(() => {
      setProgMap(prev => {
        const next = { ...prev };
        flights
          .filter(f => f.status === 'In Flight')
          .forEach(f => {
            next[f.id] = Math.min(1, (next[f.id] ?? f.progress) + 0.008);
          });
        return next;
      });
    }, 120);
    return () => clearInterval(id);
  }, [flights]);
  return progMap;
};

interface StaticMapProps {
  flights: Flight[];
  selected: string;
  onSelect: (id: string) => void;
}

const StaticMap: React.FC<StaticMapProps> = ({ flights, selected, onSelect }) => {
  const progMap = useAnimatedProgress(flights);
  const airborne = flights.filter(f => f.status === 'In Flight').length;

  return (
    <View style={mapStyles.container}>
      <Svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
        <Defs>
          <RadialGradient id="skyGrad" cx="50%" cy="50%" r="70%">
            <Stop offset="0%" stopColor={colors.mapBgStart} />
            <Stop offset="100%" stopColor={colors.mapBgEnd} />
          </RadialGradient>
          <Pattern id="grid" width="5" height="5" patternUnits="userSpaceOnUse">
            <Path d="M 5 0 L 0 0 0 5" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="0.3" />
          </Pattern>
        </Defs>

        <Rect width="100" height="100" fill="url(#skyGrad)" />
        <Rect width="100" height="100" fill="url(#grid)" />

        {Object.values(VERTIPORTS).map(vp => (
          <Circle key={`glow-${vp.code}`} cx={vp.x} cy={vp.y} r={12} fill="rgba(59,130,246,0.07)" />
        ))}

        {ROUTES.map(([a, b], i) => {
          const pa = VERTIPORTS[a];
          const pb = VERTIPORTS[b];
          return (
            <Line
              key={`route-${i}`}
              x1={pa.x}
              y1={pa.y}
              x2={pb.x}
              y2={pb.y}
              stroke="rgba(255,255,255,0.05)"
              strokeWidth={0.5}
              strokeDasharray="1,2"
            />
          );
        })}

        {flights
          .filter(f => f.status === 'In Flight' || f.status === 'Boarding')
          .map(f => {
            const from = VERTIPORTS[f.from];
            const to = VERTIPORTS[f.to];
            const dotColor = STATUS_STYLES[f.status].dot;
            return (
              <Line
                key={`path-${f.id}`}
                x1={from.x}
                y1={from.y}
                x2={to.x}
                y2={to.y}
                stroke={dotColor}
                strokeWidth={0.6}
                strokeDasharray="2,2"
                opacity={0.5}
              />
            );
          })}

        {Object.values(VERTIPORTS).map(vp => (
          <G key={`vp-${vp.code}`}>
            <Circle cx={vp.x} cy={vp.y} r={5} fill="#1E3A5F" stroke="rgba(255,255,255,0.2)" strokeWidth={0.4} />
            <Circle cx={vp.x} cy={vp.y} r={2.5} fill="rgba(59,130,246,0.6)" />
            <SvgText
              x={vp.x}
              y={vp.y - 6.5}
              textAnchor="middle"
              fontSize={2.8}
              fontWeight="700"
              fill="white"
              opacity={0.9}
            >
              {vp.code}
            </SvgText>
            <SvgText
              x={vp.x}
              y={vp.y + 9}
              textAnchor="middle"
              fontSize={2.2}
              fill="rgba(255,255,255,0.45)"
            >
              {vp.city}
            </SvgText>
          </G>
        ))}

        {flights.map(f => {
          if (f.status !== 'In Flight' && f.status !== 'Boarding') return null;
          const from = VERTIPORTS[f.from];
          const to = VERTIPORTS[f.to];
          const t = progMap[f.id] ?? 0;
          const cx = lerp(from.x, to.x, t);
          const cy = lerp(from.y, to.y, t);
          const isSelected = selected === f.id;
          const dotColor = STATUS_STYLES[f.status].dot;
          const dx = to.x - from.x;
          const dy = to.y - from.y;
          const angle = (Math.atan2(dy, dx) * 180) / Math.PI + 90;
          return (
            <G key={`ac-${f.id}`} onPress={() => onSelect(f.id)}>
              <Circle
                cx={cx}
                cy={cy}
                r={isSelected ? 3.5 : 2.8}
                fill={dotColor}
                stroke={isSelected ? '#fff' : 'rgba(255,255,255,0.4)'}
                strokeWidth={isSelected ? 0.8 : 0.5}
              />
              <SvgText
                x={cx}
                y={cy + 1}
                textAnchor="middle"
                fontSize={3}
                fill="white"
                transform={`rotate(${angle}, ${cx}, ${cy})`}
              >
                ✈
              </SvgText>
              {isSelected && (
                <SvgText
                  x={cx}
                  y={cy - 5}
                  textAnchor="middle"
                  fontSize={2.4}
                  fill="white"
                  fontWeight="700"
                >
                  {f.id}
                </SvgText>
              )}
            </G>
          );
        })}
      </Svg>

      <View style={mapStyles.legend}>
        <Text style={mapStyles.legendTitle}>LEGEND</Text>
        {(['In Flight', 'Boarding', 'Scheduled', 'Landed'] as const).map(s => (
          <View key={s} style={mapStyles.legendRow}>
            <View style={[mapStyles.legendDot, { backgroundColor: STATUS_STYLES[s].dot }]} />
            <Text style={mapStyles.legendLabel}>{s}</Text>
          </View>
        ))}
      </View>

      <View style={mapStyles.airborneBadge}>
        <View style={mapStyles.airborneDot} />
        <Text style={mapStyles.airborneText}>{airborne} airborne</Text>
      </View>

      <View style={mapStyles.vertiportLegend}>
        {Object.values(VERTIPORTS).map(vp => (
          <View key={vp.code} style={mapStyles.vpChip}>
            <View style={mapStyles.vpChipDot} />
            <Text style={mapStyles.vpChipCode}>{vp.code}</Text>
            <Text style={mapStyles.vpChipCity}>{vp.city}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

interface FlightRowProps {
  flight: Flight;
  active: boolean;
  onPress: () => void;
}

const FlightRow: React.FC<FlightRowProps> = ({ flight, active, onPress }) => {
  const sc = STATUS_STYLES[flight.status];
  const from = VERTIPORTS[flight.from];
  const to = VERTIPORTS[flight.to];
  return (
    <Pressable
      onPress={onPress}
      style={[
        rowStyles.row,
        {
          backgroundColor: active ? '#EFF6FF' : 'transparent',
          borderLeftColor: active ? colors.infoDeep : 'transparent',
        },
      ]}
    >
      <View style={rowStyles.headerRow}>
        <View style={rowStyles.idRow}>
          <Text style={rowStyles.idText}>{flight.id}</Text>
          <View style={[rowStyles.statusPill, { backgroundColor: sc.bg }]}>
            <View style={[rowStyles.statusDot, { backgroundColor: sc.dot }]} />
            <Text style={[rowStyles.statusText, { color: sc.color }]}>{flight.status}</Text>
          </View>
        </View>
        <Text style={rowStyles.timeText}>{flight.dep}</Text>
      </View>

      <View style={rowStyles.routeRow}>
        <View style={rowStyles.endpoint}>
          <Text style={rowStyles.endpointCode}>{flight.from}</Text>
          <Text style={rowStyles.endpointCity}>{from?.city}</Text>
        </View>
        <View style={rowStyles.middle}>
          <View style={rowStyles.middleLineWrap}>
            <View style={rowStyles.line} />
            <Text style={rowStyles.planeIcon}>✈</Text>
            <View style={rowStyles.line} />
          </View>
          <Text style={rowStyles.modelText}>{flight.model}</Text>
        </View>
        <View style={rowStyles.endpoint}>
          <Text style={rowStyles.endpointCode}>{flight.to}</Text>
          <Text style={rowStyles.endpointCity}>{to?.city}</Text>
        </View>
      </View>

      <Text style={rowStyles.meta}>
        {flight.aircraft} · {flight.pax} pax · {flight.pilot}
      </Text>

      {flight.status === 'In Flight' && (
        <View style={rowStyles.progressTrack}>
          <View style={[rowStyles.progressFill, { width: `${flight.progress * 100}%` }]} />
        </View>
      )}
    </Pressable>
  );
};

const FlightDetail: React.FC<{ flight?: Flight }> = ({ flight }) => {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (flight?.status === 'In Flight') {
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
          Animated.timing(pulse, { toValue: 0, duration: 900, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        ]),
      );
      loop.start();
      return () => loop.stop();
    }
  }, [flight?.status, pulse]);

  if (!flight) return null;
  const sc = STATUS_STYLES[flight.status];
  const pulseOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 0.3] });

  const items: Array<[string, string]> = [
    ['Aircraft', flight.aircraft],
    ['Model', flight.model],
    ['Pilot', flight.pilot],
    ['Passengers', `${flight.pax} pax`],
    ['Route', `${flight.from}→${flight.to}`],
  ];

  return (
    <View style={detailStyles.container}>
      <View style={detailStyles.headerRow}>
        <View style={detailStyles.idRow}>
          <Text style={detailStyles.idText}>{flight.id}</Text>
          <View style={[detailStyles.pill, { backgroundColor: sc.bg }]}>
            <Animated.View
              style={[
                detailStyles.pillDot,
                { backgroundColor: sc.dot },
                flight.status === 'In Flight' ? { opacity: pulseOpacity } : null,
              ]}
            />
            <Text style={[detailStyles.pillText, { color: sc.color }]}>{flight.status}</Text>
          </View>
        </View>
        <View style={detailStyles.timeRow}>
          <Text style={detailStyles.timeLabel}>
            <Text style={detailStyles.timeValue}>{flight.dep}</Text> dep
          </Text>
          <Text style={detailStyles.timeArrow}>→</Text>
          <Text style={detailStyles.timeLabel}>
            <Text style={detailStyles.timeValue}>{flight.arr}</Text> arr
          </Text>
        </View>
      </View>

      <View style={detailStyles.grid}>
        {items.map(([label, value]) => (
          <View key={label} style={detailStyles.cell}>
            <Text style={detailStyles.cellLabel}>{label}</Text>
            <Text style={detailStyles.cellValue}>{value}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

export const FlightsScreen: React.FC = () => {
  const { isMobile } = useViewport();
  const [selected, setSelected] = useState<string>('GH-101');
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>('All');
  const [showMap, setShowMap] = useState<boolean>(true);

  const counts = FILTERS.reduce<Record<string, number>>((acc, f) => {
    acc[f] = f === 'All' ? FLIGHTS.length : FLIGHTS.filter(fl => fl.status === f).length;
    return acc;
  }, {});
  const filtered = filter === 'All' ? FLIGHTS : FLIGHTS.filter(f => f.status === filter);
  const selectedFlight = FLIGHTS.find(f => f.id === selected);
  const inFlight = FLIGHTS.filter(f => f.status === 'In Flight').length;

  if (isMobile) {
    return (
      <View style={styles.mobileRoot}>
        {showMap ? (
          <View style={styles.mobileMapWrap}>
            <StaticMap flights={FLIGHTS} selected={selected} onSelect={setSelected} />
            <Pressable style={styles.mapToggleBtn} onPress={() => setShowMap(false)}>
              <Text style={styles.mapToggleText}>Hide Map ↑</Text>
            </Pressable>
          </View>
        ) : (
          <Pressable style={styles.showMapBtn} onPress={() => setShowMap(true)}>
            <Text style={styles.showMapText}>🗺  Show Live Map</Text>
          </Pressable>
        )}

        <View style={styles.mobileFilters}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
            {FILTERS.filter(f => counts[f] > 0 || f === 'All').map(f => (
              <FilterChip
                key={f}
                label={f}
                active={filter === f}
                onPress={() => setFilter(f)}
                activeColor={f === 'All' ? colors.infoDeep : STATUS_STYLES[f as Flight['status']].dot}
              />
            ))}
          </ScrollView>
        </View>

        <View style={styles.mobileList}>
          <ScrollView>
            {filtered.map(f => (
              <FlightRow
                key={f.id}
                flight={f}
                active={selected === f.id}
                onPress={() => setSelected(f.id)}
              />
            ))}
          </ScrollView>
        </View>

        {selectedFlight && <FlightDetail flight={selectedFlight} />}
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <View style={styles.mainRow}>
        <View style={styles.listPane}>
          <View style={styles.listHeader}>
            <View style={styles.listHeaderRow}>
              <Text style={styles.listHeaderTitle}>Flights</Text>
              <View style={styles.liveRow}>
                <View style={styles.liveDot} />
                <Text style={styles.liveText}>{inFlight} in flight</Text>
              </View>
            </View>
            <Text style={styles.listHeaderSub}>VTOL-PORT ALPHA · Today</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
              {FILTERS.filter(f => counts[f] > 0 || f === 'All').map(f => (
                <FilterChip
                  key={f}
                  label={`${f} (${counts[f]})`}
                  active={filter === f}
                  onPress={() => setFilter(f)}
                  activeColor={f === 'All' ? colors.infoDeep : STATUS_STYLES[f as Flight['status']].dot}
                />
              ))}
            </ScrollView>
          </View>
          <ScrollView style={styles.listScroll}>
            {filtered.map(f => (
              <FlightRow
                key={f.id}
                flight={f}
                active={selected === f.id}
                onPress={() => setSelected(f.id)}
              />
            ))}
          </ScrollView>
        </View>

        <View style={styles.mapPane}>
          <StaticMap flights={FLIGHTS} selected={selected} onSelect={setSelected} />
        </View>
      </View>

      {selectedFlight && <FlightDetail flight={selectedFlight} />}
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.heroStart },
  mainRow: { flex: 1, flexDirection: 'row' },
  listPane: {
    width: 320,
    backgroundColor: colors.surface,
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  listHeader: {
    paddingHorizontal: spacing.xxl,
    paddingTop: spacing.xl,
    paddingBottom: spacing.base,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderSoft,
  },
  listHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  listHeaderTitle: {
    fontFamily: fontFamilies.sans,
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
  },
  liveRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  liveDot: {
    width: 7,
    height: 7,
    borderRadius: 999,
    backgroundColor: colors.success,
  },
  liveText: { fontSize: 12, color: colors.successDeep, fontWeight: '600' },
  listHeaderSub: {
    fontSize: 12,
    color: colors.textFaint,
    marginTop: 2,
    marginBottom: spacing.base,
  },
  listScroll: { flex: 1 },
  mapPane: { flex: 1, position: 'relative' },

  mobileRoot: { flex: 1, backgroundColor: colors.bg },
  mobileMapWrap: { height: 220, position: 'relative' },
  mapToggleBtn: {
    position: 'absolute',
    bottom: 10,
    alignSelf: 'center',
    backgroundColor: 'rgba(255,255,255,0.92)',
    borderRadius: radius.pill,
    paddingHorizontal: spacing.xxl,
    paddingVertical: spacing.sm,
  },
  mapToggleText: { fontSize: 12, fontWeight: '600', color: colors.text },
  showMapBtn: {
    marginHorizontal: spacing.xxl,
    marginTop: spacing.base,
    marginBottom: 4,
    backgroundColor: colors.surface,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.lg,
    paddingVertical: spacing.base,
    alignItems: 'center',
  },
  showMapText: { fontSize: 13, color: colors.textMuted, fontWeight: '500' },
  mobileFilters: { paddingHorizontal: spacing.xxl, paddingTop: spacing.base, paddingBottom: spacing.sm },
  filterRow: { gap: 6, paddingBottom: 2 },
  mobileList: {
    flex: 1,
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    marginTop: 4,
    overflow: 'hidden',
  },
});

const mapStyles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    position: 'relative',
    overflow: 'hidden',
    backgroundColor: colors.mapBgEnd,
  },
  legend: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: 'rgba(6,13,26,0.88)',
    borderRadius: radius.lg,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  legendTitle: {
    fontSize: 9,
    fontWeight: '700',
    color: 'rgba(255,255,255,0.4)',
    letterSpacing: 1,
    marginBottom: 7,
  },
  legendRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  legendDot: { width: 7, height: 7, borderRadius: 999 },
  legendLabel: { fontSize: 10, color: 'rgba(255,255,255,0.65)', fontWeight: '500' },
  airborneBadge: {
    position: 'absolute',
    top: 12,
    left: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    backgroundColor: 'rgba(37,99,235,0.9)',
    borderRadius: 9,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderWidth: 1,
    borderColor: 'rgba(96,165,250,0.3)',
  },
  airborneDot: { width: 7, height: 7, borderRadius: 999, backgroundColor: '#93C5FD' },
  airborneText: { fontSize: 12, fontWeight: '700', color: '#fff' },
  vertiportLegend: {
    position: 'absolute',
    bottom: 12,
    left: 12,
    right: 12,
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  vpChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(6,13,26,0.8)',
    borderRadius: radius.sm,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.07)',
  },
  vpChipDot: { width: 6, height: 6, borderRadius: 999, backgroundColor: colors.info },
  vpChipCode: { fontSize: 10, color: 'rgba(255,255,255,0.7)', fontFamily: fontFamilies.mono, fontWeight: '600' },
  vpChipCity: { fontSize: 10, color: 'rgba(255,255,255,0.4)' },
});

const rowStyles = StyleSheet.create({
  row: {
    paddingVertical: 13,
    paddingHorizontal: spacing.xxl,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
    borderLeftWidth: 3,
  },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  idRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  idText: { fontSize: 13, fontWeight: '700', color: colors.text, fontFamily: fontFamilies.mono },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 2,
    borderRadius: radius.pill,
  },
  statusDot: { width: 6, height: 6, borderRadius: 999 },
  statusText: { fontSize: 11, fontWeight: '600' },
  timeText: { fontSize: 11, color: colors.textFaint, fontFamily: fontFamilies.mono },
  routeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: 4 },
  endpoint: { alignItems: 'center' },
  endpointCode: { fontSize: 15, fontWeight: '800', color: colors.text, fontFamily: fontFamilies.mono },
  endpointCity: { fontSize: 10, color: colors.textFaint },
  middle: { flex: 1, alignItems: 'center', gap: 2 },
  middleLineWrap: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'stretch' },
  line: { flex: 1, height: 1.5, backgroundColor: colors.border, borderRadius: 1 },
  planeIcon: { fontSize: 12 },
  modelText: { fontSize: 10, color: colors.textFaint },
  meta: { fontSize: 11, color: colors.textFaint },
  progressTrack: {
    marginTop: 7,
    height: 3,
    borderRadius: 2,
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  progressFill: { height: '100%', backgroundColor: colors.infoDeep, borderRadius: 2 },
});

const detailStyles = StyleSheet.create({
  container: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(255,255,255,0.98)',
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  idRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  idText: { fontSize: 15, fontWeight: '700', color: colors.text, fontFamily: fontFamilies.mono },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: radius.pill,
  },
  pillDot: { width: 7, height: 7, borderRadius: 999 },
  pillText: { fontSize: 12, fontWeight: '600' },
  timeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xl },
  timeLabel: { fontSize: 12, color: colors.textSubtle },
  timeValue: { color: colors.text, fontWeight: '700', fontFamily: fontFamilies.mono },
  timeArrow: { fontSize: 12, color: colors.textSubtle },
  grid: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  cell: {
    flex: 1,
    minWidth: 110,
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.md,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  cellLabel: {
    fontSize: 10,
    color: colors.textFaint,
    fontWeight: '600',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  cellValue: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.text,
    fontFamily: fontFamilies.mono,
  },
});
