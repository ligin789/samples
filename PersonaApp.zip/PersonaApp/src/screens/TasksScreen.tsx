import React, { useMemo, useState } from 'react';
import {
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {
  BottomSheet,
  Button,
  FilterChip,
  Icon,
  PriorityBadge,
  SearchBar,
  StatusBadge,
} from '../components';
import { Task } from '../data/mockData';
import { useAppDispatch, useAppSelector } from '../redux/store';
import {
  toggleChecklistItem,
  updateTaskStatus,
} from '../redux/dashboard/slice';
import { colors, fontFamilies } from '../theme';
import { useViewport } from '../utils/responsive';

type TaskFilter = 'All' | Task['status'];
const FILTERS: TaskFilter[] = ['All', 'Pending', 'In Progress', 'Completed', 'Delayed'];
const FLOW: Partial<Record<Task['status'], Task['status']>> = {
  Pending: 'In Progress',
  'In Progress': 'Completed',
};

interface TaskRowProps {
  task: Task;
  active: boolean;
  onPress: () => void;
}

const TaskRow: React.FC<TaskRowProps> = ({ task, active, onPress }) => {
  const doneCount = task.checklist.filter(c => c.done).length;
  const pct = task.checklist.length
    ? Math.round((doneCount / task.checklist.length) * 100)
    : 0;
  return (
    <Pressable
      style={[
        styles.listRow,
        active && styles.listRowActive,
      ]}
      onPress={onPress}
    >
      <View style={styles.listRowHeader}>
        <Text style={styles.listTitle}>{task.type}</Text>
        <StatusBadge value={task.status} />
      </View>
      <Text style={styles.listMeta}>
        {task.id} · {task.aircraft}
      </Text>
      {task.checklist.length > 0 && (
        <View style={styles.progressRow}>
          <View style={styles.progressBar}>
            <View
              style={[styles.progressFill, { width: `${pct}%` }]}
            />
          </View>
          <Text style={styles.progressText}>
            {doneCount}/{task.checklist.length}
          </Text>
          <PriorityBadge value={task.priority} />
        </View>
      )}
    </Pressable>
  );
};

const TaskDetail: React.FC<{ task: Task }> = ({ task }) => {
  const dispatch = useAppDispatch();
  const doneCount = task.checklist.filter(c => c.done).length;
  const pct = task.checklist.length
    ? Math.round((doneCount / task.checklist.length) * 100)
    : 0;
  const nextStatus = FLOW[task.status];

  const fields: Array<[string, string, boolean?]> = [
    ['Aircraft', task.aircraft, true],
    ['Staff', task.staff],
    ['Gate', task.gate, true],
    ['Start', task.time, true],
    ['End', task.endTime, true],
  ];

  return (
    <View style={styles.detailRoot}>
      <View style={styles.detailHeader}>
        <Text style={styles.detailId}>{task.id}</Text>
        <Text style={styles.detailTitle}>{task.type}</Text>
        <View style={styles.detailBadges}>
          <StatusBadge value={task.status} />
          <PriorityBadge value={task.priority} />
        </View>
      </View>

      <ScrollView style={styles.detailBody} showsVerticalScrollIndicator={false}>
        {fields.map(([label, value, mono]) => (
          <View key={label} style={styles.detailField}>
            <Text style={styles.detailLabel}>{label}</Text>
            <Text
              style={[
                styles.detailValue,
                mono && { fontFamily: fontFamilies.mono },
              ]}
            >
              {value}
            </Text>
          </View>
        ))}

        {task.notes ? (
          <View style={styles.notesBlock}>
            <Text style={styles.detailLabelCaps}>NOTES</Text>
            <View style={styles.notesBox}>
              <Text style={styles.notesText}>{task.notes}</Text>
            </View>
          </View>
        ) : null}

        {task.checklist.length > 0 && (
          <View style={styles.checklistBlock}>
            <View style={styles.checklistHeader}>
              <Text style={styles.checklistTitle}>Checklist</Text>
              <View style={styles.checklistProgress}>
                <View style={styles.checklistBar}>
                  <View
                    style={[
                      styles.checklistFill,
                      { width: `${pct}%` },
                    ]}
                  />
                </View>
                <Text style={styles.checklistCount}>
                  {doneCount}/{task.checklist.length}
                </Text>
              </View>
            </View>
            {task.checklist.map(item => (
              <Pressable
                key={item.id}
                style={styles.checklistItem}
                onPress={() =>
                  dispatch(
                    toggleChecklistItem({ taskId: task.id, itemId: item.id }),
                  )
                }
              >
                <View
                  style={[
                    styles.checkBox,
                    item.done && {
                      backgroundColor: colors.accent,
                      borderColor: colors.accent,
                    },
                  ]}
                >
                  {item.done && (
                    <Icon name="check" size={11} color="#fff" />
                  )}
                </View>
                <Text
                  style={[
                    styles.checklistLabel,
                    item.done && styles.checklistLabelDone,
                  ]}
                >
                  {item.label}
                </Text>
              </Pressable>
            ))}
          </View>
        )}
      </ScrollView>

      <View style={styles.actionBar}>
        {nextStatus && (
          <Button
            label={task.status === 'Pending' ? '▶ Start Task' : '✓ Complete'}
            variant="primary"
            size="lg"
            onPress={() =>
              dispatch(
                updateTaskStatus({ taskId: task.id, status: nextStatus }),
              )
            }
          />
        )}
        {task.status === 'In Progress' && (
          <Button
            label="⏸ Pause"
            variant="secondary"
            size="lg"
            onPress={() =>
              dispatch(updateTaskStatus({ taskId: task.id, status: 'Pending' }))
            }
          />
        )}
        <Button label="⚑ Issue" variant="danger" size="sm" />
      </View>
    </View>
  );
};

export const TasksScreen: React.FC = () => {
  const { isMobile } = useViewport();
  const tasks = useAppSelector(s => s.dashboard.data?.tasks ?? []);
  const [filter, setFilter] = useState<TaskFilter>('All');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(tasks[0]?.id ?? null);
  const [detailVisible, setDetailVisible] = useState(false);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return tasks.filter(t => {
      const passF = filter === 'All' || t.status === filter;
      const passS =
        !q ||
        t.id.toLowerCase().includes(q) ||
        t.type.toLowerCase().includes(q) ||
        t.aircraft.toLowerCase().includes(q);
      return passF && passS;
    });
  }, [tasks, filter, search]);

  const selected = tasks.find(t => t.id === selectedId) ?? null;

  const toolbar = (
    <View style={styles.toolbar}>
      <View style={styles.searchRow}>
        <SearchBar
          value={search}
          onChange={setSearch}
          placeholder="Search tasks…"
        />
        <Pressable style={styles.addBtn}>
          <Icon name="plus" size={18} color="#fff" />
        </Pressable>
      </View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.chipRow}
      >
        {FILTERS.map(f => (
          <FilterChip
            key={f}
            label={f}
            active={filter === f}
            onPress={() => setFilter(f as TaskFilter)}
          />
        ))}
      </ScrollView>
    </View>
  );

  if (isMobile) {
    return (
      <View style={styles.root}>
        {toolbar}
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          style={styles.mobileList}
          renderItem={({ item }) => (
            <TaskRow
              task={item}
              active={false}
              onPress={() => {
                setSelectedId(item.id);
                setDetailVisible(true);
              }}
            />
          )}
        />
        <BottomSheet
          visible={detailVisible && !!selected}
          title={selected?.type ?? ''}
          onClose={() => setDetailVisible(false)}
          tall
        >
          {selected && <TaskDetail task={selected} />}
        </BottomSheet>
      </View>
    );
  }

  return (
    <View style={styles.rootRow}>
      <View style={styles.listPane}>
        {toolbar}
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <TaskRow
              task={item}
              active={selectedId === item.id}
              onPress={() => setSelectedId(item.id)}
            />
          )}
        />
      </View>
      <View style={styles.detailPane}>
        {selected ? (
          <TaskDetail task={selected} />
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📋</Text>
            <Text style={styles.emptyTitle}>Select a task</Text>
            <Text style={styles.emptyDesc}>
              Tap any task to view details and checklist
            </Text>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  rootRow: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: colors.bg,
  },
  listPane: {
    width: 340,
    backgroundColor: '#fff',
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  detailPane: {
    flex: 1,
  },
  mobileList: {
    flex: 1,
    backgroundColor: '#fff',
  },
  toolbar: {
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderSoft,
    backgroundColor: '#fff',
  },
  searchRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 10,
  },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chipRow: {
    paddingRight: 12,
  },
  listRow: {
    paddingHorizontal: 16,
    paddingVertical: 13,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
    borderLeftWidth: 3,
    borderLeftColor: 'transparent',
  },
  listRowActive: {
    backgroundColor: '#F0FDF4',
    borderLeftColor: colors.accent,
  },
  listRowHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  listTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
    flex: 1,
    marginRight: 8,
  },
  listMeta: {
    fontSize: 12,
    color: colors.textFaint,
    fontFamily: fontFamilies.mono,
    marginBottom: 6,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  progressBar: {
    flex: 1,
    height: 3,
    borderRadius: 2,
    backgroundColor: colors.borderSoft,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.accent,
  },
  progressText: {
    fontSize: 11,
    color: colors.textFaint,
  },
  detailRoot: {
    flex: 1,
    backgroundColor: '#fff',
  },
  detailHeader: {
    padding: 22,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderSoft,
  },
  detailId: {
    fontSize: 11,
    color: colors.textFaint,
    fontFamily: fontFamilies.mono,
    marginBottom: 3,
  },
  detailTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 10,
  },
  detailBadges: {
    flexDirection: 'row',
    gap: 8,
  },
  detailBody: {
    flex: 1,
  },
  detailField: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 22,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  detailLabel: {
    fontSize: 12,
    color: colors.textFaint,
    fontWeight: '600',
  },
  detailValue: {
    fontSize: 13,
    color: colors.text,
    fontWeight: '500',
  },
  detailLabelCaps: {
    fontSize: 11,
    color: colors.textFaint,
    fontWeight: '600',
    letterSpacing: 0.6,
    marginBottom: 6,
  },
  notesBlock: {
    paddingHorizontal: 22,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  notesBox: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  notesText: {
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 20,
  },
  checklistBlock: {
    padding: 22,
  },
  checklistHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  checklistTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
  },
  checklistProgress: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  checklistBar: {
    width: 60,
    height: 5,
    borderRadius: 3,
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  checklistFill: {
    height: '100%',
    backgroundColor: colors.accent,
    borderRadius: 3,
  },
  checklistCount: {
    fontSize: 12,
    color: colors.accent,
    fontWeight: '700',
  },
  checklistItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 9,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  checkBox: {
    width: 20,
    height: 20,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#CBD5E1',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checklistLabel: {
    flex: 1,
    fontSize: 13,
    color: colors.text,
  },
  checklistLabelDone: {
    color: colors.textFaint,
    textDecorationLine: 'line-through',
  },
  actionBar: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    paddingHorizontal: 22,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: colors.borderSoft,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyEmoji: {
    fontSize: 40,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.textSubtle,
    marginBottom: 4,
  },
  emptyDesc: {
    fontSize: 13,
    color: colors.textFaint,
    textAlign: 'center',
  },
});
