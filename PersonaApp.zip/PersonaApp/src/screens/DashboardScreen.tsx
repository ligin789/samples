import React from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { useAppSelector } from '../redux/store';
import { colors, fontFamilies } from '../theme';
import { Avatar, Button, Loader, StatusBadge } from '../components';
import { Icon, IconName } from '../components/Icon';
import { getStatusColor } from '../utils/statusColors';
import { useViewport } from '../utils/responsive';

const batteryColor = (battery: number) =>
  battery > 60 ? colors.success : battery > 25 ? colors.warn : colors.danger;

const TIMELINE = [
  { time: '07:00', label: 'EVT-003 Arrived', gate: 'G-04', color: '#10B981' },
  { time: '08:00', label: 'Safety Check — EVT-004', gate: 'G-06', color: '#F59E0B' },
  { time: '08:15', label: 'INC-001 Reported', gate: 'MRO-1', color: '#EF4444' },
  { time: '09:30', label: 'EVT-005 Departure', gate: 'G-03', color: '#059669' },
  { time: '10:30', label: 'EVT-001 Departure', gate: 'G-01', color: '#059669' },
];

const ProgressRing: React.FC<{ pct: number }> = ({ pct }) => {
  const r = 32;
  const c = 2 * Math.PI * r;
  const dash = (c * pct) / 100;
  return (
    <View style={styles.ringWrap}>
      <Svg width={80} height={80}>
        <Circle
          cx={40}
          cy={40}
          r={r}
          stroke="rgba(255,255,255,0.1)"
          strokeWidth={7}
          fill="none"
        />
        <Circle
          cx={40}
          cy={40}
          r={r}
          stroke={colors.success}
          strokeWidth={7}
          fill="none"
          strokeDasharray={`${dash} ${c}`}
          strokeLinecap="round"
          transform="rotate(-90 40 40)"
        />
      </Svg>
      <View style={styles.ringLabel}>
        <Text style={styles.ringPct}>{pct}%</Text>
        <Text style={styles.ringCaption}>done</Text>
      </View>
    </View>
  );
};

const taskIconFor = (type: string): IconName => {
  if (type === 'Battery Charging') return 'aircraft';
  if (type === 'Safety Inspection') return 'incidents';
  return 'tasks';
};

export const DashboardScreen: React.FC = () => {
  const { isMobile } = useViewport();
  const { data, loading } = useAppSelector(s => s.dashboard);

  if (loading || !data) {
    return <Loader message="Loading dashboard…" />;
  }

  const { tasks, aircraft, shifts, incidents } = data;
  const activeTasks = tasks.filter(t => t.status === 'In Progress').length;
  const completed = tasks.filter(t => t.status === 'Completed').length;
  const pending = tasks.filter(t => t.status === 'Pending').length;
  const activeStaff = shifts.filter(s => s.status === 'Active').length;
  const completionPct = Math.round((completed / tasks.length) * 100);
  const avgBattery = Math.round(
    aircraft.reduce((s, a) => s + a.battery, 0) / aircraft.length,
  );
  const criticalInc = incidents.filter(
    i => i.severity === 'Critical' && i.status !== 'Resolved',
  ).length;
  const activeShifts = shifts.filter(s => s.status === 'Active');
  const recent = tasks
    .filter(t => ['In Progress', 'Pending'].includes(t.status))
    .slice(0, 4);

  const stats = [
    { label: 'Active', val: activeTasks, color: '#3B82F6' },
    { label: 'Pending', val: pending, color: '#F59E0B' },
    { label: 'Completed', val: completed, color: '#10B981' },
    { label: 'Staff On', val: activeStaff, color: '#A78BFA' },
  ];

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* Hero banner */}
      <View
        style={[
          styles.hero,
          { padding: isMobile ? 20 : 28, paddingBottom: isMobile ? 24 : 28 },
        ]}
      >
        <View style={[styles.heroBlob, styles.heroBlobA]} />
        <View style={[styles.heroBlob, styles.heroBlobB]} />
        <Text style={styles.heroEyebrow}>
          VTOL-PORT ALPHA · APRIL 24, 2026
        </Text>
        <Text
          style={[styles.heroTitle, { fontSize: isMobile ? 20 : 26 }]}
        >
          Good morning, Controller
        </Text>
        <View style={styles.heroRow}>
          <ProgressRing pct={completionPct} />
          <View style={styles.statGrid}>
            {stats.map(s => (
              <View key={s.label} style={styles.statCard}>
                <Text style={[styles.statValue, { color: s.color }]}>
                  {s.val}
                </Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>

      <View style={[styles.body, { padding: isMobile ? 16 : 20 }]}>
        {criticalInc > 0 && (
          <View style={styles.alertBanner}>
            <View style={styles.alertIcon}>
              <Text style={styles.alertEmoji}>🚨</Text>
            </View>
            <View style={styles.alertContent}>
              <Text style={styles.alertTitle}>
                Critical Incident Active
              </Text>
              <Text style={styles.alertSub}>
                INC-004 — Taxiway B guidance system failure
              </Text>
            </View>
            <Button label="View" variant="ghost" size="sm" />
          </View>
        )}

        {/* Fleet status */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Fleet Status</Text>
            <View style={styles.row}>
              <Text
                style={[
                  styles.bigNum,
                  { color: batteryColor(avgBattery) },
                ]}
              >
                {avgBattery}%
              </Text>
              <Text style={styles.bigNumCaption}>avg battery</Text>
            </View>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.fleetStrip}
          >
            {aircraft.map(ac => {
              const bc = batteryColor(ac.battery);
              const sc = getStatusColor(ac.status);
              return (
                <View
                  key={ac.id}
                  style={[
                    styles.fleetCell,
                    {
                      width: isMobile ? 90 : 100,
                      borderColor: `${sc.dot}33`,
                    },
                  ]}
                >
                  <Text style={styles.fleetId}>{ac.id}</Text>
                  <View style={styles.fleetBar}>
                    <View
                      style={[
                        styles.fleetBarFill,
                        { width: `${ac.battery}%`, backgroundColor: bc },
                      ]}
                    />
                  </View>
                  <Text style={[styles.fleetPct, { color: bc }]}>
                    {ac.battery}%
                  </Text>
                  <Text style={[styles.fleetStatus, { color: sc.color }]}>
                    {ac.status}
                  </Text>
                </View>
              );
            })}
          </ScrollView>
        </View>

        {/* Two column */}
        <View
          style={[
            styles.twoCol,
            { flexDirection: isMobile ? 'column' : 'row' },
          ]}
        >
          <View style={[styles.card, styles.flex1, { padding: 0 }]}>
            <View style={styles.listHeader}>
              <Text style={styles.cardTitle}>Recent Tasks</Text>
              <Text style={styles.viewAll}>View all →</Text>
            </View>
            {recent.map((t, i) => {
              const sc = getStatusColor(t.status);
              return (
                <View
                  key={t.id}
                  style={[
                    styles.taskRow,
                    i === recent.length - 1 && { borderBottomWidth: 0 },
                  ]}
                >
                  <View
                    style={[
                      styles.taskIcon,
                      { backgroundColor: `${sc.dot}22` },
                    ]}
                  >
                    <Icon
                      name={taskIconFor(t.type)}
                      size={16}
                      color={sc.dot}
                    />
                  </View>
                  <View style={styles.flex1}>
                    <Text style={styles.taskType}>{t.type}</Text>
                    <Text style={styles.taskMeta}>
                      {t.aircraft} · {t.gate}
                    </Text>
                  </View>
                  <StatusBadge value={t.status} />
                </View>
              );
            })}
          </View>

          <View style={[styles.card, styles.flex1]}>
            <Text style={[styles.cardTitle, { marginBottom: 14 }]}>
              Today's Timeline
            </Text>
            {TIMELINE.map((e, i) => (
              <View key={i} style={styles.timelineRow}>
                <View style={styles.timelineDotCol}>
                  <View
                    style={[styles.timelineDot, { backgroundColor: e.color }]}
                  />
                  {i < TIMELINE.length - 1 && (
                    <View style={styles.timelineLine} />
                  )}
                </View>
                <View style={styles.timelineContent}>
                  <Text style={styles.timelineTime}>{e.time}</Text>
                  <Text style={styles.timelineLabel}>{e.label}</Text>
                  <Text style={styles.timelineGate}>{e.gate}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Active staff */}
        <View style={styles.card}>
          <Text style={[styles.cardTitle, { marginBottom: 12 }]}>
            Active Staff
          </Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.staffRow}
          >
            {activeShifts.map(s => (
              <View key={s.id} style={styles.staffCell}>
                <View style={styles.avatarWithDot}>
                  <Avatar initials={s.avatar} color={s.color} size={44} />
                  <View style={styles.onlineDot} />
                </View>
                <Text style={styles.staffName}>{s.name.split(' ')[0]}</Text>
                <Text style={styles.staffTasks}>{s.tasks} tasks</Text>
              </View>
            ))}
          </ScrollView>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  content: {
    paddingBottom: 24,
  },
  hero: {
    backgroundColor: colors.heroStart,
    overflow: 'hidden',
  },
  heroBlob: {
    position: 'absolute',
    borderRadius: 200,
    opacity: 0.08,
  },
  heroBlobA: {
    width: 180,
    height: 180,
    top: -40,
    right: -40,
    backgroundColor: colors.accent,
  },
  heroBlobB: {
    width: 120,
    height: 120,
    bottom: -30,
    left: 20,
    backgroundColor: '#2B6AFF',
  },
  heroEyebrow: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.45)',
    fontWeight: '600',
    letterSpacing: 1.1,
    marginBottom: 4,
  },
  heroTitle: {
    fontWeight: '800',
    color: '#fff',
    letterSpacing: -0.4,
    marginBottom: 16,
  },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  ringWrap: {
    width: 80,
    height: 80,
    position: 'relative',
  },
  ringLabel: {
    position: 'absolute',
    inset: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ringPct: {
    fontSize: 18,
    fontWeight: '800',
    color: '#fff',
  },
  ringCaption: {
    fontSize: 9,
    color: 'rgba(255,255,255,0.5)',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  statGrid: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginLeft: 20,
  },
  statCard: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: '45%',
    flexGrow: 1,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  statLabel: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.45)',
    marginTop: 1,
  },
  body: {
    gap: 14,
  },
  alertBanner: {
    backgroundColor: colors.purple,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  alertIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  alertEmoji: {
    fontSize: 18,
  },
  alertContent: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#fff',
  },
  alertSub: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.75)',
    marginTop: 1,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bigNum: {
    fontSize: 22,
    fontWeight: '800',
  },
  bigNumCaption: {
    fontSize: 11,
    color: colors.textFaint,
    fontWeight: '500',
  },
  fleetStrip: {
    gap: 8,
    paddingBottom: 4,
  },
  fleetCell: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderWidth: 1.5,
  },
  fleetId: {
    fontSize: 10,
    fontWeight: '700',
    color: colors.text,
    fontFamily: fontFamilies.mono,
    marginBottom: 2,
  },
  fleetBar: {
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.border,
    marginBottom: 4,
    overflow: 'hidden',
  },
  fleetBarFill: {
    height: '100%',
    borderRadius: 2,
  },
  fleetPct: {
    fontSize: 11,
    fontWeight: '700',
  },
  fleetStatus: {
    fontSize: 9,
    fontWeight: '600',
    marginTop: 2,
  },
  twoCol: {
    gap: 14,
  },
  flex1: {
    flex: 1,
  },
  listHeader: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderSoft,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  viewAll: {
    fontSize: 12,
    color: colors.accent,
    fontWeight: '500',
  },
  taskRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  taskIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  taskType: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.text,
  },
  taskMeta: {
    fontSize: 11,
    color: colors.textFaint,
    fontFamily: fontFamilies.mono,
  },
  timelineRow: {
    flexDirection: 'row',
    gap: 12,
  },
  timelineDotCol: {
    alignItems: 'center',
  },
  timelineDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginTop: 3,
  },
  timelineLine: {
    width: 1.5,
    height: 26,
    backgroundColor: colors.border,
  },
  timelineContent: {
    paddingBottom: 6,
  },
  timelineTime: {
    fontSize: 11,
    color: colors.textFaint,
    fontFamily: fontFamilies.mono,
  },
  timelineLabel: {
    fontSize: 13,
    fontWeight: '500',
    color: colors.text,
  },
  timelineGate: {
    fontSize: 11,
    color: colors.textFaint,
  },
  staffRow: {
    gap: 14,
    paddingBottom: 4,
    paddingRight: 14,
  },
  staffCell: {
    alignItems: 'center',
    gap: 6,
  },
  avatarWithDot: {
    position: 'relative',
  },
  onlineDot: {
    position: 'absolute',
    bottom: 1,
    right: 1,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.success,
    borderWidth: 2,
    borderColor: '#fff',
  },
  staffName: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.text,
  },
  staffTasks: {
    fontSize: 10,
    color: colors.textFaint,
  },
});
