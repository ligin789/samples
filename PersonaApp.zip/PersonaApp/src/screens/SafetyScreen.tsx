import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import {
  BottomSheet,
  Button,
  FilterChip,
  Icon,
  SeverityBadge,
  StatusBadge,
} from '../components';
import { INCIDENTS, Incident, TASKS, SHIFTS } from '../data/mockData';
import { colors, fontFamilies, radius, shadow, spacing } from '../theme';
import { getSeverityColor } from '../utils/statusColors';

type SubTab = 'Incidents' | 'Reports';
type SeverityFilter = 'All' | Incident['severity'];

const SEVERITY_FILTERS: SeverityFilter[] = ['All', 'Critical', 'High', 'Medium', 'Low'];

const IncidentCard: React.FC<{ incident: Incident; onPress: () => void }> = ({
  incident,
  onPress,
}) => {
  const sev = getSeverityColor(incident.severity);
  return (
    <Pressable
      onPress={onPress}
      style={[styles.card, { borderLeftColor: sev.bg }]}
    >
      <View style={styles.cardHeader}>
        <View style={styles.cardIdRow}>
          <Text style={styles.cardId}>{incident.id}</Text>
          <SeverityBadge value={incident.severity} />
        </View>
        <StatusBadge value={incident.status} />
      </View>
      <Text style={styles.cardDesc} numberOfLines={2}>
        {incident.description}
      </Text>
      <View style={styles.cardMetaRow}>
        <Text style={styles.cardMeta}>{incident.aircraft}</Text>
        <Text style={styles.cardMetaDot}>·</Text>
        <Text style={styles.cardMeta}>{incident.location}</Text>
        <Text style={styles.cardMetaDot}>·</Text>
        <Text style={styles.cardMeta}>{incident.reportedBy}</Text>
        <Text style={[styles.cardMeta, styles.cardMetaMono]}>
          {' '}{incident.date}
        </Text>
      </View>
    </Pressable>
  );
};

const IncidentDetail: React.FC<{ incident: Incident }> = ({ incident }) => {
  const rows: Array<[string, string, boolean?]> = [
    ['Aircraft', incident.aircraft, true],
    ['Location', incident.location, false],
    ['Reported By', incident.reportedBy, false],
    ['Date & Time', incident.date, true],
  ];
  return (
    <ScrollView>
      <View style={styles.detailPills}>
        <SeverityBadge value={incident.severity} />
        <StatusBadge value={incident.status} />
      </View>
      {rows.map(([label, value, mono]) => (
        <View key={label} style={styles.detailRow}>
          <Text style={styles.detailLabel}>{label}</Text>
          <Text style={[styles.detailValue, mono ? styles.mono : null]}>
            {value}
          </Text>
        </View>
      ))}
      <View style={styles.descBlock}>
        <Text style={styles.descLabel}>DESCRIPTION</Text>
        <View style={styles.descBody}>
          <Text style={styles.descText}>{incident.description}</Text>
        </View>
      </View>
      <View style={styles.detailActions}>
        {incident.status !== 'Resolved' && (
          <Button label="Mark Resolved" variant="success" size="md" />
        )}
        {incident.status !== 'Escalated' && incident.severity !== 'Low' && (
          <Button label="Escalate" variant="danger" size="md" />
        )}
      </View>
    </ScrollView>
  );
};

const IncidentsView: React.FC<{
  onOpenReport: () => void;
  incidents: Incident[];
  onSelect: (inc: Incident) => void;
}> = ({ onOpenReport, incidents, onSelect }) => {
  const [filter, setFilter] = useState<SeverityFilter>('All');
  const active = incidents.filter(i => i.status !== 'Resolved').length;
  const resolved = incidents.filter(i => i.status === 'Resolved').length;
  const critical = incidents.find(
    i => i.severity === 'Critical' && i.status !== 'Resolved',
  );
  const filtered =
    filter === 'All' ? incidents : incidents.filter(i => i.severity === filter);

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.headerRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.pageTitle}>Incidents</Text>
          <Text style={styles.pageSub}>
            {active} active · {resolved} resolved
          </Text>
        </View>
        <Button
          label="Report"
          variant="danger"
          size="md"
          onPress={onOpenReport}
          leftIcon={<Icon name="flag" size={14} color="#fff" />}
        />
      </View>

      {critical ? (
        <Pressable style={styles.criticalBanner} onPress={() => onSelect(critical)}>
          <Text style={styles.criticalEmoji}>🚨</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.criticalTitle}>Critical Incident Active</Text>
            <Text style={styles.criticalDesc}>
              {critical.id} — {critical.description.slice(0, 60)}…
            </Text>
          </View>
          <View style={styles.criticalView}>
            <Text style={styles.criticalViewText}>View</Text>
          </View>
        </Pressable>
      ) : null}

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterRow}
      >
        {SEVERITY_FILTERS.map(f => (
          <FilterChip
            key={f}
            label={f}
            active={filter === f}
            onPress={() => setFilter(f)}
            activeColor={
              f === 'All' ? colors.infoDeep : getSeverityColor(f).bg
            }
          />
        ))}
      </ScrollView>

      <ScrollView contentContainerStyle={styles.cardList}>
        {filtered.map(inc => (
          <IncidentCard
            key={inc.id}
            incident={inc}
            onPress={() => onSelect(inc)}
          />
        ))}
      </ScrollView>
    </View>
  );
};

const ReportsView: React.FC = () => {
  const stats = useMemo(() => {
    const byStatus: Record<string, number> = {};
    TASKS.forEach(t => {
      byStatus[t.status] = (byStatus[t.status] || 0) + 1;
    });
    const totalTasks = TASKS.length;
    const bySeverity: Record<string, number> = {};
    INCIDENTS.forEach(i => {
      bySeverity[i.severity] = (bySeverity[i.severity] || 0) + 1;
    });
    const activeStaff = SHIFTS.filter(s => s.status === 'Active');
    return { byStatus, totalTasks, bySeverity, activeStaff };
  }, []);

  const taskStatuses: Array<keyof typeof stats.byStatus | string> = [
    'In Progress',
    'Pending',
    'Completed',
    'Delayed',
  ];
  const severities: Array<Incident['severity']> = ['Critical', 'High', 'Medium', 'Low'];

  return (
    <ScrollView contentContainerStyle={styles.reportsRoot}>
      <Text style={styles.pageTitle}>Reports</Text>
      <Text style={styles.pageSub}>Operational summary — today</Text>

      <View style={styles.summaryRow}>
        {[
          { label: 'Total Tasks', value: stats.totalTasks, color: colors.infoDeep },
          {
            label: 'Resolved',
            value: INCIDENTS.filter(i => i.status === 'Resolved').length,
            color: colors.successDeep,
          },
          { label: 'Open Incidents', value: INCIDENTS.filter(i => i.status !== 'Resolved').length, color: colors.danger },
          { label: 'Staff On', value: stats.activeStaff.length, color: colors.warn },
        ].map(s => (
          <View key={s.label} style={[styles.summaryCard, { borderTopColor: s.color }]}>
            <Text style={styles.summaryValue}>{s.value}</Text>
            <Text style={styles.summaryLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.reportCard}>
        <Text style={styles.reportCardTitle}>Task Breakdown</Text>
        {taskStatuses.map(st => {
          const count = stats.byStatus[st] || 0;
          const pct = stats.totalTasks ? (count / stats.totalTasks) * 100 : 0;
          return (
            <View key={st} style={styles.barRow}>
              <Text style={styles.barLabel}>{st}</Text>
              <View style={styles.barTrack}>
                <View style={[styles.barFill, { width: `${pct}%` }]} />
              </View>
              <Text style={styles.barValue}>{count}</Text>
            </View>
          );
        })}
      </View>

      <View style={styles.reportCard}>
        <Text style={styles.reportCardTitle}>Incident Summary</Text>
        <View style={styles.sevGrid}>
          {severities.map(sv => {
            const c = getSeverityColor(sv);
            return (
              <View key={sv} style={styles.sevCell}>
                <Text style={[styles.sevValue, { color: c.bg }]}>
                  {stats.bySeverity[sv] || 0}
                </Text>
                <Text style={styles.sevLabel}>{sv}</Text>
              </View>
            );
          })}
        </View>
      </View>

      <View style={styles.reportCard}>
        <Text style={styles.reportCardTitle}>Staff Utilization</Text>
        <View style={styles.staffGrid}>
          {stats.activeStaff.map(s => (
            <View key={s.id} style={styles.staffCell}>
              <View style={[styles.staffDot, { backgroundColor: s.color }]}>
                <Text style={styles.staffAvatar}>{s.avatar}</Text>
              </View>
              <Text style={styles.staffName}>{s.name.split(' ')[0]}</Text>
              <Text style={styles.staffTasks}>{s.tasks} tasks</Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};

export const SafetyScreen: React.FC = () => {
  const [sub, setSub] = useState<SubTab>('Incidents');
  const [selected, setSelected] = useState<Incident | null>(null);
  const [showReport, setShowReport] = useState(false);

  return (
    <View style={styles.root}>
      <View style={styles.tabs}>
        {(['Incidents', 'Reports'] as SubTab[]).map(t => (
          <Pressable
            key={t}
            onPress={() => setSub(t)}
            style={[styles.tab, sub === t ? styles.tabActive : null]}
          >
            <Text style={[styles.tabText, sub === t ? styles.tabTextActive : null]}>
              {t}
            </Text>
          </Pressable>
        ))}
      </View>

      {sub === 'Incidents' ? (
        <IncidentsView
          incidents={INCIDENTS}
          onSelect={setSelected}
          onOpenReport={() => setShowReport(true)}
        />
      ) : (
        <ReportsView />
      )}

      <BottomSheet
        visible={!!selected}
        title={selected ? `${selected.id} — Incident Report` : ''}
        onClose={() => setSelected(null)}
      >
        {selected ? <IncidentDetail incident={selected} /> : null}
      </BottomSheet>

      <BottomSheet
        visible={showReport}
        title="Report Incident"
        onClose={() => setShowReport(false)}
        tall
      >
        <View style={styles.reportFormNote}>
          <Text style={styles.reportFormNoteTitle}>Quick Report</Text>
          <Text style={styles.reportFormNoteDesc}>
            Use this form to flag a new safety incident. Critical severity
            automatically escalates to the operations manager.
          </Text>
        </View>
        <View style={styles.reportFormActions}>
          <Button
            label="Cancel"
            variant="ghost"
            onPress={() => setShowReport(false)}
          />
          <Button
            label="Submit Report"
            variant="danger"
            size="lg"
            onPress={() => setShowReport(false)}
          />
        </View>
      </BottomSheet>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  tabs: {
    flexDirection: 'row',
    gap: 4,
    backgroundColor: colors.border,
    borderRadius: radius.xl,
    padding: 3,
    alignSelf: 'flex-start',
    marginHorizontal: spacing.x5l,
    marginTop: spacing.x4l,
  },
  tab: {
    paddingHorizontal: 22,
    paddingVertical: 8,
    borderRadius: radius.lg,
  },
  tabActive: {
    backgroundColor: colors.surface,
    ...shadow.card,
  },
  tabText: { fontSize: 14, color: colors.textSubtle, fontWeight: '500' },
  tabTextActive: { color: colors.text, fontWeight: '600' },

  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.x5l,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.md,
  },
  pageTitle: {
    fontFamily: fontFamilies.sans,
    fontSize: 22,
    fontWeight: '700',
    color: colors.text,
    letterSpacing: -0.4,
  },
  pageSub: { fontSize: 13, color: colors.textFaint, marginTop: 2 },

  criticalBanner: {
    marginHorizontal: spacing.x5l,
    marginBottom: spacing.xl,
    backgroundColor: colors.purple,
    borderRadius: radius.xxl,
    paddingHorizontal: 16,
    paddingVertical: 13,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  criticalEmoji: { fontSize: 20 },
  criticalTitle: { fontSize: 14, fontWeight: '700', color: '#fff' },
  criticalDesc: { fontSize: 12, color: 'rgba(255,255,255,0.8)', marginTop: 2 },
  criticalView: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  criticalViewText: { color: '#fff', fontSize: 13, fontWeight: '600' },

  filterRow: {
    gap: 6,
    paddingHorizontal: spacing.x5l,
    paddingBottom: spacing.lg,
  },
  cardList: {
    paddingHorizontal: spacing.x5l,
    paddingBottom: spacing.x5l,
    gap: 10,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.xxl,
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderLeftWidth: 4,
    ...shadow.card,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardIdRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  cardId: {
    fontSize: 12,
    fontFamily: fontFamilies.mono,
    color: colors.infoDeep,
    fontWeight: '600',
  },
  cardDesc: { fontSize: 14, fontWeight: '500', color: colors.text, marginBottom: 6 },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
  },
  cardMeta: { fontSize: 12, color: colors.textFaint },
  cardMetaDot: { fontSize: 12, color: colors.textFaint },
  cardMetaMono: { fontFamily: fontFamilies.mono },

  detailPills: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  detailLabel: { fontSize: 13, color: colors.textFaint, fontWeight: '600' },
  detailValue: { fontSize: 14, color: colors.text, fontWeight: '500' },
  mono: { fontFamily: fontFamilies.mono },
  descBlock: { marginTop: 14 },
  descLabel: {
    fontSize: 12,
    color: colors.textFaint,
    fontWeight: '600',
    letterSpacing: 0.6,
    marginBottom: 8,
  },
  descBody: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.lg,
    padding: 14,
  },
  descText: { fontSize: 14, color: colors.textMuted, lineHeight: 22 },
  detailActions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 20,
    justifyContent: 'flex-end',
  },

  reportsRoot: { padding: spacing.x5l, gap: spacing.xl },
  summaryRow: { flexDirection: 'row', gap: 10, flexWrap: 'wrap' },
  summaryCard: {
    flex: 1,
    minWidth: 130,
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderTopWidth: 3,
    ...shadow.card,
  },
  summaryValue: { fontSize: 22, fontWeight: '700', color: colors.text },
  summaryLabel: { fontSize: 12, color: colors.textSubtle, marginTop: 2 },

  reportCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.xxl,
    padding: 16,
    ...shadow.card,
  },
  reportCardTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 12,
  },
  barRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },
  barLabel: { width: 90, fontSize: 12, color: colors.textMuted },
  barTrack: {
    flex: 1,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  barFill: { height: '100%', backgroundColor: colors.accent, borderRadius: 4 },
  barValue: {
    width: 30,
    fontSize: 12,
    fontWeight: '700',
    color: colors.text,
    textAlign: 'right',
    fontFamily: fontFamilies.mono,
  },

  sevGrid: { flexDirection: 'row', gap: 10 },
  sevCell: {
    flex: 1,
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.lg,
    paddingVertical: 14,
    alignItems: 'center',
  },
  sevValue: { fontSize: 22, fontWeight: '800' },
  sevLabel: { fontSize: 11, color: colors.textFaint, marginTop: 2 },

  staffGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  staffCell: { alignItems: 'center', width: 72 },
  staffDot: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  staffAvatar: { color: '#fff', fontWeight: '700', fontSize: 12 },
  staffName: { fontSize: 12, color: colors.text, fontWeight: '600', marginTop: 4 },
  staffTasks: { fontSize: 10, color: colors.textFaint },

  reportFormNote: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.lg,
    padding: 14,
    marginBottom: 16,
  },
  reportFormNoteTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  reportFormNoteDesc: { fontSize: 13, color: colors.textMuted, lineHeight: 20 },
  reportFormActions: { flexDirection: 'row', gap: 10, justifyContent: 'flex-end' },
});
