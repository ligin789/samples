import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Avatar, Icon } from '../components';
import {
  Conversation,
  CONVERSATIONS,
  Message,
} from '../data/mockData';
import { colors, fontFamilies, radius, shadow, spacing } from '../theme';
import { useViewport } from '../utils/responsive';

const currentTime = () =>
  new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });

interface ConversationItemProps {
  conv: Conversation;
  active: boolean;
  onPress: () => void;
}

const ConversationItem: React.FC<ConversationItemProps> = ({
  conv,
  active,
  onPress,
}) => {
  const last = conv.messages[conv.messages.length - 1];
  return (
    <Pressable
      onPress={onPress}
      style={[
        convStyles.row,
        active ? convStyles.rowActive : null,
        active ? { borderLeftColor: colors.accent } : null,
      ]}
    >
      <View style={{ position: 'relative' }}>
        <Avatar initials={conv.avatar} color={conv.color} size={40} />
        {conv.online === true ? (
          <View style={convStyles.onlineDot} />
        ) : null}
      </View>
      <View style={{ flex: 1 }}>
        <View style={convStyles.headerRow}>
          <Text style={convStyles.name} numberOfLines={1}>
            {conv.name}
          </Text>
          <Text style={convStyles.time}>{last?.time}</Text>
        </View>
        <View style={convStyles.previewRow}>
          <Text style={convStyles.preview} numberOfLines={1}>
            {last?.system ? `· ${last.text}` : last?.text || conv.subtitle}
          </Text>
          {conv.unread > 0 ? (
            <View style={convStyles.unread}>
              <Text style={convStyles.unreadText}>{conv.unread}</Text>
            </View>
          ) : null}
        </View>
      </View>
    </Pressable>
  );
};

const MessageBubble: React.FC<{ msg: Message }> = ({ msg }) => {
  if (msg.system) {
    return (
      <View style={msgStyles.systemWrap}>
        <Text style={msgStyles.systemText}>
          {msg.text} · {msg.time}
        </Text>
      </View>
    );
  }
  if (msg.sent) {
    return (
      <View style={msgStyles.sentWrap}>
        <View style={msgStyles.sentBubble}>
          <Text style={msgStyles.sentText}>{msg.text}</Text>
        </View>
        <Text style={msgStyles.sentMeta}>{msg.time} · Delivered</Text>
      </View>
    );
  }
  return (
    <View style={msgStyles.incomingRow}>
      <Avatar initials={msg.avatar || ''} color={msg.color || colors.textFaint} size={28} />
      <View style={{ maxWidth: '78%' }}>
        <Text style={msgStyles.incomingName}>{msg.sender}</Text>
        <View style={msgStyles.incomingBubble}>
          <Text style={msgStyles.incomingText}>{msg.text}</Text>
        </View>
        <Text style={msgStyles.incomingMeta}>{msg.time}</Text>
      </View>
    </View>
  );
};

interface MessageThreadProps {
  conv: Conversation;
  onBack?: () => void;
}

const MessageThread: React.FC<MessageThreadProps> = ({ conv, onBack }) => {
  const [messages, setMessages] = useState<Message[]>(conv.messages);
  const [input, setInput] = useState('');
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    setMessages(conv.messages);
  }, [conv.id, conv.messages]);

  useEffect(() => {
    const t = setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 60);
    return () => clearTimeout(t);
  }, [messages.length]);

  const send = () => {
    const text = input.trim();
    if (!text) return;
    setMessages(prev => [
      ...prev,
      { id: prev.length + 1, sender: 'Me', text, time: currentTime(), sent: true },
    ]);
    setInput('');
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={threadStyles.root}
    >
      <View style={threadStyles.header}>
        {onBack ? (
          <Pressable onPress={onBack} style={threadStyles.back}>
            <Icon name="chevronLeft" size={18} color="#fff" />
          </Pressable>
        ) : null}
        <View style={{ position: 'relative' }}>
          <Avatar initials={conv.avatar} color={conv.color} size={36} />
          {conv.online === true ? <View style={threadStyles.onlineDot} /> : null}
        </View>
        <View style={{ flex: 1 }}>
          <Text style={threadStyles.headerTitle}>{conv.name}</Text>
          <Text style={threadStyles.headerSub}>{conv.subtitle}</Text>
        </View>
      </View>

      <ScrollView
        ref={scrollRef}
        style={threadStyles.scroll}
        contentContainerStyle={threadStyles.scrollContent}
      >
        {messages.map(msg => (
          <MessageBubble key={msg.id} msg={msg} />
        ))}
      </ScrollView>

      {conv.replies.length > 0 ? (
        <View style={threadStyles.quickRepliesWrap}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={threadStyles.quickReplies}
          >
            {conv.replies.map(r => (
              <Pressable key={r} style={threadStyles.quickReply} onPress={() => setInput(r)}>
                <Text style={threadStyles.quickReplyText}>{r}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      ) : null}

      <View style={threadStyles.inputWrap}>
        <View style={threadStyles.inputBox}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Type a message..."
            placeholderTextColor={colors.textFaint}
            style={threadStyles.input}
            onSubmitEditing={send}
            returnKeyType="send"
          />
          <Pressable style={threadStyles.iconBtn}>
            <Icon name="attach" size={16} color={colors.textFaint} />
          </Pressable>
          <Pressable
            style={[
              threadStyles.sendBtn,
              { backgroundColor: input.trim() ? colors.accent : colors.border },
            ]}
            onPress={send}
            disabled={!input.trim()}
          >
            <Icon name="send" size={14} color={input.trim() ? '#fff' : colors.textFaint} />
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

export const ChatScreen: React.FC = () => {
  const { isMobile } = useViewport();
  const [selectedId, setSelectedId] = useState<string>(CONVERSATIONS[0].id);
  const [mobileView, setMobileView] = useState<'list' | 'thread'>('list');

  const groups = useMemo(
    () => CONVERSATIONS.filter(c => c.type === 'group'),
    [],
  );
  const dms = useMemo(() => CONVERSATIONS.filter(c => c.type === 'dm'), []);
  const selected = CONVERSATIONS.find(c => c.id === selectedId) || CONVERSATIONS[0];

  const renderList = () => (
    <ScrollView style={styles.list}>
      <Text style={styles.sectionHeader}>GROUPS</Text>
      {groups.map(c => (
        <ConversationItem
          key={c.id}
          conv={c}
          active={!isMobile && selectedId === c.id}
          onPress={() => {
            setSelectedId(c.id);
            if (isMobile) setMobileView('thread');
          }}
        />
      ))}
      <Text style={styles.sectionHeader}>DIRECT MESSAGES</Text>
      {dms.map(c => (
        <ConversationItem
          key={c.id}
          conv={c}
          active={!isMobile && selectedId === c.id}
          onPress={() => {
            setSelectedId(c.id);
            if (isMobile) setMobileView('thread');
          }}
        />
      ))}
      <View style={{ height: 24 }} />
    </ScrollView>
  );

  if (isMobile) {
    if (mobileView === 'thread') {
      return (
        <View style={styles.mobileRoot}>
          <MessageThread conv={selected} onBack={() => setMobileView('list')} />
        </View>
      );
    }
    return <View style={styles.mobileRoot}>{renderList()}</View>;
  }

  return (
    <View style={styles.root}>
      <View style={styles.listPane}>
        <View style={styles.listHeader}>
          <Text style={styles.listHeaderTitle}>Team Chat</Text>
          <Text style={styles.listHeaderSub}>
            {CONVERSATIONS.reduce((acc, c) => acc + c.unread, 0)} unread messages
          </Text>
        </View>
        {renderList()}
      </View>
      <View style={styles.threadPane}>
        <MessageThread conv={selected} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, flexDirection: 'row' },
  mobileRoot: { flex: 1, backgroundColor: colors.surface },
  listPane: {
    width: 320,
    backgroundColor: colors.surface,
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  listHeader: {
    paddingHorizontal: spacing.xxl,
    paddingVertical: spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderSoft,
  },
  listHeaderTitle: { fontSize: 18, fontWeight: '700', color: colors.text },
  listHeaderSub: { fontSize: 12, color: colors.textFaint, marginTop: 2 },
  list: { flex: 1 },
  sectionHeader: {
    fontSize: 10,
    color: colors.textFaint,
    fontWeight: '700',
    letterSpacing: 1,
    paddingHorizontal: spacing.xxl,
    paddingTop: spacing.xl,
    paddingBottom: spacing.md,
  },
  threadPane: { flex: 1, backgroundColor: colors.bg },
});

const convStyles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: spacing.xxl,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
    borderLeftWidth: 3,
    borderLeftColor: 'transparent',
  },
  rowActive: { backgroundColor: colors.accentSoft },
  onlineDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 11,
    height: 11,
    borderRadius: 999,
    backgroundColor: colors.success,
    borderWidth: 2,
    borderColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  name: { fontSize: 13, fontWeight: '700', color: colors.text, flex: 1 },
  time: { fontSize: 11, color: colors.textFaint, fontFamily: fontFamilies.mono, marginLeft: 6 },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },
  preview: { flex: 1, fontSize: 12, color: colors.textSubtle },
  unread: {
    minWidth: 18,
    height: 18,
    paddingHorizontal: 6,
    borderRadius: 999,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadText: { color: '#fff', fontSize: 10, fontWeight: '700' },
});

const threadStyles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: spacing.xxl,
    paddingVertical: 14,
    backgroundColor: colors.heroStart,
  },
  back: {
    width: 32,
    height: 32,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  onlineDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 10,
    height: 10,
    borderRadius: 999,
    backgroundColor: colors.success,
    borderWidth: 2,
    borderColor: colors.heroStart,
  },
  headerTitle: { fontSize: 15, fontWeight: '700', color: '#fff' },
  headerSub: { fontSize: 11, color: colors.textFaint, marginTop: 1 },
  scroll: { flex: 1, backgroundColor: colors.surfaceAlt },
  scrollContent: { padding: 14, gap: 10 },
  quickRepliesWrap: {
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.borderSoft,
  },
  quickReplies: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    gap: 8,
    alignItems: 'center',
  },
  quickReply: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    alignSelf: 'center',
  },
  quickReplyText: { fontSize: 12, color: colors.textMuted },
  inputWrap: {
    padding: 10,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.borderSoft,
  },
  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.xl,
    paddingLeft: 12,
    paddingRight: 6,
    paddingVertical: 4,
    borderWidth: 1.5,
    borderColor: colors.border,
  },
  input: {
    flex: 1,
    fontSize: 13,
    color: colors.text,
    paddingVertical: 8,
    fontFamily: fontFamilies.sans,
  },
  iconBtn: { padding: 4 },
  sendBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

const msgStyles = StyleSheet.create({
  systemWrap: { alignItems: 'center' },
  systemText: {
    fontSize: 11,
    color: colors.purpleDeep,
    backgroundColor: '#F5F3FF',
    paddingHorizontal: 12,
    paddingVertical: 3,
    borderRadius: radius.pill,
    fontWeight: '500',
    overflow: 'hidden',
  },
  sentWrap: { alignItems: 'flex-end' },
  sentBubble: {
    backgroundColor: colors.infoDeep,
    borderRadius: 14,
    borderBottomRightRadius: 4,
    paddingVertical: 9,
    paddingHorizontal: 13,
    maxWidth: '78%',
  },
  sentText: { color: '#fff', fontSize: 13, lineHeight: 19 },
  sentMeta: { fontSize: 10, color: colors.textFaint, marginTop: 3 },
  incomingRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  incomingName: { fontSize: 10, color: colors.textFaint, fontWeight: '600', marginBottom: 3 },
  incomingBubble: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    borderBottomLeftRadius: 4,
    paddingVertical: 9,
    paddingHorizontal: 13,
    ...shadow.card,
  },
  incomingText: { fontSize: 13, color: colors.text, lineHeight: 19 },
  incomingMeta: { fontSize: 10, color: colors.textFaint, marginTop: 3 },
});
