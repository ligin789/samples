import React, { useEffect, useRef } from 'react';
import {
  Animated,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { colors } from '../theme';
import { Icon, IconName } from './Icon';
import type { TabId } from '../navigation/types';

export interface TabItem {
  id: TabId;
  label: string;
  icon: IconName;
  badge?: number;
}

interface BottomTabBarProps {
  active: TabId;
  tabs: TabItem[];
  onChange: (id: TabId) => void;
  isMobile?: boolean;
}

const TabButton: React.FC<{
  tab: TabItem;
  active: boolean;
  onPress: () => void;
  isMobile?: boolean;
}> = ({ tab, active, onPress, isMobile }) => {
  const scale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (active) {
      Animated.sequence([
        Animated.timing(scale, { toValue: 0.88, duration: 120, useNativeDriver: true }),
        Animated.spring(scale, { toValue: 1, friction: 4, useNativeDriver: true }),
      ]).start();
    }
  }, [active, scale]);

  const badgeBg =
    tab.id === 'safety' ? colors.danger : colors.accent;

  return (
    <Pressable style={styles.btn} onPress={onPress}>
      {active && <View style={styles.activePill} />}
      <Animated.View style={[styles.iconWrap, { transform: [{ scale }] }]}>
        <Icon
          name={tab.icon}
          size={isMobile ? 22 : 24}
          color={active ? colors.accent : colors.textFaint}
        />
      </Animated.View>
      <Text
        style={[
          styles.label,
          {
            fontSize: isMobile ? 9 : 10,
            color: active ? colors.accent : colors.textFaint,
            fontWeight: active ? '700' : '400',
          },
        ]}
      >
        {tab.label}
      </Text>
      {tab.badge && tab.badge > 0 ? (
        <View style={[styles.badge, { backgroundColor: badgeBg }]}>
          <Text style={styles.badgeText}>{tab.badge}</Text>
        </View>
      ) : null}
    </Pressable>
  );
};

export const BottomTabBar: React.FC<BottomTabBarProps> = ({
  active,
  tabs,
  onChange,
  isMobile,
}) => (
  <View style={[styles.bar, { height: isMobile ? 66 : 74 }]}>
    {tabs.map(tab => (
      <TabButton
        key={tab.id}
        tab={tab}
        active={active === tab.id}
        onPress={() => onChange(tab.id)}
        isMobile={isMobile}
      />
    ))}
  </View>
);

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.97)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.08)',
    paddingBottom: 4,
  },
  btn: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  activePill: {
    position: 'absolute',
    top: 8,
    width: 40,
    height: 30,
    borderRadius: 10,
    backgroundColor: 'rgba(5,150,105,0.12)',
  },
  iconWrap: {
    marginBottom: 3,
  },
  label: {
    letterSpacing: 0.1,
  },
  badge: {
    position: 'absolute',
    top: 6,
    right: '30%',
    minWidth: 16,
    height: 16,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '700',
  },
});
