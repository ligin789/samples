import React from 'react';
import { StyleSheet, TextInput, View } from 'react-native';
import { Icon } from './Icon';
import { colors } from '../theme';

interface SearchBarProps {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChange,
  placeholder = 'Search…',
}) => (
  <View style={styles.wrap}>
    <View style={styles.icon}>
      <Icon name="search" size={14} color={colors.textFaint} />
    </View>
    <TextInput
      value={value}
      onChangeText={onChange}
      placeholder={placeholder}
      placeholderTextColor={colors.textFaint}
      style={styles.input}
    />
  </View>
);

const styles = StyleSheet.create({
  wrap: {
    flex: 1,
    position: 'relative',
    justifyContent: 'center',
  },
  icon: {
    position: 'absolute',
    left: 10,
    zIndex: 2,
  },
  input: {
    paddingVertical: 9,
    paddingLeft: 30,
    paddingRight: 10,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.surfaceAlt,
    fontSize: 14,
    color: colors.text,
  },
});
