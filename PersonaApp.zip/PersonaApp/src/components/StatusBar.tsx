import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Path, Rect } from 'react-native-svg';
import { colors, fontFamilies } from '../theme';

const formatTime = (d: Date) =>
  d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

export const AppStatusBar: React.FC = () => {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(id);
  }, []);

  return (
    <View style={styles.bar}>
      <Text style={styles.time}>{formatTime(now)}</Text>
      <View style={styles.right}>
        <Svg width={17} height={12} viewBox="0 0 17 12">
          {[0, 1, 2, 3].map(i => (
            <Rect
              key={i}
              x={i * 4.5}
              y={12 - (i + 1) * 3}
              width={3}
              height={(i + 1) * 3}
              rx={1}
              fill={i < 3 ? colors.text : '#D1D5DB'}
            />
          ))}
        </Svg>
        <Svg width={15} height={11} viewBox="0 0 15 11">
          <Circle cx={7.5} cy={9} r={1} fill={colors.text} />
          <Path
            d="M5 7a3.5 3.5 0 015 0"
            stroke={colors.text}
            strokeWidth={1.4}
            strokeLinecap="round"
            fill="none"
          />
          <Path
            d="M2.5 4.5a7 7 0 0110 0"
            stroke="#D1D5DB"
            strokeWidth={1.4}
            strokeLinecap="round"
            fill="none"
          />
        </Svg>
        <View style={styles.batteryWrap}>
          <View style={styles.batteryBody}>
            <View style={styles.batteryFill} />
          </View>
          <View style={styles.batteryTip} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  bar: {
    height: 44,
    backgroundColor: '#fff',
    paddingHorizontal: 22,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  time: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.text,
    fontFamily: fontFamilies.mono,
  },
  right: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  batteryWrap: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  batteryBody: {
    width: 22,
    height: 11,
    borderRadius: 3,
    borderWidth: 1.5,
    borderColor: colors.text,
    padding: 1.5,
    justifyContent: 'center',
  },
  batteryFill: {
    width: '75%',
    height: '100%',
    backgroundColor: colors.text,
    borderRadius: 1,
  },
  batteryTip: {
    width: 2,
    height: 5,
    backgroundColor: 'rgba(15,23,42,0.35)',
    marginLeft: 1,
    borderTopRightRadius: 1,
    borderBottomRightRadius: 1,
  },
});
