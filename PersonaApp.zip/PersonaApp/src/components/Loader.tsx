import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme';

interface LoaderProps {
  message?: string;
}

export const Loader: React.FC<LoaderProps> = ({ message }) => (
  <View style={styles.wrap}>
    <ActivityIndicator size="large" color={colors.accent} />
    {message ? <Text style={styles.msg}>{message}</Text> : null}
  </View>
);

const styles = StyleSheet.create({
  wrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  msg: {
    marginTop: 12,
    fontSize: 13,
    color: colors.textSubtle,
  },
});
