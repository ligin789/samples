import React from 'react';
import { Pressable, StyleSheet, Text } from 'react-native';
import { colors } from '../theme';

interface FilterChipProps {
  label: string;
  active?: boolean;
  onPress: () => void;
  activeColor?: string;
}

export const FilterChip: React.FC<FilterChipProps> = ({
  label,
  active,
  onPress,
  activeColor = colors.accent,
}) => (
  <Pressable
    onPress={onPress}
    style={[
      styles.chip,
      { backgroundColor: active ? activeColor : '#F1F5F9' },
    ]}
  >
    <Text
      style={[
        styles.label,
        {
          color: active ? '#fff' : colors.textMuted,
          fontWeight: active ? '600' : '400',
        },
      ]}
    >
      {label}
    </Text>
  </Pressable>
);

const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 22,
    marginRight: 6,
  },
  label: {
    fontSize: 13,
  },
});
