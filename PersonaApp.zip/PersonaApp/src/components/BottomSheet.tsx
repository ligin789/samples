import React, { useEffect, useRef } from 'react';
import {
  Animated,
  Dimensions,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Icon } from './Icon';
import { colors } from '../theme';

interface BottomSheetProps {
  visible: boolean;
  title: string;
  onClose: () => void;
  tall?: boolean;
  children: React.ReactNode;
}

export const BottomSheet: React.FC<BottomSheetProps> = ({
  visible,
  title,
  onClose,
  tall,
  children,
}) => {
  const translateY = useRef(new Animated.Value(Dimensions.get('window').height)).current;
  const height = Dimensions.get('window').height * (tall ? 0.9 : 0.75);

  useEffect(() => {
    Animated.timing(translateY, {
      toValue: visible ? 0 : Dimensions.get('window').height,
      duration: 280,
      useNativeDriver: true,
    }).start();
  }, [translateY, visible]);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable onPress={e => e.stopPropagation()}>
          <Animated.View
            style={[
              styles.sheet,
              { height, transform: [{ translateY }] },
            ]}
          >
            <View style={styles.handleWrap}>
              <View style={styles.handle} />
            </View>
            <View style={styles.header}>
              <Text style={styles.title}>{title}</Text>
              <Pressable style={styles.close} onPress={onClose}>
                <Icon name="x" size={16} color={colors.textSubtle} />
              </Pressable>
            </View>
            <View style={styles.divider} />
            <View style={styles.body}>{children}</View>
          </Animated.View>
        </Pressable>
      </Pressable>
    </Modal>
  );
};

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    overflow: 'hidden',
  },
  handleWrap: {
    alignItems: 'center',
    paddingTop: 10,
  },
  handle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#D1D5DB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingTop: 12,
    paddingBottom: 14,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  close: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.borderSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  divider: {
    height: 1,
    backgroundColor: colors.borderSoft,
  },
  body: {
    flex: 1,
    padding: 24,
  },
});
