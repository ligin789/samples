import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, fontFamilies } from '../theme';
import { Icon } from './Icon';
import { Avatar } from './Avatar';

interface HeaderProps {
  title: string;
  isMobile?: boolean;
  onNotificationsPress?: () => void;
  onProfilePress?: () => void;
}

const formatTime = (d: Date) =>
  d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

export const Header: React.FC<HeaderProps> = ({
  title,
  isMobile,
  onNotificationsPress,
  onProfilePress,
}) => {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(id);
  }, []);

  return (
    <View
      style={[
        styles.bar,
        { paddingHorizontal: isMobile ? 16 : 24 },
      ]}
    >
      <Text
        style={[styles.title, { fontSize: isMobile ? 16 : 18 }]}
        numberOfLines={1}
      >
        {title}
      </Text>
      {!isMobile && (
        <View style={styles.clock}>
          <View style={styles.liveDot} />
          <Text style={styles.time}>{formatTime(now)}</Text>
          <Text style={styles.vfr}>VFR</Text>
        </View>
      )}
      <Pressable
        onPress={onNotificationsPress}
        style={styles.bellBtn}
      >
        <Icon name="bell" size={17} color={colors.textSubtle} />
        <View style={styles.bellBadge} />
      </Pressable>
      <Pressable onPress={onProfilePress}>
        <Avatar initials="OC" color={colors.accent} size={34} />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  bar: {
    height: 54,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: colors.borderSoft,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  title: {
    flex: 1,
    fontWeight: '700',
    color: colors.text,
    letterSpacing: -0.18,
  },
  clock: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceAlt,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 6,
  },
  liveDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.success,
  },
  time: {
    fontSize: 13,
    color: colors.text,
    fontWeight: '500',
    fontFamily: fontFamilies.mono,
  },
  vfr: {
    fontSize: 11,
    color: colors.textFaint,
  },
  bellBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  bellBadge: {
    position: 'absolute',
    top: 7,
    right: 7,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.danger,
    borderWidth: 1.5,
    borderColor: '#fff',
  },
});
