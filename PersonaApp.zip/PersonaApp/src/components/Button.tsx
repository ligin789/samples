import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleProp,
  StyleSheet,
  Text,
  View,
  ViewStyle,
} from 'react-native';
import { colors } from '../theme';

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost' | 'success';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps {
  label: string;
  onPress?: () => void;
  variant?: Variant;
  size?: Size;
  disabled?: boolean;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

const variantStyles: Record<Variant, { bg: string; color: string; border?: string }> = {
  primary: { bg: colors.accent, color: '#fff' },
  secondary: { bg: '#fff', color: colors.text, border: colors.border },
  danger: { bg: colors.danger, color: '#fff' },
  ghost: { bg: 'transparent', color: colors.textSubtle },
  success: { bg: colors.success, color: '#fff' },
};

const sizeStyles: Record<Size, { padV: number; padH: number; font: number }> = {
  sm: { padV: 6, padH: 14, font: 12 },
  md: { padV: 9, padH: 18, font: 13 },
  lg: { padV: 11, padH: 22, font: 14 },
};

export const Button: React.FC<ButtonProps> = ({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled,
  loading,
  leftIcon,
  style,
}) => {
  const v = variantStyles[variant];
  const s = sizeStyles[size];

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.base,
        {
          backgroundColor: v.bg,
          paddingVertical: s.padV,
          paddingHorizontal: s.padH,
          borderWidth: v.border ? 1.5 : 0,
          borderColor: v.border,
          opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={v.color} size="small" />
      ) : (
        <View style={styles.row}>
          {leftIcon}
          <Text
            style={[
              styles.label,
              { color: v.color, fontSize: s.font, marginLeft: leftIcon ? 6 : 0 },
            ]}
          >
            {label}
          </Text>
        </View>
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  base: {
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  label: {
    fontWeight: '600',
  },
});
