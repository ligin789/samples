import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {
  getPriorityColor,
  getSeverityColor,
  getStatusColor,
} from '../utils/statusColors';

interface BadgeProps {
  value: string;
}

export const StatusBadge: React.FC<BadgeProps> = ({ value }) => {
  const c = getStatusColor(value);
  return (
    <View style={[styles.statusPill, { backgroundColor: c.bg }]}>
      <View style={[styles.dot, { backgroundColor: c.dot }]} />
      <Text style={[styles.statusText, { color: c.color }]}>{value}</Text>
    </View>
  );
};

export const PriorityBadge: React.FC<BadgeProps> = ({ value }) => {
  const c = getPriorityColor(value);
  return (
    <View style={[styles.solidPill, { backgroundColor: c.bg }]}>
      <Text style={[styles.solidText, { color: c.color }]}>
        {value.toUpperCase()}
      </Text>
    </View>
  );
};

export const SeverityBadge: React.FC<BadgeProps> = ({ value }) => {
  const c = getSeverityColor(value);
  return (
    <View style={[styles.solidPill, { backgroundColor: c.bg }]}>
      <Text style={[styles.solidText, { color: c.color }]}>
        {value.toUpperCase()}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 5,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  solidPill: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
  },
  solidText: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});
