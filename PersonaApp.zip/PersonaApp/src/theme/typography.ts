import { Platform } from 'react-native';

export const fontFamilies = {
  sans: Platform.select({
    ios: 'IBM Plex Sans',
    android: 'sans-serif',
    default: 'System',
  })!,
  mono: Platform.select({
    ios: 'IBM Plex Mono',
    android: 'monospace',
    default: 'Menlo',
  })!,
};

export const fontSizes = {
  xxs: 9,
  xs: 10,
  sm: 11,
  base: 12,
  md: 13,
  lg: 14,
  xl: 15,
  xxl: 16,
  title: 18,
  heading: 20,
  hero: 22,
  display: 26,
} as const;

export const fontWeights = {
  regular: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
  black: '800' as const,
};
