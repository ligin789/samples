export const colors = {
  accent: '#059669',
  accentDark: '#047857',
  accentSoft: '#ECFDF5',

  bg: '#F0F4FA',
  surface: '#FFFFFF',
  surfaceAlt: '#F8FAFC',

  text: '#0F172A',
  textMuted: '#475569',
  textSubtle: '#64748B',
  textFaint: '#94A3B8',

  border: '#E2E8F0',
  borderSoft: '#F1F5F9',
  divider: '#F8FAFC',

  success: '#10B981',
  successDeep: '#059669',
  info: '#3B82F6',
  infoDeep: '#2563EB',
  warn: '#F59E0B',
  warnDeep: '#D97706',
  danger: '#EF4444',
  dangerDeep: '#DC2626',
  purple: '#7C3AED',
  purpleDeep: '#9333EA',

  heroStart: '#0D1B2A',
  heroMid: '#1a3554',
  mapBgStart: '#0f2744',
  mapBgEnd: '#060d1a',

  white: '#FFFFFF',
  black: '#000000',
} as const;

export type Colors = typeof colors;
