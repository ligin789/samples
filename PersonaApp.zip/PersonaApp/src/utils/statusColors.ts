export interface StatusPalette {
  bg: string;
  color: string;
  dot: string;
}

const STATUS_MAP: Record<string, StatusPalette> = {
  Ready: { bg: '#ECFDF5', color: '#059669', dot: '#10B981' },
  'In Progress': { bg: '#EFF6FF', color: '#2563EB', dot: '#3B82F6' },
  Pending: { bg: '#FFFBEB', color: '#D97706', dot: '#F59E0B' },
  Completed: { bg: '#F0FDF4', color: '#16A34A', dot: '#22C55E' },
  Delayed: { bg: '#FEF2F2', color: '#DC2626', dot: '#EF4444' },
  Charging: { bg: '#EFF6FF', color: '#2563EB', dot: '#3B82F6' },
  Cleaning: { bg: '#F0F9FF', color: '#0369A1', dot: '#38BDF8' },
  Boarding: { bg: '#FDF4FF', color: '#9333EA', dot: '#A855F7' },
  Maintenance: { bg: '#FEF2F2', color: '#DC2626', dot: '#EF4444' },
  Inspection: { bg: '#FFFBEB', color: '#D97706', dot: '#F59E0B' },
  Active: { bg: '#ECFDF5', color: '#059669', dot: '#10B981' },
  Upcoming: { bg: '#EFF6FF', color: '#2563EB', dot: '#3B82F6' },
  Open: { bg: '#FEF2F2', color: '#DC2626', dot: '#EF4444' },
  'Under Review': { bg: '#FFFBEB', color: '#D97706', dot: '#F59E0B' },
  Resolved: { bg: '#ECFDF5', color: '#059669', dot: '#10B981' },
  Escalated: { bg: '#FDF4FF', color: '#9333EA', dot: '#A855F7' },
  'In Flight': { bg: '#EFF6FF', color: '#2563EB', dot: '#3B82F6' },
  Scheduled: { bg: '#F8FAFC', color: '#64748B', dot: '#94A3B8' },
  Landed: { bg: '#ECFDF5', color: '#059669', dot: '#10B981' },
  Cancelled: { bg: '#FEF2F2', color: '#DC2626', dot: '#EF4444' },
};

export const getStatusColor = (status: string): StatusPalette =>
  STATUS_MAP[status] || { bg: '#F1F5F9', color: '#64748B', dot: '#94A3B8' };

export const getPriorityColor = (priority: string) => {
  const map: Record<string, { bg: string; color: string }> = {
    Critical: { bg: '#FDF4FF', color: '#9333EA' },
    High: { bg: '#FEF2F2', color: '#DC2626' },
    Medium: { bg: '#FFFBEB', color: '#D97706' },
    Low: { bg: '#F0F9FF', color: '#0369A1' },
  };
  return map[priority] || { bg: '#F1F5F9', color: '#64748B' };
};

export const getSeverityColor = (severity: string) => {
  const map: Record<string, { bg: string; color: string }> = {
    Critical: { bg: '#7C3AED', color: '#fff' },
    High: { bg: '#EF4444', color: '#fff' },
    Medium: { bg: '#F59E0B', color: '#1a1a1a' },
    Low: { bg: '#10B981', color: '#fff' },
  };
  return map[severity] || { bg: '#94A3B8', color: '#fff' };
};
