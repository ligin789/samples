import { useEffect, useState } from 'react';
import { Dimensions, ScaledSize } from 'react-native';

const MOBILE_BREAKPOINT = 768;

export interface Viewport {
  width: number;
  height: number;
  isMobile: boolean;
  isTablet: boolean;
  isLandscape: boolean;
}

const toViewport = ({ width, height }: { width: number; height: number }): Viewport => ({
  width,
  height,
  isMobile: width < MOBILE_BREAKPOINT,
  isTablet: width >= MOBILE_BREAKPOINT,
  isLandscape: width > height,
});

export const useViewport = (): Viewport => {
  const [vp, setVp] = useState<Viewport>(() => toViewport(Dimensions.get('window')));

  useEffect(() => {
    const handler = ({ window }: { window: ScaledSize }) => setVp(toViewport(window));
    const sub = Dimensions.addEventListener('change', handler);
    return () => sub.remove();
  }, []);

  return vp;
};
