import { AppThunk } from '../store';
import { AIRCRAFT, INCIDENTS, SHIFTS, TASKS } from '../../data/mockData';
import { fetchFailure, fetchStart, fetchSuccess } from './slice';

export const fetchDashboardData = (): AppThunk => async dispatch => {
  dispatch(fetchStart());
  try {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 400));
    dispatch(
      fetchSuccess({
        tasks: TASKS,
        aircraft: AIRCRAFT,
        shifts: SHIFTS,
        incidents: INCIDENTS,
      }),
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to load dashboard data';
    dispatch(fetchFailure(message));
  }
};
