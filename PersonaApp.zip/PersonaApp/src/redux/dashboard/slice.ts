import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Task, Aircraft, Shift, Incident } from '../../data/mockData';

export interface DashboardData {
  tasks: Task[];
  aircraft: Aircraft[];
  shifts: Shift[];
  incidents: Incident[];
}

export interface DashboardState {
  loading: boolean;
  error: string | null;
  data: DashboardData | null;
  lastUpdated: number | null;
}

const initialState: DashboardState = {
  loading: false,
  error: null,
  data: null,
  lastUpdated: null,
};

const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    fetchStart: state => {
      state.loading = true;
      state.error = null;
    },
    fetchSuccess: (state, action: PayloadAction<DashboardData>) => {
      state.loading = false;
      state.data = action.payload;
      state.lastUpdated = Date.now();
    },
    fetchFailure: (state, action: PayloadAction<string>) => {
      state.loading = false;
      state.error = action.payload;
    },
    toggleChecklistItem: (
      state,
      action: PayloadAction<{ taskId: string; itemId: number }>,
    ) => {
      if (!state.data) return;
      const task = state.data.tasks.find(t => t.id === action.payload.taskId);
      if (!task) return;
      const item = task.checklist.find(c => c.id === action.payload.itemId);
      if (item) item.done = !item.done;
    },
    updateTaskStatus: (
      state,
      action: PayloadAction<{ taskId: string; status: Task['status'] }>,
    ) => {
      if (!state.data) return;
      const task = state.data.tasks.find(t => t.id === action.payload.taskId);
      if (task) task.status = action.payload.status;
    },
  },
});

export const {
  fetchStart,
  fetchSuccess,
  fetchFailure,
  toggleChecklistItem,
  updateTaskStatus,
} = dashboardSlice.actions;

export default dashboardSlice.reducer;
