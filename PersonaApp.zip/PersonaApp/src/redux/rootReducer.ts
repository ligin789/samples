import { combineReducers } from 'redux';
import dashboardReducer from './dashboard/slice';

export const rootReducer = combineReducers({
  dashboard: dashboardReducer,
});

export type RootState = ReturnType<typeof rootReducer>;
