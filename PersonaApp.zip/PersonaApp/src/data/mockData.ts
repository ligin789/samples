export interface ChecklistItem {
  id: number;
  label: string;
  done: boolean;
}

export interface Task {
  id: string;
  aircraft: string;
  type: string;
  staff: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Pending' | 'In Progress' | 'Completed' | 'Delayed';
  time: string;
  endTime: string;
  gate: string;
  notes: string;
  checklist: ChecklistItem[];
}

export interface Aircraft {
  id: string;
  model: string;
  battery: number;
  status: string;
  gate: string;
  departure: string;
  arrival: string;
  flights: number;
}

export interface Shift {
  id: number;
  name: string;
  role: string;
  start: string;
  end: string;
  status: 'Active' | 'Upcoming' | 'Completed';
  tasks: number;
  avatar: string;
  color: string;
}

export interface Incident {
  id: string;
  aircraft: string;
  location: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  reportedBy: string;
  date: string;
  status: 'Open' | 'Under Review' | 'Resolved' | 'Escalated';
  description: string;
}

export interface Message {
  id: number;
  sender: string;
  avatar?: string;
  color?: string;
  text: string;
  time: string;
  sent?: boolean;
  system?: boolean;
}

export interface Conversation {
  id: string;
  name: string;
  type: 'group' | 'dm';
  avatar: string;
  color: string;
  subtitle: string;
  online: boolean | number;
  unread: number;
  messages: Message[];
  replies: string[];
}

export interface Flight {
  id: string;
  aircraft: string;
  model: string;
  from: string;
  to: string;
  dep: string;
  arr: string;
  status: 'In Flight' | 'Boarding' | 'Scheduled' | 'Landed' | 'Cancelled';
  pax: number;
  pilot: string;
  progress: number;
}

export interface Vertiport {
  code: string;
  name: string;
  x: number;
  y: number;
  city: string;
}

export const TASKS: Task[] = [
  {
    id: 'TSK-001', aircraft: 'EVT-001', type: 'Refueling', staff: 'J. Martinez',
    priority: 'High', status: 'In Progress', time: '08:30', gate: 'G-01', endTime: '09:00',
    notes: 'Standard fuel top-up before next departure.',
    checklist: [
      { id: 1, label: 'Connect fuel line to port A', done: true },
      { id: 2, label: 'Verify fuel type — JP-1 Electric Hybrid', done: true },
      { id: 3, label: 'Monitor flow rate — max 40L/min', done: false },
      { id: 4, label: 'Confirm 87% target capacity reached', done: false },
      { id: 5, label: 'Disconnect and seal fuel port', done: false },
      { id: 6, label: 'Log refuel in system', done: false },
    ],
  },
  {
    id: 'TSK-002', aircraft: 'EVT-002', type: 'Battery Charging', staff: 'A. Chen',
    priority: 'Critical', status: 'Pending', time: '09:00', gate: 'G-02', endTime: '10:30',
    notes: 'Battery at 12%, urgent charge required before next flight.',
    checklist: [
      { id: 1, label: 'Connect Level 3 charging cable', done: false },
      { id: 2, label: 'Confirm BMS handshake — green', done: false },
      { id: 3, label: 'Set charge rate to 2C', done: false },
      { id: 4, label: 'Monitor cell temperature < 35°C', done: false },
      { id: 5, label: 'Alert ops when 80% reached', done: false },
      { id: 6, label: 'Disconnect and log charge cycle', done: false },
    ],
  },
  {
    id: 'TSK-003', aircraft: 'EVT-003', type: 'Cleaning', staff: 'M. Williams',
    priority: 'Medium', status: 'Completed', time: '07:45', gate: 'G-04', endTime: '08:20',
    notes: 'Full cabin cleaning post-arrival.',
    checklist: [
      { id: 1, label: 'Remove passenger items & lost property', done: true },
      { id: 2, label: 'Vacuum cabin floor and seats', done: true },
      { id: 3, label: 'Wipe all touch surfaces with disinfectant', done: true },
      { id: 4, label: 'Replace headrest covers', done: true },
      { id: 5, label: 'Clean windows (interior)', done: true },
      { id: 6, label: 'Restock safety cards and literature', done: true },
    ],
  },
  {
    id: 'TSK-004', aircraft: 'EVT-004', type: 'Safety Inspection', staff: 'R. Johnson',
    priority: 'Critical', status: 'In Progress', time: '08:00', gate: 'G-06', endTime: '08:45',
    notes: 'Pre-departure safety check — rotor and avionics systems.',
    checklist: [
      { id: 1, label: 'Visually inspect all 6 rotors', done: true },
      { id: 2, label: 'Check rotor blade integrity — no chips/cracks', done: true },
      { id: 3, label: 'Avionics boot sequence — all green', done: false },
      { id: 4, label: 'GPS lock confirmed', done: false },
      { id: 5, label: 'Emergency parachute system armed', done: false },
      { id: 6, label: 'Sign off inspection sheet', done: false },
    ],
  },
  {
    id: 'TSK-005', aircraft: 'EVT-005', type: 'Boarding', staff: 'S. Park',
    priority: 'High', status: 'Pending', time: '09:30', gate: 'G-03', endTime: '09:50',
    notes: '6 passengers confirmed. VIP in row 1.',
    checklist: [
      { id: 1, label: 'Verify passenger manifest (6 pax)', done: false },
      { id: 2, label: 'ID check — all passengers', done: false },
      { id: 3, label: 'Weight & balance calculation confirmed', done: false },
      { id: 4, label: 'Brief passengers on safety procedures', done: false },
      { id: 5, label: 'Secure cabin door and seal', done: false },
      { id: 6, label: 'Notify pilot — clear for departure', done: false },
    ],
  },
  {
    id: 'TSK-006', aircraft: 'EVT-001', type: 'Gate Assignment', staff: 'L. Torres',
    priority: 'Low', status: 'Completed', time: '07:00', gate: 'G-01', endTime: '07:15',
    notes: 'Gate reassigned from G-07 due to construction.',
    checklist: [
      { id: 1, label: 'Check gate availability in system', done: true },
      { id: 2, label: 'Update gate display board', done: true },
      { id: 3, label: 'Notify ground crew of gate change', done: true },
      { id: 4, label: 'Update passenger notifications', done: true },
    ],
  },
  {
    id: 'TSK-007', aircraft: 'EVT-006', type: 'Maintenance Check', staff: 'K. Brown',
    priority: 'High', status: 'Delayed', time: '08:15', gate: 'MRO-1', endTime: '10:00',
    notes: 'Rotor system check — third-party MRO on-site.',
    checklist: [
      { id: 1, label: 'MRO team arrival confirmed', done: true },
      { id: 2, label: 'Aircraft power down — all systems off', done: true },
      { id: 3, label: 'Remove rotor assembly cover panels', done: false },
      { id: 4, label: 'MRO rotor bearing inspection', done: false },
      { id: 5, label: 'Vibration test post-reassembly', done: false },
      { id: 6, label: 'Airworthiness sign-off', done: false },
      { id: 7, label: 'Return to service log entry', done: false },
    ],
  },
  {
    id: 'TSK-008', aircraft: 'EVT-007', type: 'Refueling', staff: 'J. Martinez',
    priority: 'Medium', status: 'Pending', time: '10:00', gate: 'G-05', endTime: '10:30',
    notes: '',
    checklist: [
      { id: 1, label: 'Connect fuel line', done: false },
      { id: 2, label: 'Set target to 80% capacity', done: false },
      { id: 3, label: 'Monitor flow and temperature', done: false },
      { id: 4, label: 'Disconnect and log', done: false },
    ],
  },
  {
    id: 'TSK-009', aircraft: 'EVT-008', type: 'Battery Charging', staff: 'A. Chen',
    priority: 'Low', status: 'Completed', time: '06:30', gate: 'G-08', endTime: '08:00',
    notes: 'Overnight charge completed.',
    checklist: [
      { id: 1, label: 'Connect overnight charger', done: true },
      { id: 2, label: 'Set to 1C overnight rate', done: true },
      { id: 3, label: 'Confirm full charge (100%)', done: true },
      { id: 4, label: 'Disconnect and log', done: true },
    ],
  },
  {
    id: 'TSK-010', aircraft: 'EVT-003', type: 'Safety Inspection', staff: 'R. Johnson',
    priority: 'High', status: 'Completed', time: '07:00', gate: 'G-04', endTime: '07:40',
    notes: 'All systems nominal.',
    checklist: [
      { id: 1, label: 'Rotor inspection — all 6', done: true },
      { id: 2, label: 'Avionics check', done: true },
      { id: 3, label: 'Battery cell health check', done: true },
      { id: 4, label: 'Emergency systems test', done: true },
      { id: 5, label: 'Sign-off', done: true },
    ],
  },
];

export const AIRCRAFT: Aircraft[] = [
  { id: 'EVT-001', model: 'ePlane e200x', battery: 87, status: 'Ready', gate: 'G-01', departure: '10:30', arrival: '08:15', flights: 3 },
  { id: 'EVT-002', model: 'ePlane e200x Pro', battery: 12, status: 'Charging', gate: 'G-02', departure: '11:00', arrival: '09:00', flights: 2 },
  { id: 'EVT-003', model: 'ePlane e200x', battery: 100, status: 'Ready', gate: 'G-04', departure: '09:45', arrival: '07:30', flights: 4 },
  { id: 'EVT-004', model: 'ePlane e200x XL', battery: 74, status: 'Inspection', gate: 'G-06', departure: '10:15', arrival: '08:00', flights: 1 },
  { id: 'EVT-005', model: 'ePlane e200x Pro', battery: 95, status: 'Boarding', gate: 'G-03', departure: '09:30', arrival: '08:45', flights: 5 },
  { id: 'EVT-006', model: 'ePlane e200x Cargo', battery: 45, status: 'Maintenance', gate: 'MRO-1', departure: 'TBD', arrival: '07:00', flights: 0 },
  { id: 'EVT-007', model: 'ePlane e200x', battery: 68, status: 'Cleaning', gate: 'G-05', departure: '10:00', arrival: '08:30', flights: 2 },
  { id: 'EVT-008', model: 'ePlane e200x XL', battery: 100, status: 'Ready', gate: 'G-08', departure: '11:30', arrival: '09:15', flights: 3 },
  { id: 'EVT-009', model: 'ePlane e200x Cargo', battery: 55, status: 'Ready', gate: 'G-09', departure: '12:00', arrival: '10:00', flights: 1 },
];

export const SHIFTS: Shift[] = [
  { id: 1, name: 'James Martinez', role: 'Senior Ground Tech', start: '06:00', end: '14:00', status: 'Active', tasks: 3, avatar: 'JM', color: '#2563EB' },
  { id: 2, name: 'Alice Chen', role: 'Battery Specialist', start: '06:00', end: '14:00', status: 'Active', tasks: 2, avatar: 'AC', color: '#7C3AED' },
  { id: 3, name: 'Marcus Williams', role: 'Cabin Crew Lead', start: '07:00', end: '15:00', status: 'Active', tasks: 4, avatar: 'MW', color: '#059669' },
  { id: 4, name: 'Rachel Johnson', role: 'Safety Inspector', start: '06:00', end: '14:00', status: 'Active', tasks: 2, avatar: 'RJ', color: '#DC2626' },
  { id: 5, name: 'Sophie Park', role: 'Passenger Handler', start: '08:00', end: '16:00', status: 'Active', tasks: 1, avatar: 'SP', color: '#D97706' },
  { id: 6, name: 'Luis Torres', role: 'Gate Manager', start: '05:00', end: '13:00', status: 'Active', tasks: 5, avatar: 'LT', color: '#0891B2' },
  { id: 7, name: 'Kevin Brown', role: 'Maintenance Tech', start: '06:00', end: '14:00', status: 'Active', tasks: 1, avatar: 'KB', color: '#65A30D' },
  { id: 8, name: 'Nina Patel', role: 'Ground Tech', start: '14:00', end: '22:00', status: 'Upcoming', tasks: 0, avatar: 'NP', color: '#9333EA' },
  { id: 9, name: 'Omar Hassan', role: 'Battery Specialist', start: '14:00', end: '22:00', status: 'Upcoming', tasks: 0, avatar: 'OH', color: '#EA580C' },
  { id: 10, name: 'Priya Sharma', role: 'Safety Inspector', start: '22:00', end: '06:00', status: 'Upcoming', tasks: 0, avatar: 'PS', color: '#0D9488' },
  { id: 11, name: 'Tom Bradley', role: 'Gate Manager', start: '22:00', end: '06:00', status: 'Upcoming', tasks: 0, avatar: 'TB', color: '#B45309' },
  { id: 12, name: 'Diana Flores', role: 'Cabin Crew', start: '00:00', end: '08:00', status: 'Completed', tasks: 6, avatar: 'DF', color: '#6366F1' },
];

export const INCIDENTS: Incident[] = [
  { id: 'INC-001', aircraft: 'EVT-006', location: 'Gate MRO-1', severity: 'High', reportedBy: 'K. Brown', date: '2026-04-24 07:15', status: 'Open', description: 'Unusual vibration detected in rotor assembly during pre-flight check. Ground crew halted operation pending MRO inspection.' },
  { id: 'INC-002', aircraft: 'EVT-002', location: 'Gate G-02', severity: 'Medium', reportedBy: 'A. Chen', date: '2026-04-24 08:02', status: 'Under Review', description: 'Battery charging cable connector showing signs of wear. Replaced with backup unit, original sent for evaluation.' },
  { id: 'INC-003', aircraft: 'EVT-004', location: 'Gate G-06', severity: 'Low', reportedBy: 'R. Johnson', date: '2026-04-24 08:20', status: 'Resolved', description: 'Minor surface scratch on fuselage panel, cosmetic only. Documented per protocol.' },
  { id: 'INC-004', aircraft: 'EVT-001', location: 'Taxiway B', severity: 'Critical', reportedBy: 'L. Torres', date: '2026-04-23 22:45', status: 'Escalated', description: 'Aircraft taxi guidance system unresponsive during pushback. Operations halted. Safety team and OEM notified.' },
  { id: 'INC-005', aircraft: 'EVT-007', location: 'Gate G-05', severity: 'Low', reportedBy: 'M. Williams', date: '2026-04-23 19:30', status: 'Resolved', description: 'Cleaning supply spill in cabin area. Cleaned and documented. No damage to aircraft systems.' },
];

export const MESSAGES: Message[] = [
  { id: 1, sender: 'Luis Torres', avatar: 'LT', color: '#0891B2', text: 'EVT-001 is ready for departure at G-01. Docs confirmed and signed.', time: '08:12', sent: false },
  { id: 2, sender: 'Me', text: 'Copy that. Departure clearance issued. Stand by for pushback signal.', time: '08:13', sent: true },
  { id: 3, sender: 'Rachel Johnson', avatar: 'RJ', color: '#DC2626', text: 'Safety inspection for EVT-004 in progress. ETA 20 mins to clear.', time: '08:15', sent: false },
  { id: 4, sender: 'System', text: 'ALERT: INC-004 escalated to Critical — Taxiway B guidance failure', time: '08:18', system: true },
  { id: 5, sender: 'Alice Chen', avatar: 'AC', color: '#7C3AED', text: 'EVT-002 charging at 2C rate. Estimated full charge by 09:45.', time: '08:22', sent: false },
  { id: 6, sender: 'Me', text: 'Alice — flag if it drops below 2C. We need that bird airworthy by 11:00.', time: '08:24', sent: true },
];

export const CONVERSATIONS: Conversation[] = [
  {
    id: 'group-all', name: 'All Ops — Ground Team', type: 'group',
    avatar: 'GT', color: '#7C3AED', subtitle: 'All ground handlers',
    online: 7, unread: 2, messages: MESSAGES,
    replies: ['Copy that, standing by.', 'On it.', 'Acknowledged.'],
  },
  {
    id: 'group-safety', name: 'Safety & Incidents', type: 'group',
    avatar: 'SI', color: '#DC2626', subtitle: 'Safety team · R. Johnson, K. Brown +2',
    online: 3, unread: 1,
    messages: [
      { id: 1, sender: 'Rachel Johnson', avatar: 'RJ', color: '#DC2626', text: 'Safety inspection on EVT-004 in progress. Rotor clearance nominal.', time: '08:05', sent: false },
      { id: 2, sender: 'Kevin Brown', avatar: 'KB', color: '#65A30D', text: 'MRO tech arrived for EVT-006 rotor check. ETA 90 mins.', time: '08:10', sent: false },
      { id: 3, sender: 'System', text: 'INC-001 status updated — Under Review', time: '08:12', system: true },
      { id: 4, sender: 'Me', text: 'Kevin — keep me posted every 30. We need that bird by 12:00.', time: '08:14', sent: true },
      { id: 5, sender: 'Kevin Brown', avatar: 'KB', color: '#65A30D', text: 'Understood. Will check in at 08:45.', time: '08:15', sent: false },
    ],
    replies: ['Understood.', 'Will update in 30 mins.', 'On my way.'],
  },
  {
    id: 'dm-luis', name: 'Luis Torres', type: 'dm',
    avatar: 'LT', color: '#0891B2', subtitle: 'Gate Manager · Active now',
    online: true, unread: 0,
    messages: [
      { id: 1, sender: 'Luis Torres', avatar: 'LT', color: '#0891B2', text: 'Good morning — all gates checked and clear. G-07 is closed for maintenance today.', time: '06:15', sent: false },
      { id: 2, sender: 'Me', text: 'Morning Luis. Noted on G-07. Reroute EVT-001 to G-01 if needed.', time: '06:18', sent: true },
      { id: 3, sender: 'Luis Torres', avatar: 'LT', color: '#0891B2', text: 'EVT-001 is ready for departure at G-01. Docs confirmed and signed.', time: '08:12', sent: false },
      { id: 4, sender: 'Me', text: 'Copy that. Departure clearance issued. Stand by for pushback signal.', time: '08:13', sent: true },
    ],
    replies: ['Got it, thanks.', 'Copy that.', 'Please confirm when done.'],
  },
  {
    id: 'dm-alice', name: 'Alice Chen', type: 'dm',
    avatar: 'AC', color: '#7C3AED', subtitle: 'Battery Specialist · Active now',
    online: true, unread: 1,
    messages: [
      { id: 1, sender: 'Alice Chen', avatar: 'AC', color: '#7C3AED', text: 'EVT-002 battery at 12% — starting 2C charge cycle now.', time: '08:02', sent: false },
      { id: 2, sender: 'Me', text: 'Alice — flag if it drops below 2C. We need that bird airworthy by 11:00.', time: '08:04', sent: true },
      { id: 3, sender: 'Alice Chen', avatar: 'AC', color: '#7C3AED', text: 'EVT-002 charging at 2C rate. Estimated full charge by 09:45.', time: '08:22', sent: false },
    ],
    replies: ['Great, thanks Alice.', 'Keep me posted.', 'Perfect timing.'],
  },
  {
    id: 'dm-rachel', name: 'Rachel Johnson', type: 'dm',
    avatar: 'RJ', color: '#DC2626', subtitle: 'Safety Inspector · Active now',
    online: true, unread: 0,
    messages: [
      { id: 1, sender: 'Rachel Johnson', avatar: 'RJ', color: '#DC2626', text: 'Safety inspection for EVT-004 in progress. ETA 20 mins to clear.', time: '08:15', sent: false },
      { id: 2, sender: 'Me', text: 'Roger that. Hold departure until you give the all-clear.', time: '08:16', sent: true },
      { id: 3, sender: 'Rachel Johnson', avatar: 'RJ', color: '#DC2626', text: 'All clear on EVT-004. Avionics and rotor both nominal. Cleared for departure.', time: '08:38', sent: false },
    ],
    replies: ['Thanks Rachel.', 'Departure clearance issued.', 'Copy.'],
  },
  {
    id: 'dm-james', name: 'James Martinez', type: 'dm',
    avatar: 'JM', color: '#2563EB', subtitle: 'Senior Ground Tech · Active now',
    online: true, unread: 0,
    messages: [
      { id: 1, sender: 'James Martinez', avatar: 'JM', color: '#2563EB', text: 'Refueling on EVT-001 complete. 87% capacity confirmed.', time: '07:55', sent: false },
      { id: 2, sender: 'Me', text: 'Thanks James. Move to EVT-007 next — departs at 10:00.', time: '07:57', sent: true },
      { id: 3, sender: 'James Martinez', avatar: 'JM', color: '#2563EB', text: 'On it. EVT-007 refuel starting now at G-05.', time: '08:01', sent: false },
    ],
    replies: ['Copy that.', 'Good work.', 'Roger.'],
  },
  {
    id: 'dm-marcus', name: 'Marcus Williams', type: 'dm',
    avatar: 'MW', color: '#059669', subtitle: 'Cabin Crew Lead · Active now',
    online: true, unread: 0,
    messages: [
      { id: 1, sender: 'Marcus Williams', avatar: 'MW', color: '#059669', text: 'Cabin cleaning on EVT-003 done. Ready for boarding check.', time: '08:22', sent: false },
      { id: 2, sender: 'Me', text: 'Great. Boarding starts at 09:15 — 6 pax confirmed.', time: '08:24', sent: true },
    ],
    replies: ['Got it.', 'Ready when you are.', 'Understood.'],
  },
];

export const VERTIPORTS: Record<string, Vertiport> = {
  VPA: { name: 'VTOL-PORT ALPHA', code: 'VPA', x: 72, y: 68, city: 'South Hub' },
  VPB: { name: 'VTOL-PORT BETA', code: 'VPB', x: 38, y: 28, city: 'Midtown' },
  VPC: { name: 'VTOL-PORT GAMMA', code: 'VPC', x: 18, y: 58, city: 'West Hub' },
  VPD: { name: 'VTOL-PORT DELTA', code: 'VPD', x: 58, y: 18, city: 'North Hub' },
  VPE: { name: 'VTOL-PORT EPSILON', code: 'VPE', x: 82, y: 38, city: 'East Hub' },
};

export const FLIGHTS: Flight[] = [
  { id: 'GH-101', aircraft: 'EVT-003', model: 'ePlane e200x', from: 'VPA', to: 'VPB', dep: '08:15', arr: '08:38', status: 'In Flight', pax: 4, pilot: 'A. Reeves', progress: 0.58 },
  { id: 'GH-102', aircraft: 'EVT-005', model: 'ePlane e200x Pro', from: 'VPA', to: 'VPC', dep: '09:30', arr: '09:58', status: 'Boarding', pax: 6, pilot: 'S. Park', progress: 0 },
  { id: 'GH-103', aircraft: 'EVT-001', model: 'ePlane e200x', from: 'VPD', to: 'VPA', dep: '10:30', arr: '10:52', status: 'Scheduled', pax: 5, pilot: 'T. Bradley', progress: 0 },
  { id: 'GH-104', aircraft: 'EVT-008', model: 'ePlane e200x XL', from: 'VPB', to: 'VPD', dep: '07:45', arr: '08:10', status: 'Landed', pax: 3, pilot: 'D. Flores', progress: 1 },
  { id: 'GH-105', aircraft: 'EVT-002', model: 'ePlane e200x Pro', from: 'VPA', to: 'VPE', dep: '11:00', arr: '11:18', status: 'Scheduled', pax: 2, pilot: 'N. Patel', progress: 0 },
  { id: 'GH-106', aircraft: 'EVT-007', model: 'ePlane e200x', from: 'VPC', to: 'VPA', dep: '09:00', arr: '09:28', status: 'In Flight', pax: 5, pilot: 'O. Hassan', progress: 0.38 },
  { id: 'GH-107', aircraft: 'EVT-009', model: 'ePlane e200x Cargo', from: 'VPE', to: 'VPB', dep: '07:00', arr: '07:22', status: 'Landed', pax: 1, pilot: 'P. Sharma', progress: 1 },
  { id: 'GH-108', aircraft: 'EVT-004', model: 'ePlane e200x XL', from: 'VPA', to: 'VPD', dep: '12:00', arr: '12:18', status: 'Cancelled', pax: 4, pilot: 'R. Johnson', progress: 0 },
];
