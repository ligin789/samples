import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Avatar,
  BottomSheet,
  BottomTabBar,
  Header,
  Icon,
  IconName,
  TabItem,
} from '../components';
import { ChatScreen } from '../screens/ChatScreen';
import { DashboardScreen } from '../screens/DashboardScreen';
import { FlightsScreen } from '../screens/FlightsScreen';
import { SafetyScreen } from '../screens/SafetyScreen';
import { TasksScreen } from '../screens/TasksScreen';
import { colors, fontFamilies, radius, spacing } from '../theme';
import { useViewport } from '../utils/responsive';
import { TAB_TITLES, TabId } from './types';

const TABS: TabItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'tasks', label: 'Tasks', icon: 'tasks', badge: 3 },
  { id: 'flights', label: 'Flights', icon: 'aircraft' },
  { id: 'safety', label: 'Safety', icon: 'incidents', badge: 1 },
  { id: 'chat', label: 'Chat', icon: 'chat', badge: 2 },
];

interface Notification {
  id: string;
  icon: IconName;
  iconColor: string;
  iconBg: string;
  title: string;
  body: string;
  time: string;
  unread: boolean;
}

const NOTIFICATIONS: Notification[] = [
  {
    id: 'n1',
    icon: 'incidents',
    iconColor: '#fff',
    iconBg: colors.purple,
    title: 'Critical incident escalated',
    body: 'INC-004 — Taxiway B guidance system failure. Operations team notified.',
    time: '08:18',
    unread: true,
  },
  {
    id: 'n2',
    icon: 'aircraft',
    iconColor: colors.infoDeep,
    iconBg: '#EFF6FF',
    title: 'EVT-002 battery low',
    body: 'Battery at 12% — charge cycle started by A. Chen.',
    time: '08:02',
    unread: true,
  },
  {
    id: 'n3',
    icon: 'tasks',
    iconColor: colors.accent,
    iconBg: colors.accentSoft,
    title: 'Task TSK-003 completed',
    body: 'Cabin cleaning on EVT-003 finished. Ready for boarding.',
    time: '08:20',
    unread: true,
  },
  {
    id: 'n4',
    icon: 'shifts',
    iconColor: colors.warnDeep,
    iconBg: '#FFFBEB',
    title: 'Shift starting soon',
    body: 'N. Patel begins shift in 30 min — handover EVT-007 refuel.',
    time: '07:45',
    unread: false,
  },
  {
    id: 'n5',
    icon: 'chat',
    iconColor: colors.purpleDeep,
    iconBg: '#FDF4FF',
    title: 'New message — Safety & Incidents',
    body: 'Kevin Brown: MRO tech arrived for EVT-006 rotor check.',
    time: '08:10',
    unread: false,
  },
];

const renderScreen = (tab: TabId) => {
  switch (tab) {
    case 'dashboard':
      return <DashboardScreen />;
    case 'tasks':
      return <TasksScreen />;
    case 'flights':
      return <FlightsScreen />;
    case 'safety':
      return <SafetyScreen />;
    case 'chat':
      return <ChatScreen />;
  }
};

const NotificationRow: React.FC<{ notif: Notification }> = ({ notif }) => (
  <View style={[rowStyles.row, notif.unread ? rowStyles.rowUnread : null]}>
    <View style={[rowStyles.icon, { backgroundColor: notif.iconBg }]}>
      <Icon name={notif.icon} size={16} color={notif.iconColor} />
    </View>
    <View style={{ flex: 1 }}>
      <View style={rowStyles.topRow}>
        <Text style={rowStyles.title} numberOfLines={1}>
          {notif.title}
        </Text>
        <Text style={rowStyles.time}>{notif.time}</Text>
      </View>
      <Text style={rowStyles.body} numberOfLines={2}>
        {notif.body}
      </Text>
    </View>
    {notif.unread ? <View style={rowStyles.unreadDot} /> : null}
  </View>
);

const ProfileMenu: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const items: Array<{ icon: IconName; label: string; onPress: () => void; danger?: boolean }> = [
    {
      icon: 'user',
      label: 'View profile',
      onPress: () => Alert.alert('Profile', 'Operations Controller'),
    },
    {
      icon: 'settings',
      label: 'Settings',
      onPress: () => Alert.alert('Settings', 'Settings screen coming soon'),
    },
    {
      icon: 'x',
      label: 'Log out',
      onPress: () => {
        onClose();
        Alert.alert('Logged out', 'You have been signed out.');
      },
      danger: true,
    },
  ];

  return (
    <View>
      <View style={profileStyles.header}>
        <Avatar initials="OC" color={colors.accent} size={64} />
        <Text style={profileStyles.name}>Operations Controller</Text>
        <Text style={profileStyles.email}>controller@vtolport.ops</Text>
        <View style={profileStyles.roleBadge}>
          <View style={profileStyles.liveDot} />
          <Text style={profileStyles.roleText}>On duty · VTOL-PORT ALPHA</Text>
        </View>
      </View>

      <View style={profileStyles.menu}>
        {items.map(item => (
          <Pressable
            key={item.label}
            style={profileStyles.menuItem}
            onPress={() => {
              item.onPress();
              if (!item.danger) onClose();
            }}
          >
            <View
              style={[
                profileStyles.menuIcon,
                item.danger ? profileStyles.menuIconDanger : null,
              ]}
            >
              <Icon
                name={item.icon}
                size={16}
                color={item.danger ? colors.danger : colors.textSubtle}
              />
            </View>
            <Text
              style={[
                profileStyles.menuLabel,
                item.danger ? profileStyles.menuLabelDanger : null,
              ]}
            >
              {item.label}
            </Text>
            <Icon name="chevronRight" size={14} color={colors.textFaint} />
          </Pressable>
        ))}
      </View>
    </View>
  );
};

export const AppNavigator: React.FC = () => {
  const [tab, setTab] = useState<TabId>('dashboard');
  const [showNotifs, setShowNotifs] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const { isMobile } = useViewport();

  const unreadCount = NOTIFICATIONS.filter(n => n.unread).length;

  return (
    <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
      <Header
        title={TAB_TITLES[tab]}
        isMobile={isMobile}
        onNotificationsPress={() => setShowNotifs(true)}
        onProfilePress={() => setShowProfile(true)}
      />
      <View style={styles.content}>{renderScreen(tab)}</View>
      <BottomTabBar active={tab} tabs={TABS} onChange={setTab} isMobile={isMobile} />

      <BottomSheet
        visible={showNotifs}
        title={unreadCount > 0 ? `Notifications (${unreadCount})` : 'Notifications'}
        onClose={() => setShowNotifs(false)}
      >
        <ScrollView>
          {NOTIFICATIONS.map(n => (
            <NotificationRow key={n.id} notif={n} />
          ))}
        </ScrollView>
      </BottomSheet>

      <BottomSheet
        visible={showProfile}
        title="Profile"
        onClose={() => setShowProfile(false)}
      >
        <ProfileMenu onClose={() => setShowProfile(false)} />
      </BottomSheet>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  content: { flex: 1 },
});

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
    paddingVertical: 12,
    paddingHorizontal: 4,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  rowUnread: { backgroundColor: '#FAFBFF' },
  icon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 8,
    marginBottom: 3,
  },
  title: { flex: 1, fontSize: 13, fontWeight: '700', color: colors.text },
  time: { fontSize: 11, color: colors.textFaint, fontFamily: fontFamilies.mono },
  body: { fontSize: 12, color: colors.textSubtle, lineHeight: 17 },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 999,
    backgroundColor: colors.accent,
    marginTop: 14,
  },
});

const profileStyles = StyleSheet.create({
  header: {
    alignItems: 'center',
    paddingVertical: spacing.xxl,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderSoft,
    gap: 8,
  },
  name: { fontSize: 18, fontWeight: '700', color: colors.text, marginTop: 4 },
  email: { fontSize: 13, color: colors.textSubtle, fontFamily: fontFamilies.mono },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.accentSoft,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: radius.pill,
    marginTop: 4,
  },
  liveDot: { width: 7, height: 7, borderRadius: 999, backgroundColor: colors.success },
  roleText: { fontSize: 12, color: colors.successDeep, fontWeight: '600' },
  menu: { paddingTop: spacing.base },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 14,
    paddingHorizontal: 4,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  menuIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuIconDanger: { backgroundColor: '#FEF2F2' },
  menuLabel: { flex: 1, fontSize: 14, color: colors.text, fontWeight: '500' },
  menuLabelDanger: { color: colors.danger },
});
