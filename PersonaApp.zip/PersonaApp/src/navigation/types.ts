export type TabId = 'dashboard' | 'tasks' | 'flights' | 'safety' | 'chat';

export const TAB_TITLES: Record<TabId, string> = {
  dashboard: 'Operations Dashboard',
  tasks: 'My Tasks',
  flights: 'Flight Operations',
  safety: 'Safety & Reports',
  chat: 'Team Chat',
};
