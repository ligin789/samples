import { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import '../App.css'
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'

function MenuPage() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    axios
      .get("https://www.themealdb.com/api/json/v1/1/categories.php")
      .then((response) => setCategories(response.data.categories));
  }, []);

  return (
    <div className="container-fluid mt-5">
            <h1 className="text-center m-5">Menu</h1>

      {categories.length > 0 ?  <ul className="d-flex justify-content-around flex-wrap mt-5">
        {categories.map((category) => (
          <Link className="text-decoration-none " to={`/meals/${category?.strCategory}`}>
            <div
              className="card mealAppBox m-2 "
              key={category.idCategory}
            >
              <img
                className="card-img-top"
                src={category?.strCategoryThumb}
                alt="Card image cap"
                width={200}
              />
              <div className="card-body mx-auto">
                <h5 className="card-title" >
                  {category?.strCategory}
                </h5>
              </div>
            </div>
          </Link>
        ))}
      </ul> :  <Skeleton height={1000} count={2} >
        </Skeleton>}
     
     
    </div>
  );
}

export default MenuPage;
