import {  useEffect } from 'react';
import { useFavourites } from '../components/ContextApi';
import MealCard from '../components/MealCard';

function FavoritesPage() {
const {favourites,addFavourite,removeFavourite}=useFavourites();
  useEffect(() => {
    // Load favorites from local storage or backend here
  }, []);

  const handleRemove = (id:string) => {
    // Remove from favorites and update state here
    removeFavourite(id)
  };
  const handleAdd = () => {
    // Remove from favorites and update state here
    addFavourite(newItem)
  };

  return (
    <div className='container'>
      <h1 className="text-center m-5">My Favorites</h1>
      <div className='container-fluid'>
      <div className='d-flex justify-content-around flex-wrap'>
        {favourites.map(meal => (
          <MealCard key={meal.idMeal} meal={meal} />
        ))}
      </div>
    </div>
      

    </div>
  );
}

export default FavoritesPage;
