import { useState, useEffect } from "react";
import axios from "axios";
import { useFavourites } from "../components/ContextApi";

function RandomMealPage() {
  const [meal, setMeal] = useState(null);
  const { favourites, addFavourite, removeFavourite } = useFavourites();
  const [fav,setFav]=useState(false);

  const fetchRandomMeal = () => {
    axios
      .get("https://www.themealdb.com/api/json/v1/1/random.php")
      .then((response) => setMeal(response.data.meals[0]));
  };
  const addFavourites = () => {
    if (!checkexistInFav(favourites, meal)) {
      addFavourite(meal);
      setFav(true)
    } else {
      removeFavourite(meal.idMeal);
      setFav(false)
    }
  };
  const checkexistInFav = (favourites: FavouriteItem[], meal: any) => {
    return favourites.some((item) => item.idMeal === meal.idMeal);
  };
  useEffect(() => {
    fetchRandomMeal();
    
  }, []);
  useEffect(()=>
  {
    if(meal!==null)
    {
      setFav(checkexistInFav(favourites, meal))
    }
  },[meal])

  return (
    <div className="container">
      <h1 className="text-center m-5">Random Meal Generator</h1>
      {meal && (
        <div className="card m-auto p-3 " style={{ width: "30rem" }}>
          <img
            src={meal.strMealThumb}
            alt={meal.strMeal}
            className="card-img-top"
          />
          <div className="card-body">
            <h5 className="card-title">{meal.strMeal}</h5>
            <div className="d-flex">
              {fav ? 
               <button className="btn btn-primary  p-2" onClick={addFavourites}>
               Remove From Favorites
             </button> :
              <button className="btn btn-primary  p-2" onClick={addFavourites}>
              Add to Favorites
            </button>}
             
             
              <button
                className="btn btn-secondary p-2 mx-2"
                onClick={fetchRandomMeal}
              >
                Get Another Meal
              </button>
            </div>
          </div>
        </div>
        // <div className="col-3 m-auto text-center">
        //   <div className="card m-5 ">
        //     <img className="ml-3" src={meal.strMealThumb} alt={meal.strMeal} width={400} />
        //     <div className=" ">
        //     <h1>{meal.strMeal}</h1>
        //     <button className="btn btn-primary m-2 p-3" onClick={addFavourites}>
        //       Add to Favorites
        //     </button>
        //     <button className="btn btn-secondary p-3" onClick={fetchRandomMeal}>
        //       Get Another Meal
        //     </button>
        //   </div>
        //   </div>

        // </div>
      )}
    </div>
  );
}

export default RandomMealPage;
