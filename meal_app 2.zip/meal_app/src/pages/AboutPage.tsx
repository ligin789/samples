function AboutPage() {
    return (
      <div>
      <h1 className="text-center m-5">About Me</h1>
      <p>Personal information and comments go here.</p>
      </div>
    );
  }
  
  export default AboutPage;
  