import React from "react";
import '../assets/css/style.css'

function HomePage() {
  return (
    <div className="container">
      <div className="row mt-5" >
        
        <div className="col" >
          <div className=" heroSection p-auto">
            <h2 className="mainTextHero my-5">Peri Set go!</h2>
            <h2 className="mainTextHeroSub">Welcome to Bright Meal . We Serve good food</h2>
          </div>
        </div>
        <div className="col">
          <img src="https://p.w3layouts.com/demos_new/template_demo/01-10-2020/foodies-liberty-demo_Free/495579608/web/assets/images/bannerimg.png" width={500}></img>
        </div>
       
      </div>
    </div>
  );
}

export default HomePage;
