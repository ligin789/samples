import { Link } from "react-router-dom";
import "./Navbar.css";
import { useState } from "react";
import Logo from "../assets/images/logo.png";

const Navbar = (props: any) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleMenuToggle = () => {
    setIsMenuOpen((prevState) => !prevState);
  };

  return (
    <header className="header">
      <nav>
          <div className="logo">
            <Link className="link" to="/">
              <img src={Logo} alt="Logo" width={50} />
            </Link>
          </div>
          <input type="checkbox" id="menu-toggle"/>
          <label for="menu-toggle" class="menu-icon">&#9776;</label>

          
            <ul className="menu">
              <li>
                <Link className="link" to="/">
                  Home
                </Link>
              </li>
              <li>
                <Link className="link" to="/menu">
                  Menu
                </Link>
              </li>
              <li>
                <Link className="link" to="/favorites">
                  My Favourites
                </Link>
              </li>
              <li>
                {" "}
                <Link className="link" to="/random">
                  Meal Generator
                </Link>
              </li>
              <li>
                {" "}
                <Link className="link" to="/about">
                  About Me
                </Link>
              </li>
            </ul>
         
      </nav>
    </header>
  );
};

export default Navbar;
