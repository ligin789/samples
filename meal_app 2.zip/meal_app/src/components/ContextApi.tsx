import React, { createContext, useContext, useState, ReactNode } from 'react';
 
// Define the type for a favourite item
interface FavouriteItem {
  idMeal: string;
  strMeal: string;
  strMealThumb:string;
}
 
// Define the context type
interface FavouritesContextType {
  favourites: FavouriteItem[];
  addFavourite: (item: FavouriteItem) => void;
  removeFavourite: (id: string) => void;
}
 
// Create the context
const FavouritesContext = createContext<FavouritesContextType | undefined>(undefined);
 
// Create a provider component
const FavouritesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [favourites, setFavourites] = useState<FavouriteItem[]>([]);
 
  const addFavourite = (item: FavouriteItem) => {
    setFavourites((prevFavourites) => [...prevFavourites, item]);
  };
 
  const removeFavourite = (id: string) => {
setFavourites((prevFavourites) => prevFavourites.filter(item => item.idMeal !== id));
  };
 
  return (
    <FavouritesContext.Provider value={{ favourites, addFavourite, removeFavourite }}>
      {children}
    </FavouritesContext.Provider>
  );
};
 
// Custom hook to use the FavouritesContext
const useFavourites = () => {
  const context = useContext(FavouritesContext);
  if (context === undefined) {
    throw new Error('useFavourites must be used within a FavouritesProvider');
  }
  return context;
};
 
export { FavouritesProvider, useFavourites };