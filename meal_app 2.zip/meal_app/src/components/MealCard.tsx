import { useEffect, useState } from "react";
import { useFavourites } from "./ContextApi";
import FavImg from "../assets/images/love.png";
import FavImg2 from "../assets/images/save.png";

function MealCard({ meal }) {
  const { favourites, addFavourite, removeFavourite } = useFavourites();

  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    setIsFavorite(checkexistInFav(favourites, meal));
  }, []);

  const checkexistInFav = (favourites: FavouriteItem[], meal: any) => {
    return favourites.some((item) => item.idMeal === meal.idMeal);
  };

  const handleFavorite = () => {
    setIsFavorite(!isFavorite);
    if (isFavorite) {
      removeFavourite(meal.idMeal);
    } else {
      addFavourite(meal);
    }
    // Save or remove from local storage or backend here
  };

  return (
    <div className="card mealCard  my-3 p-4">
      <img
        className="m-auto"
        src={meal.strMealThumb}
        alt={meal.strMeal}
        width={290}
      />
      <div className="d-flex justify-content-between my-3">
        <h4 className="text-center py-2 font-weight-bold">{meal.strMeal}</h4>
        <a onClick={handleFavorite} className="">
          {!isFavorite ? (
            <img src={FavImg} width={30} />
          ) : (
            <img src={FavImg2} width={30} />
          )}
        </a>
      </div>
    </div>
  );
}

export default MealCard;
