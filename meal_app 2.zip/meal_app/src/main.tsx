import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import { FavouritesProvider } from "./components/ContextApi.tsx";
createRoot(document.getElementById("root")!).render(
  <FavouritesProvider>
    <StrictMode>
      <App />
    </StrictMode>
  </FavouritesProvider>
);
