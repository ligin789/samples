import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import MenuPage from './pages/MenuPage';
import MealsPage from './pages/MealPage';
import FavoritesPage from './pages/FavoritePage';
import RandomMealPage from './pages/RandomMealPage';
import AboutPage from './pages/AboutPage';
import './App.css'
function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/menu" element={<MenuPage />} />
        <Route path="/meals/:category" element={<MealsPage />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/random" element={<RandomMealPage />} />
        <Route path="/about" element={<AboutPage />} />
      </Routes>
    </Router>
  );
}

export default App;
