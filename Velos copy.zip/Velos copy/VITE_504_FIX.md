# Fix 504 Outdated Optimize Dep Error

## The Error
`Failed to load resource: the server responded with a status of 504 (Outdated Optimize Dep)`

## What Happened
When new files are added to the project, Vite needs to rebuild its dependency cache. This error means Vite's cache is outdated.

## Fix Applied
I've already cleared the Vite cache directories:
- Removed `node_modules/.vite`
- Removed `.vite`

## What You Need To Do

### Step 1: Stop the Dev Server
Press `Ctrl+C` in your terminal to stop the running dev server

### Step 2: Restart the Dev Server
```bash
npm run dev
```

### Step 3: Wait for Rebuild
Vite will automatically rebuild the dependencies. You'll see output like:
```
VITE v5.x.x  ready in xxx ms
```

### Step 4: Refresh Browser
Once the server is ready, refresh your browser (Ctrl+R or Cmd+R)

## Alternative (if issue persists)

If the error continues, do a full clean:

```bash
# Stop dev server (Ctrl+C)

# Clean everything
rm -rf node_modules/.vite
rm -rf .vite
rm -rf dist

# Restart
npm run dev
```

## After Server Restarts

1. Clear browser localStorage (DevTools → Application → Clear Storage)
2. Refresh page
3. Login with: `platformadmin@aam.com`
4. Check users at: `/admin/administration/login-users`

The Platform Admin user should now appear automatically.
