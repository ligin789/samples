import { useOutletContext } from 'react-router-dom';
import LeafletMap2D from '../../components/maps/LeafletMap2D';
import CesiumMap3D from '../../components/maps/CesiumMap3D';
import FlightGanttChart from '../../components/gantt/FlightGanttChart';

interface OutletContext {
  activeTab: string;
}

const Home = () => {
  const { activeTab } = useOutletContext<OutletContext>();
  
  return (
    <div className='p-0 m-0' >
      {activeTab === 'map' && <LeafletMap2D />}
      {activeTab === 'map2' && <CesiumMap3D />}
      {activeTab === 'gantt' && <FlightGanttChart />}
    </div>
  );
};

export default Home;
