const OperatorDashboard = () => {
  return (
    <div className="container-fluid p-4">
      <h2>Operator Dashboard</h2>
      <div className="row">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Fleet Overview</h5>
              <p className="card-text">Monitor your aircraft fleet status and operations.</p>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Vertiport Operations</h5>
              <p className="card-text">Manage vertiport operations and capacity.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OperatorDashboard;