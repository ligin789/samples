const EvtolOperator = () => {
  return (
    <div className="container-fluid p-4">
      <h2>eVTOL Operator Management</h2>
      <p>Manage eVTOL operators here.</p>
    </div>
  );
};

export default EvtolOperator;
