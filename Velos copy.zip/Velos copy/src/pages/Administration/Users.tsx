import UsersPage from '../../features/users/pages/UsersPage';

const Users = () => <UsersPage />;

export default Users;
