import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../store/rootReducer';
import { addRegion, updateRegion, deleteRegion } from '../../redux/region/regionThunks';
import type { Region } from '../../redux/region/regionTypes';
import LeafletMap from '../../components/Map/LeafletMap';
import DrawableMap from '../../components/Map/DrawableMap';

const Regions = () => {
  const dispatch = useDispatch();
  const { regions, loading } = useSelector((state: RootState) => state.region);
  const { clusters } = useSelector((state: RootState) => state.cluster);
  const [expanded, setExpanded] = useState(false);
  const [selectedRegionId, setSelectedRegionId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [editingRegion, setEditingRegion] = useState<Region | null>(null);
  const [formData, setFormData] = useState<Omit<Region, 'id'>>({
    region_code: '',
    region_name: '',
    cluster_id: '',
    city: '',
    altitude: 0,
    status: 'ACTIVE',
    geojson: null,
  });

  const handleOpenModal = (region?: Region) => {
    if (region) {
      setEditingRegion(region);
      setFormData({
        region_code: region.region_code,
        region_name: region.region_name,
        cluster_id: region.cluster_id,
        city: region.city,
        altitude: region.altitude,
        status: region.status,
        geojson: region.geojson,
      });
    } else {
      setEditingRegion(null);
      setFormData({
        region_code: '',
        region_name: '',
        cluster_id: '',
        city: '',
        altitude: 0,
        status: 'ACTIVE',
        geojson: null,
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingRegion(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ 
      ...formData, 
      [name]: name === 'altitude' ? Number(value) : value 
    });
  };

  const handlePolygonCreated = (geojson: any) => {
    setFormData({ ...formData, geojson });
  };

  const handleSubmit = () => {
    if (!formData.region_code || !formData.region_name || !formData.cluster_id || !formData.city) {
      alert('Please fill all required fields');
      return;
    }

    if (editingRegion) {
      dispatch(updateRegion({
        ...editingRegion,
        ...formData
      }) as any);
    } else {
      dispatch(addRegion(formData) as any);
    }

    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this region?')) {
      dispatch(deleteRegion(id) as any);
    }
  };

  const filteredRegions = regions.filter(region => {
    const matchesSearch = 
      region.region_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      region.region_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      region.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || region.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      ACTIVE: 'success',
      INACTIVE: 'danger',
    };
    return <span className={`badge bg-${colors[status] || 'secondary'}`}>{status}</span>;
  };

  const mapRegions = regions.map(r => ({
    id: r.id,
    cityCode: r.region_code,
    cityName: r.region_name,
    geoJson: r.geojson
  }));

  return (
    <div className="container-fluid h-100 p-0">
      <div className="d-flex justify-content-between align-items-center p-3 bg-light border-bottom">
        <h4 className="mb-0">Regions Management</h4>
        <button
          className="btn btn-outline-primary btn-sm"
          onClick={() => setExpanded(!expanded)}
        >
          ⇄ Toggle View
        </button>
      </div>
      
      <div className="row g-0 h-100">
        <div className={`${expanded ? 'col-md-8' : 'col-md-4'} cities-map-col`}>
          <div className="h-100 position-relative shadow-sm">
            <LeafletMap 
              zoom={expanded ? 13 : 11} 
              cities={mapRegions}
              selectedCityId={selectedRegionId}
            />
          </div>
        </div>
        
        <div className={`${expanded ? 'col-md-4' : 'col-md-8'} cities-table-col`}>
          <div className="h-100 p-3 overflow-auto">
            <div className="card">
              <div className="card-header">
                <h5 className="mb-0">Regions</h5>
              </div>
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <div className="d-flex gap-2">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search by region code, name or city..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      style={{ width: '300px' }}
                    />
                    <select
                      className="form-select"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      style={{ width: '150px' }}
                    >
                      <option value="All">All Status</option>
                      <option value="ACTIVE">Active</option>
                      <option value="INACTIVE">Inactive</option>
                    </select>
                  </div>
                  <button
                    className="btn btn-primary"
                    onClick={() => handleOpenModal()}
                  >
                    + Add Region
                  </button>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead>
                      <tr>
                        <th>Region Code</th>
                        <th>Region Name</th>
                        <th>Cluster</th>
                        <th>City</th>
                        <th>Altitude</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRegions.map((region) => {
                        const cluster = clusters.find(c => c.id === region.cluster_id);
                        return (
                          <tr 
                            key={region.id}
                            onClick={() => setSelectedRegionId(region.id)}
                            style={{ cursor: 'pointer' }}
                            className={selectedRegionId === region.id ? 'table-active' : ''}
                          >
                            <td>{region.region_code}</td>
                            <td>{region.region_name}</td>
                            <td>{cluster?.cluster_name || 'N/A'}</td>
                            <td>{region.city}</td>
                            <td>{region.altitude}m</td>
                            <td>{getStatusBadge(region.status)}</td>
                            <td>
                              <button
                                className="btn btn-sm btn-outline-primary me-2"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenModal(region);
                                }}
                              >
                                Edit
                              </button>
                              <button
                                className="btn btn-sm btn-outline-danger"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(region.id);
                                }}
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
      <div className="modal fade show" id="regionModal" tabIndex={-1} style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{editingRegion ? 'Edit Region' : 'Add Region'}</h5>
              <button type="button" className="btn-close" onClick={handleCloseModal} aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Region Code *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="region_code"
                    value={formData.region_code}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Region Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="region_name"
                    value={formData.region_name}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Cluster *</label>
                  <select
                    className="form-select"
                    name="cluster_id"
                    value={formData.cluster_id}
                    onChange={handleInputChange}
                  >
                    <option value="">Select Cluster</option>
                    {clusters.map(cluster => (
                      <option key={cluster.id} value={cluster.id}>
                        {cluster.cluster_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">City *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Altitude (meters) *</label>
                  <input
                    type="number"
                    className="form-control"
                    name="altitude"
                    value={formData.altitude}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Status</label>
                  <select
                    className="form-select"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                </div>
                <div className="col-12">
                  <label className="form-label">Draw Region Boundary</label>
                  <div style={{ height: '400px' }}>
                    <DrawableMap
                      onPolygonCreated={handlePolygonCreated}
                      existingGeoJson={formData.geojson}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                Cancel
              </button>
              <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                {editingRegion ? 'Update' : 'Add'}
              </button>
            </div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
};

export default Regions;
