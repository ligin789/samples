import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../store/rootReducer';
import { addCluster, updateCluster, deleteCluster } from '../../redux/cluster/clusterThunks';
import type { Cluster } from '../../redux/cluster/clusterTypes';
import LeafletMap from '../../components/Map/LeafletMap';
import DrawableMap from '../../components/Map/DrawableMap';
import './Cities.css';

const Cities = () => {
  const dispatch = useDispatch();
  const { clusters, loading } = useSelector((state: RootState) => state.cluster);
  const [expanded, setExpanded] = useState(false);
  const [selectedClusterId, setSelectedClusterId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [editingCluster, setEditingCluster] = useState<Cluster | null>(null);
  const [formData, setFormData] = useState<Omit<Cluster, 'id' | 'createdDate'>>({
    cluster_code: '',
    cluster_name: '',
    description: '',
    country: '',
    code: '',
    timezone: '',
    status: 'Active',
    geoJson: null,
  });

  const handleOpenModal = (cluster?: Cluster) => {
    if (cluster) {
      setEditingCluster(cluster);
      setFormData({
        cluster_code: cluster.cluster_code,
        cluster_name: cluster.cluster_name,
        description: cluster.description,
        country: cluster.country,
        code: cluster.code,
        timezone: cluster.timezone,
        status: cluster.status,
        geoJson: cluster.geoJson,
      });
    } else {
      setEditingCluster(null);
      setFormData({
        cluster_code: '',
        cluster_name: '',
        description: '',
        country: '',
        code: '',
        timezone: '',
        status: 'Active',
        geoJson: null,
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingCluster(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePolygonCreated = (geoJson: any) => {
    setFormData({ ...formData, geoJson });
  };

  const handleSubmit = () => {
    if (!formData.cluster_code || !formData.cluster_name || !formData.country || !formData.code || !formData.timezone) {
      alert('Please fill all required fields');
      return;
    }

    if (editingCluster) {
      dispatch(updateCluster({
        ...editingCluster,
        ...formData
      }) as any);
    } else {
      dispatch(addCluster(formData) as any);
    }

    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this cluster?')) {
      dispatch(deleteCluster(id) as any);
    }
  };

  const filteredClusters = clusters.filter(cluster => {
    const matchesSearch = cluster.cluster_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || cluster.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      Active: 'success',
      Pending: 'warning',
      Inactive: 'danger',
    };
    return <span className={`badge bg-${colors[status] || 'secondary'}`}>{status}</span>;
  };

  return (
    <div className="container-fluid h-100 p-0">
      <div className="d-flex justify-content-between align-items-center p-3 bg-light border-bottom">
        <h4 className="mb-0">Clusters Management</h4>
        <button
          className="btn btn-outline-primary btn-sm"
          onClick={() => setExpanded(!expanded)}
        >
          ⇄ Toggle View
        </button>
      </div>
      
      <div className="row g-0 h-100">
        <div className={`${expanded ? 'col-md-8' : 'col-md-4'} cities-map-col`}>
          <div className="h-100 position-relative shadow-sm">
            <LeafletMap 
              zoom={expanded ? 13 : 11} 
              cities={clusters}
              selectedCityId={selectedClusterId}
            />
          </div>
        </div>
        
        <div className={`${expanded ? 'col-md-4' : 'col-md-8'} cities-table-col`}>
          <div className="h-100 p-3 overflow-auto">
            <div className="card">
              <div className="card-header">
                <h5 className="mb-0">Clusters</h5>
              </div>
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <div className="d-flex gap-2">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search by cluster name..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      style={{ width: '250px' }}
                    />
                    <select
                      className="form-select"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      style={{ width: '150px' }}
                    >
                      <option value="All">All Status</option>
                      <option value="Active">Active</option>
                      <option value="Pending">Pending</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                  <button
                    className="btn btn-primary"
                    onClick={() => handleOpenModal()}
                  >
                    + Add Cluster
                  </button>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead>
                      <tr>
                        <th>Cluster Code</th>
                        <th>Cluster Name</th>
                        <th>Country</th>
                        <th>Code</th>
                        <th>Timezone</th>
                        <th>Created Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredClusters.map((cluster) => (
                        <tr 
                          key={cluster.id}
                          onClick={() => setSelectedClusterId(cluster.id)}
                          style={{ cursor: 'pointer' }}
                          className={selectedClusterId === cluster.id ? 'table-active' : ''}
                        >
                          <td>{cluster.cluster_code}</td>
                          <td>{cluster.cluster_name}</td>
                          <td>{cluster.country}</td>
                          <td>{cluster.code}</td>
                          <td>{cluster.timezone}</td>
                          <td>{cluster.createdDate}</td>
                          <td>{getStatusBadge(cluster.status || 'Active')}</td>
                          <td>
                            <button
                              className="btn btn-sm btn-outline-primary me-2"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenModal(cluster);
                              }}
                            >
                              Edit
                            </button>
                            <button
                              className="btn btn-sm btn-outline-danger"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(cluster.id);
                              }}
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
      <div className="modal fade show" id="clusterModal" tabIndex={-1} style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{editingCluster ? 'Edit Cluster' : 'Add Cluster'}</h5>
              <button type="button" className="btn-close" onClick={handleCloseModal} aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Cluster Code *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="cluster_code"
                    value={formData.cluster_code}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Cluster Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="cluster_name"
                    value={formData.cluster_name}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Country *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="country"
                    value={formData.country}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Code *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="code"
                    value={formData.code}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Timezone *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="timezone"
                    value={formData.timezone}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Status</label>
                  <select
                    className="form-select"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
                <div className="col-12">
                  <label className="form-label">Draw Boundary Polygon</label>
                  <div style={{ height: '400px' }}>
                    <DrawableMap
                      onPolygonCreated={handlePolygonCreated}
                      existingGeoJson={formData.geoJson}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                Cancel
              </button>
              <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                {editingCluster ? 'Update' : 'Add'}
              </button>
            </div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
};

export default Cities;
