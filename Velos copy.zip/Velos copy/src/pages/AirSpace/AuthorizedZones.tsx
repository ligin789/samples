import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../store/rootReducer';
import { addAuthorizedZone, updateAuthorizedZone, deleteAuthorizedZone } from '../../redux/authorizedZones/authorizedZonesThunks';
import type { AuthorizedZone } from '../../redux/authorizedZones/authorizedZonesTypes';
import LeafletMap from '../../components/Map/LeafletMap';
import DrawableMap from '../../components/Map/DrawableMap';

const AuthorizedZones = () => {
  const dispatch = useDispatch();
  const { zones, loading } = useSelector((state: RootState) => state.authorizedZones);
  const { regions } = useSelector((state: RootState) => state.region);
  const [expanded, setExpanded] = useState(false);
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [regionFilter, setRegionFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [editingZone, setEditingZone] = useState<AuthorizedZone | null>(null);
  const [formData, setFormData] = useState<Omit<AuthorizedZone, 'id'>>({
    zoneCode: '',
    zoneName: '',
    regionId: '',
    type: 'commercial',
    priority: 5,
    noFlyReason: '',
    status: 'active',
    geojson: null,
  });

  const handleOpenModal = (zone?: AuthorizedZone) => {
    if (zone) {
      setEditingZone(zone);
      setFormData({
        zoneCode: zone.zoneCode,
        zoneName: zone.zoneName,
        regionId: zone.regionId,
        type: zone.type,
        priority: zone.priority,
        noFlyReason: zone.noFlyReason || '',
        status: zone.status,
        geojson: zone.geojson,
      });
    } else {
      setEditingZone(null);
      setFormData({
        zoneCode: '',
        zoneName: '',
        regionId: '',
        type: 'commercial',
        priority: 5,
        noFlyReason: '',
        status: 'active',
        geojson: null,
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingZone(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ 
      ...formData, 
      [name]: name === 'priority' ? Number(value) : value 
    });
  };

  const handlePolygonCreated = (geojson: any) => {
    setFormData({ ...formData, geojson });
  };

  const handleSubmit = () => {
    if (!formData.zoneCode || !formData.zoneName || !formData.regionId) {
      alert('Please fill all required fields');
      return;
    }

    const zoneData = {
      ...formData,
      noFlyReason: formData.type === 'restricted' ? formData.noFlyReason : undefined
    };

    if (editingZone) {
      dispatch(updateAuthorizedZone({
        ...editingZone,
        ...zoneData
      }) as any);
    } else {
      dispatch(addAuthorizedZone(zoneData) as any);
    }

    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this zone?')) {
      dispatch(deleteAuthorizedZone(id) as any);
    }
  };

  const filteredZones = zones.filter(zone => {
    const matchesSearch = zone.zoneName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'All' || zone.type === typeFilter;
    const matchesRegion = regionFilter === 'All' || zone.regionId === regionFilter;
    const matchesStatus = statusFilter === 'All' || zone.status === statusFilter;
    return matchesSearch && matchesType && matchesRegion && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      active: 'success',
      inactive: 'danger',
    };
    return <span className={`badge bg-${colors[status] || 'secondary'}`}>{status}</span>;
  };

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      commercial: 'primary',
      residential: 'info',
      industrial: 'warning',
      restricted: 'danger',
    };
    return <span className={`badge bg-${colors[type] || 'secondary'}`}>{type}</span>;
  };

  const mapZones = zones.map(z => ({
    id: z.id,
    cityCode: z.zoneCode,
    cityName: z.zoneName,
    geoJson: z.geojson
  }));

  const totalZones = zones.length;
  const restrictedZones = zones.filter(z => z.type === 'restricted').length;
  const commercialZones = zones.filter(z => z.type === 'commercial').length;
  const activeZones = zones.filter(z => z.status === 'active').length;

  return (
    <div className="container-fluid h-100 p-0">
      <div className="d-flex justify-content-between align-items-center p-3 bg-light border-bottom">
        <h4 className="mb-0">Authorized Zones Management</h4>
        <button
          className="btn btn-outline-primary btn-sm"
          onClick={() => setExpanded(!expanded)}
        >
          ⇄ Toggle View
        </button>
      </div>
      
      <div className="row g-0 h-100">
        <div className={`${expanded ? 'col-md-8' : 'col-md-4'} cities-map-col`}>
          <div className="h-100 position-relative shadow-sm">
            <LeafletMap 
              zoom={expanded ? 13 : 11} 
              cities={mapZones}
              selectedCityId={selectedZoneId}
            />
          </div>
        </div>
        
        <div className={`${expanded ? 'col-md-4' : 'col-md-8'} cities-table-col`}>
          <div className="h-100 p-3 overflow-auto">
            <div className="card">
              <div className="card-header">
                <h5 className="mb-0">Authorized Zones</h5>
              </div>
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                  <div className="d-flex gap-2 flex-wrap">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search by zone name..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      style={{ width: '200px' }}
                    />
                    <select
                      className="form-select"
                      value={typeFilter}
                      onChange={(e) => setTypeFilter(e.target.value)}
                      style={{ width: '150px' }}
                    >
                      <option value="All">All Types</option>
                      <option value="commercial">Commercial</option>
                      <option value="residential">Residential</option>
                      <option value="industrial">Industrial</option>
                      <option value="restricted">Restricted</option>
                    </select>
                    <select
                      className="form-select"
                      value={regionFilter}
                      onChange={(e) => setRegionFilter(e.target.value)}
                      style={{ width: '150px' }}
                    >
                      <option value="All">All Regions</option>
                      {regions.map(region => (
                        <option key={region.id} value={region.id}>
                          {region.region_name}
                        </option>
                      ))}
                    </select>
                    <select
                      className="form-select"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      style={{ width: '120px' }}
                    >
                      <option value="All">All Status</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                    </select>
                  </div>
                  <button
                    className="btn btn-primary"
                    onClick={() => handleOpenModal()}
                  >
                    + Add Zone
                  </button>
                </div>

                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead>
                      <tr>
                        <th>Zone Code</th>
                        <th>Zone Name</th>
                        <th>Region</th>
                        <th>Type</th>
                        <th>Priority</th>
                        <th>No Fly Reason</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredZones.map((zone) => {
                        const region = regions.find(r => r.id === zone.regionId);
                        return (
                          <tr 
                            key={zone.id}
                            onClick={() => setSelectedZoneId(zone.id)}
                            style={{ cursor: 'pointer' }}
                            className={selectedZoneId === zone.id ? 'table-active' : ''}
                          >
                            <td>{zone.zoneCode}</td>
                            <td>{zone.zoneName}</td>
                            <td>{region?.region_name || 'N/A'}</td>
                            <td>{getTypeBadge(zone.type)}</td>
                            <td>{zone.priority}</td>
                            <td>{zone.noFlyReason || '-'}</td>
                            <td>{getStatusBadge(zone.status)}</td>
                            <td>
                              <button
                                className="btn btn-sm btn-outline-primary me-2"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenModal(zone);
                                }}
                              >
                                Edit
                              </button>
                              <button
                                className="btn btn-sm btn-outline-danger"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(zone.id);
                                }}
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showModal && (
      <div className="modal fade show" id="zoneModal" tabIndex={-1} style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{editingZone ? 'Edit Zone' : 'Add Zone'}</h5>
              <button type="button" className="btn-close" onClick={handleCloseModal} aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Zone Code *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="zoneCode"
                    value={formData.zoneCode}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Zone Name *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="zoneName"
                    value={formData.zoneName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Region *</label>
                  <select
                    className="form-select"
                    name="regionId"
                    value={formData.regionId}
                    onChange={handleInputChange}
                  >
                    <option value="">Select Region</option>
                    {regions.map(region => (
                      <option key={region.id} value={region.id}>
                        {region.region_name} ({region.region_code})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Type *</label>
                  <select
                    className="form-select"
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                  >
                    <option value="commercial">Commercial</option>
                    <option value="residential">Residential</option>
                    <option value="industrial">Industrial</option>
                    <option value="restricted">Restricted</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Priority (1-10) *</label>
                  <input
                    type="number"
                    className="form-control"
                    name="priority"
                    min="1"
                    max="10"
                    value={formData.priority}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Status</label>
                  <select
                    className="form-select"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                {formData.type === 'restricted' && (
                  <div className="col-12">
                    <label className="form-label">No Fly Reason *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="noFlyReason"
                      value={formData.noFlyReason}
                      onChange={handleInputChange}
                      placeholder="Enter reason for restriction"
                    />
                  </div>
                )}
                <div className="col-12">
                  <label className="form-label">Draw Zone Boundary</label>
                  <div style={{ height: '400px' }}>
                    <DrawableMap
                      onPolygonCreated={handlePolygonCreated}
                      existingGeoJson={formData.geojson}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>
                Cancel
              </button>
              <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                {editingZone ? 'Update' : 'Add'}
              </button>
            </div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
};

export default AuthorizedZones;
