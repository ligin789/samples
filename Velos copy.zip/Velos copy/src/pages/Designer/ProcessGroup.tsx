import { useLayoutEffect, useRef } from 'react';
import LeftSideBar from '../../components/processGroup/LeftSideBar';
import MainCanvas from '../../components/processGroup/MainCanvas';
import ProcessGroup4 from '../../components/processGroup/ProcessGroup4';
import ProcessGroup5 from '../../components/processGroup/ProcessGroup5';
import ProcessGroup6 from '../../components/processGroup/ProcessGroup6';
import styles from './ProcessGroup.module.css';

import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { setSelectedProcess } from '../../redux/process/processActions';
import type { Process } from '../../redux/process/processTypes';

// react-resizable-layout
import { useResizable } from 'react-resizable-layout';

const ProcessGroup = () => {
  const dispatch = useAppDispatch();

  const handleProcessSelect = (process: Process) => {
    dispatch(setSelectedProcess(process));
  };

  const handleDeleteProcess = (id: string) => {
    console.log('Delete process:', id);
  };

  const processGroups = useAppSelector((state) => state.processGroup.processGroup);
  const processes = useAppSelector((state) => state.process.process);

  // Container for the vertical resizable area (MainCanvas + BottomToolbar)
  const centerContainerRef = useRef<HTMLDivElement>(null);

  // Create a vertical resizer between MainCanvas (top) and BottomToolbar (bottom)
  const { position, separatorProps, setPosition } = useResizable({
    axis: 'y',
    containerRef: centerContainerRef,
    // We'll set the initial position to ~65% of container height after mount.
    initial: 650,
    min: 200,      // minimum height of MainCanvas (px)
    max: Infinity, // no explicit max; bottom panel has its own min via CSS
  });

  // After mount (and when we know container height), initialize to 65% / 35%
  useLayoutEffect(() => {
    const el = centerContainerRef.current;
    if (!el) return;
    if (position === 0) {
      const h = el.clientHeight;
      if (h > 0) {
        setPosition(Math.round(h * 0.65));
      }
    }
  }, [position, setPosition]);

  return (
    <div className={`container-fluid ${styles.processGroupContainer}`}>
      <div className="row g-0 h-100">
        {/* Left Sidebar */}
        <div className={`${styles.leftSidebar} ${styles.scrollable}`}>
          <LeftSideBar
            processGroups={processGroups}
            processes={processes}
            onProcessSelect={handleProcessSelect}
            onDeleteProcess={handleDeleteProcess}
          />
        </div>

        {/* Center Area */}
        <div className="col d-flex flex-column">
          {/* If you later need a top toolbar, place it here. */}

          {/* Resizable: MainCanvas (top) + BottomToolbar (bottom) */}
          <div ref={centerContainerRef} className={styles.centerResizableContainer}>
            <div className={styles.verticalStack}>
              {/* Main Canvas (height controlled by 'position') */}
              <div className={styles.mainCanvas} style={{ height: position }}>
                <MainCanvas />
              </div>

              {/* Separator (drag/keyboard/double-click supported via separatorProps) */}
              <div className={styles.resizeSeparator} {...separatorProps}>
                <div className={styles.resizeHandle} />
              </div>

              {/* Bottom Toolbar (fills remaining space) */}
              <div className={styles.bottomToolbar}>
                <ProcessGroup6 />
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className={`${styles.rightSidebar} d-flex flex-column`}>
          <div className={styles.rightTop}>
            <ProcessGroup4 />
          </div>
          <div className={styles.rightBottom}>
            <ProcessGroup5 />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProcessGroup;