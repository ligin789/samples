import type { Dispatch } from 'redux';
import type { RootState } from '../../../store/rootReducer';
import type { LoginUser } from './loginUsersTypes';
import {
  createLoginUserRequest,
  createLoginUserSuccess,
  createLoginUserFailure,
  updateLoginUserSuccess,
  fetchLoginUsersSuccess,
} from './loginUsersActions';

export const createLoginUserThunk = (userData: Omit<LoginUser, 'id' | 'createdAt' | 'updatedAt'>) => {
  return async (dispatch: Dispatch, getState: () => RootState) => {
    dispatch(createLoginUserRequest());
    
    try {
      const { loginUsers } = getState().loginUsers;
      const newId = `USR-${String(loginUsers.length + 1).padStart(3, '0')}`;
      
      const newUser: LoginUser = {
        ...userData,
        id: newId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      dispatch(createLoginUserSuccess(newUser));
      return newUser;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create login user';
      dispatch(createLoginUserFailure(errorMessage));
      throw error;
    }
  };
};

export const updateLoginUserStatusThunk = (email: string, status: 'ACTIVE' | 'INACTIVE') => {
  return async (dispatch: Dispatch, getState: () => RootState) => {
    try {
      const { loginUsers } = getState().loginUsers;
      const userToUpdate = loginUsers.find(
        lu => lu.officialEmail.toLowerCase() === email.toLowerCase()
      );
      
      if (userToUpdate) {
        const updatedUser = {
          ...userToUpdate,
          status,
          updatedAt: new Date().toISOString(),
          updatedBy: 'PLATFORM_ADMIN'
        };
        
        dispatch(updateLoginUserSuccess(updatedUser));
        return updatedUser;
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to update login user status';
      dispatch(createLoginUserFailure(errorMessage));
      throw error;
    }
  };
};

export const fetchLoginUsersThunk = () => {
  return async (dispatch: Dispatch, getState: () => RootState) => {
    const { loginUsers } = getState().loginUsers;
    dispatch(fetchLoginUsersSuccess(loginUsers));
  };
};
