export type UserRole =
  | 'PLATFORM_ADMIN'
  | 'OPERATOR_ADMIN'
  | 'FLEET_MANAGER'
  | 'VERTIPORT_MANAGER'
  | 'AIRSPACE_MANAGER'
  | 'GROUND_HANDLER_ADMIN'
  | 'GROUND_HANDLER_USER'
  | 'BOOKING_PARTNER_ADMIN'
  | 'BOOKING_PARTNER_USER'
  | 'GUEST_PARTNER_ADMIN'
  | 'GUEST_USER'
  | 'OPS_FLEET_MANAGER'
  | 'CREW_MANAGER'
  | 'SAFETY_OFFICER';

export type UserStatus = 'ACTIVE' | 'INACTIVE';

export interface LoginUser {
  id: string;
  name: string;
  officialEmail: string;
  mobileNumber: string;
  role: UserRole;
  whichTenant: string | null;
  status: UserStatus;
  createdAt: string;
  updatedAt: string;
  updatedBy: string;
}

export interface LoginUsersState {
  loginUsers: LoginUser[];
  loading: boolean;
  error: string | null;
}

export const CREATE_LOGIN_USER_REQUEST = 'CREATE_LOGIN_USER_REQUEST';
export const CREATE_LOGIN_USER_SUCCESS = 'CREATE_LOGIN_USER_SUCCESS';
export const CREATE_LOGIN_USER_FAILURE = 'CREATE_LOGIN_USER_FAILURE';
export const UPDATE_LOGIN_USER_SUCCESS = 'UPDATE_LOGIN_USER_SUCCESS';
export const FETCH_LOGIN_USERS_SUCCESS = 'FETCH_LOGIN_USERS_SUCCESS';

export interface CreateLoginUserRequestAction {
  type: typeof CREATE_LOGIN_USER_REQUEST;
}

export interface CreateLoginUserSuccessAction {
  type: typeof CREATE_LOGIN_USER_SUCCESS;
  payload: LoginUser;
}

export interface CreateLoginUserFailureAction {
  type: typeof CREATE_LOGIN_USER_FAILURE;
  payload: string;
}

export interface UpdateLoginUserSuccessAction {
  type: typeof UPDATE_LOGIN_USER_SUCCESS;
  payload: LoginUser;
}

export interface FetchLoginUsersSuccessAction {
  type: typeof FETCH_LOGIN_USERS_SUCCESS;
  payload: LoginUser[];
}

export type LoginUsersActionTypes =
  | CreateLoginUserRequestAction
  | CreateLoginUserSuccessAction
  | CreateLoginUserFailureAction
  | UpdateLoginUserSuccessAction
  | FetchLoginUsersSuccessAction;
