import type {
  LoginUsersState,
  LoginUsersActionTypes,
} from './loginUsersTypes';
import {
  CREATE_LOGIN_USER_REQUEST,
  CREATE_LOGIN_USER_SUCCESS,
  CREATE_LOGIN_USER_FAILURE,
  UPDATE_LOGIN_USER_SUCCESS,
  FETCH_LOGIN_USERS_SUCCESS,
} from './loginUsersTypes';
import { REHYDRATE } from 'redux-persist';

const getInitialLoginUsers = () => {
  return [{
    id: 'USR-001',
    name: 'Platform Admin',
    officialEmail: 'platformadmin@aam.com',
    mobileNumber: '9999999999',
    role: 'PLATFORM_ADMIN' as const,
    whichTenant: null,
    status: 'ACTIVE' as const,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    updatedBy: 'SYSTEM',
  }];
};

const initialState: LoginUsersState = {
  loginUsers: getInitialLoginUsers(),
  loading: false,
  error: null,
};

const loginUsersReducer = (
  state = initialState,
  action: any
): LoginUsersState => {
  
  switch (action.type) {
    case REHYDRATE:
      if (action.payload && action.payload.loginUsers) {
        const rehydratedUsers = action.payload.loginUsers.loginUsers;
        if (!rehydratedUsers || rehydratedUsers.length === 0) {
          return initialState;
        }
        return action.payload.loginUsers;
      }
      return state;
    case CREATE_LOGIN_USER_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case CREATE_LOGIN_USER_SUCCESS:
      return {
        ...state,
        loading: false,
        loginUsers: [...state.loginUsers, action.payload],
      };
    case CREATE_LOGIN_USER_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case UPDATE_LOGIN_USER_SUCCESS:
      return {
        ...state,
        loginUsers: state.loginUsers.map(user => 
          user.id === action.payload.id ? action.payload : user
        ),
      };
    case FETCH_LOGIN_USERS_SUCCESS:
      return {
        ...state,
        loginUsers: action.payload,
      };
    default:
      return state;
  }
};

export default loginUsersReducer;
