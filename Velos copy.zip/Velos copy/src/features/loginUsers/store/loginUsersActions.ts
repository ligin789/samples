import type {
  LoginUser,
  LoginUsersActionTypes,
} from './loginUsersTypes';
import {
  CREATE_LOGIN_USER_REQUEST,
  CREATE_LOGIN_USER_SUCCESS,
  CREATE_LOGIN_USER_FAILURE,
  UPDATE_LOGIN_USER_SUCCESS,
  FETCH_LOGIN_USERS_SUCCESS,
} from './loginUsersTypes';

export const createLoginUserRequest = (): LoginUsersActionTypes => ({
  type: CREATE_LOGIN_USER_REQUEST,
});

export const createLoginUserSuccess = (loginUser: LoginUser): LoginUsersActionTypes => ({
  type: CREATE_LOGIN_USER_SUCCESS,
  payload: loginUser,
});

export const createLoginUserFailure = (error: string): LoginUsersActionTypes => ({
  type: CREATE_LOGIN_USER_FAILURE,
  payload: error,
});

export const updateLoginUserSuccess = (loginUser: LoginUser): LoginUsersActionTypes => ({
  type: UPDATE_LOGIN_USER_SUCCESS,
  payload: loginUser,
});

export const fetchLoginUsersSuccess = (loginUsers: LoginUser[]): LoginUsersActionTypes => ({
  type: FETCH_LOGIN_USERS_SUCCESS,
  payload: loginUsers,
});
