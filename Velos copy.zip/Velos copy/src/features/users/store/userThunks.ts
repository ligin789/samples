import type { Dispatch } from 'redux';
import type { RootState } from '../../../store/rootReducer';
import type { User } from './userTypes';
import {
  addUserRequest,
  addUserSuccess,
  addUserFailure,
  updateUserSuccess,
  deleteUserSuccess,
  fetchUsersSuccess,
} from './userActions';
import { createLoginUserThunk } from '../../loginUsers/store/loginUsersThunks';
import { updateLoginUserStatusThunk } from '../../loginUsers/store/loginUsersThunks';

export const addUserThunk = (userData: Omit<User, 'id' | 'createdAt'>) => {
  return async (dispatch: Dispatch<any>, getState: () => RootState) => {
    dispatch(addUserRequest());
    try {
      const newUser: User = {
        ...userData,
        id: Date.now().toString(),
        status: 'active',
        createdAt: new Date().toISOString(),
      };
      
      // Create the regular user first
      dispatch(addUserSuccess(newUser));
      
      // If this is an EVTOL Operator Admin, also create a login user
      if (newUser.role === 'EVTOL_OPERATOR_ADMIN') {
        const { loginUsers } = getState().loginUsers;
        
        // Check for duplicate email in login users
        const existingLoginUser = loginUsers.find(
          lu => lu.officialEmail.toLowerCase() === newUser.email.toLowerCase()
        );
        
        if (!existingLoginUser) {
          // Map user fields to login user fields
          const loginUserData = {
            name: newUser.name,
            officialEmail: newUser.email,
            mobileNumber: newUser.mobile,
            role: 'OPERATOR_ADMIN' as const,
            whichTenant: newUser.operatorCode || null,
            status: 'ACTIVE' as const,
            updatedBy: 'PLATFORM_ADMIN',
          };
          
          try {
            await dispatch(createLoginUserThunk(loginUserData));
          } catch (loginError) {
            console.error('Failed to create login user:', loginError);
            // Don't fail the entire operation if login user creation fails
          }
        }
      }
      
      return newUser;
    } catch (error: any) {
      dispatch(addUserFailure(error.message || 'Failed to add user'));
      throw error;
    }
  };
};

export const updateUserThunk = (user: User) => {
  return async (dispatch: Dispatch<any>, getState: () => RootState) => {
    try {
      dispatch(updateUserSuccess(user));
      
      // If this is an EVTOL Operator Admin, also update login user status
      if (user.role === 'EVTOL_OPERATOR_ADMIN') {
        const loginStatus = user.status === 'active' ? 'ACTIVE' : 'INACTIVE';
        try {
          await dispatch(updateLoginUserStatusThunk(user.email, loginStatus));
        } catch (loginError) {
          console.error('Failed to update login user status:', loginError);
        }
      }
      
      return user;
    } catch (error: any) {
      throw error;
    }
  };
};

export const deleteUserThunk = (userId: string) => {
  return async (dispatch: Dispatch<any>, getState: () => RootState) => {
    try {
      const { users } = getState().users;
      const userToDelete = users.find(u => u.id === userId);
      
      dispatch(deleteUserSuccess(userId));
      
      // If this is an EVTOL Operator Admin, also update login user status to INACTIVE
      if (userToDelete && userToDelete.role === 'EVTOL_OPERATOR_ADMIN') {
        try {
          await dispatch(updateLoginUserStatusThunk(userToDelete.email, 'INACTIVE'));
        } catch (loginError) {
          console.error('Failed to update login user status:', loginError);
        }
      }
    } catch (error: any) {
      throw error;
    }
  };
};

export const fetchUsersThunk = () => {
  return async (dispatch: Dispatch) => {
    try {
      const serializedState = localStorage.getItem('platformUsers');
      const users = serializedState ? JSON.parse(serializedState) : [];
      dispatch(fetchUsersSuccess(users));
    } catch (error) {
      console.error('Failed to fetch users', error);
    }
  };
};
