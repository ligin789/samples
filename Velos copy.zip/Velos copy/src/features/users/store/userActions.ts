import type {
  User,
  UserActionTypes,
} from './userTypes';
import {
  ADD_USER_REQUEST,
  ADD_USER_SUCCESS,
  ADD_USER_FAILURE,
  UPDATE_USER_SUCCESS,
  DELETE_USER_SUCCESS,
  FETCH_USERS_SUCCESS,
} from './userTypes';

export const addUserRequest = (): UserActionTypes => ({
  type: ADD_USER_REQUEST,
});

export const addUserSuccess = (user: User): UserActionTypes => ({
  type: ADD_USER_SUCCESS,
  payload: user,
});

export const addUserFailure = (error: string): UserActionTypes => ({
  type: ADD_USER_FAILURE,
  payload: error,
});

export const updateUserSuccess = (user: User): UserActionTypes => ({
  type: UPDATE_USER_SUCCESS,
  payload: user,
});

export const deleteUserSuccess = (userId: string): UserActionTypes => ({
  type: DELETE_USER_SUCCESS,
  payload: userId,
});

export const fetchUsersSuccess = (users: User[]): UserActionTypes => ({
  type: FETCH_USERS_SUCCESS,
  payload: users,
});
