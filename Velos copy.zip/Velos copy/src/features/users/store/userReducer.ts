import type {
  UserState,
  UserActionTypes,
} from './userTypes';
import {
  ADD_USER_REQUEST,
  ADD_USER_SUCCESS,
  ADD_USER_FAILURE,
  UPDATE_USER_SUCCESS,
  DELETE_USER_SUCCESS,
  FETCH_USERS_SUCCESS,
} from './userTypes';

const loadState = () => {
  try {
    const serializedState = localStorage.getItem('platformUsers');
    if (!serializedState) return [];
    return JSON.parse(serializedState);
  } catch {
    return [];
  }
};

const saveState = (users: any[]) => {
  try {
    localStorage.setItem('platformUsers', JSON.stringify(users));
  } catch {
    console.error('Failed to save users to localStorage');
  }
};

const initialState: UserState = {
  users: loadState(),
  loading: false,
  error: null,
};

const userReducer = (
  state = initialState,
  action: UserActionTypes
): UserState => {
  let newState: UserState;
  
  switch (action.type) {
    case ADD_USER_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case ADD_USER_SUCCESS:
      newState = {
        ...state,
        loading: false,
        users: [...state.users, action.payload],
      };
      saveState(newState.users);
      return newState;
    case ADD_USER_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case UPDATE_USER_SUCCESS:
      newState = {
        ...state,
        users: state.users.map(user => 
          user.id === action.payload.id ? action.payload : user
        ),
      };
      saveState(newState.users);
      return newState;
    case DELETE_USER_SUCCESS:
      newState = {
        ...state,
        users: state.users.filter(user => user.id !== action.payload),
      };
      saveState(newState.users);
      return newState;
    case FETCH_USERS_SUCCESS:
      newState = {
        ...state,
        users: action.payload,
      };
      saveState(newState.users);
      return newState;
    default:
      return state;
  }
};

export default userReducer;
