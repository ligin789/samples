export interface User {
  id: string;
  photo?: string;
  name: string;
  email: string;
  mobile: string;
  customerId: string;
  role: 'EVTOL_OPERATOR_ADMIN' | 'GROUND_HANDLERS_ADMIN' | 'CUSTOMER_PORTAL_ADMIN' | 'BOOKING_PARTNERS_ADMIN';
  companyName?: string;
  operatorCode?: string;
  status: 'active' | 'disabled';
  createdAt: string;
}

export interface UserState {
  users: User[];
  loading: boolean;
  error: string | null;
}

export const ADD_USER_REQUEST = 'ADD_USER_REQUEST';
export const ADD_USER_SUCCESS = 'ADD_USER_SUCCESS';
export const ADD_USER_FAILURE = 'ADD_USER_FAILURE';
export const UPDATE_USER_SUCCESS = 'UPDATE_USER_SUCCESS';
export const DELETE_USER_SUCCESS = 'DELETE_USER_SUCCESS';
export const FETCH_USERS_SUCCESS = 'FETCH_USERS_SUCCESS';

export interface AddUserRequestAction {
  type: typeof ADD_USER_REQUEST;
}

export interface AddUserSuccessAction {
  type: typeof ADD_USER_SUCCESS;
  payload: User;
}

export interface AddUserFailureAction {
  type: typeof ADD_USER_FAILURE;
  payload: string;
}

export interface UpdateUserSuccessAction {
  type: typeof UPDATE_USER_SUCCESS;
  payload: User;
}

export interface DeleteUserSuccessAction {
  type: typeof DELETE_USER_SUCCESS;
  payload: string;
}

export interface FetchUsersSuccessAction {
  type: typeof FETCH_USERS_SUCCESS;
  payload: User[];
}

export type UserActionTypes =
  | AddUserRequestAction
  | AddUserSuccessAction
  | AddUserFailureAction
  | UpdateUserSuccessAction
  | DeleteUserSuccessAction
  | FetchUsersSuccessAction;
