import { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../../store/hooks';
import CreateUserModal from '../components/CreateUserModal';
import UserTable from '../components/UserTable';
import { fetchUsersThunk } from '../store/userThunks';
import { fetchOperatorsThunk } from '../../evtolOperator/store/operatorThunks';

const UsersPage = () => {
  const dispatch = useAppDispatch();
  const { users, loading } = useAppSelector((state) => state.users);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    dispatch(fetchUsersThunk() as any);
    dispatch(fetchOperatorsThunk() as any);
  }, [dispatch]);

  return (
    <div className="container-fluid p-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>User Management</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          + Create User
        </button>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : users.length === 0 ? (
        <div className="text-center py-5">
          <h4 className="text-muted">No users found</h4>
          <p className="text-muted">Create your first user to get started</p>
        </div>
      ) : (
        <UserTable users={users} />
      )}

      <CreateUserModal show={showModal} onClose={() => setShowModal(false)} />
    </div>
  );
};

export default UsersPage;
