import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { addUserThunk } from '../store/userThunks';
import type { User } from '../store/userTypes';

interface CreateUserModalProps {
  show: boolean;
  onClose: () => void;
}

const CreateUserModal = ({ show, onClose }: CreateUserModalProps) => {
  const dispatch = useAppDispatch();
  const operators = useAppSelector((state) => state.operator.operators);
  
  const [formData, setFormData] = useState<Omit<User, 'id' | 'createdAt'>>({
    photo: '',
    name: '',
    email: '',
    mobile: '',
    customerId: '',
    role: 'EVTOL_OPERATOR_ADMIN',
    companyName: '',
    operatorCode: '',
    status: 'active',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, photo: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name) newErrors.name = 'Name is required';
    if (!formData.email) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!formData.mobile) newErrors.mobile = 'Mobile number is required';
    if (!formData.customerId) newErrors.customerId = 'Customer ID is required';
    
    if (formData.role === 'EVTOL_OPERATOR_ADMIN' && !formData.operatorCode) {
      newErrors.operatorCode = 'EVTOL Operator is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    try {
      const userData = { ...formData };
      if (formData.role === 'EVTOL_OPERATOR_ADMIN' && formData.operatorCode) {
        const selectedOperator = operators.find(op => op.operatorCode === formData.operatorCode);
        userData.companyName = selectedOperator?.tradingName || selectedOperator?.legalName || '';
      }
      
      await dispatch(addUserThunk(userData) as any);
      onClose();
      setFormData({
        photo: '',
        name: '',
        email: '',
        mobile: '',
        customerId: '',
        role: 'EVTOL_OPERATOR_ADMIN',
        companyName: '',
        operatorCode: '',
        status: 'active',
      });
    } catch (error) {
      console.error('Failed to create user', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (errors[name]) {
      setErrors({ ...errors, [name]: '' });
    }
  };

  if (!show) return null;

  return (
    <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog modal-lg">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Create User</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              <div className="row g-3">
                <div className="col-12">
                  <label className="form-label">Photo</label>
                  <input
                    type="file"
                    className="form-control"
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                  {formData.photo && (
                    <div className="mt-2">
                      <img src={formData.photo} alt="Photo preview" style={{ width: '60px', height: '60px', objectFit: 'cover', borderRadius: '50%' }} />
                    </div>
                  )}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Name *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                  />
                  {errors.name && <div className="invalid-feedback">{errors.name}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Company Email *</label>
                  <input
                    type="email"
                    className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                  />
                  {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Mobile Number *</label>
                  <input
                    type="tel"
                    className={`form-control ${errors.mobile ? 'is-invalid' : ''}`}
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                  />
                  {errors.mobile && <div className="invalid-feedback">{errors.mobile}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Customer ID *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.customerId ? 'is-invalid' : ''}`}
                    name="customerId"
                    value={formData.customerId}
                    onChange={handleChange}
                  />
                  {errors.customerId && <div className="invalid-feedback">{errors.customerId}</div>}
                </div>
                <div className="col-md-6">
                  <label className="form-label">Role *</label>
                  <select
                    className="form-select"
                    name="role"
                    value={formData.role}
                    onChange={handleChange}
                  >
                    <option value="EVTOL_OPERATOR_ADMIN">EVTOL Operator Admin</option>
                    <option value="GROUND_HANDLERS_ADMIN">Ground Handlers Admin</option>
                    <option value="CUSTOMER_PORTAL_ADMIN">Customer Portal Admin</option>
                    <option value="BOOKING_PARTNERS_ADMIN">Booking Partners Admin</option>
                  </select>
                </div>
                {formData.role === 'EVTOL_OPERATOR_ADMIN' ? (
                  <div className="col-md-6">
                    <label className="form-label">Company Name (EVTOL Operator) *</label>
                    <select
                      className={`form-select ${errors.operatorCode ? 'is-invalid' : ''}`}
                      name="operatorCode"
                      value={formData.operatorCode}
                      onChange={handleChange}
                    >
                      <option value="">Select EVTOL Operator</option>
                      {operators.map((operator) => (
                        <option key={operator.id} value={operator.operatorCode}>
                          {operator.tradingName || operator.legalName}
                        </option>
                      ))}
                    </select>
                    {errors.operatorCode && <div className="invalid-feedback">{errors.operatorCode}</div>}
                  </div>
                ) : (
                  <div className="col-md-6">
                    <label className="form-label">Company Name</label>
                    <input
                      type="text"
                      className="form-control"
                      name="companyName"
                      value={formData.companyName}
                      onChange={handleChange}
                    />
                  </div>
                )}
                <div className="col-md-6">
                  <label className="form-label">Status *</label>
                  <select
                    className="form-select"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                  >
                    <option value="active">Active</option>
                    <option value="disabled">Disabled</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose} disabled={loading}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Creating...' : 'Create User'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateUserModal;
