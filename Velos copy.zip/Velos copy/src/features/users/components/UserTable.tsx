import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { deleteUserThunk, updateUserThunk } from '../store/userThunks';
import type { User } from '../store/userTypes';

interface UserTableProps {
  users: User[];
}

const UserTable = ({ users }: UserTableProps) => {
  const dispatch = useAppDispatch();
  const operators = useAppSelector((state) => state.operator.operators);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const handleToggleStatus = async (user: User) => {
    const newStatus = user.status === 'active' ? 'disabled' : 'active';
    const updatedUser = { ...user, status: newStatus };
    try {
      await dispatch(updateUserThunk(updatedUser) as any);
    } catch (error) {
      console.error('Failed to update user status', error);
    }
  };

  const handleDelete = async (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        await dispatch(deleteUserThunk(userId) as any);
      } catch (error) {
        console.error('Failed to delete user', error);
      }
    }
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setShowEditModal(true);
  };

  const handleUpdateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    try {
      await dispatch(updateUserThunk(editingUser) as any);
      setShowEditModal(false);
      setEditingUser(null);
    } catch (error) {
      console.error('Failed to update user', error);
    }
  };

  const getRoleDisplay = (role: string) => {
    const roleMap: Record<string, string> = {
      EVTOL_OPERATOR_ADMIN: 'EVTOL Operator Admin',
      GROUND_HANDLERS_ADMIN: 'Ground Handlers Admin',
      CUSTOMER_PORTAL_ADMIN: 'Customer Portal Admin',
      BOOKING_PARTNERS_ADMIN: 'Booking Partners Admin',
    };
    return roleMap[role] || role;
  };

  const getOperatorName = (operatorCode?: string) => {
    if (!operatorCode) return '-';
    const operator = operators.find(op => op.operatorCode === operatorCode);
    return operator?.tradingName || operator?.legalName || operatorCode;
  };

  return (
    <>
      <div className="table-responsive">
        <table className="table table-hover">
          <thead>
            <tr>
              <th>Photo</th>
              <th>Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Customer ID</th>
              <th>Role</th>
              <th>Company Name</th>
              <th>Operator</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} style={{ opacity: user.status === 'disabled' ? 0.6 : 1 }}>
                <td>
                  {user.photo ? (
                    <img src={user.photo} alt={user.name} style={{ width: '40px', height: '40px', objectFit: 'cover', borderRadius: '50%' }} />
                  ) : (
                    <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: '#e0e0e0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.mobile}</td>
                <td>{user.customerId}</td>
                <td>
                  <span className="badge bg-primary">{getRoleDisplay(user.role)}</span>
                </td>
                <td>{user.companyName || '-'}</td>
                <td>{user.role === 'EVTOL_OPERATOR_ADMIN' ? getOperatorName(user.operatorCode) : '-'}</td>
                <td>
                  <span className={`badge ${user.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
                    {user.status === 'active' ? 'Active' : 'Disabled'}
                  </span>
                </td>
                <td>
                  <button 
                    className={`btn btn-sm me-2 ${user.status === 'active' ? 'btn-outline-warning' : 'btn-outline-success'}`}
                    onClick={() => handleToggleStatus(user)}
                  >
                    {user.status === 'active' ? 'Disable' : 'Enable'}
                  </button>
                  <button className="btn btn-sm btn-outline-primary me-2" onClick={() => handleEdit(user)}>
                    Edit
                  </button>
                  <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(user.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showEditModal && editingUser && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit User</h5>
                <button type="button" className="btn-close" onClick={() => setShowEditModal(false)}></button>
              </div>
              <form onSubmit={handleUpdateSubmit}>
                <div className="modal-body">
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label">Name</label>
                      <input
                        type="text"
                        className="form-control"
                        value={editingUser.name}
                        onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        value={editingUser.email}
                        onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Mobile</label>
                      <input
                        type="tel"
                        className="form-control"
                        value={editingUser.mobile}
                        onChange={(e) => setEditingUser({ ...editingUser, mobile: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Customer ID</label>
                      <input
                        type="text"
                        className="form-control"
                        value={editingUser.customerId}
                        onChange={(e) => setEditingUser({ ...editingUser, customerId: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Status</label>
                      <select
                        className="form-select"
                        value={editingUser.status}
                        onChange={(e) => setEditingUser({ ...editingUser, status: e.target.value as 'active' | 'disabled' })}
                      >
                        <option value="active">Active</option>
                        <option value="disabled">Disabled</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowEditModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Update User
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default UserTable;
