import { Routes, Route } from 'react-router-dom';
import VertiportPortalLayout from '../components/VertiportPortalLayout';

const DummyPage = ({ title }: { title: string }) => (
  <div>
    <h3>{title}</h3>
    <p className="text-muted">This is a placeholder page for {title.toLowerCase()}.</p>
  </div>
);

const VertiportPortalPage = () => {
  return (
    <VertiportPortalLayout>
      <Routes>
        <Route index element={<DummyPage title="Overview" />} />
        <Route path="infrastructure" element={<DummyPage title="Infrastructure" />} />
        <Route path="operations" element={<DummyPage title="Operations" />} />
        <Route path="safety" element={<DummyPage title="Safety & Compliance" />} />
        <Route path="maintenance" element={<DummyPage title="Maintenance" />} />
        <Route path="analytics" element={<DummyPage title="Analytics" />} />
        <Route path="documents" element={<DummyPage title="Documents" />} />
      </Routes>
    </VertiportPortalLayout>
  );
};

export default VertiportPortalPage;
