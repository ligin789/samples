import { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../../store/hooks';
import CreateVertiportModal from '../components/CreateVertiportModal';
import VertiportCard from '../components/VertiportCard';
import { fetchVertiportsThunk } from '../store/vertiportThunks';

const VertiportListPage = () => {
  const dispatch = useAppDispatch();
  const { vertiports, loading } = useAppSelector((state) => state.vertiport);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    dispatch(fetchVertiportsThunk() as any);
  }, [dispatch]);

  return (
    <div className="container-fluid p-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Vertiport Management</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          + Create Vertiport
        </button>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : vertiports.length === 0 ? (
        <div className="text-center py-5">
          <h4 className="text-muted">No vertiports found</h4>
          <p className="text-muted">Create your first vertiport to get started</p>
        </div>
      ) : (
        <div className="row g-4">
          {vertiports.map((vertiport) => (
            <div key={vertiport.id} className="col-md-4">
              <VertiportCard vertiport={vertiport} />
            </div>
          ))}
        </div>
      )}

      <CreateVertiportModal show={showModal} onClose={() => setShowModal(false)} />
    </div>
  );
};

export default VertiportListPage;
