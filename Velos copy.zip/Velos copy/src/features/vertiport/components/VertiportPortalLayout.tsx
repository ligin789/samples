import { Link, Outlet, useParams } from 'react-router-dom';
import { useAppSelector } from '../../../store/hooks';

const VertiportPortalLayout = () => {
  const { id } = useParams();
  const vertiport = useAppSelector((state) =>
    state.vertiport.vertiports.find((vp) => vp.id === id)
  );

  const menuItems = [
    { name: 'Overview', path: '' },
    { name: 'Infrastructure', path: 'infrastructure' },
    { name: 'Operations', path: 'operations' },
    { name: 'Safety & Compliance', path: 'safety' },
    { name: 'Maintenance', path: 'maintenance' },
    { name: 'Analytics', path: 'analytics' },
    { name: 'Documents', path: 'documents' },
  ];

  return (
    <div className="d-flex" style={{ minHeight: 'calc(100vh - 80px)' }}>
      <div
        className="bg-light border-end"
        style={{ width: '250px', padding: '20px' }}
      >
        <h5 className="mb-4">{vertiport?.facility_name || 'Vertiport Portal'}</h5>
        <nav className="nav flex-column">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              to={`/admin/vertiport/${id}/${item.path}`}
              className="nav-link text-dark"
              style={{ padding: '10px 15px', borderRadius: '6px' }}
            >
              {item.name}
            </Link>
          ))}
        </nav>
        <div className="mt-4">
          <Link
            to="/admin/vertiport"
            className="btn btn-outline-secondary btn-sm w-100"
          >
            ← Back to Vertiports
          </Link>
        </div>
      </div>
      <div className="flex-grow-1 p-4">
        <Outlet />
      </div>
    </div>
  );
};

export default VertiportPortalLayout;
