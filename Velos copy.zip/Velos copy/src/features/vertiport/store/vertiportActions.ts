import type {
  Vertiport,
  VertiportActionTypes,
} from './vertiportTypes';
import {
  CREATE_VERTIPORT_REQUEST,
  CREATE_VERTIPORT_SUCCESS,
  CREATE_VERTIPORT_FAILURE,
  FETCH_VERTIPORTS_SUCCESS,
} from './vertiportTypes';

export const createVertiportRequest = (): VertiportActionTypes => ({
  type: CREATE_VERTIPORT_REQUEST,
});

export const createVertiportSuccess = (vertiport: Vertiport): VertiportActionTypes => ({
  type: CREATE_VERTIPORT_SUCCESS,
  payload: vertiport,
});

export const createVertiportFailure = (error: string): VertiportActionTypes => ({
  type: CREATE_VERTIPORT_FAILURE,
  payload: error,
});

export const fetchVertiportsSuccess = (vertiports: Vertiport[]): VertiportActionTypes => ({
  type: FETCH_VERTIPORTS_SUCCESS,
  payload: vertiports,
});
