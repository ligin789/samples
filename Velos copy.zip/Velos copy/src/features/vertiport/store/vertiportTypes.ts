export interface Vertiport {
  id: string;
  vertiport_code: string;
  vertiport_icao_code: string;
  vertiport_type_code: string;
  vertiport_type_name: string;
  facility_name: string;
  facility_code: string;
  facility_status_code: string;
  facility_status: string;
  vertiport_operational_status_code: string;
  vertiport_operational_status: string;
  certification_level: string;
  facility_class_code: string;
  facility_class_description: string;
  total_area_sqm: number;
  total_parking_stands: number;
  total_FATO_pads: number;
  hangar_capacity: number;
  is_maintenance_facilities_available: boolean;
  onboarding_datetime: string;
  logo?: string;
}

export interface VertiportState {
  vertiports: Vertiport[];
  loading: boolean;
  error: string | null;
}

export const CREATE_VERTIPORT_REQUEST = 'CREATE_VERTIPORT_REQUEST';
export const CREATE_VERTIPORT_SUCCESS = 'CREATE_VERTIPORT_SUCCESS';
export const CREATE_VERTIPORT_FAILURE = 'CREATE_VERTIPORT_FAILURE';
export const FETCH_VERTIPORTS_SUCCESS = 'FETCH_VERTIPORTS_SUCCESS';

export interface CreateVertiportRequestAction {
  type: typeof CREATE_VERTIPORT_REQUEST;
}

export interface CreateVertiportSuccessAction {
  type: typeof CREATE_VERTIPORT_SUCCESS;
  payload: Vertiport;
}

export interface CreateVertiportFailureAction {
  type: typeof CREATE_VERTIPORT_FAILURE;
  payload: string;
}

export interface FetchVertiportsSuccessAction {
  type: typeof FETCH_VERTIPORTS_SUCCESS;
  payload: Vertiport[];
}

export type VertiportActionTypes =
  | CreateVertiportRequestAction
  | CreateVertiportSuccessAction
  | CreateVertiportFailureAction
  | FetchVertiportsSuccessAction;
