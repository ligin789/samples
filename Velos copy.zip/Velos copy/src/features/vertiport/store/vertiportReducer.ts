import type {
  VertiportState,
  VertiportActionTypes,
} from './vertiportTypes';
import {
  CREATE_VERTIPORT_REQUEST,
  CREATE_VERTIPORT_SUCCESS,
  CREATE_VERTIPORT_FAILURE,
  FETCH_VERTIPORTS_SUCCESS,
} from './vertiportTypes';

const loadState = () => {
  try {
    const serializedState = localStorage.getItem('vertiports');
    if (!serializedState) return [];
    return JSON.parse(serializedState);
  } catch {
    return [];
  }
};

const saveState = (vertiports: any[]) => {
  try {
    localStorage.setItem('vertiports', JSON.stringify(vertiports));
  } catch {
    console.error('Failed to save vertiports to localStorage');
  }
};

const initialState: VertiportState = {
  vertiports: loadState(),
  loading: false,
  error: null,
};

const vertiportReducer = (
  state = initialState,
  action: VertiportActionTypes
): VertiportState => {
  let newState: VertiportState;
  
  switch (action.type) {
    case CREATE_VERTIPORT_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case CREATE_VERTIPORT_SUCCESS:
      newState = {
        ...state,
        loading: false,
        vertiports: [...state.vertiports, action.payload],
      };
      saveState(newState.vertiports);
      return newState;
    case CREATE_VERTIPORT_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case FETCH_VERTIPORTS_SUCCESS:
      newState = {
        ...state,
        vertiports: action.payload,
      };
      saveState(newState.vertiports);
      return newState;
    default:
      return state;
  }
};

export default vertiportReducer;
