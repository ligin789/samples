import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  createVertiportRequest,
  createVertiportSuccess,
  createVertiportFailure,
  fetchVertiportsSuccess,
} from './vertiportActions';
import type { Vertiport, VertiportActionTypes } from './vertiportTypes';

export const createVertiportThunk = (vertiportData: Omit<Vertiport, 'id'>) => {
  return async (dispatch: Dispatch<VertiportActionTypes>) => {
    dispatch(createVertiportRequest());
    
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      const newVertiport: Vertiport = {
        id: uuidv4(),
        ...vertiportData,
      };
      
      dispatch(createVertiportSuccess(newVertiport));
      return newVertiport;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create vertiport';
      dispatch(createVertiportFailure(errorMessage));
      throw error;
    }
  };
};

export const fetchVertiportsThunk = () => {
  return async (dispatch: Dispatch<VertiportActionTypes>) => {
    try {
      // Load from localStorage instead of dispatching empty array
      const serializedState = localStorage.getItem('vertiports');
      const vertiports = serializedState ? JSON.parse(serializedState) : [];
      
      await new Promise((resolve) => setTimeout(resolve, 500));
      dispatch(fetchVertiportsSuccess(vertiports));
    } catch (error) {
      console.error('Failed to fetch vertiports', error);
      dispatch(fetchVertiportsSuccess([]));
    }
  };
};
