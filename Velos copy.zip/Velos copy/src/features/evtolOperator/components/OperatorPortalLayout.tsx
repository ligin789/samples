import { Link, Outlet, useParams } from 'react-router-dom';
import { useAppSelector } from '../../../store/hooks';

const OperatorPortalLayout = () => {
  const { id } = useParams();
  const operator = useAppSelector((state) =>
    state.operator.operators.find((op) => op.id === id)
  );

  const menuItems = [
    { name: 'Dashboard', path: '' },
    { name: 'Fleet', path: 'fleet' },
    { name: 'Pilots', path: 'pilots' },
    { name: 'Maintenance', path: 'maintenance' },
    { name: 'Compliance', path: 'compliance' },
    { name: 'Reports', path: 'reports' },
  ];

  return (
    <div className="d-flex" style={{ minHeight: 'calc(100vh - 80px)' }}>
      <div
        className="bg-light border-end"
        style={{ width: '250px', padding: '20px' }}
      >
        <h5 className="mb-4">{operator?.legalName || 'Operator Portal'}</h5>
        <nav className="nav flex-column">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              to={`/admin/administration/evtol-operator/${id}/${item.path}`}
              className="nav-link text-dark"
              style={{ padding: '10px 15px', borderRadius: '6px' }}
            >
              {item.name}
            </Link>
          ))}
        </nav>
        <div className="mt-4">
          <Link
            to="/admin/administration/evtol-operator"
            className="btn btn-outline-secondary btn-sm w-100"
          >
            ← Back to Operators
          </Link>
        </div>
      </div>
      <div className="flex-grow-1 p-4">
        <Outlet />
      </div>
    </div>
  );
};

export default OperatorPortalLayout;
