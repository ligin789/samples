import type {
  OperatorState,
  OperatorActionTypes,
} from './operatorTypes';
import {
  CREATE_OPERATOR_REQUEST,
  CREATE_OPERATOR_SUCCESS,
  CREATE_OPERATOR_FAILURE,
  FETCH_OPERATORS_SUCCESS,
} from './operatorTypes';

const loadState = () => {
  try {
    const serializedState = localStorage.getItem('evtolOperators');
    if (!serializedState) return [];
    return JSON.parse(serializedState);
  } catch {
    return [];
  }
};

const saveState = (operators: any[]) => {
  try {
    localStorage.setItem('evtolOperators', JSON.stringify(operators));
  } catch {
    console.error('Failed to save operators to localStorage');
  }
};

const initialState: OperatorState = {
  operators: loadState(),
  loading: false,
  error: null,
};

const operatorReducer = (
  state = initialState,
  action: OperatorActionTypes
): OperatorState => {
  let newState: OperatorState;
  
  switch (action.type) {
    case CREATE_OPERATOR_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case CREATE_OPERATOR_SUCCESS:
      newState = {
        ...state,
        loading: false,
        operators: [...state.operators, action.payload],
      };
      saveState(newState.operators);
      return newState;
    case CREATE_OPERATOR_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case FETCH_OPERATORS_SUCCESS:
      newState = {
        ...state,
        operators: action.payload,
      };
      saveState(newState.operators);
      return newState;
    default:
      return state;
  }
};

export default operatorReducer;
