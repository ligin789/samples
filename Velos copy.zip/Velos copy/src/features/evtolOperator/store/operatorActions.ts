import type {
  EvtolOperator,
  OperatorActionTypes,
} from './operatorTypes';
import {
  CREATE_OPERATOR_REQUEST,
  CREATE_OPERATOR_SUCCESS,
  CREATE_OPERATOR_FAILURE,
  FETCH_OPERATORS_SUCCESS,
} from './operatorTypes';

export const createOperatorRequest = (): OperatorActionTypes => ({
  type: CREATE_OPERATOR_REQUEST,
});

export const createOperatorSuccess = (operator: EvtolOperator): OperatorActionTypes => ({
  type: CREATE_OPERATOR_SUCCESS,
  payload: operator,
});

export const createOperatorFailure = (error: string): OperatorActionTypes => ({
  type: CREATE_OPERATOR_FAILURE,
  payload: error,
});

export const fetchOperatorsSuccess = (operators: EvtolOperator[]): OperatorActionTypes => ({
  type: FETCH_OPERATORS_SUCCESS,
  payload: operators,
});
