import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  createOperatorRequest,
  createOperatorSuccess,
  createOperatorFailure,
  fetchOperatorsSuccess,
} from './operatorActions';
import type { EvtolOperator, OperatorActionTypes } from './operatorTypes';
import { createLoginUserThunk } from '../../loginUsers/store/loginUsersThunks';
import type { RootState } from '../../../store/rootReducer';

export const createOperatorThunk = (operatorData: Omit<EvtolOperator, 'id'>) => {
  return async (dispatch: Dispatch<any>, getState: () => RootState) => {
    dispatch(createOperatorRequest());
    
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      const newOperator: EvtolOperator = {
        id: uuidv4(),
        ...operatorData,
      };
      
      dispatch(createOperatorSuccess(newOperator));
      
      // Create login user for Operator Admin
      const operatorAdminEmail = `admin@${operatorData.operatorCode.toLowerCase()}.com`;
      await dispatch(createLoginUserThunk({
        name: `${operatorData.legalName} Admin`,
        officialEmail: operatorAdminEmail,
        mobileNumber: '0000000000',
        role: 'OPERATOR_ADMIN',
        whichTenant: operatorData.operatorCode,
        status: 'ACTIVE',
        updatedBy: 'PLATFORM_ADMIN',
      }));
      
      return newOperator;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create operator';
      dispatch(createOperatorFailure(errorMessage));
      throw error;
    }
  };
};

export const fetchOperatorsThunk = () => {
  return async (dispatch: Dispatch<OperatorActionTypes>) => {
    try {
      // Load from localStorage instead of dispatching empty array
      const serializedState = localStorage.getItem('evtolOperators');
      const operators = serializedState ? JSON.parse(serializedState) : [];
      
      await new Promise((resolve) => setTimeout(resolve, 500));
      dispatch(fetchOperatorsSuccess(operators));
    } catch (error) {
      console.error('Failed to fetch operators', error);
      dispatch(fetchOperatorsSuccess([]));
    }
  };
};
