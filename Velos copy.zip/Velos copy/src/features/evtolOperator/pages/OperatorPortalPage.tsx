import { Routes, Route } from 'react-router-dom';
import OperatorPortalLayout from '../components/OperatorPortalLayout';

const DummyPage = ({ title }: { title: string }) => (
  <div>
    <h3>{title}</h3>
    <p className="text-muted">This is a placeholder page for {title.toLowerCase()}.</p>
  </div>
);

const OperatorPortalPage = () => {
  return (
    <OperatorPortalLayout>
      <Routes>
        <Route index element={<DummyPage title="Dashboard" />} />
        <Route path="fleet" element={<DummyPage title="Fleet Management" />} />
        <Route path="pilots" element={<DummyPage title="Pilots" />} />
        <Route path="maintenance" element={<DummyPage title="Maintenance" />} />
        <Route path="compliance" element={<DummyPage title="Compliance" />} />
        <Route path="reports" element={<DummyPage title="Reports" />} />
      </Routes>
    </OperatorPortalLayout>
  );
};

export default OperatorPortalPage;
