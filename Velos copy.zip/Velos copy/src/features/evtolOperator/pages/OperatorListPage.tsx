import { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../../store/hooks';
import CreateOperatorModal from '../components/CreateOperatorModal';
import OperatorCard from '../components/OperatorCard';
import { fetchOperatorsThunk } from '../store/operatorThunks';

const OperatorListPage = () => {
  const dispatch = useAppDispatch();
  const { operators, loading } = useAppSelector((state) => state.operator);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    dispatch(fetchOperatorsThunk() as any);
  }, [dispatch]);

  return (
    <div className="container-fluid p-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>eVTOL Operator Management</h2>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          + Create eVTOL Operator
        </button>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : operators.length === 0 ? (
        <div className="text-center py-5">
          <h4 className="text-muted">No operators found</h4>
          <p className="text-muted">Create your first eVTOL operator to get started</p>
        </div>
      ) : (
        <div className="row g-4">
          {operators.map((operator) => (
            <div key={operator.id} className="col-md-4">
              <OperatorCard operator={operator} />
            </div>
          ))}
        </div>
      )}

      <CreateOperatorModal show={showModal} onClose={() => setShowModal(false)} />
    </div>
  );
};

export default OperatorListPage;
