export interface SubmenuItem {
  id: string;
  label: string;
}

export interface MenuSubmenus {
  [key: string]: SubmenuItem[];
}

export const menuSubmenus: MenuSubmenus = {
  home: [
    { id: 'map', label: '2d Map' },
    { id: 'map2', label: '3d Map' },
    { id: 'gantt', label: 'Gantt' }
  ],
  // Future submenus can be added here
  // airspace: [
  //   { id: 'clusters', label: 'Clusters' },
  //   { id: 'regions', label: 'Regions' },
  //   { id: 'zones', label: 'Zones' }
  // ],
};

// Helper to get submenu for current route
export const getSubmenuForRoute = (pathname: string): SubmenuItem[] | null => {
  // Extract the main menu from pathname (e.g., /admin/home -> home)
  const pathParts = pathname.split('/').filter(Boolean);
  if (pathParts.length < 2) return null;
  
  const mainMenu = pathParts[1]; // e.g., 'home', 'airspace', etc.
  return menuSubmenus[mainMenu] || null;
};
