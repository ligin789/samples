import type { UserRole } from '../features/loginUsers/store/loginUsersTypes';

export interface MenuItem {
  name: string;
  path: string;
}

export interface MenuGroup {
  label: string;
  submenu: MenuItem[];
}

export const roleMenuConfig: Record<UserRole, string[]> = {
  PLATFORM_ADMIN: [
    'designer',
    'airspace',
    'kernel',
    'performance',
    'configuration',
    'administration',
    'help'
  ],
  OPERATOR_ADMIN: [
    'dashboard',
    'fleet',
    'vertiports',
    'airspace',
    'operator-users',
    'help'
  ],
  FLEET_MANAGER: [
    'dashboard',
    'fleet',
    'help'
  ],
  VERTIPORT_MANAGER: [
    'dashboard',
    'vertiports',
    'help'
  ],
  AIRSPACE_MANAGER: [
    'dashboard',
    'airspace',
    'help'
  ],
  GROUND_HANDLER_ADMIN: [
    'dashboard',
    'ground-operations',
    'help'
  ],
  GROUND_HANDLER_USER: [
    'dashboard',
    'ground-operations'
  ],
  BOOKING_PARTNER_ADMIN: [
    'dashboard',
    'bookings',
    'partner-users',
    'help'
  ],
  BOOKING_PARTNER_USER: [
    'dashboard',
    'bookings'
  ],
  GUEST_PARTNER_ADMIN: [
    'dashboard',
    'guest-services',
    'help'
  ],
  GUEST_USER: [
    'dashboard',
    'guest-services'
  ],
  OPS_FLEET_MANAGER: [
    'dashboard',
    'fleet',
    'operations',
    'help'
  ],
  CREW_MANAGER: [
    'dashboard',
    'crew',
    'help'
  ],
  SAFETY_OFFICER: [
    'dashboard',
    'safety',
    'help'
  ]
};

export const menuStructure: Record<string, MenuGroup> = {
  designer: {
    label: "Designer",
    submenu: [
      { name: "Process Group", path: "/admin/designer/process-group" },
      { name: "Templates", path: "/admin/designer/templates" },
      { name: "Workflow", path: "/admin/designer/workflow" },
      { name: "Business Rules", path: "/admin/designer/business-rules" },
      { name: "Registry", path: "/admin/designer/registry" },
    ],
  },
  airspace: {
    label: "AirSpace",
    submenu: [
      { name: "Cities", path: "/admin/airspace/cities" },
      { name: "Regions", path: "/admin/airspace/regions" },
      { name: "Authorized Zones", path: "/admin/airspace/zones" },
      { name: "Demand Zones", path: "/admin/airspace/demand-zones" },
    ],
  },
  kernel: {
    label: "Kernel",
    submenu: [
      { name: "Runtime", path: "/admin/kernel/runtime" },
      { name: "Monitoring", path: "/admin/kernel/monitoring" },
    ],
  },
  performance: {
    label: "Performance",
    submenu: [
      { name: "Metrics", path: "/admin/performance/metrics" },
      { name: "KPIs", path: "/admin/performance/kpis" },
    ],
  },
  configuration: {
    label: "Configuration",
    submenu: [
      { name: "Global Settings", path: "/admin/configuration/global-settings" },
      { name: "Execution Settings", path: "/admin/configuration/execution-settings" },
      { name: "Event", path: "/admin/configuration/event" },
      { name: "Configuration", path: "/admin/configuration/configuration" },
      { name: "Security Settings", path: "/admin/configuration/security-settings" },
      { name: "Notification Settings", path: "/admin/configuration/notification-settings" },
    ],
  },
  administration: {
    label: "Administration",
    submenu: [
      { name: "Users", path: "/admin/administration/users" },
      { name: "Tenants", path: "/admin/administration/tenants" },
      { name: "Partners", path: "/admin/administration/partners" },
      { name: "eVTOL Operator", path: "/admin/administration/evtol-operator" },
      { name: "Vertiport", path: "/admin/vertiport" },
      { name: "Login Users", path: "/admin/administration/login-users" },
    ],
  },
  help: {
    label: "Help",
    submenu: [
      { name: "Documentation", path: "/admin/help/documentation" },
      { name: "Support", path: "/admin/help/support" },
      { name: "About", path: "/admin/help/about" },
    ],
  },
  // Operator-specific menus
  dashboard: {
    label: "Dashboard",
    submenu: [
      { name: "Overview", path: "/evtol/dashboard" },
      { name: "Analytics", path: "/evtol/analytics" },
    ],
  },
  fleet: {
    label: "Fleet Management",
    submenu: [
      { name: "Aircraft", path: "/evtol/fleet/aircraft" },
      { name: "Maintenance", path: "/evtol/fleet/maintenance" },
      { name: "Scheduling", path: "/evtol/fleet/scheduling" },
    ],
  },
  vertiports: {
    label: "Vertiports",
    submenu: [
      { name: "Locations", path: "/evtol/vertiports/locations" },
      { name: "Operations", path: "/evtol/vertiports/operations" },
      { name: "Capacity", path: "/evtol/vertiports/capacity" },
    ],
  },
  'operator-users': {
    label: "Users",
    submenu: [
      { name: "Manage Users", path: "/evtol/users" },
      { name: "Roles & Permissions", path: "/evtol/users/roles" },
    ],
  },
  // Ground Handler menus
  'ground-operations': {
    label: "Ground Operations",
    submenu: [
      { name: "Ground Support", path: "/ground/operations" },
      { name: "Equipment", path: "/ground/equipment" },
    ],
  },
  // Booking Partner menus
  bookings: {
    label: "Bookings",
    submenu: [
      { name: "Reservations", path: "/booking/reservations" },
      { name: "Schedule", path: "/booking/schedule" },
    ],
  },
  'partner-users': {
    label: "Partner Users",
    submenu: [
      { name: "Manage Users", path: "/booking/users" },
    ],
  },
  // Guest Services menus
  'guest-services': {
    label: "Guest Services",
    submenu: [
      { name: "Customer Support", path: "/support/customers" },
      { name: "Inquiries", path: "/support/inquiries" },
    ],
  },
  // Operations menus
  operations: {
    label: "Operations",
    submenu: [
      { name: "Flight Operations", path: "/evtol/operations/flights" },
      { name: "Mission Control", path: "/evtol/operations/control" },
    ],
  },
  crew: {
    label: "Crew Management",
    submenu: [
      { name: "Pilots", path: "/evtol/crew/pilots" },
      { name: "Scheduling", path: "/evtol/crew/scheduling" },
    ],
  },
  safety: {
    label: "Safety",
    submenu: [
      { name: "Incidents", path: "/evtol/safety/incidents" },
      { name: "Compliance", path: "/evtol/safety/compliance" },
    ],
  },
};

export const getMenusForRole = (role: UserRole): MenuGroup[] => {
  const allowedMenus = roleMenuConfig[role] || [];
  return allowedMenus.map(menuKey => menuStructure[menuKey]).filter(Boolean);
};