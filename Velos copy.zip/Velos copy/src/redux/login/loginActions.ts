import { LOGIN_REQUEST, LOGIN_SUCCESS, LOGIN_FAILURE, LOGOUT, ADD_USER } from './loginTypes';
import type { User } from './types';
import type { Dispatch } from 'redux';
import type { RootState } from '../../store/rootReducer';

export const loginUser = (email: string) => {
  return (dispatch: Dispatch, getState: () => RootState) => {
    dispatch({ type: LOGIN_REQUEST });

    setTimeout(() => {
      const { loginUsers } = getState().loginUsers;
      const loginUserData = loginUsers.find(
        lu => lu.officialEmail.toLowerCase() === email.toLowerCase() && lu.status === 'ACTIVE'
      );

      if (loginUserData) {
        // Create a User object compatible with old login state
        const user: User = {
          id: 1,
          name: email,
          role: 1,
          roleName: loginUserData.role
        };
        dispatch({ type: LOGIN_SUCCESS, payload: user });
      } else {
        dispatch({ type: LOGIN_FAILURE, payload: 'User not found or inactive' });
      }
    }, 1000);
  };
};

export const logoutUser = () => ({
  type: LOGOUT
});

export const addUser = (userData: User) => ({
  type: ADD_USER,
  payload: userData
});
