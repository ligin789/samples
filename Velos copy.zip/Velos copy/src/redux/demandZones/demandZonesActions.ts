import {
  FETCH_DEMAND_ZONES_REQUEST,
  FETCH_DEMAND_ZONES_SUCCESS,
  FETCH_DEMAND_ZONES_FAILURE,
  ADD_DEMAND_ZONE,
  UPDATE_DEMAND_ZONE,
  DELETE_DEMAND_ZONE,
  type DemandZone,
  type DemandZonesActionTypes
} from './demandZonesTypes';

export const fetchDemandZonesRequest = (): DemandZonesActionTypes => ({
  type: FETCH_DEMAND_ZONES_REQUEST
});

export const fetchDemandZonesSuccess = (zones: DemandZone[]): DemandZonesActionTypes => ({
  type: FETCH_DEMAND_ZONES_SUCCESS,
  payload: zones
});

export const fetchDemandZonesFailure = (error: string): DemandZonesActionTypes => ({
  type: FETCH_DEMAND_ZONES_FAILURE,
  payload: error
});

export const addDemandZoneAction = (zone: DemandZone): DemandZonesActionTypes => ({
  type: ADD_DEMAND_ZONE,
  payload: zone
});

export const updateDemandZoneAction = (zone: DemandZone): DemandZonesActionTypes => ({
  type: UPDATE_DEMAND_ZONE,
  payload: zone
});

export const deleteDemandZoneAction = (id: string): DemandZonesActionTypes => ({
  type: DELETE_DEMAND_ZONE,
  payload: id
});
