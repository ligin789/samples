import {
  FETCH_DEMAND_ZONES_REQUEST,
  FETCH_DEMAND_ZONES_SUCCESS,
  FETCH_DEMAND_ZONES_FAILURE,
  ADD_DEMAND_ZONE,
  UPDATE_DEMAND_ZONE,
  DELETE_DEMAND_ZONE,
  type DemandZonesState,
  type DemandZonesActionTypes
} from './demandZonesTypes';

const STORAGE_KEY = 'demandZones';

const loadFromStorage = (): DemandZonesState => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load demand zones from storage:', e);
  }
  return {
    zones: [
      {
        id: 'dzone-001',
        zoneCode: 'BLR-APT-D',
        zoneName: 'Airport Demand Zone – Bangalore Airport Area',
        regionId: 'blr-central-001',
        density: 'airport',
        type: 'very_high',
        status: 'active',
        geojson: {
          type: 'Feature',
          properties: { id: 'dzone-001', name: 'Airport Demand Zone – Bangalore Airport Area' },
          geometry: {
            type: 'Polygon',
            coordinates: [[
              [77.68, 13.18],
              [77.72, 13.18],
              [77.72, 13.21],
              [77.68, 13.21],
              [77.68, 13.18]
            ]]
          }
        }
      },
      {
        id: 'dzone-002',
        zoneCode: 'BLR-HSP-W',
        zoneName: 'Hospital Demand Zone – Whitefield Medical Area',
        regionId: 'blr-central-001',
        density: 'hospital',
        type: 'high',
        status: 'active',
        geojson: {
          type: 'Feature',
          properties: { id: 'dzone-002', name: 'Hospital Demand Zone – Whitefield Medical Area' },
          geometry: {
            type: 'Polygon',
            coordinates: [[
              [77.73, 12.96],
              [77.77, 12.96],
              [77.77, 12.99],
              [77.73, 12.99],
              [77.73, 12.96]
            ]]
          }
        }
      }
    ],
    loading: false,
    error: null
  };
};

const saveToStorage = (state: DemandZonesState) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save demand zones to storage:', e);
  }
};

const initialState: DemandZonesState = loadFromStorage();

const demandZonesReducer = (
  state = initialState,
  action: DemandZonesActionTypes
): DemandZonesState => {
  let newState: DemandZonesState;

  switch (action.type) {
    case FETCH_DEMAND_ZONES_REQUEST:
      return {
        ...state,
        loading: true,
        error: null
      };

    case FETCH_DEMAND_ZONES_SUCCESS:
      newState = {
        ...state,
        loading: false,
        zones: action.payload
      };
      saveToStorage(newState);
      return newState;

    case FETCH_DEMAND_ZONES_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload
      };

    case ADD_DEMAND_ZONE:
      newState = {
        ...state,
        zones: [...state.zones, action.payload]
      };
      saveToStorage(newState);
      return newState;

    case UPDATE_DEMAND_ZONE:
      newState = {
        ...state,
        zones: state.zones.map((zone) =>
          zone.id === action.payload.id ? action.payload : zone
        )
      };
      saveToStorage(newState);
      return newState;

    case DELETE_DEMAND_ZONE:
      newState = {
        ...state,
        zones: state.zones.filter((zone) => zone.id !== action.payload)
      };
      saveToStorage(newState);
      return newState;

    default:
      return state;
  }
};

export default demandZonesReducer;
