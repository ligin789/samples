export const FETCH_DEMAND_ZONES_REQUEST = 'FETCH_DEMAND_ZONES_REQUEST';
export const FETCH_DEMAND_ZONES_SUCCESS = 'FETCH_DEMAND_ZONES_SUCCESS';
export const FETCH_DEMAND_ZONES_FAILURE = 'FETCH_DEMAND_ZONES_FAILURE';
export const ADD_DEMAND_ZONE = 'ADD_DEMAND_ZONE';
export const UPDATE_DEMAND_ZONE = 'UPDATE_DEMAND_ZONE';
export const DELETE_DEMAND_ZONE = 'DELETE_DEMAND_ZONE';

export interface DemandZone {
  id: string;
  zoneCode: string;
  zoneName: string;
  regionId: string;
  density: 'airport' | 'station' | 'hospital' | 'campus' | 'commercial' | 'tourism';
  type: 'very_high' | 'high' | 'medium' | 'low';
  status: 'active' | 'inactive';
  geojson: any;
}

export interface DemandZonesState {
  zones: DemandZone[];
  loading: boolean;
  error: string | null;
}

interface FetchDemandZonesRequestAction {
  type: typeof FETCH_DEMAND_ZONES_REQUEST;
}

interface FetchDemandZonesSuccessAction {
  type: typeof FETCH_DEMAND_ZONES_SUCCESS;
  payload: DemandZone[];
}

interface FetchDemandZonesFailureAction {
  type: typeof FETCH_DEMAND_ZONES_FAILURE;
  payload: string;
}

interface AddDemandZoneAction {
  type: typeof ADD_DEMAND_ZONE;
  payload: DemandZone;
}

interface UpdateDemandZoneAction {
  type: typeof UPDATE_DEMAND_ZONE;
  payload: DemandZone;
}

interface DeleteDemandZoneAction {
  type: typeof DELETE_DEMAND_ZONE;
  payload: string;
}

export type DemandZonesActionTypes =
  | FetchDemandZonesRequestAction
  | FetchDemandZonesSuccessAction
  | FetchDemandZonesFailureAction
  | AddDemandZoneAction
  | UpdateDemandZoneAction
  | DeleteDemandZoneAction;
