import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  fetchDemandZonesRequest,
  fetchDemandZonesSuccess,
  fetchDemandZonesFailure,
  addDemandZoneAction,
  updateDemandZoneAction,
  deleteDemandZoneAction
} from './demandZonesActions';
import type { DemandZone, DemandZonesActionTypes } from './demandZonesTypes';

export const fetchDemandZones = () => {
  return async (dispatch: Dispatch<DemandZonesActionTypes>) => {
    dispatch(fetchDemandZonesRequest());
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      const zones: DemandZone[] = [];
      dispatch(fetchDemandZonesSuccess(zones));
    } catch (error: any) {
      dispatch(fetchDemandZonesFailure(error.message || 'Failed to fetch demand zones'));
    }
  };
};

export const addDemandZone = (zoneData: Omit<DemandZone, 'id'>) => {
  return async (dispatch: Dispatch<DemandZonesActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      const newZone: DemandZone = {
        ...zoneData,
        id: uuidv4()
      };
      dispatch(addDemandZoneAction(newZone));
    } catch (error: any) {
      console.error('Failed to add demand zone:', error);
    }
  };
};

export const updateDemandZone = (zone: DemandZone) => {
  return async (dispatch: Dispatch<DemandZonesActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(updateDemandZoneAction(zone));
    } catch (error: any) {
      console.error('Failed to update demand zone:', error);
    }
  };
};

export const deleteDemandZone = (id: string) => {
  return async (dispatch: Dispatch<DemandZonesActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(deleteDemandZoneAction(id));
    } catch (error: any) {
      console.error('Failed to delete demand zone:', error);
    }
  };
};
