import {
  FETCH_PROCESS_REQUEST,
  FETCH_PROCESS_SUCCESS,
  FETCH_PROCESS_FAILURE,
  ADD_PROCESS,
  UPDATE_PROCESS,
  DELETE_PROCESS,
  SET_SELECTED_PROCESS,
  UPDATE_PROCESS_FLOW,
  type ProcessState,
  type Process
} from './processTypes';

interface ProcessAction {
  type: string;
  payload?: Process[] | Process | { id: string; data: Partial<Process> } | { processId: string; processFlow: { nodes: any[]; edges: any[] } } | string;
}

const initialState: any = {
  loading: false,
  error: null,
  process: [],
  selectedProcess: null,
  selectedNode: null
};

const processReducer = (state = initialState, action: ProcessAction): ProcessState => {
  switch (action.type) {
    case FETCH_PROCESS_REQUEST:
      return { ...state, loading: true, error: null };

    case FETCH_PROCESS_SUCCESS:
      return { 
        ...state, 
        loading: false, 
        process: action.payload as Process[] 
      };

    case FETCH_PROCESS_FAILURE:
      return { 
        ...state, 
        loading: false, 
        error: action.payload as string 
      };

    case ADD_PROCESS:
      return {
        ...state,
        process: [...state.process, action.payload as Process]
      };

    case UPDATE_PROCESS: {
      const { id, data } = action.payload as { id: string; data: Partial<Process> };
      return {
        ...state,
        process: state.process.map((p:any) =>
          p.process_id === id ? { ...p, ...data } : p
        )
      };
    }

    case DELETE_PROCESS:
      return {
        ...state,
        process: state.process.filter(
          (p:any) => p.process_id !== (action.payload as string)
        )
      };

    case SET_SELECTED_PROCESS:
      return {
        ...state,
        selectedProcess: action.payload as Process
      };

    case UPDATE_PROCESS_FLOW: {
      const { processId, processFlow } = action.payload as { processId: string; processFlow: { nodes: any[]; edges: any[] } };
      return {
        ...state,
        process: state.process.map((p: any) =>
          p.process_id === processId ? { ...p, processFlow } : p
        ),
        selectedProcess: state.selectedProcess?.process_id === processId
          ? { ...state.selectedProcess, processFlow }
          : state.selectedProcess
      };
    }

    case 'SET_SELECTED_NODE':
      return {
        ...state,
        selectedNode: action.payload
      };

    case 'UPDATE_NODE': {
      const { nodeId, nodeData } = action.payload as { nodeId: string; nodeData: any };
      if (!state.selectedProcess?.processFlow?.nodes) return state;
      
      const updatedNodes = state.selectedProcess.processFlow.nodes.map((n: any) =>
        (n.node_id === nodeId || n.id === nodeId) ? { ...n, ...nodeData } : n
      );
      
      const updatedProcess = {
        ...state.selectedProcess,
        processFlow: {
          ...state.selectedProcess.processFlow,
          nodes: updatedNodes
        }
      };
      
      return {
        ...state,
        selectedProcess: updatedProcess,
        selectedNode: state.selectedNode?.node_id === nodeId || state.selectedNode?.id === nodeId
          ? { ...state.selectedNode, ...nodeData }
          : state.selectedNode,
        process: state.process.map((p: any) =>
          p.process_id === state.selectedProcess.process_id ? updatedProcess : p
        )
      };
    }

    case 'UPDATE_TASK': {
      const { taskKey, taskData } = action.payload as { taskKey: string; taskData: any };
      if (!state.selectedProcess?.tasks) return state;
      
      const updatedTasks = state.selectedProcess.tasks.map((t: any) =>
        t.task_key === taskKey ? { ...t, ...taskData } : t
      );
      
      const updatedProcess = {
        ...state.selectedProcess,
        tasks: updatedTasks
      };
      
      return {
        ...state,
        selectedProcess: updatedProcess,
        process: state.process.map((p: any) =>
          p.process_id === state.selectedProcess.process_id ? updatedProcess : p
        )
      };
    }

    case 'ADD_TASK': {
      if (!state.selectedProcess) return state;
      
      const updatedProcess = {
        ...state.selectedProcess,
        tasks: [...(state.selectedProcess.tasks || []), action.payload]
      };
      
      return {
        ...state,
        selectedProcess: updatedProcess,
        process: state.process.map((p: any) =>
          p.process_id === state.selectedProcess.process_id ? updatedProcess : p
        )
      };
    }

    default:
      return state;
  }
};

export default processReducer;
