import {
  FETCH_ZONES_REQUEST,
  FETCH_ZONES_SUCCESS,
  FETCH_ZONES_FAILURE,
  ADD_ZONE,
  UPDATE_ZONE,
  DELETE_ZONE,
  type AuthorizedZonesState,
  type AuthorizedZonesActionTypes
} from './authorizedZonesTypes';

const STORAGE_KEY = 'authorizedZones';

const loadFromStorage = (): AuthorizedZonesState => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Failed to load authorized zones from storage:', e);
  }
  return {
    zones: [
      {
        id: 'zone-001',
        zoneCode: 'BLR-COM-N',
        zoneName: 'Commercial Zone – Bangalore North',
        regionId: 'blr-central-001',
        type: 'commercial',
        priority: 5,
        status: 'active',
        geojson: {
          type: 'Feature',
          properties: { id: 'zone-001', name: 'Commercial Zone – Bangalore North' },
          geometry: {
            type: 'Polygon',
            coordinates: [[
              [77.58, 12.98],
              [77.62, 12.98],
              [77.62, 13.01],
              [77.58, 13.01],
              [77.58, 12.98]
            ]]
          }
        }
      },
      {
        id: 'zone-002',
        zoneCode: 'BLR-IND-E',
        zoneName: 'Industrial Zone – Bangalore East',
        regionId: 'blr-central-001',
        type: 'industrial',
        priority: 7,
        status: 'active',
        geojson: {
          type: 'Feature',
          properties: { id: 'zone-002', name: 'Industrial Zone – Bangalore East' },
          geometry: {
            type: 'Polygon',
            coordinates: [[
              [77.65, 12.95],
              [77.69, 12.95],
              [77.69, 12.98],
              [77.65, 12.98],
              [77.65, 12.95]
            ]]
          }
        }
      }
    ],
    loading: false,
    error: null
  };
};

const saveToStorage = (state: AuthorizedZonesState) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save authorized zones to storage:', e);
  }
};

const initialState: AuthorizedZonesState = loadFromStorage();

const authorizedZonesReducer = (
  state = initialState,
  action: AuthorizedZonesActionTypes
): AuthorizedZonesState => {
  let newState: AuthorizedZonesState;

  switch (action.type) {
    case FETCH_ZONES_REQUEST:
      return {
        ...state,
        loading: true,
        error: null
      };

    case FETCH_ZONES_SUCCESS:
      newState = {
        ...state,
        loading: false,
        zones: action.payload
      };
      saveToStorage(newState);
      return newState;

    case FETCH_ZONES_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload
      };

    case ADD_ZONE:
      newState = {
        ...state,
        zones: [...state.zones, action.payload]
      };
      saveToStorage(newState);
      return newState;

    case UPDATE_ZONE:
      newState = {
        ...state,
        zones: state.zones.map((zone) =>
          zone.id === action.payload.id ? action.payload : zone
        )
      };
      saveToStorage(newState);
      return newState;

    case DELETE_ZONE:
      newState = {
        ...state,
        zones: state.zones.filter((zone) => zone.id !== action.payload)
      };
      saveToStorage(newState);
      return newState;

    default:
      return state;
  }
};

export default authorizedZonesReducer;
