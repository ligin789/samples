import {
  FETCH_ZONES_REQUEST,
  FETCH_ZONES_SUCCESS,
  FETCH_ZONES_FAILURE,
  ADD_ZONE,
  UPDATE_ZONE,
  DELETE_ZONE,
  type AuthorizedZone,
  type AuthorizedZonesActionTypes
} from './authorizedZonesTypes';

export const fetchZonesRequest = (): AuthorizedZonesActionTypes => ({
  type: FETCH_ZONES_REQUEST
});

export const fetchZonesSuccess = (zones: AuthorizedZone[]): AuthorizedZonesActionTypes => ({
  type: FETCH_ZONES_SUCCESS,
  payload: zones
});

export const fetchZonesFailure = (error: string): AuthorizedZonesActionTypes => ({
  type: FETCH_ZONES_FAILURE,
  payload: error
});

export const addZoneAction = (zone: AuthorizedZone): AuthorizedZonesActionTypes => ({
  type: ADD_ZONE,
  payload: zone
});

export const updateZoneAction = (zone: AuthorizedZone): AuthorizedZonesActionTypes => ({
  type: UPDATE_ZONE,
  payload: zone
});

export const deleteZoneAction = (id: string): AuthorizedZonesActionTypes => ({
  type: DELETE_ZONE,
  payload: id
});
