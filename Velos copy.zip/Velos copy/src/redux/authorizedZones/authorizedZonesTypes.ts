export const FETCH_ZONES_REQUEST = 'FETCH_ZONES_REQUEST';
export const FETCH_ZONES_SUCCESS = 'FETCH_ZONES_SUCCESS';
export const FETCH_ZONES_FAILURE = 'FETCH_ZONES_FAILURE';
export const ADD_ZONE = 'ADD_ZONE';
export const UPDATE_ZONE = 'UPDATE_ZONE';
export const DELETE_ZONE = 'DELETE_ZONE';

export interface AuthorizedZone {
  id: string;
  zoneCode: string;
  zoneName: string;
  regionId: string;
  type: 'commercial' | 'residential' | 'industrial' | 'restricted';
  priority: number;
  noFlyReason?: string;
  status: 'active' | 'inactive';
  geojson: any;
}

export interface AuthorizedZonesState {
  zones: AuthorizedZone[];
  loading: boolean;
  error: string | null;
}

interface FetchZonesRequestAction {
  type: typeof FETCH_ZONES_REQUEST;
}

interface FetchZonesSuccessAction {
  type: typeof FETCH_ZONES_SUCCESS;
  payload: AuthorizedZone[];
}

interface FetchZonesFailureAction {
  type: typeof FETCH_ZONES_FAILURE;
  payload: string;
}

interface AddZoneAction {
  type: typeof ADD_ZONE;
  payload: AuthorizedZone;
}

interface UpdateZoneAction {
  type: typeof UPDATE_ZONE;
  payload: AuthorizedZone;
}

interface DeleteZoneAction {
  type: typeof DELETE_ZONE;
  payload: string;
}

export type AuthorizedZonesActionTypes =
  | FetchZonesRequestAction
  | FetchZonesSuccessAction
  | FetchZonesFailureAction
  | AddZoneAction
  | UpdateZoneAction
  | DeleteZoneAction;
