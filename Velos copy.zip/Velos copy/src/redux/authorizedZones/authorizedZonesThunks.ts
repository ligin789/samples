import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  fetchZonesRequest,
  fetchZonesSuccess,
  fetchZonesFailure,
  addZoneAction,
  updateZoneAction,
  deleteZoneAction
} from './authorizedZonesActions';
import type { AuthorizedZone, AuthorizedZonesActionTypes } from './authorizedZonesTypes';

export const fetchAuthorizedZones = () => {
  return async (dispatch: Dispatch<AuthorizedZonesActionTypes>) => {
    dispatch(fetchZonesRequest());
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      const zones: AuthorizedZone[] = [];
      dispatch(fetchZonesSuccess(zones));
    } catch (error: any) {
      dispatch(fetchZonesFailure(error.message || 'Failed to fetch zones'));
    }
  };
};

export const addAuthorizedZone = (zoneData: Omit<AuthorizedZone, 'id'>) => {
  return async (dispatch: Dispatch<AuthorizedZonesActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      const newZone: AuthorizedZone = {
        ...zoneData,
        id: uuidv4()
      };
      dispatch(addZoneAction(newZone));
    } catch (error: any) {
      console.error('Failed to add zone:', error);
    }
  };
};

export const updateAuthorizedZone = (zone: AuthorizedZone) => {
  return async (dispatch: Dispatch<AuthorizedZonesActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(updateZoneAction(zone));
    } catch (error: any) {
      console.error('Failed to update zone:', error);
    }
  };
};

export const deleteAuthorizedZone = (id: string) => {
  return async (dispatch: Dispatch<AuthorizedZonesActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(deleteZoneAction(id));
    } catch (error: any) {
      console.error('Failed to delete zone:', error);
    }
  };
};
