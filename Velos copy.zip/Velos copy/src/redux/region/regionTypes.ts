export const FETCH_REGIONS_REQUEST = 'FETCH_REGIONS_REQUEST';
export const FETCH_REGIONS_SUCCESS = 'FETCH_REGIONS_SUCCESS';
export const FETCH_REGIONS_FAILURE = 'FETCH_REGIONS_FAILURE';
export const ADD_REGION = 'ADD_REGION';
export const UPDATE_REGION = 'UPDATE_REGION';
export const DELETE_REGION = 'DELETE_REGION';

export interface Region {
  id: string;
  region_code: string;
  region_name: string;
  cluster_id: string;
  city: string;
  altitude: number;
  status: 'ACTIVE' | 'INACTIVE';
  geojson?: any;
}

export interface RegionState {
  regions: Region[];
  loading: boolean;
  error: string | null;
}

interface FetchRegionsRequestAction {
  type: typeof FETCH_REGIONS_REQUEST;
}

interface FetchRegionsSuccessAction {
  type: typeof FETCH_REGIONS_SUCCESS;
  payload: Region[];
}

interface FetchRegionsFailureAction {
  type: typeof FETCH_REGIONS_FAILURE;
  payload: string;
}

interface AddRegionAction {
  type: typeof ADD_REGION;
  payload: Region;
}

interface UpdateRegionAction {
  type: typeof UPDATE_REGION;
  payload: Region;
}

interface DeleteRegionAction {
  type: typeof DELETE_REGION;
  payload: string;
}

export type RegionActionTypes =
  | FetchRegionsRequestAction
  | FetchRegionsSuccessAction
  | FetchRegionsFailureAction
  | AddRegionAction
  | UpdateRegionAction
  | DeleteRegionAction;
