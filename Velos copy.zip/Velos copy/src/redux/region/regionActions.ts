import {
  FETCH_REGIONS_REQUEST,
  FETCH_REGIONS_SUCCESS,
  FETCH_REGIONS_FAILURE,
  ADD_REGION,
  UPDATE_REGION,
  DELETE_REGION,
  type Region,
  type RegionActionTypes
} from './regionTypes';

export const fetchRegionsRequest = (): RegionActionTypes => ({
  type: FETCH_REGIONS_REQUEST
});

export const fetchRegionsSuccess = (regions: Region[]): RegionActionTypes => ({
  type: FETCH_REGIONS_SUCCESS,
  payload: regions
});

export const fetchRegionsFailure = (error: string): RegionActionTypes => ({
  type: FETCH_REGIONS_FAILURE,
  payload: error
});

export const addRegionAction = (region: Region): RegionActionTypes => ({
  type: ADD_REGION,
  payload: region
});

export const updateRegionAction = (region: Region): RegionActionTypes => ({
  type: UPDATE_REGION,
  payload: region
});

export const deleteRegionAction = (id: string): RegionActionTypes => ({
  type: DELETE_REGION,
  payload: id
});
