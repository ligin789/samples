import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  fetchRegionsRequest,
  fetchRegionsSuccess,
  fetchRegionsFailure,
  addRegionAction,
  updateRegionAction,
  deleteRegionAction
} from './regionActions';
import type { Region, RegionActionTypes } from './regionTypes';

export const fetchRegions = () => {
  return async (dispatch: Dispatch<RegionActionTypes>) => {
    dispatch(fetchRegionsRequest());
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      const regions: Region[] = [];
      dispatch(fetchRegionsSuccess(regions));
    } catch (error: any) {
      dispatch(fetchRegionsFailure(error.message || 'Failed to fetch regions'));
    }
  };
};

export const addRegion = (regionData: Omit<Region, 'id'>) => {
  return async (dispatch: Dispatch<RegionActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      const newRegion: Region = {
        ...regionData,
        id: uuidv4()
      };
      dispatch(addRegionAction(newRegion));
    } catch (error: any) {
      console.error('Failed to add region:', error);
    }
  };
};

export const updateRegion = (region: Region) => {
  return async (dispatch: Dispatch<RegionActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(updateRegionAction(region));
    } catch (error: any) {
      console.error('Failed to update region:', error);
    }
  };
};

export const deleteRegion = (id: string) => {
  return async (dispatch: Dispatch<RegionActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(deleteRegionAction(id));
    } catch (error: any) {
      console.error('Failed to delete region:', error);
    }
  };
};
