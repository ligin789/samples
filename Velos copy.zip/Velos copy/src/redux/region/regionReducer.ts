import {
  FETCH_REGIONS_REQUEST,
  FETCH_REGIONS_SUCCESS,
  FETCH_REGIONS_FAILURE,
  ADD_REGION,
  UPDATE_REGION,
  DELETE_REGION,
  type RegionState,
  type RegionActionTypes
} from './regionTypes';

const initialState: RegionState = {
  regions: [],
  loading: false,
  error: null
};

const regionReducer = (
  state = initialState,
  action: RegionActionTypes
): RegionState => {
  switch (action.type) {
    case FETCH_REGIONS_REQUEST:
      return {
        ...state,
        loading: true,
        error: null
      };

    case FETCH_REGIONS_SUCCESS:
      return {
        ...state,
        loading: false,
        regions: action.payload
      };

    case FETCH_REGIONS_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload
      };

    case ADD_REGION:
      return {
        ...state,
        regions: [...state.regions, action.payload]
      };

    case UPDATE_REGION:
      return {
        ...state,
        regions: state.regions.map((region) =>
          region.id === action.payload.id ? action.payload : region
        )
      };

    case DELETE_REGION:
      return {
        ...state,
        regions: state.regions.filter((region) => region.id !== action.payload)
      };

    default:
      return state;
  }
};

export default regionReducer;
