import type { Dispatch } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import {
  fetchClustersRequest,
  fetchClustersSuccess,
  fetchClustersFailure,
  addClusterAction,
  updateClusterAction,
  deleteClusterAction
} from './clusterActions';
import type { Cluster, ClusterActionTypes } from './clusterTypes';

export const fetchClusters = () => {
  return async (dispatch: Dispatch<ClusterActionTypes>) => {
    dispatch(fetchClustersRequest());
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      const clusters: Cluster[] = [];
      dispatch(fetchClustersSuccess(clusters));
    } catch (error: any) {
      dispatch(fetchClustersFailure(error.message || 'Failed to fetch clusters'));
    }
  };
};

export const addCluster = (clusterData: Omit<Cluster, 'id' | 'createdDate'>) => {
  return async (dispatch: Dispatch<ClusterActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      const newCluster: Cluster = {
        ...clusterData,
        id: uuidv4(),
        createdDate: new Date().toISOString()
      };
      dispatch(addClusterAction(newCluster));
    } catch (error: any) {
      console.error('Failed to add cluster:', error);
    }
  };
};

export const updateCluster = (cluster: Cluster) => {
  return async (dispatch: Dispatch<ClusterActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(updateClusterAction(cluster));
    } catch (error: any) {
      console.error('Failed to update cluster:', error);
    }
  };
};

export const deleteCluster = (id: string) => {
  return async (dispatch: Dispatch<ClusterActionTypes>) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      dispatch(deleteClusterAction(id));
    } catch (error: any) {
      console.error('Failed to delete cluster:', error);
    }
  };
};
