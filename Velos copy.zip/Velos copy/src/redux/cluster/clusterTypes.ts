export const FETCH_CLUSTERS_REQUEST = 'FETCH_CLUSTERS_REQUEST';
export const FETCH_CLUSTERS_SUCCESS = 'FETCH_CLUSTERS_SUCCESS';
export const FETCH_CLUSTERS_FAILURE = 'FETCH_CLUSTERS_FAILURE';
export const ADD_CLUSTER = 'ADD_CLUSTER';
export const UPDATE_CLUSTER = 'UPDATE_CLUSTER';
export const DELETE_CLUSTER = 'DELETE_CLUSTER';

export interface Cluster {
  id: string;
  cluster_code: string;
  cluster_name: string;
  description?: string;
  country?: string;
  code?: string;
  timezone?: string;
  createdDate?: string;
  status?: string;
  geoJson?: any;
}

export interface ClusterState {
  clusters: Cluster[];
  loading: boolean;
  error: string | null;
}

interface FetchClustersRequestAction {
  type: typeof FETCH_CLUSTERS_REQUEST;
}

interface FetchClustersSuccessAction {
  type: typeof FETCH_CLUSTERS_SUCCESS;
  payload: Cluster[];
}

interface FetchClustersFailureAction {
  type: typeof FETCH_CLUSTERS_FAILURE;
  payload: string;
}

interface AddClusterAction {
  type: typeof ADD_CLUSTER;
  payload: Cluster;
}

interface UpdateClusterAction {
  type: typeof UPDATE_CLUSTER;
  payload: Cluster;
}

interface DeleteClusterAction {
  type: typeof DELETE_CLUSTER;
  payload: string;
}

export type ClusterActionTypes =
  | FetchClustersRequestAction
  | FetchClustersSuccessAction
  | FetchClustersFailureAction
  | AddClusterAction
  | UpdateClusterAction
  | DeleteClusterAction;
