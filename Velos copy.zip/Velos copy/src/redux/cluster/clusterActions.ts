import {
  FETCH_CLUSTERS_REQUEST,
  FETCH_CLUSTERS_SUCCESS,
  FETCH_CLUSTERS_FAILURE,
  ADD_CLUSTER,
  UPDATE_CLUSTER,
  DELETE_CLUSTER,
  type Cluster,
  type ClusterActionTypes
} from './clusterTypes';

export const fetchClustersRequest = (): ClusterActionTypes => ({
  type: FETCH_CLUSTERS_REQUEST
});

export const fetchClustersSuccess = (clusters: Cluster[]): ClusterActionTypes => ({
  type: FETCH_CLUSTERS_SUCCESS,
  payload: clusters
});

export const fetchClustersFailure = (error: string): ClusterActionTypes => ({
  type: FETCH_CLUSTERS_FAILURE,
  payload: error
});

export const addClusterAction = (cluster: Cluster): ClusterActionTypes => ({
  type: ADD_CLUSTER,
  payload: cluster
});

export const updateClusterAction = (cluster: Cluster): ClusterActionTypes => ({
  type: UPDATE_CLUSTER,
  payload: cluster
});

export const deleteClusterAction = (id: string): ClusterActionTypes => ({
  type: DELETE_CLUSTER,
  payload: id
});
