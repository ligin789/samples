import {
  FETCH_CLUSTERS_REQUEST,
  FETCH_CLUSTERS_SUCCESS,
  FETCH_CLUSTERS_FAILURE,
  ADD_CLUSTER,
  UPDATE_CLUSTER,
  DELETE_CLUSTER,
  type ClusterState,
  type ClusterActionTypes
} from './clusterTypes';

const blrId = 'blr-central-001';

const initialState: ClusterState = {
  clusters: [
    {
      id: blrId,
      cluster_code: 'BLR',
      cluster_name: 'Bangalore Central',
      description: 'Bangalore Central Cluster',
      country: 'India',
      code: 'KA',
      timezone: 'Asia/Kolkata',
      createdDate: '2024-01-15',
      status: 'Active',
      geoJson: {
        type: 'Feature',
        properties: { id: blrId, name: 'Bangalore Central' },
        geometry: {
          type: 'Polygon',
          coordinates: [[
            [77.56, 12.96],
            [77.60, 12.96],
            [77.60, 12.99],
            [77.56, 12.99],
            [77.56, 12.96]
          ]]
        }
      }
    }
  ],
  loading: false,
  error: null
};

const clusterReducer = (
  state = initialState,
  action: ClusterActionTypes
): ClusterState => {
  switch (action.type) {
    case FETCH_CLUSTERS_REQUEST:
      return {
        ...state,
        loading: true,
        error: null
      };

    case FETCH_CLUSTERS_SUCCESS:
      return {
        ...state,
        loading: false,
        clusters: action.payload
      };

    case FETCH_CLUSTERS_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload
      };

    case ADD_CLUSTER:
      return {
        ...state,
        clusters: [...state.clusters, action.payload]
      };

    case UPDATE_CLUSTER:
      return {
        ...state,
        clusters: state.clusters.map((cluster) =>
          cluster.id === action.payload.id ? action.payload : cluster
        )
      };

    case DELETE_CLUSTER:
      return {
        ...state,
        clusters: state.clusters.filter((cluster) => cluster.id !== action.payload)
      };

    default:
      return state;
  }
};

export default clusterReducer;
