import { useLocation } from 'react-router-dom';
import { getSubmenuForRoute } from '../../config/menuSubmenus';
import styles from './SecondaryHeader.module.css';

interface SecondaryHeaderProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

const SecondaryHeader = ({ activeTab, onTabChange }: SecondaryHeaderProps) => {
  const location = useLocation();
  const submenuItems = getSubmenuForRoute(location.pathname);

  if (!submenuItems || submenuItems.length === 0) {
    return null;
  }

  return (
    <div className={styles.secondaryHeader}>
      <div className={styles.tabContainer}>
        {submenuItems.map((item) => (
          <button
            key={item.id}
            className={`${styles.tab} ${activeTab === item.id ? styles.active : ''}`}
            onClick={() => onTabChange(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SecondaryHeader;
