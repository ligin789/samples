import { useMemo } from 'react';
import flightData from '../../data/flightOperations.json';

interface TimelineStage {
  stage: string;
  expectedStart: string;
  expectedEnd: string;
  actualStart: string | null;
  actualEnd: string | null;
  status: 'completed' | 'in_progress' | 'pending' | 'delayed';
  delayMinutes: number;
}

interface Flight {
  id: string;
  aircraftId: string;
  originVertiportId: string;
  destinationVertiportId: string;
  timeline: TimelineStage[];
}

const FlightGanttChart = () => {
  const { generatedAt, vertiports, aircraft, flights } = flightData;

  const getVertiportName = (id: string) => {
    return vertiports.find(v => v.id === id)?.name || id;
  };

  const getAircraftModel = (id: string) => {
    return aircraft.find(a => a.id === id)?.model || id;
  };

  const getStageColor = (status: string, delayMinutes: number) => {
    if (delayMinutes > 0) return '#ef4444';
    switch (status) {
      case 'completed': return '#22c55e';
      case 'in_progress': return '#3b82f6';
      case 'pending': return '#9ca3af';
      default: return '#9ca3af';
    }
  };

  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const { minTime, maxTime, timeRange } = useMemo(() => {
    let min = new Date(flights[0].timeline[0].expectedStart).getTime();
    let max = new Date(flights[0].timeline[0].expectedEnd).getTime();

    flights.forEach((flight: Flight) => {
      flight.timeline.forEach((stage: TimelineStage) => {
        const start = new Date(stage.expectedStart).getTime();
        const end = new Date(stage.expectedEnd).getTime();
        if (start < min) min = start;
        if (end > max) max = end;
      });
    });

    return { minTime: min, maxTime: max, timeRange: max - min };
  }, [flights]);

  const currentTime = new Date(generatedAt).getTime();
  const currentTimePosition = ((currentTime - minTime) / timeRange) * 100;

  const getStagePosition = (startTime: string, endTime: string) => {
    const start = new Date(startTime).getTime();
    const end = new Date(endTime).getTime();
    const left = ((start - minTime) / timeRange) * 100;
    const width = ((end - start) / timeRange) * 100;
    return { left: `${left}%`, width: `${width}%` };
  };

  const timeMarkers = useMemo(() => {
    const markers = [];
    const interval = 15 * 60 * 1000; // 15 minutes
    for (let time = minTime; time <= maxTime; time += interval) {
      markers.push(time);
    }
    return markers;
  }, [minTime, maxTime]);

  return (
    <div style={{ 
      width: '100%', 
      height: 'calc(100vh - 130px)', 
      background: '#f9fafb',
      overflow: 'auto',
      padding: '20px'
    }}>
      <div style={{ minWidth: '1200px' }}>
        <h2 style={{ marginBottom: '20px', fontSize: '24px', fontWeight: 'bold' }}>
          Flight Operations Gantt Chart
        </h2>

        {/* Timeline Header */}
        <div style={{ marginBottom: '10px', marginLeft: '300px', position: 'relative', height: '40px' }}>
          {timeMarkers.map((time, idx) => {
            const position = ((time - minTime) / timeRange) * 100;
            return (
              <div
                key={idx}
                style={{
                  position: 'absolute',
                  left: `${position}%`,
                  top: 0,
                  fontSize: '12px',
                  color: '#6b7280',
                  transform: 'translateX(-50%)'
                }}
              >
                {formatTime(new Date(time).toISOString())}
              </div>
            );
          })}
        </div>

        {/* Gantt Rows */}
        {flights.map((flight: Flight) => (
          <div
            key={flight.id}
            style={{
              display: 'flex',
              marginBottom: '15px',
              background: 'white',
              borderRadius: '8px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              overflow: 'hidden'
            }}
          >
            {/* Flight Label */}
            <div
              style={{
                width: '300px',
                padding: '15px',
                borderRight: '1px solid #e5e7eb',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center'
              }}
            >
              <div style={{ fontWeight: 'bold', fontSize: '14px', marginBottom: '4px' }}>
                {flight.id}
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>
                {getAircraftModel(flight.aircraftId)}
              </div>
              <div style={{ fontSize: '12px', color: '#374151' }}>
                {getVertiportName(flight.originVertiportId)} → {getVertiportName(flight.destinationVertiportId)}
              </div>
            </div>

            {/* Timeline Bars */}
            <div style={{ flex: 1, position: 'relative', height: '80px', padding: '10px 0' }}>
              {/* Grid Lines */}
              {timeMarkers.map((time, idx) => {
                const position = ((time - minTime) / timeRange) * 100;
                return (
                  <div
                    key={idx}
                    style={{
                      position: 'absolute',
                      left: `${position}%`,
                      top: 0,
                      bottom: 0,
                      width: '1px',
                      background: '#e5e7eb'
                    }}
                  />
                );
              })}

              {/* Current Time Indicator */}
              {currentTimePosition >= 0 && currentTimePosition <= 100 && (
                <div
                  style={{
                    position: 'absolute',
                    left: `${currentTimePosition}%`,
                    top: 0,
                    bottom: 0,
                    width: '2px',
                    background: '#dc2626',
                    zIndex: 10
                  }}
                />
              )}

              {/* Stage Bars */}
              {flight.timeline.map((stage: TimelineStage, idx: number) => {
                const position = getStagePosition(stage.expectedStart, stage.expectedEnd);
                const color = getStageColor(stage.status, stage.delayMinutes);

                return (
                  <div
                    key={idx}
                    style={{
                      position: 'absolute',
                      left: position.left,
                      width: position.width,
                      top: '15px',
                      height: '50px',
                      background: color,
                      borderRadius: '4px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'white',
                      fontSize: '11px',
                      fontWeight: '500',
                      textTransform: 'capitalize',
                      border: '1px solid rgba(255,255,255,0.2)',
                      boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
                    }}
                    title={`${stage.stage} - ${stage.status}${stage.delayMinutes > 0 ? ` (Delayed ${stage.delayMinutes} min)` : ''}`}
                  >
                    {stage.stage}
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {/* Legend */}
        <div style={{ 
          marginTop: '30px', 
          padding: '15px', 
          background: 'white', 
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontWeight: 'bold', marginBottom: '10px' }}>Legend</div>
          <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ width: '20px', height: '20px', background: '#22c55e', borderRadius: '4px' }} />
              <span style={{ fontSize: '13px' }}>Completed</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ width: '20px', height: '20px', background: '#3b82f6', borderRadius: '4px' }} />
              <span style={{ fontSize: '13px' }}>In Progress</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ width: '20px', height: '20px', background: '#9ca3af', borderRadius: '4px' }} />
              <span style={{ fontSize: '13px' }}>Pending</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ width: '20px', height: '20px', background: '#ef4444', borderRadius: '4px' }} />
              <span style={{ fontSize: '13px' }}>Delayed</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ width: '2px', height: '20px', background: '#dc2626' }} />
              <span style={{ fontSize: '13px' }}>Current Time</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlightGanttChart;
