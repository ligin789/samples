import { useEffect, useRef } from 'react';
import * as Cesium from 'cesium';

const CitiesMap = () => {
  const viewerRef = useRef<HTMLDivElement>(null);
  const cesiumViewerRef = useRef<Cesium.Viewer | null>(null);

  useEffect(() => {
    if (!viewerRef.current) return;

    cesiumViewerRef.current = new Cesium.Viewer(viewerRef.current, {
      animation: false,
      timeline: false,
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      baseLayerPicker: false,
      navigationHelpButton: false,
      fullscreenButton: false,
    });

    cesiumViewerRef.current.camera.setView({
      destination: Cesium.Cartesian3.fromDegrees(77.5946, 12.9716, 15000),
    });

    cesiumViewerRef.current.entities.add({
      position: Cesium.Cartesian3.fromDegrees(77.5946, 12.9716),
      point: {
        pixelSize: 10,
        color: Cesium.Color.RED,
        outlineColor: Cesium.Color.WHITE,
        outlineWidth: 2,
      },
      label: {
        text: 'Bangalore',
        font: '14px sans-serif',
        fillColor: Cesium.Color.WHITE,
        outlineColor: Cesium.Color.BLACK,
        outlineWidth: 2,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
        pixelOffset: new Cesium.Cartesian2(0, -10),
      },
    });

    return () => {
      if (cesiumViewerRef.current) {
        cesiumViewerRef.current.destroy();
        cesiumViewerRef.current = null;
      }
    };
  }, []);

  return <div ref={viewerRef} style={{ width: '100%', height: '100%' }} />;
};

export default CitiesMap;
