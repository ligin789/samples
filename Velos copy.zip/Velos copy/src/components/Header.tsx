import { Link } from "react-router-dom";
import { useAppSelector } from "../store/hooks";
import { getMenusForRole } from "../config/roleMenuConfig";
import { getCurrentUserRole, getOperatorName } from "../utils/roleAccess";
import styles from "./Header.module.css";

import logo from "../assets/images/landingPage/logo.svg";

const Header = () => {
  const { user } = useAppSelector((state) => state.login);
  const { loginUsers } = useAppSelector((state) => state.loginUsers);
  const { operators } = useAppSelector((state) => state.operator);
  
  // Get current user role
  const currentRole = user ? getCurrentUserRole(loginUsers, user.name) : null;
  const operatorName = user ? getOperatorName(loginUsers, user.name, operators) : null;
  
  // Get menus for current role
  const menuStructure = currentRole ? getMenusForRole(currentRole) : [];
  
  // Determine platform name based on role
  const getPlatformName = () => {
    if (currentRole === 'OPERATOR_ADMIN' && operatorName) {
      return `Operator Portal - ${operatorName}`;
    }
    if (currentRole && currentRole !== 'PLATFORM_ADMIN') {
      return 'User Portal';
    }
    return 'Platform Portal';
  };
  
  // Get user display info
  const getUserDisplayInfo = () => {
    if (user && currentRole) {
      const loginUser = loginUsers.find(
        lu => lu.officialEmail.toLowerCase() === user.name.toLowerCase()
      );
      return {
        name: loginUser?.name || 'User',
        role: currentRole.replace('_', ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase())
      };
    }
    return { name: 'Gilbert Dawson', role: 'Duty Manager' };
  };
  
  const userInfo = getUserDisplayInfo();
  const initials = userInfo.name.split(' ').map(n => n[0]).join('').toUpperCase();

  return (
    <header className={styles.header}>
      <div className={styles.topBar}>
        <Link to="/admin/home" className="d-flex text-decoration-none">
          <div className={styles.logo}>
            <img src={logo} width={70} alt="Platform Logo" />
          </div>
          <div className={styles.platformName}>{getPlatformName()}</div>
        </Link>

        <nav className={styles.mainNav}>
          {menuStructure.map((menu) => (
            <div key={menu.label} className={styles.navItem}>
              <button className={styles.navButton}>{menu.label}</button>
              <div className={styles.dropdown}>
                {menu.submenu.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={styles.dropdownItem}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div className={styles.profile}>
          <div className={styles.profileInfo}>
            <p className={styles.profileName}>{userInfo.name}</p>
            <p className={styles.profileRole}>{userInfo.role}</p>
          </div>
          <div className={styles.avatar}>{initials}</div>
        </div>
      </div>
    </header>
  );
};

export default Header;
