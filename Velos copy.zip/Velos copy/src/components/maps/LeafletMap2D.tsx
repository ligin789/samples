import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, GeoJSON, useMap } from 'react-leaflet';
import { useAppSelector } from '../../store/hooks';
import type { LatLngBoundsExpression } from 'leaflet';
import 'leaflet/dist/leaflet.css';

const MapController = ({ selectedClusterId }: { selectedClusterId: string | null }) => {
  const map = useMap();
  const clusters = useAppSelector((state) => state.cluster.clusters);

  useEffect(() => {
    if (selectedClusterId) {
      const cluster = clusters.find((c) => c.id === selectedClusterId);
      if (cluster?.geoJson?.geometry?.coordinates) {
        const coords = cluster.geoJson.geometry.coordinates[0];
        const bounds: LatLngBoundsExpression = coords.map((coord: number[]) => [coord[1], coord[0]]);
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [selectedClusterId, clusters, map]);

  return null;
};

const LeafletMap2D = () => {
  const bangaloreCenter: [number, number] = [12.9716, 77.5946];
  const defaultZoom = 12;
  const [selectedClusterId, setSelectedClusterId] = useState<string | null>(null);

  const clusters = useAppSelector((state) => state.cluster.clusters);
  const regions = useAppSelector((state) => state.region.regions);
  const authorizedZones = useAppSelector((state) => state.authorizedZones.zones);
  const demandZones = useAppSelector((state) => state.demandZones.zones);

  const selectedCluster = selectedClusterId
    ? clusters.find((c) => c.id === selectedClusterId)
    : null;

  const filteredRegions = selectedClusterId
    ? regions.filter((r) => r.cluster_id === selectedClusterId)
    : [];

  const filteredAuthorizedZones = selectedClusterId
    ? authorizedZones.filter((z) => filteredRegions.some((r) => r.id === z.regionId))
    : [];

  const filteredDemandZones = selectedClusterId
    ? demandZones.filter((z) => filteredRegions.some((r) => r.id === z.regionId))
    : [];

  return (
    <div style={{ width: '100%', height: 'calc(100vh - 130px)', position: 'relative', zIndex: 1 }}>
      {/* Cluster Dropdown */}
      <div
        style={{
          position: 'absolute',
          top: '10px',
          right: '10px',
          zIndex: 500,
          background: 'white',
          padding: '8px 12px',
          borderRadius: '4px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
        }}
      >
        <select
          value={selectedClusterId || ''}
          onChange={(e) => setSelectedClusterId(e.target.value || null)}
          style={{
            border: '1px solid #ddd',
            borderRadius: '4px',
            padding: '6px 10px',
            fontSize: '14px',
            cursor: 'pointer',
          }}
        >
          <option value="">Select Cluster</option>
          {clusters.map((cluster) => (
            <option key={cluster.id} value={cluster.id}>
              {cluster.cluster_name}
            </option>
          ))}
        </select>
      </div>

      {/* Legend Box */}
      <div
        style={{
          position: 'absolute',
          bottom: '20px',
          right: '10px',
          zIndex: 500,
          background: 'white',
          padding: '12px',
          borderRadius: '4px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
          fontSize: '13px',
        }}
      >
        <div style={{ fontWeight: 'bold', marginBottom: '8px' }}>Legend</div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '4px' }}>
          <div
            style={{
              width: '16px',
              height: '16px',
              background: 'rgba(0, 0, 255, 0.3)',
              border: '2px solid blue',
              marginRight: '8px',
            }}
          />
          <span>Cluster</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '4px' }}>
          <div
            style={{
              width: '16px',
              height: '16px',
              background: 'rgba(0, 255, 0, 0.3)',
              border: '2px solid green',
              marginRight: '8px',
            }}
          />
          <span>Region</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '4px' }}>
          <div
            style={{
              width: '16px',
              height: '16px',
              background: 'rgba(255, 165, 0, 0.3)',
              border: '2px solid orange',
              marginRight: '8px',
            }}
          />
          <span>Zone</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '4px' }}>
          <div
            style={{
              width: '16px',
              height: '16px',
              background: 'rgba(128, 0, 128, 0.3)',
              border: '2px solid purple',
              marginRight: '8px',
            }}
          />
          <span>Authorized Zone</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div
            style={{
              width: '16px',
              height: '16px',
              background: 'rgba(255, 0, 0, 0.3)',
              border: '2px solid red',
              marginRight: '8px',
            }}
          />
          <span>Demand Zone</span>
        </div>
      </div>

      <MapContainer
        center={bangaloreCenter}
        zoom={defaultZoom}
        style={{ width: '100%', height: '100%', zIndex: 1 }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        <MapController selectedClusterId={selectedClusterId} />

        {/* Cluster Layer */}
        {selectedCluster?.geoJson && (
          <GeoJSON
            key={`cluster-${selectedCluster.id}`}
            data={selectedCluster.geoJson}
            style={{
              color: 'blue',
              weight: 3,
              fillOpacity: 0.1,
            }}
          />
        )}

        {/* Regions Layer */}
        {filteredRegions.map((region) =>
          region.geojson ? (
            <GeoJSON
              key={`region-${region.id}`}
              data={region.geojson}
              style={{
                color: 'green',
                weight: 2,
                fillOpacity: 0.15,
              }}
            />
          ) : null
        )}

        {/* Authorized Zones Layer */}
        {filteredAuthorizedZones.map((zone) =>
          zone.geojson ? (
            <GeoJSON
              key={`authorized-zone-${zone.id}`}
              data={zone.geojson}
              style={{
                color: 'purple',
                weight: 2,
                fillOpacity: 0.25,
              }}
            />
          ) : null
        )}

        {/* Demand Zones Layer */}
        {filteredDemandZones.map((zone) =>
          zone.geojson ? (
            <GeoJSON
              key={`demand-zone-${zone.id}`}
              data={zone.geojson}
              style={{
                color: 'red',
                weight: 2,
                fillOpacity: 0.25,
              }}
            />
          ) : null
        )}
      </MapContainer>
    </div>
  );
};

export default LeafletMap2D;
