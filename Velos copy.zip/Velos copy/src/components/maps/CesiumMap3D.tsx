import { useEffect, useRef, useState } from 'react';
import * as Cesium from 'cesium';
import 'cesium/Source/Widgets/widgets.css';
import evtolData from '../../data/evtolAirTraffic.json';

interface Vertiport {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  capacity: number;
  status: string;
  type: 'hub' | 'standard';
  chargingStations: number;
}

interface Evtol {
  id: string;
  name: string;
  speed: number;
  altitude: number;
  batteryLevel: number;
  destinationVertiport: string;
  status: string;
}

interface EvtolEntity {
  entity: Cesium.Entity;
  routeEntity: Cesium.Entity | null;
  currentVertiportIndex: number;
  targetVertiportIndex: number;
  progress: number;
  data: Evtol;
}

const CesiumMap3D = () => {
  const cesiumContainer = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<Cesium.Viewer | null>(null);
  const evtolEntitiesRef = useRef<EvtolEntity[]>([]);
  const animationIntervalRef = useRef<number | null>(null);
  const [selectedEvtol, setSelectedEvtol] = useState<Evtol | null>(null);
  const [isPerspectiveView, setIsPerspectiveView] = useState(true);
  const [metrics, setMetrics] = useState({
    totalAircraft: 0,
    flyingAircraft: 0,
    parkedAircraft: 0,
    activeRoutes: 0,
    averageSpeed: 0
  });

  useEffect(() => {
    if (!cesiumContainer.current) return;

    (window as any).CESIUM_BASE_URL = '/cesium';

    const initializeViewer = async () => {
      const viewer = new Cesium.Viewer(cesiumContainer.current!, {
        animation: false,
        timeline: false,
        baseLayerPicker: false,
        geocoder: false,
        homeButton: true,
        sceneModePicker: true,
        navigationHelpButton: false,
        fullscreenButton: false,
        vrButton: false,
        infoBox: true,
        selectionIndicator: true,
        terrainProvider: await Cesium.createWorldTerrainAsync(),
        baseLayer: await Cesium.ImageryLayer.fromProviderAsync(
          Cesium.ArcGisMapServerImageryProvider.fromUrl(
            "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer"
          )
        )
      });

      viewerRef.current = viewer;

      const buildingTileset = await Cesium.createOsmBuildingsAsync();
      viewer.scene.primitives.add(buildingTileset);

      viewer.camera.flyTo({
        destination: Cesium.Cartesian3.fromDegrees(77.5946, 12.9716, 5000),
        orientation: {
          heading: Cesium.Math.toRadians(0),
          pitch: Cesium.Math.toRadians(-22),
          roll: 0
        },
        duration: 3
      });

      const vertiports: Vertiport[] = evtolData.vertiports;
      const evtols: Evtol[] = evtolData.evtols;

      vertiports.forEach((vertiport) => {
        const isHub = vertiport.type === 'hub';
        
        // Main landing pad
        viewer.entities.add({
          id: vertiport.id,
          position: Cesium.Cartesian3.fromDegrees(vertiport.longitude, vertiport.latitude, 0),
          cylinder: {
            length: 2,
            topRadius: isHub ? 120 : 100,
            bottomRadius: isHub ? 120 : 100,
            material: isHub ? Cesium.Color.ORANGE.withAlpha(0.6) : Cesium.Color.CYAN.withAlpha(0.5),
            outline: true,
            outlineColor: Cesium.Color.WHITE,
            outlineWidth: 2,
            heightReference: Cesium.HeightReference.CLAMP_TO_GROUND
          },
          label: {
            text: vertiport.name,
            font: '14px sans-serif',
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
            pixelOffset: new Cesium.Cartesian2(0, -120),
            heightReference: Cesium.HeightReference.CLAMP_TO_GROUND
          },
          description: `<div>
          <h3>${vertiport.name}</h3>
          <p>ID: ${vertiport.id}</p>
          <p>Type: ${vertiport.type === 'hub' ? 'Hub' : 'Standard'}</p>
          <p>Capacity: ${vertiport.capacity}</p>
          <p>Charging Stations: ${vertiport.chargingStations}</p>
          <p>Status: ${vertiport.status}</p>
        </div>`
        });

        // Add parking pads and charging stations for hubs
        if (isHub) {
          const parkingRadius = 200;
          const numParkingPads = 6;
          
          for (let i = 0; i < numParkingPads; i++) {
            const angle = (i / numParkingPads) * 2 * Math.PI;
            const offsetLon = (parkingRadius * Math.cos(angle)) / 111320;
            const offsetLat = (parkingRadius * Math.sin(angle)) / 110540;
            
            viewer.entities.add({
              position: Cesium.Cartesian3.fromDegrees(
                vertiport.longitude + offsetLon,
                vertiport.latitude + offsetLat,
                0
              ),
              ellipse: {
                semiMinorAxis: 30,
                semiMajorAxis: 30,
                material: Cesium.Color.YELLOW.withAlpha(0.4),
                outline: true,
                outlineColor: Cesium.Color.WHITE,
                outlineWidth: 1,
                heightReference: Cesium.HeightReference.CLAMP_TO_GROUND
              }
            });
          }
          
          // Add charging station indicators
          const chargingRadius = 150;
          for (let i = 0; i < vertiport.chargingStations; i++) {
            const angle = (i / vertiport.chargingStations) * 2 * Math.PI + Math.PI / vertiport.chargingStations;
            const offsetLon = (chargingRadius * Math.cos(angle)) / 111320;
            const offsetLat = (chargingRadius * Math.sin(angle)) / 110540;
            
            viewer.entities.add({
              position: Cesium.Cartesian3.fromDegrees(
                vertiport.longitude + offsetLon,
                vertiport.latitude + offsetLat,
                0
              ),
              point: {
                pixelSize: 12,
                color: Cesium.Color.LIME,
                outlineColor: Cesium.Color.WHITE,
                outlineWidth: 2,
                heightReference: Cesium.HeightReference.CLAMP_TO_GROUND
              }
            });
          }
        }
      });

      evtols.forEach((evtol, index) => {
        const startVertiportIndex = index % vertiports.length;
        const targetVertiportIndex = (index + 1) % vertiports.length;
        const startVertiport = vertiports[startVertiportIndex];

        const entity = viewer.entities.add({
          id: evtol.id,
          position: Cesium.Cartesian3.fromDegrees(
            startVertiport.longitude,
            startVertiport.latitude,
            evtol.altitude
          ),
          point: {
            pixelSize: 10,
            color: Cesium.Color.RED,
            outlineColor: Cesium.Color.WHITE,
            outlineWidth: 2
          },
          label: {
            text: evtol.name,
            font: '12px sans-serif',
            fillColor: Cesium.Color.YELLOW,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
            pixelOffset: new Cesium.Cartesian2(0, -15)
          },
          description: `<div>
          <h3>${evtol.name}</h3>
          <p>ID: ${evtol.id}</p>
          <p>Speed: ${evtol.speed} km/h</p>
          <p>Altitude: ${evtol.altitude} m</p>
          <p>Battery: ${evtol.batteryLevel}%</p>
          <p>Status: ${evtol.status}</p>
        </div>`
        });

        evtolEntitiesRef.current.push({
          entity,
          routeEntity: null,
          currentVertiportIndex: startVertiportIndex,
          targetVertiportIndex,
          progress: 0,
          data: evtol
        });
      });

      const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
      handler.setInputAction((click: any) => {
        const pickedObject = viewer.scene.pick(click.position);
        if (Cesium.defined(pickedObject) && pickedObject.id) {
          const entityId = pickedObject.id.id;
          const evtol = evtols.find(e => e.id === entityId);
          if (evtol) {
            setSelectedEvtol(evtol);
          }
        }
      }, Cesium.ScreenSpaceEventType.LEFT_CLICK);

      const updateMetrics = () => {
        const flying = evtols.filter(e => e.status === 'flying').length;
        const parked = evtols.length - flying;
        const avgSpeed = evtols.reduce((sum, e) => sum + e.speed, 0) / evtols.length;
        
        setMetrics({
          totalAircraft: evtols.length,
          flyingAircraft: flying,
          parkedAircraft: parked,
          activeRoutes: vertiports.length,
          averageSpeed: Math.round(avgSpeed)
        });
      };

      updateMetrics();

      const animateEvtols = () => {
        evtolEntitiesRef.current.forEach((evtolEntity) => {
          evtolEntity.progress += 0.01;

          if (evtolEntity.progress >= 1) {
            evtolEntity.progress = 0;
            evtolEntity.currentVertiportIndex = evtolEntity.targetVertiportIndex;
            evtolEntity.targetVertiportIndex = (evtolEntity.targetVertiportIndex + 1) % vertiports.length;
            
            if (evtolEntity.routeEntity) {
              viewer.entities.remove(evtolEntity.routeEntity);
              evtolEntity.routeEntity = null;
            }
          }

          const startVertiport = vertiports[evtolEntity.currentVertiportIndex];
          const endVertiport = vertiports[evtolEntity.targetVertiportIndex];

          const startLon = startVertiport.longitude;
          const startLat = startVertiport.latitude;
          const endLon = endVertiport.longitude;
          const endLat = endVertiport.latitude;

          const t = evtolEntity.progress;
          const lon = startLon + (endLon - startLon) * t;
          const lat = startLat + (endLat - startLat) * t;

          let altitude = evtolEntity.data.altitude;
          if (t < 0.2) {
            altitude = evtolEntity.data.altitude * (t / 0.2);
          } else if (t > 0.8) {
            altitude = evtolEntity.data.altitude * ((1 - t) / 0.2);
          }

          const currentPosition = Cesium.Cartesian3.fromDegrees(lon, lat, altitude);
          evtolEntity.entity.position = new Cesium.ConstantPositionProperty(currentPosition);

          if (evtolEntity.data.status === 'flying') {
            // Create elevated arc route for better visibility
            const routeAltitude = 400;
            const numPoints = 20;
            const routePositions = [];
            
            for (let i = 0; i <= numPoints; i++) {
              const fraction = i / numPoints;
              const routeLon = startLon + (endLon - startLon) * fraction;
              const routeLat = startLat + (endLat - startLat) * fraction;
              
              // Create arc effect - highest in the middle
              const arcHeight = Math.sin(fraction * Math.PI) * routeAltitude;
              routePositions.push(Cesium.Cartesian3.fromDegrees(routeLon, routeLat, arcHeight));
            }
            
            if (evtolEntity.routeEntity) {
              evtolEntity.routeEntity.polyline!.positions = new Cesium.ConstantProperty(routePositions);
            } else {
              evtolEntity.routeEntity = viewer.entities.add({
                polyline: {
                  positions: routePositions,
                  width: 3,
                  material: new Cesium.PolylineDashMaterialProperty({
                    color: Cesium.Color.CYAN.withAlpha(0.8)
                  }),
                  clampToGround: false
                }
              });
            }
          } else {
            if (evtolEntity.routeEntity) {
              viewer.entities.remove(evtolEntity.routeEntity);
              evtolEntity.routeEntity = null;
            }
          }
        });
      };

      animationIntervalRef.current = window.setInterval(animateEvtols, 100);

      return () => {
        if (animationIntervalRef.current) {
          clearInterval(animationIntervalRef.current);
        }
        handler.destroy();
        viewer.destroy();
      };
    };

    initializeViewer();
  }, []);

  const toggleCameraView = () => {
    if (!viewerRef.current) return;

    const viewer = viewerRef.current;
    const currentPosition = viewer.camera.positionCartographic;
    const longitude = Cesium.Math.toDegrees(currentPosition.longitude);
    const latitude = Cesium.Math.toDegrees(currentPosition.latitude);

    if (isPerspectiveView) {
      viewer.camera.flyTo({
        destination: Cesium.Cartesian3.fromDegrees(longitude, latitude, 15000),
        orientation: {
          heading: Cesium.Math.toRadians(0),
          pitch: Cesium.Math.toRadians(-90),
          roll: 0
        },
        duration: 2
      });
    } else {
      viewer.camera.flyTo({
        destination: Cesium.Cartesian3.fromDegrees(longitude, latitude, 5000),
        orientation: {
          heading: Cesium.Math.toRadians(0),
          pitch: Cesium.Math.toRadians(-22),
          roll: 0
        },
        duration: 2
      });
    }

    setIsPerspectiveView(!isPerspectiveView);
  };

  return (
    <div style={{ width: '100%', height: 'calc(100vh - 130px)', position: 'relative' }}>
      <div ref={cesiumContainer} style={{ width: '100%', height: '100%' }} />
      
      <button
        onClick={toggleCameraView}
        style={{
          position: 'absolute',
          bottom: '20px',
          right: '15px',
          background: 'rgba(0, 0, 0, 0.8)',
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          padding: '12px',
          cursor: 'pointer',
          fontSize: '20px',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: '48px',
          height: '48px',
          pointerEvents: 'auto'
        }}
        title={isPerspectiveView ? 'Switch to Top View' : 'Switch to Perspective View'}
      >
        📷
      </button>

      <div style={{
        position: 'absolute',
        top: '10px',
        left: '10px',
        background: 'rgba(0, 0, 0, 0.8)',
        color: 'white',
        padding: '15px',
        borderRadius: '8px',
        minWidth: '200px',
        fontSize: '13px',
        zIndex: 1000
      }}>
        <div style={{ fontWeight: 'bold', marginBottom: '10px', fontSize: '15px' }}>
          Dashboard Metrics
        </div>
        <div style={{ marginBottom: '6px' }}>
          <strong>Total Aircraft:</strong> {metrics.totalAircraft}
        </div>
        <div style={{ marginBottom: '6px' }}>
          <strong>Flying:</strong> {metrics.flyingAircraft}
        </div>
        <div style={{ marginBottom: '6px' }}>
          <strong>Parked:</strong> {metrics.parkedAircraft}
        </div>
        <div style={{ marginBottom: '6px' }}>
          <strong>Active Routes:</strong> {metrics.activeRoutes}
        </div>
        <div>
          <strong>Avg Speed:</strong> {metrics.averageSpeed} km/h
        </div>
      </div>

      {selectedEvtol && (
        <div style={{
          position: 'absolute',
          bottom: '20px',
          left: '10px',
          background: 'rgba(0, 0, 0, 0.9)',
          color: 'white',
          padding: '15px',
          borderRadius: '8px',
          minWidth: '250px',
          fontSize: '13px',
          zIndex: 1000
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <div style={{ fontWeight: 'bold', fontSize: '15px' }}>
              {selectedEvtol.name}
            </div>
            <button
              onClick={() => setSelectedEvtol(null)}
              style={{
                background: 'transparent',
                border: 'none',
                color: 'white',
                cursor: 'pointer',
                fontSize: '18px',
                padding: '0',
                lineHeight: '1'
              }}
            >
              ×
            </button>
          </div>
          <div style={{ marginBottom: '5px' }}>
            <strong>ID:</strong> {selectedEvtol.id}
          </div>
          <div style={{ marginBottom: '5px' }}>
            <strong>Speed:</strong> {selectedEvtol.speed} km/h
          </div>
          <div style={{ marginBottom: '5px' }}>
            <strong>Altitude:</strong> {selectedEvtol.altitude} m
          </div>
          <div style={{ marginBottom: '5px' }}>
            <strong>Battery:</strong> {selectedEvtol.batteryLevel}%
          </div>
          <div style={{ marginBottom: '5px' }}>
            <strong>Destination:</strong> {selectedEvtol.destinationVertiport}
          </div>
          <div>
            <strong>Status:</strong> <span style={{ color: selectedEvtol.status === 'flying' ? '#00ff00' : '#ffff00' }}>
              {selectedEvtol.status}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default CesiumMap3D;
