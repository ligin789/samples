import { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, GeoJSON, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface City {
  id: string;
  cityCode: string;
  cityName: string;
  geoJson?: any;
}

interface LeafletMapProps {
  center?: [number, number];
  zoom?: number;
  cities?: City[];
  selectedCityId?: string | null;
}

const ZoomToSelected = ({ cities, selectedCityId }: { cities: City[], selectedCityId: string | null }) => {
  const map = useMap();

  useEffect(() => {
    if (selectedCityId) {
      const city = cities.find(c => c.id === selectedCityId);
      if (city?.geoJson) {
        const layer = L.geoJSON(city.geoJson);
        map.fitBounds(layer.getBounds(), { padding: [50, 50] });
      }
    }
  }, [selectedCityId, cities, map]);

  return null;
};

const MapResizer = () => {
  const map = useMap();

  useEffect(() => {
    const handleResize = () => {
      setTimeout(() => map.invalidateSize(), 100);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [map]);

  return null;
};

const LeafletMap = ({ 
  center = [12.9716, 77.5946], 
  zoom = 12,
  cities = [],
  selectedCityId = null
}: LeafletMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new ResizeObserver(() => {
      const mapContainer = document.querySelector('.leaflet-container') as any;
      if (mapContainer && mapContainer._leaflet_map) {
        mapContainer._leaflet_map.invalidateSize();
      }
    });

    if (mapRef.current) {
      observer.observe(mapRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div ref={mapRef} style={{ width: '100%', height: '100%' }}>
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ width: '100%', height: '100%' }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapResizer />
        <ZoomToSelected cities={cities} selectedCityId={selectedCityId} />
        {cities.map((city) => (
          city.geoJson && (
            <GeoJSON
              key={city.id}
              data={city.geoJson}
              style={() => ({
                color: selectedCityId === city.id ? '#ff0000' : '#0d6efd',
                weight: selectedCityId === city.id ? 4 : 2,
                fillOpacity: selectedCityId === city.id ? 0.4 : 0.2,
              })}
            >
              <Popup>{city.cityName}</Popup>
            </GeoJSON>
          )
        ))}
      </MapContainer>
    </div>
  );
};

export default LeafletMap;
