import { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, FeatureGroup, useMap } from 'react-leaflet';
import { EditControl } from 'react-leaflet-draw';
import 'leaflet/dist/leaflet.css';
import 'leaflet-draw/dist/leaflet.draw.css';
import L from 'leaflet';

const MapResizer = () => {
  const map = useMap();

  useEffect(() => {
    setTimeout(() => map.invalidateSize(), 300);
  }, [map]);

  return null;
};

interface DrawableMapProps {
  center?: [number, number];
  zoom?: number;
  onPolygonCreated: (geoJson: any) => void;
  existingGeoJson?: any;
}

const DrawableMap = ({ 
  center = [12.9716, 77.5946], 
  zoom = 12,
  onPolygonCreated,
  existingGeoJson
}: DrawableMapProps) => {
  const featureGroupRef = useRef<L.FeatureGroup>(null);

  useEffect(() => {
    if (existingGeoJson && featureGroupRef.current) {
      featureGroupRef.current.clearLayers();
      L.geoJSON(existingGeoJson).eachLayer((layer) => {
        if (featureGroupRef.current) {
          featureGroupRef.current.addLayer(layer);
        }
      });
    }
  }, [existingGeoJson]);

  const handleCreated = (e: any) => {
    const layer = e.layer;
    
    if (featureGroupRef.current) {
      featureGroupRef.current.clearLayers();
      featureGroupRef.current.addLayer(layer);
    }
    
    const geoJson = layer.toGeoJSON();
    onPolygonCreated(geoJson);
  };

  const handleEdited = (e: any) => {
    const layers = e.layers;
    layers.eachLayer((layer: any) => {
      const geoJson = layer.toGeoJSON();
      onPolygonCreated(geoJson);
    });
  };

  const handleDeleted = () => {
    onPolygonCreated(null);
  };

  return (
    <MapContainer
      center={center}
      zoom={zoom}
      style={{ width: '100%', height: '100%' }}
      scrollWheelZoom={true}
    >
      <TileLayer
        attribution='&copy; OpenStreetMap contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <MapResizer />
      <FeatureGroup ref={featureGroupRef}>
        <EditControl
          position="topright"
          onCreated={handleCreated}
          onEdited={handleEdited}
          onDeleted={handleDeleted}
          draw={{
            rectangle: false,
            circle: false,
            circlemarker: false,
            marker: false,
            polyline: false,
            polygon: {
              allowIntersection: true,
              showArea: true,
              shapeOptions: {
                color: '#0d6efd'
              }
            },
          }}
        />
      </FeatureGroup>
    </MapContainer>
  );
};

export default DrawableMap;
