import { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import '@gorules/jdm-editor/dist/style.css';
import { JdmConfigProvider, DecisionGraph } from '@gorules/jdm-editor';
import { updateRule } from '../../store/businessRules/businessRulesActions';
import type { Rule } from '../../store/businessRules/businessRulesTypes';

interface RuleEditorCanvasProps {
  rule: Rule;
}

const RuleEditorCanvas = ({ rule }: RuleEditorCanvasProps) => {
  const dispatch = useDispatch();
  const [graph, setGraph] = useState(rule.value);
  const [key, setKey] = useState(rule.id);

  useEffect(() => {
    setGraph(rule.value);
    setKey(rule.id);
  }, [rule.id]);

  const saveGraph = () => {
    dispatch(updateRule({
      ...rule,
      value: graph
    }));
    alert('Saved!');
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header style={{ padding: 8, borderBottom: '1px solid #eee' }}>
        <button style={{position:"absolute",border:'none',backgroundColor:"#fff",marginTop:93,marginLeft:1}} onClick={saveGraph}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-save" viewBox="0 0 16 16">
  <path d="M2 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H9.5a1 1 0 0 0-1 1v7.293l2.646-2.647a.5.5 0 0 1 .708.708l-3.5 3.5a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L7.5 9.293V2a2 2 0 0 1 2-2H14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h2.5a.5.5 0 0 1 0 1z"/>
</svg></button>
      </header>

      <div style={{ flex: 1 }}>
        <JdmConfigProvider>
          <DecisionGraph
            key={key}
            value={graph}
            onChange={(val) => setGraph(val as any)}
            onSimulatorOpen={(opened: any) => console.log('Simulator:', opened)}
            onSimulationRun={async ({ context, decisionGraph }: any) => {
              const res = await fetch('/api/simulate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ context, decisionGraph }),
              });
              return await res.json();
            }}
          />
        </JdmConfigProvider>
      </div>
    </div>
  );
};

export default RuleEditorCanvas;
