import { useState, useCallback, useRef, useEffect } from "react";
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  MarkerType,
  ReactFlowProvider,
  useReactFlow,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
  ConnectionMode,
  useEdgesState,
  Panel,
} from "@xyflow/react";
import type {
  Node,
  Edge,
  Connection,
  NodeChange,
  EdgeChange,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";

import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { setSelectedProcess, updateProcessFlow, setSelectedNode, addTask } from "../../redux/process/processActions";
import GatewayNode from "./nodes/GatewayNode";

// Register custom node(s)
const nodeTypes = {
  gateway: GatewayNode,
};

type RawNode = {
  node_id?: string;
  id?: string | number;
  name?: string;
  label?: string;
  type?: string; // "ENTRY" | "TASK" | "GATEWAY" | "EXIT" | ...
  next?: Array<string | number>;
  position?: { x: number; y: number };
  task_key?: string;
  [key: string]: any; // Allow other properties
};

type RawEdge = {
  source?: string | number;
  target?: string | number;
  from?: string | number;
  to?: string | number;
  label?: string;
  type?: string;
};

type RawFlow = {
  nodes?: RawNode[];
  edges?: RawEdge[];
};

const FlowCanvas = () => {
  const dispatch = useAppDispatch();
  const selectedProcess = useAppSelector((state) => state.process.selectedProcess);

  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [showTaskKeyModal, setShowTaskKeyModal] = useState(false);
  const [taskKeyInput, setTaskKeyInput] = useState('');
  const [taskKeyError, setTaskKeyError] = useState('');
  const pendingNodeRef = useRef<{ businessType: string; position: { x: number; y: number } } | null>(null);

  // Needed for drop position conversion & fitView
  const { screenToFlowPosition, fitView } = useReactFlow();
  const reactFlowWrapper = useRef<HTMLDivElement>(null);

  // Optional: clear selected process on unmount
  useEffect(() => {
    return () => {
      // If this causes issues, comment it out
      // dispatch(setSelectedProcess(null));
    };
  }, [dispatch]);

  useEffect(() => {
    return () => {
      // removing the selected process
      dispatch(setSelectedProcess(null));
    };
  }, [dispatch]);

  // Normalize and render nodes/edges when selectedProcess changes
  useEffect(() => {
    if (!selectedProcess) {
      setNodes([]);
      setEdges([]);
      return;
    }

    // Be resilient against different property names
    const flow: RawFlow =
      selectedProcess.processFlow ||
      selectedProcess.processflow ||
      selectedProcess.flow ||
      {};

    const rawNodes: RawNode[] = Array.isArray(flow.nodes) ? flow.nodes : [];
    const rawEdges: RawEdge[] = Array.isArray(flow.edges) ? flow.edges : [];

    if (!rawNodes.length && !rawEdges.length) {
      console.warn("No nodes/edges found in selectedProcess.processFlow");
      setNodes([]);
      setEdges([]);
      return;
    }

    // ---- Normalize Nodes ----
    const normNodes = rawNodes
      .map((n) => {
        const id = String(n.node_id ?? n.id ?? "");
        if (!id) return null;
        const name = n.name ?? n.label ?? id;
        const type = (n.type || "TASK").toUpperCase(); // ENTRY / EXIT / GATEWAY / TASK / ...
        const next = Array.isArray(n.next) ? n.next.map((t) => String(t)) : [];
        const position =
          n.position && typeof n.position.x === "number" && typeof n.position.y === "number"
            ? n.position
            : undefined; // <-- use saved position if available
        return { ...n, id, name, type, next, position };
      })
      .filter(Boolean) as Array<any>;

    if (!normNodes.length) {
      console.warn("After normalization, nodes are empty");
      setNodes([]);
      setEdges([]);
      return;
    }

    const nodeIdSet = new Set(normNodes.map((n) => n.id));

    // ---- Leveling (LAYOUT) ----
    // Compute incoming degrees to detect roots if there are no explicit ENTRY nodes
    const incoming = new Map<string, number>();
    normNodes.forEach((n) => {
      if (!incoming.has(n.id)) incoming.set(n.id, 0);
      n.next.forEach((t) => incoming.set(t, (incoming.get(t) || 0) + 1));
    });

    let entryNodes = normNodes.filter((n) => n.type === "ENTRY");
    if (!entryNodes.length) {
      const roots = normNodes.filter((n) => (incoming.get(n.id) || 0) === 0);
      entryNodes = roots.length ? roots : [normNodes[0]];
    }

    const levelMap = new Map<string, number>();
    const calculateLevels = (nodeId: string, level: number, visited = new Set<string>()) => {
      if (visited.has(nodeId)) return;
      visited.add(nodeId);

      const currentLevel = levelMap.get(nodeId) ?? -1;
      if (level > currentLevel) levelMap.set(nodeId, level);

      const node = normNodes.find((n) => n.id === nodeId);
      if (node?.next?.length) {
        node.next.forEach((nextId) => calculateLevels(nextId, level + 1, new Set(visited)));
      }
    };

    entryNodes.forEach((n) => calculateLevels(n.id, 0));

    // If any nodes not reached, place them below
    const maxAssigned = levelMap.size ? Math.max(...Array.from(levelMap.values())) : 0;
    normNodes.forEach((n) => {
      if (!levelMap.has(n.id)) levelMap.set(n.id, maxAssigned + 1);
    });

    // Group by level and place
    const levelGroups = new Map<number, string[]>();
    levelMap.forEach((lvl, nodeId) => {
      if (!levelGroups.has(lvl)) levelGroups.set(lvl, []);
      levelGroups.get(lvl)!.push(nodeId);
    });

    const nodePositions = new Map<string, { x: number; y: number }>();
    levelGroups.forEach((ids, lvl) => {
      const count = ids.length;
      const startX = 250 - ((count - 1) * 220) / 2; // spread horizontally
      ids.forEach((nodeId, index) => {
        nodePositions.set(nodeId, {
          x: startX + index * 220,
          y: lvl * 160,
        });
      });
    });

    // ---- Map to React Flow Nodes ----
    const rfNodes: Node[] = normNodes.map((n) => {
      const pos = n.position ?? nodePositions.get(n.id) ?? { x: 250, y: 0 }; // <-- prefer saved pos

      let nodeType: Node["type"] = "default";
      let style: React.CSSProperties | undefined = {
        background: "#2196f3",
        color: "white",
        border: "2px solid #1565c0",
        padding: 10,
      };

      if (n.type === "ENTRY") {
        nodeType = "input";
        style = {
          background: "#4caf50",
          color: "white",
          border: "2px solid #2e7d32",
          padding: 10,
          borderRadius: "50%", // your style tweak kept
        };
      } 
      else if (n.type === "EXIT") {
        nodeType = "output";
        style = {
          background: "#f44336",
          color: "white",
          border: "2px solid #c62828",
          padding: 10,
        };
      } 
      else if (n.type === "MANUAL_TASK") {
        nodeType = "default";
        style = {
          background: "#9c27b0",
          color: "white",
          border: "2px solid #6a1b9a",
          padding: 10,
        };
      } 
      else if (n.type === "SERVICE_TASK") {
        nodeType = "default";
        style = {
          background: "#7c4dff",
          color: "white",
          border: "2px solid #5e35b1",
          padding: 10,
        };
      } 
      else if (n.type === "GATEWAY") {
        nodeType = "gateway";
        style = undefined; // styled by custom node
      }

      return {
        id: n.id,
        type: nodeType,
        position: pos,
        data: { label: n.name, businessType: n.type, task_key: n.task_key },
        style,
      };
    });

    // ---- Build Edges ----
    // Prefer explicit edges array if provided; fallback to node.next
    const edgesFromArray: Edge[] = rawEdges
      .map((e, idx) => {
        const source = String(e.source ?? e.from ?? "");
        const target = String(e.target ?? e.to ?? "");
        if (!source || !target) return null;
        if (!nodeIdSet.has(source) || !nodeIdSet.has(target)) return null;
        return {
          id: `${source}-${target}-${idx}`, // <-- unique id per edge
          source,
          target,
          type: e.type || "smoothstep",
          animated: true,
          markerEnd: { type: MarkerType.ArrowClosed },
          label: e.label,
          updatable: true, // <-- allow reconnection via drag
        } as Edge;
      })
      .filter(Boolean) as Edge[];

    let edgeCounter = 0;
    const edgesFromNext: Edge[] =
      edgesFromArray.length === 0
        ? normNodes.flatMap((n) =>
            (n.next || [])
              .filter((t) => nodeIdSet.has(t))
              .map((t) => {
                edgeCounter += 1;
                return {
                  id: `${n.id}-${t}-${edgeCounter}`, // <-- unique id per derived edge
                  source: n.id,
                  target: t,
                  type: "smoothstep",
                  animated: true,
                  markerEnd: { type: MarkerType.ArrowClosed },
                  updatable: true, // <-- allow reconnection via drag
                } as Edge;
              })
          )
        : [];

    const rfEdges = edgesFromArray.length ? edgesFromArray : edgesFromNext;

    // Debug logs to verify
    console.log("RF Nodes:", rfNodes);
    console.log("RF Edges:", rfEdges);

    setNodes(rfNodes);
    setEdges(rfEdges);
  }, [selectedProcess]);

  // Ensure the viewport fits whenever nodes change
  useEffect(() => {
    if (nodes.length) {
      const t = setTimeout(() => fitView({ padding: 0.2 }), 0);
      return () => clearTimeout(t);
    }
  }, [nodes, fitView]);

  // Sync ReactFlow state to Redux store
  const syncFlowToStore = useCallback(
    (updatedNodes: Node[], updatedEdges: Edge[]) => {
      if (!selectedProcess) return;

      const rawNodes: RawNode[] = updatedNodes.map((n) => {
        const originalNode = selectedProcess.processFlow?.nodes?.find(
          (orig: any) => orig.node_id === n.id || orig.id === n.id
        );
        return {
          ...originalNode,
          node_id: n.id,
          id: n.id,
          name: String(n.data?.label || n.id),
          type: n.data?.businessType || "TASK",
          position: { x: n.position.x, y: n.position.y },
          task_key: n.data?.task_key,
        };
      });

      const rawEdges: RawEdge[] = updatedEdges.map((e) => ({
        source: e.source,
        target: e.target,
        type: e.type,
        label: e.label as string | undefined,
      }));

      dispatch(
        updateProcessFlow(selectedProcess.process_id, {
          nodes: rawNodes,
          edges: rawEdges,
        })
      );
    },
    [dispatch, selectedProcess]
  );

  // ✅ Handle node and edge changes (required in controlled mode)
  const onNodesChange = useCallback(
    (changes: NodeChange[]) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const onNodeClick = useCallback(
    (_: any, node: Node) => {
      const rawNode = selectedProcess?.processFlow?.nodes?.find(
        (n: any) => (n.node_id === node.id || n.id === node.id)
      );
      dispatch(setSelectedNode({ ...rawNode, task_key: node.data?.task_key }));
    },
    [dispatch, selectedProcess]
  );

  const onEdgesChange = useCallback(
    (changes: EdgeChange[]) => {
      setEdges((eds) => {
        const updated = applyEdgeChanges(changes, eds);
        syncFlowToStore(nodes, updated);
        return updated;
      });
    },
    [nodes, syncFlowToStore]
  );

  // ✅ Update an existing edge by dragging its handle to a new node/handle
  const onEdgeUpdate = useCallback(
    (oldEdge: Edge, newConnection: Connection) => {
      setEdges((eds) => useEdgesState(oldEdge, { ...newConnection }, eds));
    },
    []
  );

  // ✅ Persist position back to selectedProcess on drag stop
  const onNodeDragStop = useCallback(
    (_: any, node: Node) => {
      syncFlowToStore(nodes, edges);
    },
    [nodes, edges, syncFlowToStore]
  );

  // Connections created via UI (supports multiple edges)
  const onConnect = useCallback(
    (params: Connection) => {
      setEdges((eds) => {
        const updated = addEdge(
          {
            id: `${params.source}-${params.target}-${Date.now()}`,
            ...params,
            type: "smoothstep",
            animated: true,
            markerEnd: { type: MarkerType.ArrowClosed },
            updatable: true,
          },
          eds
        );
        syncFlowToStore(nodes, updated);
        return updated;
      });
    },
    [nodes, syncFlowToStore]
  );

  // Drag-and-drop from toolbox (inside Panel)
  const onDragStart = (event: React.DragEvent, nodeType: string) => {
    // Required for some browsers (e.g., Firefox) to initiate DnD
    event.dataTransfer.setData("text/plain", nodeType);
    // Type React Flow looks for
    event.dataTransfer.setData("application/reactflow", nodeType);
    event.dataTransfer.effectAllowed = "move";
  };

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const businessType =
        event.dataTransfer.getData("application/reactflow") ||
        event.dataTransfer.getData("text/plain");
      if (!businessType) return;

      const position = screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      // Check if this is a task type that needs task_key
      const isTaskType = ['SERVICE_TASK', 'MANUAL_TASK', 'TASK'].includes(businessType);
      
      if (isTaskType) {
        // Show modal to get task_key
        pendingNodeRef.current = { businessType, position };
        setTaskKeyInput('');
        setTaskKeyError('');
        setShowTaskKeyModal(true);
        return;
      }

      // For non-task nodes (ENTRY, EXIT, GATEWAY), create directly
      const newNodeId = `${businessType.toLowerCase()}-${Date.now()}`;

      let nodeType: Node["type"] = "default";
      let style: React.CSSProperties | undefined = {
        background: "#2196f3",
        color: "white",
        border: "2px solid #1565c0",
        padding: 10,
      };

      if (businessType === "ENTRY") {
        nodeType = "input";
        style = {
          background: "#4caf50",
          color: "white",
          border: "2px solid #2e7d32",
          padding: 10,
        };
      } else if (businessType === "EXIT") {
        nodeType = "output";
        style = {
          background: "#f44336",
          color: "white",
          border: "2px solid #c62828",
          padding: 10,
        };
      } else if (businessType === "GATEWAY") {
        nodeType = "gateway";
        style = undefined;
      }

      const newNode: Node = {
        id: newNodeId,
        type: nodeType,
        position,
        data: { label: `${businessType}`, businessType },
        style,
      };

      setNodes((nds) => {
        const updated = nds.concat(newNode);
        syncFlowToStore(updated, edges);
        return updated;
      });
    },
    [screenToFlowPosition, edges, syncFlowToStore]
  );

  const handleTaskKeySubmit = useCallback(() => {
    const taskKey = taskKeyInput.trim().toUpperCase();
    
    // Validation
    if (!taskKey) {
      setTaskKeyError('Task key is required');
      return;
    }
    
    if (taskKey.includes(' ')) {
      setTaskKeyError('Task key cannot contain spaces');
      return;
    }
    
    // Check for duplicates
    const exists = selectedProcess?.tasks?.some((t: any) => t.task_key === taskKey);
    if (exists) {
      setTaskKeyError('Task key already exists');
      return;
    }
    
    if (!pendingNodeRef.current) return;
    
    const { businessType, position } = pendingNodeRef.current;
    const newNodeId = `${businessType.toLowerCase()}-${Date.now()}`;
    const taskId = `task-${Date.now()}`;
    
    let nodeType: Node["type"] = "default";
    let style: React.CSSProperties | undefined = {
      background: "#2196f3",
      color: "white",
      border: "2px solid #1565c0",
      padding: 10,
    };
    
    if (businessType === "SERVICE_TASK") {
      style = {
        background: "#7c4dff",
        color: "white",
        border: "2px solid #5e35b1",
        padding: 10,
      };
    } else if (businessType === "MANUAL_TASK") {
      style = {
        background: "#9c27b0",
        color: "white",
        border: "2px solid #6a1b9a",
        padding: 10,
      };
    }
    
    // Create node
    const newNode: Node = {
      id: newNodeId,
      type: nodeType,
      position,
      data: { label: taskKey, businessType, task_key: taskKey },
      style,
    };
    
    // Create task
    const newTask = {
      task_id: taskId,
      task_key: taskKey,
      name: '',
      type: businessType.toLowerCase(),
      department: '',
      role: '',
      description: '',
      inputs: [],
      outputs: [],
      task_steps: {
        executionMode: 'SEQUENTIAL',
        failOnFirstError: true,
        execution_steps: []
      }
    };
    
    // Dispatch both updates
    dispatch(addTask(newTask));
    
    setNodes((nds) => {
      const updated = nds.concat(newNode);
      syncFlowToStore(updated, edges);
      return updated;
    });
    
    // Close modal
    setShowTaskKeyModal(false);
    pendingNodeRef.current = null;
  }, [taskKeyInput, selectedProcess, edges, syncFlowToStore, dispatch]);

  const handleTaskKeyCancel = useCallback(() => {
    setShowTaskKeyModal(false);
    pendingNodeRef.current = null;
    setTaskKeyInput('');
    setTaskKeyError('');
  }, []);

  if (!selectedProcess) {
    return (
      <div className="p-3 h-100">
        <div className="bg-white rounded p-3 h-100 d-flex align-items-center justify-content-center">
          <h5 className="text-muted">Select a process to view workflow</h5>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 h-100">
      <div className="bg-white rounded p-3 h-100" style={{ position: "relative" }}>
        <h5>{selectedProcess.name}</h5>

        {/* Task Key Modal */}
        {showTaskKeyModal && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 9999
          }}>
            <div style={{
              background: 'white',
              padding: '20px',
              borderRadius: '8px',
              minWidth: '400px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
            }}>
              <h6 className="mb-3">Enter Task Key</h6>
              <input
                type="text"
                className="form-control mb-2"
                placeholder="e.g., VALIDATE_BOOKING_REQUEST"
                value={taskKeyInput}
                onChange={(e) => setTaskKeyInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleTaskKeySubmit()}
                autoFocus
              />
              {taskKeyError && (
                <div className="text-danger small mb-2">{taskKeyError}</div>
              )}
              <div className="d-flex gap-2 justify-content-end">
                <button className="btn btn-sm btn-secondary" onClick={handleTaskKeyCancel}>Cancel</button>
                <button className="btn btn-sm btn-primary" onClick={handleTaskKeySubmit}>Create</button>
              </div>
            </div>
          </div>
        )}

        <div
          ref={reactFlowWrapper}
          style={{ height: "calc(100% - 40px)", width: "100%", pointerEvents: "auto" }}
        >
          <ReactFlow
          proOptions={{ hideAttribution: true }}
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeDragStop={onNodeDragStop}
            onEdgeUpdate={onEdgeUpdate}          // reconnect edges by dragging
            onConnect={onConnect}
            onDrop={onDrop}
            onDragOver={onDragOver}
            onNodeClick={onNodeClick}
            fitView
            onInit={(instance) => instance.fitView({ padding: 0.2 })}
            panOnDrag={[2]}                      // right mouse to pan
            zoomOnScroll
            nodesDraggable
            elementsSelectable
            connectionMode={ConnectionMode.Loose} // allow easy multi-connections
            edgeUpdaterRadius={30}                // easier to grab edge ends
            edgesUpdatable
            defaultEdgeOptions={{
              type: "smoothstep",
              animated: true,
              markerEnd: { type: MarkerType.ArrowClosed },
              updatable: true,
            }}
          >
            {/* ✅ Toolbox inside the pane so DnD works reliably */}
            <Panel position="top-left">
              <div className="nodrag nopan" style={{
                background: "white",
                border: "1px solid #ddd",
                borderRadius: "4px",
                padding: "10px",
                boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                width: 120,
              }}>
                <div style={{ marginBottom: 6, fontWeight: "bold", fontSize: 12 }}>Toolbox</div>

                <div
                  className="nodrag nopan"
                  draggable
                  onDragStart={(e) => onDragStart(e, "ENTRY")}
                  style={{
                    padding: "8px 12px",
                    margin: "6px 0",
                    background: "#4caf50",
                    color: "white",
                    borderRadius: "4px",
                    cursor: "grab",
                    fontSize: "12px",
                  }}
                >
                  Entry
                </div>

                <div
                  className="nodrag nopan"
                  draggable
                  onDragStart={(e) => onDragStart(e, "SERVICE_TASK")}
                  style={{
                    padding: "8px 12px",
                    margin: "6px 0",
                    background: "#7c4dff",
                    color: "white",
                    borderRadius: "4px",
                    cursor: "grab",
                    fontSize: "12px",
                  }}
                >
                  Service Task
                </div>

                <div
                  className="nodrag nopan"
                  draggable
                  onDragStart={(e) => onDragStart(e, "MANUAL_TASK")}
                  style={{
                    padding: "8px 12px",
                    margin: "6px 0",
                    background: "#9c27b0",
                    color: "white",
                    borderRadius: "4px",
                    cursor: "grab",
                    fontSize: "12px",
                  }}
                >
                  Manual Task
                </div>

                <div
                  className="nodrag nopan"
                  draggable
                  onDragStart={(e) => onDragStart(e, "GATEWAY")}
                  style={{
                    padding: "8px 12px",
                    margin: "6px 0",
                    background: "#ff9800",
                    color: "white",
                    borderRadius: "4px",
                    cursor: "grab",
                    fontSize: "12px",
                  }}
                >
                  Gateway
                </div>

                <div
                  className="nodrag nopan"
                  draggable
                  onDragStart={(e) => onDragStart(e, "EXIT")}
                  style={{
                    padding: "8px 12px",
                    margin: "6px 0",
                    background: "#f44336",
                    color: "white",
                    borderRadius: "4px",
                    cursor: "grab",
                    fontSize: "12px",
                  }}
                >
                  Exit
                </div>
              </div>
            </Panel>

            <MiniMap />
            <Controls />
            <Background />
          </ReactFlow>
        </div>
      </div>
    </div>
  );
};

const MainCanvas = () => {
  return (
    <ReactFlowProvider>
      <FlowCanvas />
    </ReactFlowProvider>
  );
};

export default MainCanvas;
