import { useState, useEffect, useRef } from 'react';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { updateTask } from '../../redux/process/processActions';

const ProcessGroup6 = () => {
  const dispatch = useAppDispatch();
  const selectedNode = useAppSelector((state) => state.process.selectedNode);
  const selectedProcess = useAppSelector((state) => state.process.selectedProcess);
  const schemas = useAppSelector((state) => state.schema?.schemaList || []);
  
  const [activeTab, setActiveTab] = useState('general');
  const [stepTabs, setStepTabs] = useState<Record<number, string>>({});
  const activeTabRef = useRef(activeTab);

  useEffect(() => {
    activeTabRef.current = activeTab;
  }, [activeTab]);

  const task = selectedProcess?.tasks?.find((t: any) => 
    t.task_key === (selectedNode?.task_key || selectedNode?.data?.task_key)
  );

  useEffect(() => {
    if (selectedNode && !task) {
      setActiveTab('general');
    }
  }, [selectedNode?.id, selectedNode?.node_id]);

  const updateTaskField = (field: string, value: any) => {
    if (!task?.task_key) return;
    dispatch(updateTask(task.task_key, { [field]: value }));
  };

  const updateNestedField = (path: string[], value: any) => {
    if (!task?.task_key) return;
    const updated = { ...task };
    let current = updated;
    for (let i = 0; i < path.length - 1; i++) {
      if (!current[path[i]]) current[path[i]] = {};
      current = current[path[i]];
    }
    current[path[path.length - 1]] = value;
    dispatch(updateTask(task.task_key, updated));
  };

  const toggleInput = (schemaName: string) => {
    const inputs = task?.inputs || [];
    const updated = inputs.includes(schemaName)
      ? inputs.filter((i: string) => i !== schemaName)
      : [...inputs, schemaName];
    updateTaskField('inputs', updated);
  };

  const toggleOutput = (schemaName: string) => {
    const outputs = task?.outputs || [];
    const updated = outputs.includes(schemaName)
      ? outputs.filter((o: string) => o !== schemaName)
      : [...outputs, schemaName];
    updateTaskField('outputs', updated);
  };

  const updateStep = (idx: number, stepData: any) => {
    const steps = [...(task?.task_steps?.execution_steps || [])];
    steps[idx] = { ...steps[idx], ...stepData };
    updateNestedField(['task_steps', 'execution_steps'], steps);
  };

  const addStep = () => {
    const steps = [...(task?.task_steps?.execution_steps || [])];
    steps.push({
      name: 'New Step',
      type: 'TOOLKIT',
      api: { method: 'POST', headers: {} },
      requestMapping: { mappingLanguage: 'JSONata', map: {} },
      responseMapping: { mappingLanguage: 'JSONata', map: {} },
      successCriteria: [],
      errorHandling: { retryConfig: { maxAttempts: 3, backoffMs: 1000, jitterMs: 100, retryOnStatusCodes: [] }, failureStrategy: 'FAIL_TASK' }
    });
    updateNestedField(['task_steps', 'execution_steps'], steps);
  };

  const deleteStep = (idx: number) => {
    const steps = [...(task?.task_steps?.execution_steps || [])];
    steps.splice(idx, 1);
    updateNestedField(['task_steps', 'execution_steps'], steps);
  };

  if (!selectedNode) {
    return (
      <div className="p-3 h-100 d-flex align-items-center justify-content-center">
        <div className="text-muted text-center">
          <i className="bi bi-info-circle" style={{ fontSize: '48px' }}></i>
          <p className="mt-3">Select a node to view properties</p>
        </div>
      </div>
    );
  }

  if (!task) {
    return (
      <div className="p-3 h-100 d-flex align-items-center justify-content-center">
        <div className="text-muted text-center">
          <p>No task configuration found for this node</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-2" style={{ overflow: 'auto', height: '100%' }}>
      <div className="card">
        <div className="card-body">
          <ul className="nav nav-tabs mb-3">
            <li className="nav-item">
              <button className={`nav-link ${activeTab === 'general' ? 'active' : ''}`} onClick={() => setActiveTab('general')}>General</button>
            </li>
            <li className="nav-item">
              <button className={`nav-link ${activeTab === 'inputs' ? 'active' : ''}`} onClick={() => setActiveTab('inputs')}>Inputs</button>
            </li>
            <li className="nav-item">
              <button className={`nav-link ${activeTab === 'outputs' ? 'active' : ''}`} onClick={() => setActiveTab('outputs')}>Outputs</button>
            </li>
            <li className="nav-item">
              <button className={`nav-link ${activeTab === 'steps' ? 'active' : ''}`} onClick={() => setActiveTab('steps')}>Task Steps</button>
            </li>
          </ul>

          {activeTab === 'general' && (
            <div>
              <div className="mb-2">
                <label className="form-label small">Name</label>
                <input type="text" className="form-control form-control-sm" value={task.name || ''} onChange={(e) => updateTaskField('name', e.target.value)} />
              </div>
              <div className="mb-2">
                <label className="form-label small">Type</label>
                <input type="text" className="form-control form-control-sm" value={task.type || ''} onChange={(e) => updateTaskField('type', e.target.value)} />
              </div>
              <div className="mb-2">
                <label className="form-label small">Department</label>
                <input type="text" className="form-control form-control-sm" value={task.department || ''} onChange={(e) => updateTaskField('department', e.target.value)} />
              </div>
              <div className="mb-2">
                <label className="form-label small">Role</label>
                <input type="text" className="form-control form-control-sm" value={task.role || ''} onChange={(e) => updateTaskField('role', e.target.value)} />
              </div>
              <div className="mb-2">
                <label className="form-label small">Description</label>
                <textarea className="form-control form-control-sm" rows={3} value={task.description || ''} onChange={(e) => updateTaskField('description', e.target.value)} />
              </div>
            </div>
          )}

          {activeTab === 'inputs' && (
            <div>
              {schemas.map((schema: any) => (
                <div key={schema.id} className="form-check mb-2">
                  <input type="checkbox" className="form-check-input" id={`input-${schema.id}`} checked={(task.inputs || []).includes(schema.name)} onChange={() => toggleInput(schema.name)} />
                  <label className="form-check-label" htmlFor={`input-${schema.id}`}>{schema.name}</label>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'outputs' && (
            <div>
              {schemas.map((schema: any) => (
                <div key={schema.id} className="form-check mb-2">
                  <input type="checkbox" className="form-check-input" id={`output-${schema.id}`} checked={(task.outputs || []).includes(schema.name)} onChange={() => toggleOutput(schema.name)} />
                  <label className="form-check-label" htmlFor={`output-${schema.id}`}>{schema.name}</label>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'steps' && (
            <div>
              <div className="mb-3">
                <label className="form-label small">Execution Mode</label>
                <select className="form-select form-select-sm" value={task.task_steps?.executionMode || 'SEQUENTIAL'} onChange={(e) => updateNestedField(['task_steps', 'executionMode'], e.target.value)}>
                  <option value="SEQUENTIAL">SEQUENTIAL</option>
                  <option value="PARALLEL">PARALLEL</option>
                </select>
              </div>
              <div className="mb-3 form-check">
                <input type="checkbox" className="form-check-input" id="failOnFirstError" checked={task.task_steps?.failOnFirstError || false} onChange={(e) => updateNestedField(['task_steps', 'failOnFirstError'], e.target.checked)} />
                <label className="form-check-label" htmlFor="failOnFirstError">Fail on First Error</label>
              </div>

              {(task.task_steps?.execution_steps || []).map((step: any, idx: number) => (
                <div key={idx} className="card mb-2">
                  <div className="card-header d-flex justify-content-between align-items-center" style={{ cursor: 'pointer' }} onClick={() => {
                    const el = document.getElementById(`step-${idx}`);
                    if (el) el.classList.toggle('show');
                  }}>
                    <span>{step.name || `Step ${idx + 1}`}</span>
                    <div>
                      <button className="btn btn-sm btn-danger" onClick={(e) => { e.stopPropagation(); deleteStep(idx); }}>Delete</button>
                    </div>
                  </div>
                  <div id={`step-${idx}`} className="collapse">
                    <div className="card-body">
                      <ul className="nav nav-pills nav-fill mb-2">
                        <li className="nav-item"><button className={`nav-link btn-sm ${(stepTabs[idx] || 'general') === 'general' ? 'active' : ''}`} onClick={() => setStepTabs({ ...stepTabs, [idx]: 'general' })}>General</button></li>
                        <li className="nav-item"><button className={`nav-link btn-sm ${stepTabs[idx] === 'api' ? 'active' : ''}`} onClick={() => setStepTabs({ ...stepTabs, [idx]: 'api' })}>API</button></li>
                        <li className="nav-item"><button className={`nav-link btn-sm ${stepTabs[idx] === 'reqMap' ? 'active' : ''}`} onClick={() => setStepTabs({ ...stepTabs, [idx]: 'reqMap' })}>Request</button></li>
                        <li className="nav-item"><button className={`nav-link btn-sm ${stepTabs[idx] === 'resMap' ? 'active' : ''}`} onClick={() => setStepTabs({ ...stepTabs, [idx]: 'resMap' })}>Response</button></li>
                        <li className="nav-item"><button className={`nav-link btn-sm ${stepTabs[idx] === 'success' ? 'active' : ''}`} onClick={() => setStepTabs({ ...stepTabs, [idx]: 'success' })}>Success</button></li>
                        <li className="nav-item"><button className={`nav-link btn-sm ${stepTabs[idx] === 'error' ? 'active' : ''}`} onClick={() => setStepTabs({ ...stepTabs, [idx]: 'error' })}>Error</button></li>
                      </ul>

                      {(stepTabs[idx] || 'general') === 'general' && (
                        <div>
                          <div className="mb-2"><label className="form-label small">Name</label><input type="text" className="form-control form-control-sm" value={step.name || ''} onChange={(e) => updateStep(idx, { name: e.target.value })} /></div>
                          <div className="mb-2"><label className="form-label small">Type</label><input type="text" className="form-control form-control-sm" value={step.type || ''} onChange={(e) => updateStep(idx, { type: e.target.value })} /></div>
                          <div className="mb-2"><label className="form-label small">Toolkit Name</label><input type="text" className="form-control form-control-sm" value={step.toolkitName || ''} onChange={(e) => updateStep(idx, { toolkitName: e.target.value })} /></div>
                          <div className="mb-2"><label className="form-label small">Toolkit ID</label><input type="text" className="form-control form-control-sm" value={step.toolkitId || ''} onChange={(e) => updateStep(idx, { toolkitId: e.target.value })} /></div>
                          <div className="mb-2"><label className="form-label small">Ruleset Name</label><input type="text" className="form-control form-control-sm" value={step.rulesetName || ''} onChange={(e) => updateStep(idx, { rulesetName: e.target.value })} /></div>
                          <div className="mb-2"><label className="form-label small">Ruleset ID</label><input type="text" className="form-control form-control-sm" value={step.rulesetId || ''} onChange={(e) => updateStep(idx, { rulesetId: e.target.value })} /></div>
                        </div>
                      )}

                      {stepTabs[idx] === 'api' && (
                        <div>
                          <div className="mb-2"><label className="form-label small">Base URL</label><input type="text" className="form-control form-control-sm" value={step.api?.baseUrl || ''} onChange={(e) => updateStep(idx, { api: { ...step.api, baseUrl: e.target.value } })} /></div>
                          <div className="mb-2"><label className="form-label small">Endpoint</label><input type="text" className="form-control form-control-sm" value={step.api?.endpoint || ''} onChange={(e) => updateStep(idx, { api: { ...step.api, endpoint: e.target.value } })} /></div>
                          <div className="mb-2"><label className="form-label small">Method</label><select className="form-select form-select-sm" value={step.api?.method || 'POST'} onChange={(e) => updateStep(idx, { api: { ...step.api, method: e.target.value } })}><option>GET</option><option>POST</option><option>PUT</option><option>DELETE</option></select></div>
                          <div className="mb-2"><label className="form-label small">Timeout (ms)</label><input type="number" className="form-control form-control-sm" value={step.api?.timeoutMs || ''} onChange={(e) => updateStep(idx, { api: { ...step.api, timeoutMs: parseInt(e.target.value) } })} /></div>
                          <label className="form-label small">Headers</label>
                          {Object.entries(step.api?.headers || {}).map(([k, v]: any, i: number) => (
                            <div key={i} className="input-group input-group-sm mb-1">
                              <input type="text" className="form-control" value={k} onChange={(e) => {
                                const h = { ...step.api?.headers };
                                delete h[k];
                                h[e.target.value] = v;
                                updateStep(idx, { api: { ...step.api, headers: h } });
                              }} />
                              <input type="text" className="form-control" value={v} onChange={(e) => updateStep(idx, { api: { ...step.api, headers: { ...step.api?.headers, [k]: e.target.value } } })} />
                              <button className="btn btn-outline-danger" onClick={() => {
                                const h = { ...step.api?.headers };
                                delete h[k];
                                updateStep(idx, { api: { ...step.api, headers: h } });
                              }}>×</button>
                            </div>
                          ))}
                          <button className="btn btn-sm btn-outline-primary" onClick={() => updateStep(idx, { api: { ...step.api, headers: { ...step.api?.headers, '': '' } } })}>+ Add Header</button>
                        </div>
                      )}

                      {stepTabs[idx] === 'reqMap' && (
                        <div>
                          <div className="mb-2"><label className="form-label small">Mapping Language</label><select className="form-select form-select-sm" value={step.requestMapping?.mappingLanguage || 'JSONata'} onChange={(e) => updateStep(idx, { requestMapping: { ...step.requestMapping, mappingLanguage: e.target.value } })}><option>JSONata</option></select></div>
                          <div className="mb-2"><label className="form-label small">Map</label><textarea className="form-control form-control-sm" rows={5} value={JSON.stringify(step.requestMapping?.map || {}, null, 2)} onChange={(e) => { try { updateStep(idx, { requestMapping: { ...step.requestMapping, map: JSON.parse(e.target.value) } }); } catch {} }} /></div>
                        </div>
                      )}

                      {stepTabs[idx] === 'resMap' && (
                        <div>
                          <div className="mb-2"><label className="form-label small">Mapping Language</label><select className="form-select form-select-sm" value={step.responseMapping?.mappingLanguage || 'JSONata'} onChange={(e) => updateStep(idx, { responseMapping: { ...step.responseMapping, mappingLanguage: e.target.value } })}><option>JSONata</option></select></div>
                          <div className="mb-2"><label className="form-label small">Save As</label><input type="text" className="form-control form-control-sm" value={step.responseMapping?.saveAs || ''} onChange={(e) => updateStep(idx, { responseMapping: { ...step.responseMapping, saveAs: e.target.value } })} /></div>
                          <div className="mb-2"><label className="form-label small">$schemaRef</label><input type="text" className="form-control form-control-sm" value={step.responseMapping?.$schemaRef || ''} onChange={(e) => updateStep(idx, { responseMapping: { ...step.responseMapping, $schemaRef: e.target.value } })} /></div>
                          <div className="mb-2"><label className="form-label small">Map</label><textarea className="form-control form-control-sm" rows={5} value={JSON.stringify(step.responseMapping?.map || {}, null, 2)} onChange={(e) => { try { updateStep(idx, { responseMapping: { ...step.responseMapping, map: JSON.parse(e.target.value) } }); } catch {} }} /></div>
                        </div>
                      )}

                      {stepTabs[idx] === 'success' && (
                        <div>
                          {(step.successCriteria || []).map((c: any, i: number) => (
                            <div key={i} className="card mb-2 p-2">
                              <div className="mb-1"><input type="text" className="form-control form-control-sm" placeholder="Expression" value={c.expression || ''} onChange={(e) => {
                                const sc = [...step.successCriteria];
                                sc[i] = { ...sc[i], expression: e.target.value };
                                updateStep(idx, { successCriteria: sc });
                              }} /></div>
                              <div className="mb-1"><select className="form-select form-select-sm" value={c.severity || 'ERROR'} onChange={(e) => {
                                const sc = [...step.successCriteria];
                                sc[i] = { ...sc[i], severity: e.target.value };
                                updateStep(idx, { successCriteria: sc });
                              }}><option>ERROR</option><option>WARNING</option></select></div>
                              <div className="mb-1"><input type="text" className="form-control form-control-sm" placeholder="Message" value={c.message || ''} onChange={(e) => {
                                const sc = [...step.successCriteria];
                                sc[i] = { ...sc[i], message: e.target.value };
                                updateStep(idx, { successCriteria: sc });
                              }} /></div>
                              <button className="btn btn-sm btn-danger" onClick={() => {
                                const sc = [...step.successCriteria];
                                sc.splice(i, 1);
                                updateStep(idx, { successCriteria: sc });
                              }}>Delete</button>
                            </div>
                          ))}
                          <button className="btn btn-sm btn-outline-primary" onClick={() => updateStep(idx, { successCriteria: [...(step.successCriteria || []), { expression: '', severity: 'ERROR', message: '' }] })}>+ Add Criteria</button>
                        </div>
                      )}

                      {stepTabs[idx] === 'error' && (
                        <div>
                          <div className="mb-2"><label className="form-label small">Max Attempts</label><input type="number" className="form-control form-control-sm" value={step.errorHandling?.retryConfig?.maxAttempts || ''} onChange={(e) => updateStep(idx, { errorHandling: { ...step.errorHandling, retryConfig: { ...step.errorHandling?.retryConfig, maxAttempts: parseInt(e.target.value) } } })} /></div>
                          <div className="mb-2"><label className="form-label small">Backoff (ms)</label><input type="number" className="form-control form-control-sm" value={step.errorHandling?.retryConfig?.backoffMs || ''} onChange={(e) => updateStep(idx, { errorHandling: { ...step.errorHandling, retryConfig: { ...step.errorHandling?.retryConfig, backoffMs: parseInt(e.target.value) } } })} /></div>
                          <div className="mb-2"><label className="form-label small">Jitter (ms)</label><input type="number" className="form-control form-control-sm" value={step.errorHandling?.retryConfig?.jitterMs || ''} onChange={(e) => updateStep(idx, { errorHandling: { ...step.errorHandling, retryConfig: { ...step.errorHandling?.retryConfig, jitterMs: parseInt(e.target.value) } } })} /></div>
                          <div className="mb-2"><label className="form-label small">Retry On Status Codes (comma-separated)</label><input type="text" className="form-control form-control-sm" value={(step.errorHandling?.retryConfig?.retryOnStatusCodes || []).join(',')} onChange={(e) => updateStep(idx, { errorHandling: { ...step.errorHandling, retryConfig: { ...step.errorHandling?.retryConfig, retryOnStatusCodes: e.target.value.split(',').map((s: string) => parseInt(s.trim())).filter((n: number) => !isNaN(n)) } } })} /></div>
                          <div className="mb-2"><label className="form-label small">Failure Strategy</label><select className="form-select form-select-sm" value={step.errorHandling?.failureStrategy || 'FAIL_TASK'} onChange={(e) => updateStep(idx, { errorHandling: { ...step.errorHandling, failureStrategy: e.target.value } })}><option>FAIL_TASK</option><option>FAIL_STEP</option><option>CONTINUE</option></select></div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              <button className="btn btn-sm btn-primary" onClick={addStep}>+ Add Step</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProcessGroup6;
