import { useState, useEffect, useMemo } from "react";
import { Tree } from "react-arborist";
import { useAppSelector, useAppDispatch } from "../../store/hooks";
import {
  addProcess,
  setSelectedProcess,
} from "../../redux/process/processActions";
import { addNodeToProcessGroup } from "../../redux/processGroup/processGroupActions";
import type { Process } from "../../redux/process/processTypes";
import CreateProcessModal from "./CreateProcessModal";
import "./LeftSideBar.css";

interface TreeNode {
  id: string;
  name: string;
  children?: TreeNode[];
  isRoot?: boolean;
  processData?: Process;
}

/* =========================
   COMPONENT
========================= */

const LeftSideBar = ({
  processGroups,
  processes,
  onProcessSelect,
  onDeleteProcess,
}: any) => {
  const dispatch = useAppDispatch();
  const [selectedProcessGroup, setSelectedProcessGroup] = useState<string>("");
  const [selectedStatusFilter, setSelectedStatusFilter] =
    useState<string>("All");
  const [isModalOpen, setIsModalOpen] = useState(false);

  /* =========================
     DEFAULT SELECT GROUP
  ========================= */

  useEffect(() => {
    if (processGroups.length > 0 && !selectedProcessGroup) {
      setSelectedProcessGroup(processGroups[0].process_group_id);
    }
  }, [processGroups, selectedProcessGroup]);

  /* =========================
     PROCESS LOOKUP MAP (O1)
  ========================= */

  const processMap = useMemo(() => {
    const map: Record<string, Process> = {};
    processes.forEach((p: any) => {
      map[p.process_key] = p;
    });
    return map;
  }, [processes]);

  /* =========================
     RESOLVE PROCESSES FROM NODES
  ========================= */
  function truncateString(str: any, maxLength: any) {
    if (str.length > maxLength) {
      return str.slice(0, maxLength) + "...";
    } else {
      return str;
    }
  }

  const resolvedProcesses = useMemo(() => {
    if (!selectedProcessGroup) return [];

    const selectedGroup = processGroups.find(
      (pg: any) => pg.process_group_id === selectedProcessGroup
    );

    if (!selectedGroup) return [];

    return selectedGroup.nodes
      .map((node: any) => processMap[node.process_key])
      .filter((process: any): process is Process => {
        if (!process) return false;

        if (selectedStatusFilter === "All") return true;

        return (
          process.status.toLowerCase() === selectedStatusFilter.toLowerCase()
        );
      });
  }, [selectedProcessGroup, processGroups, processMap, selectedStatusFilter]);

  /* =========================
     TREE DATA
  ========================= */

  const treeData = useMemo<TreeNode[]>(() => {
    if (!selectedProcessGroup) return [];

    const selectedGroup = processGroups.find(
      (pg: any) => pg.process_group_id === selectedProcessGroup
    );

    if (!selectedGroup) return [];

    const rootNode: TreeNode = {
      id: selectedProcessGroup,
      name: selectedGroup.name,
      isRoot: true,
      children: resolvedProcesses.map((p: any) => ({
        id: p.process_id,
        name: p.name,
        processData: p,
      })),
    };

    return [rootNode];
  }, [selectedProcessGroup, processGroups, resolvedProcesses]);

  /* =========================
     HANDLERS
  ========================= */

  const handleCreateProcess = (
    processData: Process,
    processGroupId: string,
    templateId?: string
  ) => {
    dispatch(addProcess(processData));

    const node = {
      node_id: processData.process_id,
      process_key: processData.process_key,
      planned: { expectedDurationMinutes: 0 },
      actual: {},
      kpi_contributions: [],
    };

    dispatch(addNodeToProcessGroup(processGroupId, node));
    dispatch(setSelectedProcess(processData));
    onProcessSelect(processData);
    setIsModalOpen(false);
  };

  /* =========================
     TREE NODE RENDER
  ========================= */

  const Node = ({
    node,
    style,
    dragHandle,
  }: {
    node: any;
    style: React.CSSProperties;
    dragHandle: (el: HTMLDivElement | null) => void;
  }) => {
    const isArchived = node.data.processData?.status === "archived";

    return (
      <div
        ref={dragHandle}
        style={style}
        className={`treeNode ${isArchived ? "archived" : ""}`}
        onClick={() => {
          if (node.data.processData) {
            onProcessSelect(node.data.processData);
          }
        }}
      >
        <div className="nodeContent">
          <span className="nodeIcon">{node.data.isRoot ? "📁" : "📄"}</span>
          <span className={`nodeName ${node.data.isRoot ? "rootNode" : ""}`}>
            {truncateString(node.data.name, 20)}
          </span>
        </div>

        {node.data.processData && (
          <span
            className="deleteIcon"
            onClick={(e) => {
              e.stopPropagation();
              onDeleteProcess(node.data.processData.process_id);
            }}
          >
            🗑️
          </span>
        )}
      </div>
    );
  };

  /* =========================
     RENDER
  ========================= */

  return (
    <div className="leftSideBar">
      {/* Add Process Button */}
      <div style={{ padding: "10px", borderBottom: "1px solid #eee" }}>
        <button
          onClick={() => setIsModalOpen(true)}
          style={{
            width: "100%",
            padding: "8px",
            backgroundColor: "#28a745",
            color: "white",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "5px",
          }}
        >
          <span style={{ fontSize: "16px" }}>+</span>
          New Process
        </button>
      </div>

      {/* Process Group Dropdown */}
      <div className="dropdownSection">
        <div className="dropdownLabel">Process Group</div>
        <select
          className="dropdown"
          value={selectedProcessGroup}
          onChange={(e) => setSelectedProcessGroup(e.target.value)}
        >
          {processGroups.map((pg: any) => (
            <option key={pg.process_group_id} value={pg.process_group_id}>
              {pg.name}
            </option>
          ))}
        </select>
      </div>

      {/* Status Filter */}
      <div className="dropdownSection">
        <div className="dropdownLabel">Status Filter</div>
        <select
          className="dropdown"
          value={selectedStatusFilter}
          onChange={(e) => setSelectedStatusFilter(e.target.value)}
        >
          <option value="All">All</option>
          <option value="active">Active</option>
          <option value="archived">Archived</option>
        </select>
      </div>

      {/* Tree */}
      <div className="treeContainer">
        {resolvedProcesses.length === 0 ? (
          <div className="emptyMessage">No processes available</div>
        ) : (
          <Tree
            data={treeData}
            openByDefault
            width="100%"
            height={500}
            indent={24}
            rowHeight={50}
          >
            {Node}
          </Tree>
        )}
      </div>

      <CreateProcessModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleCreateProcess}
      />
    </div>
  );
};

export default LeftSideBar;
