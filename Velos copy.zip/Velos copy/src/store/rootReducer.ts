import { combineReducers } from "redux";
import loginReducer from "../redux/login/loginReducer";
import processGroupReducer from "../redux/processGroup/processGroupReducer";
import processReducer from "../redux/process/processReducer";
import domainReducer from "../redux/domain/domainReducer";
import schemaReducer from "../redux/schema/schemaReducer";
import templateReducer from "../redux/template/templateReducer";
import businessRulesReducer from "./businessRules/businessRulesReducer";
import operatorReducer from "../features/evtolOperator/store/operatorReducer";
import vertiportReducer from "../features/vertiport/store/vertiportReducer";
import userReducer from "../features/users/store/userReducer";
import clusterReducer from "../redux/cluster/clusterReducer";
import regionReducer from "../redux/region/regionReducer";
import authorizedZonesReducer from "../redux/authorizedZones/authorizedZonesReducer";
import demandZonesReducer from "../redux/demandZones/demandZonesReducer";
import loginUsersReducer from "../features/loginUsers/store/loginUsersReducer";

const rootReducer = combineReducers({
  login: loginReducer,
  processGroup: processGroupReducer,
  process: processReducer,
  domain: domainReducer,
  schema: schemaReducer,
  template: templateReducer,
  businessRules: businessRulesReducer,
  operator: operatorReducer,
  vertiport: vertiportReducer,
  users: userReducer,
  cluster: clusterReducer,
  region: regionReducer,
  authorizedZones: authorizedZonesReducer,
  demandZones: demandZonesReducer,
  loginUsers: loginUsersReducer,
});

type RootState = ReturnType<typeof rootReducer>;

export type { RootState };
export default rootReducer;
