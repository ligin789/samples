import type { UserRole } from '../features/loginUsers/store/loginUsersTypes';
import { roleMenuConfig, menuStructure } from '../config/roleMenuConfig';

export const canAccessPage = (role: UserRole, path: string): boolean => {
  const allowedMenus = roleMenuConfig[role] || [];
  
  // Allow access to default/home routes
  const defaultRoutes = [
    '/admin/home',
    '/admin/dashboard', 
    '/admin/notifications',
    '/evtol/dashboard',
    '/evtol/analytics',
    '/ground/operations',
    '/booking/reservations',
    '/support/customers'
  ];
  
  if (defaultRoutes.includes(path)) {
    return true;
  }
  
  // Check if any of the allowed menus contain this path
  for (const menuKey of allowedMenus) {
    const menu = menuStructure[menuKey];
    if (menu && menu.submenu.some(item => item.path === path)) {
      return true;
    }
  }
  
  return false;
};

export const getDefaultRouteForRole = (role: UserRole): string => {
  const roleRoutes: Record<UserRole, string> = {
    PLATFORM_ADMIN: '/admin/home',
    OPERATOR_ADMIN: '/evtol/dashboard',
    FLEET_MANAGER: '/evtol/dashboard',
    VERTIPORT_MANAGER: '/evtol/dashboard',
    AIRSPACE_MANAGER: '/evtol/dashboard',
    GROUND_HANDLER_ADMIN: '/ground/operations',
    GROUND_HANDLER_USER: '/ground/operations',
    BOOKING_PARTNER_ADMIN: '/booking/reservations',
    BOOKING_PARTNER_USER: '/booking/reservations',
    GUEST_PARTNER_ADMIN: '/support/customers',
    GUEST_USER: '/support/customers',
    OPS_FLEET_MANAGER: '/evtol/dashboard',
    CREW_MANAGER: '/evtol/dashboard',
    SAFETY_OFFICER: '/evtol/dashboard',
  };
  
  return roleRoutes[role] || '/admin/home';
};

export const getCurrentUserRole = (loginUsers: any[], userEmail: string): UserRole | null => {
  const loginUser = loginUsers.find(
    lu => lu.officialEmail.toLowerCase() === userEmail.toLowerCase()
  );
  return loginUser?.role || null;
};

export const getOperatorName = (loginUsers: any[], userEmail: string, operators: any[]): string | null => {
  const loginUser = loginUsers.find(
    lu => lu.officialEmail.toLowerCase() === userEmail.toLowerCase()
  );
  
  if (loginUser?.whichTenant) {
    const operator = operators.find(op => op.operatorCode === loginUser.whichTenant);
    return operator?.tradingName || operator?.legalName || null;
  }
  
  return null;
};