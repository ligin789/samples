import { useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { fetchLoginUsersThunk } from '../../features/loginUsers/store/loginUsersThunks';

const LoginUserDashboard = () => {
  const dispatch = useAppDispatch();
  const { loginUsers, loading } = useAppSelector((state) => state.loginUsers);

  useEffect(() => {
    dispatch(fetchLoginUsersThunk() as any);
  }, [dispatch]);

  return (
    <div className="container-fluid p-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Login Users</h2>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : loginUsers.length === 0 ? (
        <div className="text-center py-5">
          <h4 className="text-muted">No login users found</h4>
        </div>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Official Email</th>
                <th>Mobile Number</th>
                <th>Role</th>
                <th>Which Tenant</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Updated By</th>
              </tr>
            </thead>
            <tbody>
              {loginUsers.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.officialEmail}</td>
                  <td>{user.mobileNumber}</td>
                  <td>{user.role}</td>
                  <td>{user.whichTenant || '-'}</td>
                  <td>
                    <span className={`badge ${user.status === 'ACTIVE' ? 'bg-success' : 'bg-secondary'}`}>
                      {user.status}
                    </span>
                  </td>
                  <td>{new Date(user.createdAt).toLocaleString()}</td>
                  <td>{new Date(user.updatedAt).toLocaleString()}</td>
                  <td>{user.updatedBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default LoginUserDashboard;
