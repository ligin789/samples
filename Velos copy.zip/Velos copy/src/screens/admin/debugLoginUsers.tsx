import { useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { fetchLoginUsersThunk } from '../../features/loginUsers/store/loginUsersThunks';

const DebugLoginUsers = () => {
  const dispatch = useAppDispatch();
  const { loginUsers, loading, error } = useAppSelector((state) => state.loginUsers);

  useEffect(() => {
    console.log('DebugLoginUsers mounted');
    console.log('Current loginUsers state:', loginUsers);
    dispatch(fetchLoginUsersThunk() as any);
  }, [dispatch]);

  useEffect(() => {
    console.log('loginUsers updated:', loginUsers);
  }, [loginUsers]);

  return (
    <div className="container-fluid p-4">
      <h2>Debug Login Users</h2>
      <div className="card p-3">
        <h4>Redux State:</h4>
        <pre>{JSON.stringify({ loginUsers, loading, error }, null, 2)}</pre>
        
        <h4 className="mt-3">LocalStorage:</h4>
        <pre>{localStorage.getItem('loginUsers')}</pre>
        
        <button 
          className="btn btn-primary mt-3"
          onClick={() => {
            const users = [{
              id: 'USR-001',
              name: 'Platform Admin',
              officialEmail: 'platformadmin@aam.com',
              mobileNumber: '9999999999',
              role: 'PLATFORM_ADMIN',
              whichTenant: null,
              status: 'ACTIVE',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
              updatedBy: 'SYSTEM',
            }];
            localStorage.setItem('loginUsers', JSON.stringify(users));
            window.location.reload();
          }}
        >
          Force Initialize Platform Admin
        </button>
      </div>
    </div>
  );
};

export default DebugLoginUsers;
