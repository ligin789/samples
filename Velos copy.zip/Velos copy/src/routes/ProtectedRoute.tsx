import { Navigate, useLocation } from 'react-router-dom';
import { useAppSelector } from '../store/hooks';
import { getCurrentUserRole, canAccessPage, getDefaultRouteForRole } from '../utils/roleAccess';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: string;
}

const ProtectedRoute = ({ children, requiredRole }: ProtectedRouteProps) => {
  const { user } = useAppSelector((state) => state.login);
  const { loginUsers } = useAppSelector((state) => state.loginUsers);
  const location = useLocation();

  // If no user is logged in, redirect to login
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Get current user role
  const currentRole = getCurrentUserRole(loginUsers, user.name);
  
  if (!currentRole) {
    return <Navigate to="/login" replace />;
  }

  // If a specific role is required, check it
  if (requiredRole && currentRole !== requiredRole) {
    const defaultRoute = getDefaultRouteForRole(currentRole);
    return <Navigate to={defaultRoute} replace />;
  }

  // Check if user can access current page
  if (!canAccessPage(currentRole, location.pathname)) {
    const defaultRoute = getDefaultRouteForRole(currentRole);
    return <Navigate to={defaultRoute} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;