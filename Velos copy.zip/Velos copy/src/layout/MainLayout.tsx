import { Outlet, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Header from '../components/Header';
import SecondaryHeader from '../components/layout/SecondaryHeader';
import { getSubmenuForRoute } from '../config/menuSubmenus';

const MainLayout = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<string>('');
  const [hasSubmenu, setHasSubmenu] = useState(false);

  useEffect(() => {
    const submenuItems = getSubmenuForRoute(location.pathname);

    if (submenuItems && submenuItems.length > 0) {
      setActiveTab(submenuItems[0].id);
      setHasSubmenu(true);
    } else {
      setHasSubmenu(false);
    }
  }, [location.pathname]);

  return (
    <div>
      <div
        style={{
          height: hasSubmenu ? '12.5vh' : '7vh',
          background: 'linear-gradient(135deg, #1e3a5f 0%, #2d5a8c 100%)',
        }}
      >
        <Header />
        {hasSubmenu && (
          <SecondaryHeader activeTab={activeTab} onTabChange={setActiveTab} />
        )}
      </div>

      <main style={{ height: hasSubmenu ? '87vh' : '93vh' }}>
        <Outlet context={{ activeTab }} />
      </main>
    </div>
  );
};

export default MainLayout;