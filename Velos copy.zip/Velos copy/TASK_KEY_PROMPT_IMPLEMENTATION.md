# Task Key Prompt Implementation

## Overview
When users drag and drop task nodes (SERVICE_TASK, MANUAL_TASK, TASK) from the palette, they are now prompted to enter a unique task_key before the node and corresponding task configuration are created.

## Changes Made

### 1. Redux Actions (`/src/redux/process/processActions.ts`)
Added new action:
```typescript
export const addTask = (task: any) => ({
  type: 'ADD_TASK',
  payload: task
});
```

### 2. Redux Reducer (`/src/redux/process/processReducer.ts`)
Added new case to handle task creation:
```typescript
case 'ADD_TASK': {
  if (!state.selectedProcess) return state;
  
  const updatedProcess = {
    ...state.selectedProcess,
    tasks: [...(state.selectedProcess.tasks || []), action.payload]
  };
  
  return {
    ...state,
    selectedProcess: updatedProcess,
    process: state.process.map((p: any) =>
      p.process_id === state.selectedProcess.process_id ? updatedProcess : p
    )
  };
}
```

### 3. MainCanvas Component (`/src/components/processGroup/MainCanvas.tsx`)

#### Added State for Modal
```typescript
const [showTaskKeyModal, setShowTaskKeyModal] = useState(false);
const [taskKeyInput, setTaskKeyInput] = useState('');
const [taskKeyError, setTaskKeyError] = useState('');
const pendingNodeRef = useRef<{ businessType: string; position: { x: number; y: number } } | null>(null);
```

#### Modified `onDrop` Handler
- Detects if dropped node is a task type (SERVICE_TASK, MANUAL_TASK, TASK)
- If task type: shows modal to collect task_key
- If non-task type (ENTRY, EXIT, GATEWAY): creates node directly as before

#### Added Task Key Validation
```typescript
const handleTaskKeySubmit = useCallback(() => {
  const taskKey = taskKeyInput.trim().toUpperCase();
  
  // Validation rules:
  // 1. Required
  if (!taskKey) {
    setTaskKeyError('Task key is required');
    return;
  }
  
  // 2. No spaces
  if (taskKey.includes(' ')) {
    setTaskKeyError('Task key cannot contain spaces');
    return;
  }
  
  // 3. Must be unique
  const exists = selectedProcess?.tasks?.some((t: any) => t.task_key === taskKey);
  if (exists) {
    setTaskKeyError('Task key already exists');
    return;
  }
  
  // Create both node and task...
}, [taskKeyInput, selectedProcess, edges, syncFlowToStore, dispatch]);
```

#### Task and Node Creation
When valid task_key is provided:

1. **Creates React Flow Node:**
```typescript
const newNode: Node = {
  id: newNodeId,
  type: nodeType,
  position,
  data: { label: taskKey, businessType, task_key: taskKey },
  style,
};
```

2. **Creates Task Configuration:**
```typescript
const newTask = {
  task_id: taskId,
  task_key: taskKey,
  name: '',
  type: businessType.toLowerCase(),
  department: '',
  role: '',
  description: '',
  inputs: [],
  outputs: [],
  task_steps: {
    executionMode: 'SEQUENTIAL',
    failOnFirstError: true,
    execution_steps: []
  }
};
```

3. **Dispatches both updates:**
```typescript
dispatch(addTask(newTask));
setNodes((nds) => {
  const updated = nds.concat(newNode);
  syncFlowToStore(updated, edges);
  return updated;
});
```

#### Added Modal UI
Simple modal overlay with:
- Input field for task_key
- Validation error display
- Cancel and Create buttons
- Enter key support for quick submission

## User Flow

1. User drags SERVICE_TASK, MANUAL_TASK, or TASK from palette
2. User drops node on canvas
3. Modal appears asking for task_key
4. User enters task_key (e.g., "VALIDATE_BOOKING_REQUEST")
5. System validates:
   - Not empty
   - No spaces
   - Unique within tasks array
6. If valid:
   - Creates node in processFlow with task_key in data
   - Creates task in tasks array with matching task_key
   - Modal closes
7. If invalid:
   - Shows error message
   - User can correct or cancel

## Backward Compatibility

- Existing nodes and tasks are NOT affected
- Node click behavior unchanged
- ProcessGroup6.tsx editing unchanged
- Only affects NEW node creation for task types
- ENTRY, EXIT, and GATEWAY nodes still created directly without prompt

## Result

✅ Task nodes require task_key before creation
✅ Both processFlow node and tasks array entry created together
✅ task_key links node to task configuration
✅ Clicking node resolves correct task via task_key
✅ ProcessGroup6.tsx can immediately edit the new task
✅ Validation prevents duplicates and invalid keys
✅ Existing workflows continue to function normally
