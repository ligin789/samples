# Login Users - Troubleshooting Guide

## Issue
- Login users table showing empty
- Login with platformadmin@aam.com failing

## Root Cause
Redux-persist may be interfering with initial state or the store isn't properly initialized.

## Quick Fix Steps

### Step 1: Clear Browser Storage
1. Open browser DevTools (F12)
2. Go to Application/Storage tab
3. Clear all localStorage items
4. Refresh the page

### Step 2: Use Debug Page
1. Navigate to: `/admin/administration/debug-login-users`
2. Check the Redux state and localStorage
3. Click "Force Initialize Platform Admin" button if needed
4. This will manually create the Platform Admin user

### Step 3: Verify Login
1. Go to `/login`
2. Enter: `platformadmin@aam.com`
3. Should now work

### Step 4: Check Console
Open browser console and look for:
- "Login failed. Available users:" - shows what users are in the store
- "Attempted email:" - shows what email you tried

## Manual Initialization (if needed)

Open browser console and run:
```javascript
const users = [{
  id: 'USR-001',
  name: 'Platform Admin',
  officialEmail: 'platformadmin@aam.com',
  mobileNumber: '9999999999',
  role: 'PLATFORM_ADMIN',
  whichTenant: null,
  status: 'ACTIVE',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  updatedBy: 'SYSTEM',
}];

// For redux-persist
localStorage.setItem('persist:root', JSON.stringify({
  ...JSON.parse(localStorage.getItem('persist:root') || '{}'),
  loginUsers: JSON.stringify({ loginUsers: users, loading: false, error: null })
}));

window.location.reload();
```

## What Changed
1. Added loginUsers to redux-persist whitelist
2. Reducer now handles REHYDRATE action from redux-persist
3. Initial state always includes Platform Admin user
4. Login component fetches users on mount
5. Added debug logging to help diagnose issues

## Test After Fix
1. Login with: `platformadmin@aam.com`
2. View users at: `/admin/administration/login-users`
3. Create an operator - should auto-create operator admin login
4. Verify operator admin appears in login users table
