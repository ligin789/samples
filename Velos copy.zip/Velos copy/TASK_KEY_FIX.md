# Task Key Preservation Fix

## Problem
When loading workflow JSON into React Flow, the `task_key` field was being lost during node transformation. This caused the editor to fail when clicking on nodes because it couldn't resolve the correct task from the `tasks[]` array.

## Root Cause
The bug occurred in three places in `MainCanvas.tsx`:

1. **Line 109-119 (Normalization)**: When normalizing nodes from workflow JSON, only specific fields (`id`, `name`, `type`, `next`, `position`) were extracted, dropping `task_key` and other custom fields.

2. **Line 193-207 (React Flow Mapping)**: When creating React Flow nodes, only `label` and `businessType` were stored in the `data` object, not `task_key`.

3. **Line 327-333 (Sync to Redux)**: When syncing back to Redux store, only basic fields were saved, again missing `task_key`.

## Solution

### 1. Updated Node Normalization (Line 109-119)
Changed from extracting only specific fields to preserving all original node properties:

```typescript
// BEFORE: Only extracted specific fields
return { id, name, type, next, position };

// AFTER: Preserve all original properties using spread operator
return { ...n, id, name, type, next, position };
```

### 2. Updated React Flow Node Data (Line 207)
Added `task_key` to the React Flow node's `data` object:

```typescript
// BEFORE
data: { label: n.name, businessType: n.type }

// AFTER
data: { label: n.name, businessType: n.type, task_key: n.task_key }
```

### 3. Updated Sync to Redux (Line 327-345)
Modified to preserve original node properties and include `task_key`:

```typescript
// BEFORE: Created new object with only basic fields
const rawNodes: RawNode[] = updatedNodes.map((n) => ({
  node_id: n.id,
  id: n.id,
  name: String(n.data?.label || n.id),
  type: n.data?.businessType || "TASK",
  position: { x: n.position.x, y: n.position.y },
}));

// AFTER: Preserve original node and merge updates
const rawNodes: RawNode[] = updatedNodes.map((n) => {
  const originalNode = selectedProcess.processFlow?.nodes?.find(
    (orig: any) => orig.node_id === n.id || orig.id === n.id
  );
  return {
    ...originalNode,
    node_id: n.id,
    id: n.id,
    name: String(n.data?.label || n.id),
    type: n.data?.businessType || "TASK",
    position: { x: n.position.x, y: n.position.y },
    task_key: n.data?.task_key,
  };
});
```

### 4. Updated Type Definition
Added `task_key` and index signature to `RawNode` type:

```typescript
type RawNode = {
  node_id?: string;
  id?: string | number;
  name?: string;
  label?: string;
  type?: string;
  next?: Array<string | number>;
  position?: { x: number; y: number };
  task_key?: string;
  [key: string]: any; // Allow other properties
};
```

### 5. Updated ProcessGroup6.tsx
Made the component read `task_key` from both direct property and `data` object for compatibility:

```typescript
// BEFORE
value={localNode.task_key || ''}

// AFTER
value={localNode.task_key || localNode.data?.task_key || ''}
```

## Result
- ✅ `task_key` is now preserved when loading workflow JSON
- ✅ React Flow nodes include `data.task_key`
- ✅ Clicking a node correctly resolves the task from `tasks[]`
- ✅ ProcessGroup6.tsx can edit the correct task object
- ✅ All other custom node properties are also preserved

## Files Modified
1. `/src/components/processGroup/MainCanvas.tsx` - Fixed node transformation logic
2. `/src/components/processGroup/ProcessGroup6.tsx` - Updated to read task_key from data object
